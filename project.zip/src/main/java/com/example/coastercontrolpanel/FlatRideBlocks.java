package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * The blocks of the Enterprise, Breakdance and Wave Swinger rides. A Ride Part belongs to one moving structure of the ride
 * (its number) and only sticks to parts with the same number; number 15 is the fixed frame that never moves.
 */
public final class FlatRideBlocks {
    /** The number of the part that never moves. */
    public static final int FIXED = 15;

    private FlatRideBlocks() {
    }

    public static class PartBlock extends Block {
        public static final IntegerProperty INDEX = IntegerProperty.create("index", 0, 15);

        public PartBlock(Properties properties) {
            super(properties);
            registerDefaultState(stateDefinition.any().setValue(INDEX, 0));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(INDEX);
        }
    }

    /** The control block: right-click to start or stop the ride. */
    public static class BaseBlock extends BaseEntityBlock {
        public static final MapCodec<BaseBlock> CODEC = simpleCodec(BaseBlock::new);

        public BaseBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new FlatRideBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return createTickerHelper(type, CoasterControlPanel.FLAT_RIDE_BE.get(), (l, p, s, be) -> {
                if (l.isClientSide) {
                    be.clientTick();
                } else {
                    be.serverTick();
                }
            });
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openFlatRide(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof FlatRideBlockEntity be) {
                be.redstone(level.getBestNeighborSignal(pos) > 0);
            }
        }
    }
}
