package com.example.coastercontrolpanel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client: the current breakdown of the coaster a Control Panel belongs to (active = false when there is none). */
public record BreakdownStatePacket(boolean active, String coaster, int type, int sev, int element, boolean autoAvail, int autoLeft,
                                   boolean repairing, int repairLeft, boolean ready, int repairTotal) implements CustomPacketPayload {
    public static final Type<BreakdownStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "breakdown_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BreakdownStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBoolean(p.active);
                buf.writeUtf(p.coaster, 64);
                buf.writeVarInt(p.type);
                buf.writeVarInt(p.sev);
                buf.writeVarInt(p.element);
                buf.writeBoolean(p.autoAvail);
                buf.writeVarInt(p.autoLeft);
                buf.writeBoolean(p.repairing);
                buf.writeVarInt(p.repairLeft);
                buf.writeBoolean(p.ready);
                buf.writeVarInt(p.repairTotal);
            },
            buf -> new BreakdownStatePacket(buf.readBoolean(), buf.readUtf(64), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readBoolean(), buf.readVarInt(), buf.readBoolean(), buf.readVarInt(), buf.readBoolean(), buf.readVarInt()));

    /** The newest state this client was sent, and when (game time of arrival, in client ticks). */
    public static volatile BreakdownStatePacket latest;
    public static volatile long latestAt;

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BreakdownStatePacket p, IPayloadContext context) {
        latest = p;
        latestAt = System.currentTimeMillis();
    }
}
