package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client, every tick while an Enterprise, Breakdance or Wave Swinger runs: the client moves the structures from these numbers. */
public record FlatRideStatePacket(BlockPos pos, float s0, float s1, float s2, float s3) implements CustomPacketPayload {
    public static final Type<FlatRideStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "flat_ride_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FlatRideStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.s0);
                buf.writeFloat(p.s1);
                buf.writeFloat(p.s2);
                buf.writeFloat(p.s3);
            },
            buf -> new FlatRideStatePacket(buf.readBlockPos(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(FlatRideStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof FlatRideBlockEntity be) {
            be.receiveState(p.s0, p.s1, p.s2, p.s3);
        }
    }
}
