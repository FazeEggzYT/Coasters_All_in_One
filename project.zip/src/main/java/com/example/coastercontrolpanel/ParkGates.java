package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;

/**
 * The park's extra gates. They are ride gates in every way (same animated swing, Redstone Link, delay, wrench menu,
 * opening together with gates beside them) with their own look: the fast pass lane gate swings like a ride gate, the
 * barrier gates are boom barriers whose arm swings up.
 */
public final class ParkGates {
    private ParkGates() {
    }

    /** A gate that draws its own leaf block. */
    public interface Leafed {
        Block leaf();
    }

    public static class LaneGate extends RideGateBlock implements Leafed {
        public LaneGate(Properties p) {
            super(p);
        }

        @Override
        public Block leaf() {
            return CoasterControlPanel.FAST_PASS_LANE_GATE_LEAF.get();
        }

        @Override
        protected Component menuTitle() {
            return getName();
        }
    }

    public static class BarrierGate extends RideGateBlock implements Leafed {
        private final boolean car;

        public BarrierGate(boolean car, Properties p) {
            super(p);
            this.car = car;
        }

        @Override
        public Block leaf() {
            return car ? CoasterControlPanel.CAR_PARK_BARRIER_LEAF.get() : CoasterControlPanel.BARRIER_GATE_LEAF.get();
        }

        @Override
        protected Component menuTitle() {
            return getName();
        }
    }
}
