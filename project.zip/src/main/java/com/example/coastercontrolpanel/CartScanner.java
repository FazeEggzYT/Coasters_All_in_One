package com.example.coastercontrolpanel;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds out whether a Coasters Simulated cart is inside a box.
 * It talks to Sable (the physics mod) and Coasters Simulated by name at runtime, so this mod
 * still builds and loads without them. If anything is missing, no cart is ever found.
 *
 * Carts are "sub levels" in Sable. We ask Sable for all sub levels of the dimension, keep the ones
 * Coasters Simulated says are carts, and test each cart's centre against the box.
 */
public final class CartScanner {
    private static boolean tried = false;
    private static boolean ok = false;
    private static boolean warned = false;
    private static Method getContainer;
    private static Method getAllSubLevels;
    private static Method isCart;
    private static Method cartCenter;

    private CartScanner() {
    }

    private static void init() {
        tried = true;
        try {
            ClassLoader cl = CartScanner.class.getClassLoader();
            Class<?> containerClass = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer", true, cl);
            Method best = null;
            for (Method m : containerClass.getMethods()) {
                if (m.getName().equals("getContainer") && m.getParameterCount() == 1
                        && java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && m.getParameterTypes()[0].isAssignableFrom(ServerLevel.class)) {
                    if (best == null || best.getParameterTypes()[0].isAssignableFrom(m.getParameterTypes()[0])) {
                        best = m;
                    }
                }
            }
            if (best == null) {
                return;
            }
            getContainer = best;
            getAllSubLevels = best.getReturnType().getMethod("getAllSubLevels");
            Class<?> resolve = Class.forName(
                    "dev.silvergold.simulatedcoasters.track.cart.CoasterCartResolve", true, cl);
            for (Method m : resolve.getMethods()) {
                if (m.getParameterCount() == 1 && m.getName().equals("isCartSubLevel")) {
                    isCart = m;
                } else if (m.getParameterCount() == 1 && m.getName().equals("cartCenterWorld")) {
                    cartCenter = m;
                }
            }
            ok = isCart != null && cartCenter != null;
        } catch (Throwable t) {
            ok = false;
        }
    }

    public static boolean isAvailable() {
        if (!tried) {
            init();
        }
        return ok;
    }

    /** World positions of all cart centres in this dimension. Server side only. */
    private static List<Vector3d> cartCenters(Level level) {
        List<Vector3d> out = new ArrayList<>();
        if (!(level instanceof ServerLevel server) || !isAvailable()) {
            return out;
        }
        try {
            Object container = getContainer.invoke(null, server);
            if (container == null) {
                return out;
            }
            Object all = getAllSubLevels.invoke(container);
            if (!(all instanceof List<?> list)) {
                return out;
            }
            for (Object sub : list) {
                if (!Boolean.TRUE.equals(isCart.invoke(null, sub))) {
                    continue;
                }
                if (cartCenter.invoke(null, sub) instanceof Vector3d v) {
                    out.add(v);
                }
            }
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                CoasterControlPanel.LOGGER.warn("Section Controller could not scan for carts: {}", t.toString());
            }
        }
        return out;
    }

    /** True if the centre of any cart is inside the box. */
    public static boolean anyCartIn(Level level, AABB box) {
        for (Vector3d v : cartCenters(level)) {
            if (box.contains(v.x(), v.y(), v.z())) {
                return true;
            }
        }
        return false;
    }

    /**
     * How far along the path (0 = start anchor, 1 = end anchor) the furthest cart is.
     * -1 if no cart centre is within "radius" blocks of the path.
     */
    public static double maxProgress(Level level, List<Vec3> path, double radius) {
        if (path.size() < 2) {
            return -1;
        }
        double r2 = radius * radius;
        int best = -1;
        for (Vector3d v : cartCenters(level)) {
            for (int i = path.size() - 1; i > best; i--) {
                Vec3 p = path.get(i);
                double dx = p.x - v.x(), dy = p.y - v.y(), dz = p.z - v.z();
                if (dx * dx + dy * dy + dz * dz <= r2) {
                    best = i;
                    break;
                }
            }
        }
        return best < 0 ? -1 : best / (double) (path.size() - 1);
    }

    /** True if any cart centre is within "radius" blocks of any point on the path. */
    public static boolean anyCartNear(Level level, List<Vec3> path, double radius) {
        if (path.isEmpty()) {
            return false;
        }
        double r2 = radius * radius;
        for (Vector3d v : cartCenters(level)) {
            for (Vec3 p : path) {
                double dx = p.x - v.x(), dy = p.y - v.y(), dz = p.z - v.z();
                if (dx * dx + dy * dy + dz * dz <= r2) {
                    return true;
                }
            }
        }
        return false;
    }

    private static final java.util.Map<Object, Object> CAPTURED = java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    /** The drive hook hands us Sable's physics system for a level; kept as a fallback for {@link #systemFor}. */
    public static void capture(Object level, Object system) {
        if (level != null && system != null) {
            CAPTURED.put(level, system);
        }
    }

    /** Every cart of this dimension as {sub level, world centre as Vector3d}. Server side only. */
    public static List<Object[]> carts(Level level) {
        List<Object[]> out = new ArrayList<>();
        if (!(level instanceof ServerLevel server) || !isAvailable()) {
            return out;
        }
        try {
            Object container = getContainer.invoke(null, server);
            if (container == null) {
                return out;
            }
            Object all = getAllSubLevels.invoke(container);
            if (!(all instanceof List<?> list)) {
                return out;
            }
            for (Object sub : list) {
                if (Boolean.TRUE.equals(isCart.invoke(null, sub)) && cartCenter.invoke(null, sub) instanceof Vector3d v) {
                    out.add(new Object[] {sub, v});
                }
            }
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                CoasterControlPanel.LOGGER.warn("Could not scan for carts: {}", t.toString());
            }
        }
        return out;
    }

    /** Sable's physics system for this level, or null if it cannot be found. */
    public static Object systemFor(ServerLevel level) {
        if (!isAvailable()) {
            return CAPTURED.get(level);
        }
        try {
            ClassLoader cl = CartScanner.class.getClassLoader();
            Class<?> sys = Class.forName("dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem", true, cl);
            Object container = getContainer.invoke(null, level);
            if (container != null) {
                for (Method m : container.getClass().getMethods()) {
                    if (m.getParameterCount() == 0 && sys.isAssignableFrom(m.getReturnType())) {
                        m.setAccessible(true);
                        Object o = m.invoke(container);
                        if (o != null) {
                            return o;
                        }
                    }
                }
            }
            for (Method m : sys.getMethods()) {
                if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isAssignableFrom(ServerLevel.class) && sys.isAssignableFrom(m.getReturnType())) {
                    Object o = m.invoke(null, level);
                    if (o != null) {
                        return o;
                    }
                }
            }
        } catch (Throwable t) {
            // fall through to what the drive hook gave us
        }
        return CAPTURED.get(level);
    }
}
