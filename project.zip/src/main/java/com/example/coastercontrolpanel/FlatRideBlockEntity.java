package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Runs the Enterprise, Breakdance and Wave Swinger. The ride is a few moving structures (each starts at a Ride Part with its
 * own number); this block picks them up, moves each one by the ride's movement, and puts them back when the ride has stopped.
 */
public class FlatRideBlockEntity extends BlockEntity implements IControlContraption {
    private static final float HOLD_SECONDS = 40.0F;
    private static final float RAMP = 9.0F;
    private static final double[] POSE = new double[7];

    private int kind;
    private BlockPos[] anchors = new BlockPos[0];
    private boolean assembled;
    private boolean on;
    private float timer;
    private boolean lastSignal;
    private int orphanTicks;
    private final float[] st = new float[FlatRidePrograms.STATE];
    private ControlledContraptionEntity[] ents = new ControlledContraptionEntity[0];
    private final List<ControlledContraptionEntity> loose = new ArrayList<>();
    private boolean stateSeen;
    private int loadTicks;

    public FlatRideBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.FLAT_RIDE_BE.get(), pos, state);
    }

    /** Called when the ride is built: which ride this is and where each of its moving structures starts. */
    public void configure(int rideKind, List<BlockPos> starts) {
        kind = rideKind;
        anchors = starts.toArray(new BlockPos[0]);
        setChanged();
        sync();
    }

    // ---- IControlContraption

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        for (ControlledContraptionEntity e : ents) {
            if (e == contraption) {
                return true;
            }
        }
        return loose.contains(contraption);
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        contraption.setRotationAxis(Direction.Axis.Y);
        BlockPos anchor = contraption.getContraption() != null ? contraption.getContraption().anchor : null;
        if (ents.length != anchors.length) {
            ents = new ControlledContraptionEntity[anchors.length];
        }
        for (int i = 0; i < anchors.length; i++) {
            if (anchors[i].equals(anchor)) {
                ents[i] = contraption;
                return;
            }
        }
        if (!loose.contains(contraption)) {
            loose.add(contraption);
        }
    }

    @Override
    public void onStall() {
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- controls

    public void toggle(Player player) {
        if (level == null || level.isClientSide) {
            return;
        }
        if (assembled && on) {
            on = false;
            say(player, "flat_ride_stopping");
        } else if (!assembled) {
            if (assemble(player)) {
                on = true;
                timer = 0;
                say(player, "flat_ride_started");
            }
        } else {
            on = true;
            timer = 0;
            say(player, "flat_ride_started");
        }
        sync();
    }

    public void redstone(boolean signal) {
        if (signal && !lastSignal && !on && level != null && !level.isClientSide) {
            if (assembled || assemble(null)) {
                on = true;
                timer = 0;
                sync();
            }
        }
        lastSignal = signal;
    }

    private void say(@Nullable Player p, String key) {
        if (p != null) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key), true);
        }
    }

    // ---- assembling

    private boolean assemble(@Nullable Player player) {
        if (level == null || anchors.length == 0) {
            say(player, "flat_ride_empty");
            return false;
        }
        List<SwingCarriage.Part> parts = new ArrayList<>();
        try {
            for (BlockPos a : anchors) {
                SwingCarriage.Part part = new SwingCarriage.Part();
                SwingCarriage.Carry.begin(true, a, 14, 14, 14);
                try {
                    if (!part.assemble(level, a) || part.getBlocks().isEmpty()) {
                        say(player, "flat_ride_empty");
                        return false;
                    }
                } finally {
                    SwingCarriage.Carry.end();
                }
                parts.add(part);
            }
        } catch (AssemblyException e) {
            say(player, "flat_ride_empty");
            return false;
        }
        for (SwingCarriage.Part part : parts) {
            part.removeBlocksFromWorld(level, BlockPos.ZERO);
        }
        ents = new ControlledContraptionEntity[anchors.length];
        for (int i = 0; i < anchors.length; i++) {
            ControlledContraptionEntity e = ControlledContraptionEntity.create(level, this, parts.get(i));
            e.setRotationAxis(Direction.Axis.Y);
            e.setPos(anchors[i].getX(), anchors[i].getY(), anchors[i].getZ());
            level.addFreshEntity(e);
            ents[i] = e;
        }
        java.util.Arrays.fill(st, 0.0F);
        assembled = true;
        loadTicks = 60;
        orphanTicks = 0;
        setChanged();
        sync();
        return true;
    }

    /** Puts every structure back as blocks, exactly where it started. */
    private void landAll() {
        if (level != null && !level.isClientSide) {
            for (int i = 0; i < ents.length; i++) {
                ControlledContraptionEntity e = ents[i];
                if (e == null) {
                    continue;
                }
                Object o = e;
                if (o instanceof FreeOrient f) {
                    f.ccp$clearOrient();
                }
                e.setAngle(0);
                if (i < anchors.length) {
                    e.setPos(anchors[i].getX(), anchors[i].getY(), anchors[i].getZ());
                }
                e.setContraptionMotion(Vec3.ZERO);
                e.disassemble();
                e.discard();
            }
        }
        ents = new ControlledContraptionEntity[anchors.length];
        loose.clear();
        assembled = false;
        on = false;
        java.util.Arrays.fill(st, 0.0F);
        setChanged();
        sync();
    }

    // ---- moving the structures (both sides)

    private void place() {
        if (anchors.length == 0 || ents.length != anchors.length) {
            return;
        }
        for (int i = 0; i < anchors.length; i++) {
            ControlledContraptionEntity e = ents[i];
            if (e == null || !e.isAlive()) {
                continue;
            }
            FlatRidePrograms.pose(kind, st, i, anchors, POSE);
            Object o = e;
            if (o instanceof FreeOrient f) {
                f.ccp$orient((float) POSE[3], (float) POSE[4], (float) POSE[5], (float) POSE[6]);
            } else {
                e.setRotationAxis(Direction.Axis.Y);
                e.setAngle((float) POSE[4]);
            }
            double dx = anchors[i].getX() + POSE[0] - e.getX();
            double dy = anchors[i].getY() + POSE[1] - e.getY();
            double dz = anchors[i].getZ() + POSE[2] - e.getZ();
            if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) > 1.0E-7) {
                e.setContraptionMotion(new Vec3(dx, dy, dz));
                e.move(dx, dy, dz);
            }
        }
    }

    // ---- ticking

    public void serverTick() {
        if (level == null || level.isClientSide || !assembled) {
            return;
        }
        if (loadTicks < 60) {
            loadTicks++;
            if (loadTicks < 60 && !stateSeen) {
                // just after the world loaded: wait for the structures to be found again
                return;
            }
        }
        int missing = 0;
        for (ControlledContraptionEntity e : ents) {
            if (e == null || !e.isAlive()) {
                missing++;
            }
        }
        if (missing > 0) {
            if (++orphanTicks > 100) {
                assembled = false;
                on = false;
                ents = new ControlledContraptionEntity[anchors.length];
                java.util.Arrays.fill(st, 0.0F);
                sync();
            }
            return;
        }
        orphanTicks = 0;
        if (on) {
            timer += 0.05F;
            if (timer >= HOLD_SECONDS) {
                on = false;
            }
        }
        FlatRidePrograms.step(kind, st, 0.05F, on, RAMP, RAMP);
        place();
        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                new FlatRideStatePacket(worldPosition, st[0], st[1], st[2], st[3]));
        if (!on && st[0] <= 0.0F) {
            landAll();
        }
    }

    public void receiveState(float s0, float s1, float s2, float s3) {
        st[0] = s0;
        st[1] = s1;
        st[2] = s2;
        st[3] = s3;
        stateSeen = true;
    }

    public void clientTick() {
        if (!stateSeen || anchors.length == 0) {
            return;
        }
        if (!loose.isEmpty()) {
            for (ControlledContraptionEntity e : new ArrayList<>(loose)) {
                attach(e);
                if (e.getContraption() != null && containsEntity(e)) {
                    loose.remove(e);
                }
            }
        }
        if (st[0] > 0.0F) {
            place();
        }
    }

    private boolean containsEntity(ControlledContraptionEntity e) {
        for (ControlledContraptionEntity x : ents) {
            if (x == e) {
                return true;
            }
        }
        return false;
    }

    // ---- saving and syncing

    private void sync() {
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Kind", kind);
        tag.putBoolean("Assembled", assembled);
        long[] a = new long[anchors.length];
        for (int i = 0; i < a.length; i++) {
            a[i] = anchors[i].asLong();
        }
        tag.putLongArray("Anchors", a);
        for (int i = 0; i < st.length; i++) {
            tag.putFloat("S" + i, st[i]);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        kind = tag.getInt("Kind");
        assembled = tag.getBoolean("Assembled");
        long[] a = tag.getLongArray("Anchors");
        anchors = new BlockPos[a.length];
        for (int i = 0; i < a.length; i++) {
            anchors[i] = BlockPos.of(a[i]);
        }
        for (int i = 0; i < st.length; i++) {
            st[i] = tag.getFloat("S" + i);
        }
        if (ents.length != anchors.length) {
            ents = new ControlledContraptionEntity[anchors.length];
        }
        on = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
