package com.example.coastercontrolpanel;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chain Timer: a lift (plain chain or Drive Tyre) can be given a time to reach full speed after it is switched on and
 * a time to slow down after it is switched off. The settings live on the lift's first anchor. The speed factor 0..1 is
 * kept here, per anchor, and only runs while a cart is on the lift. It starts again from 0 when a train arrives at an
 * idle lift.
 */
public final class ChainRamp {
    private static final class St {
        float f;
        long tick = Long.MIN_VALUE / 2;
        double tgt;
        int sig;
        double scale = 1.0;
    }

    private static int logged;

    private static final Map<Long, St> STATES = new ConcurrentHashMap<>();

    private ChainRamp() {
    }

    private static St update(DriveTyre.Holder h, long key, long tick, boolean on) {
        St s = STATES.computeIfAbsent(key, k -> new St());
        float up = h.ccp$rampUp();
        float down = h.ccp$rampDown();
        if (tick - s.tick > 20) {
            s.f = 0.0F;
        } else if (tick != s.tick) {
            float el = (tick - s.tick) / 20.0F;
            if (on) {
                s.f = up <= 0.0F ? 1.0F : Math.min(1.0F, s.f + el / up);
            } else {
                s.f = down <= 0.0F ? 0.0F : Math.max(0.0F, s.f - el / down);
            }
        }
        if (on && up <= 0.0F) {
            s.f = 1.0F;
        }
        s.tick = tick;
        return s;
    }

    /**
     * Plain chain or Create-shaft Drive Tyre. Returns the velocity change to add along the track direction, or NaN
     * when the normal chain drive should simply run (full speed, or fully stopped).
     *
     * @param chainSpeed how fast the chain itself is moving (0 when it is not powered)
     * @param proj       the chain's velocity along the track direction; the drive's target is minus this
     * @param v          the cart's velocity along the track direction
     */
    public static double shaft(DriveTyre.Holder h, long key, long tick, double chainSpeed, double proj, double v, double dt) {
        boolean on = chainSpeed > 0.05;
        St s = update(h, key, tick, on);
        if (logged < 60 && tick % 10 == 0) {
            logged++;
            CoasterControlPanel.LOGGER.info("Chain Timer {}: up={}s down={}s chain={} b/s on={} factor={} cart={} b/s",
                    net.minecraft.core.BlockPos.of(key), h.ccp$rampUp(), h.ccp$rampDown(),
                    String.format("%.2f", chainSpeed), on, String.format("%.3f", s.f), String.format("%.2f", v));
        }
        if (on) {
            s.tgt = -proj;
        }
        if ((on && s.f >= 1.0F) || (!on && s.f <= 0.0F)) {
            return Double.NaN;
        }
        double u = Math.signum(s.tgt);
        if (u == 0.0) {
            return Double.NaN;
        }
        double sv = v * u;
        double target = Math.abs(s.tgt) * s.f;
        double step = 32.0 * dt;
        double dv = on ? Math.max(0.0, Math.min(target - sv, step)) : Math.max(-step, Math.min(target - sv, step));
        return dv * u;
    }

    /** Controlled Drive Tyre: the factor 0..1 to scale the push by. When off and above 0, the last push continues. */
    public static double drive(DriveTyre.Holder h, long key, long tick, int sig, double scale) {
        St s = update(h, key, tick, sig != 0);
        if (sig != 0) {
            s.sig = sig;
            s.scale = scale;
        }
        return s.f;
    }

    public static int lastSig(long key) {
        St s = STATES.get(key);
        return s == null ? 0 : s.sig;
    }

    public static double lastScale(long key) {
        St s = STATES.get(key);
        return s == null ? 1.0 : s.scale;
    }
}
