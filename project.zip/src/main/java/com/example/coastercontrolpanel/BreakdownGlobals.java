package com.example.coastercontrolpanel;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.neoforge.network.PacketDistributor;

/** The global breakdown defaults. Saved with the world, and copied to every client so the settings screen can show them. */
public final class BreakdownGlobals extends SavedData {
    private static final String NAME = "coastercontrolpanel_breakdown_globals";
    /** The client's copy. */
    public static volatile BreakdownSettings client = BreakdownSettings.defaults();

    private BreakdownSettings value = BreakdownSettings.defaults();

    public static BreakdownGlobals get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(BreakdownGlobals::new, BreakdownGlobals::load, null), NAME);
    }

    private static BreakdownGlobals load(CompoundTag tag, HolderLookup.Provider registries) {
        BreakdownGlobals g = new BreakdownGlobals();
        g.value = BreakdownSettings.fromTag(tag.getCompound("Value"));
        return g;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.put("Value", value.toTag());
        return tag;
    }

    public BreakdownSettings value() {
        return value;
    }

    /** Replaces the defaults (server side) and tells every player. */
    public void set(MinecraftServer server, BreakdownSettings s) {
        value = s;
        setDirty();
        PacketDistributor.sendToAllPlayers(new BreakdownGlobalsPacket(s.toTag()));
    }

    public void send(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new BreakdownGlobalsPacket(value.toTag()));
    }
}
