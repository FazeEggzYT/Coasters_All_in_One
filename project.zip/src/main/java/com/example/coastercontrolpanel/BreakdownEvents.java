package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Break Down Your Coaster, placing. Right-click an anchor with the item to put a breakdown zone on the element that
 * starts or ends there (a Brake Run, a chain lift, a launch...) or on the plain track. Sneak-right-click removes it.
 * The zone is invisible: it is only a block of settings saved on the element's start anchor. The Wrench opens it.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class BreakdownEvents {
    /** Players who have clicked the first end of a plain-track zone: {dimension, anchor}. */
    private static final java.util.Map<java.util.UUID, Object[]> PENDING = new java.util.concurrent.ConcurrentHashMap<>();

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            BreakdownGlobals.get(sp.server).send(sp);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND
                || !event.getItemStack().is(CoasterControlPanel.BREAKDOWN_ITEM.get())) {
            return;
        }
        Level level = event.getLevel();
        BlockPos clicked = event.getPos();
        if (!(level.getBlockEntity(clicked) instanceof DriveTyre.Holder)) {
            return; // not a coaster anchor: the item does nothing, the click carries on as normal
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (level.isClientSide) {
            return;
        }
        Player player = event.getEntity();
        BlockPos zone = zoneStart(level, clicked);
        if (player.isShiftKeyDown()) {
            PENDING.remove(player.getUUID());
            if (zone != null && level.getBlockEntity(zone) instanceof DriveTyre.Holder h) {
                h.ccp$setBreakdown(null);
                h.ccp$sync();
                BreakdownController.unregister(level, zone);
                say(player, "breakdown_removed");
            } else {
                say(player, "breakdown_none");
            }
            return;
        }
        if (zone != null) {
            say(player, "breakdown_exists");
            return;
        }
        BlockPos start = BrakeController.findChainStart(level, clicked);
        BlockPos end = null;
        if (start == null) {
            // Plain track: the first click is one end of the zone, the second click is the other end. Click the same
            // anchor twice for a small zone round that one anchor.
            Object[] pend = PENDING.get(player.getUUID());
            if (pend == null || !pend[0].equals(level.dimension())) {
                PENDING.put(player.getUUID(), new Object[] {level.dimension(), clicked});
                say(player, "breakdown_pick_end");
                return;
            }
            PENDING.remove(player.getUUID());
            start = (BlockPos) pend[1];
            end = clicked.equals(start) ? null : clicked;
            if (!(level.getBlockEntity(start) instanceof DriveTyre.Holder) || zoneStart(level, start) != null) {
                say(player, "breakdown_exists");
                return;
            }
        }
        if (level.getBlockEntity(start) instanceof DriveTyre.Holder h) {
            BreakdownSettings s = BreakdownSettings.forElement(elementOf(h));
            s.end = end;
            h.ccp$setBreakdown(s);
            h.ccp$sync();
            BreakdownController.register(level, start);
            say(player, "breakdown_added");
        }
    }

    private static void say(Player player, String key) {
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key), true);
    }

    /** What kind of element a start anchor holds, for the default breakdown weights. */
    public static int elementOf(DriveTyre.Holder h) {
        BrakeSettings b = h.ccp$brake();
        if (b != null) {
            if (b.stopper) {
                return BreakdownSettings.E_STOPPER;
            }
            if (b.trigger) {
                return BreakdownSettings.E_TRIGGER;
            }
            if (b.block) {
                return BreakdownSettings.E_BLOCK;
            }
            if (b.launch) {
                return BreakdownSettings.E_LAUNCH;
            }
            return h.ccp$isDriveTyre() ? BreakdownSettings.E_LIFT : BreakdownSettings.E_BRAKE;
        }
        if (h.ccp$isDriveTyre() || BrakeController.endOfAnchor((BlockEntity) h) != null) {
            return BreakdownSettings.E_LIFT;
        }
        return BreakdownSettings.E_GENERAL;
    }

    /** The anchor that holds the breakdown zone {@code clicked} belongs to (as its first or second anchor), or null. */
    public static BlockPos zoneStart(Level level, BlockPos clicked) {
        BlockEntity here = level.getBlockEntity(clicked);
        if (!(here instanceof DriveTyre.Holder h0)) {
            return null;
        }
        if (h0.ccp$breakdown() != null) {
            return clicked;
        }
        try {
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            int cx = clicked.getX() >> 4;
            int cz = clicked.getZ() >> 4;
            for (int dx = -4; dx <= 4; dx++) {
                for (int dz = -4; dz <= 4; dz++) {
                    LevelChunk chunk = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
                    if (chunk == null) {
                        continue;
                    }
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (be instanceof DriveTyre.Holder h && h.ccp$breakdown() != null
                                && clicked.equals(BrakeController.endOfAnchor(be))) {
                            double d = be.getBlockPos().distSqr(clicked);
                            if (d < bestD) {
                                bestD = d;
                                best = be.getBlockPos();
                            }
                        }
                    }
                }
            }
            return best;
        } catch (Throwable e) {
            return null;
        }
    }
}
