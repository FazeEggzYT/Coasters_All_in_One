package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Ride gate setup: the Redstone Link item and the delay in seconds. */
public class RideGateScreen extends AbstractContainerScreen<RideGateMenu> {
    private int delay = 3;

    public RideGateScreen(RideGateMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
    }

    @Override
    protected void init() {
        super.init();
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof RideGateBlockEntity g) {
            delay = g.getDelay();
        }
        int step = 1;
        addRenderableWidget(Button.builder(Component.literal("-"),
                        b -> delay = Math.max(0, delay - (Screen.hasShiftDown() ? 5 : step)))
                .bounds(leftPos + 62, topPos + 48, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"),
                        b -> delay = Math.min(60, delay + (Screen.hasShiftDown() ? 5 : step)))
                .bounds(leftPos + 126, topPos + 48, 18, 16).build());
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new GateConfigPacket(menu.getPos(), delay));
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        int accent = 0;
        if (minecraft != null && minecraft.level != null) {
            net.minecraft.world.level.block.Block blk = minecraft.level.getBlockState(menu.getPos()).getBlock();
            accent = blk instanceof ParkGates.LaneGate ? 0xFFD9A441 : blk instanceof ParkGates.BarrierGate ? 0xFFB0302E : 0;
        }
        if (accent != 0) {
            g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + 18, accent);
        }
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.gate_signal"), 8, 26, 0xE0E4F0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.gate_delay"), 8, 52, 0xE0E4F0, false);
        g.drawCenteredString(font, delay + " s", 103, 52, 0xFFFFFF);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.gate_hint"), 8, 70, 0x7A8098, false);
    }
}
