package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Locale;
import java.util.function.Consumer;

/** Swivel Bearing: the angles, the controls and the Redstone Links. */
public class SwivelScreen extends Screen {
    private static final int W = 340;
    private static final int H = 300;
    private static final int RH = 19;

    private final BlockPos pos;
    private SwivelSettings s = new SwivelSettings();
    private int tab;
    private int left;
    private int top;
    private boolean loaded;
    private final java.util.List<String> labels = new java.util.ArrayList<>();

    public SwivelScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.swivel.title"));
        this.pos = pos;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.swivel." + key);
    }

    private int kind() {
        SwivelBlockEntity b = be();
        return b == null ? 0 : b.kind();
    }

    private SwivelBlockEntity be() {
        return minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(pos) instanceof SwivelBlockEntity b ? b : null;
    }

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.2f", v);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (!loaded) {
            loaded = true;
            SwivelBlockEntity b = be();
            if (b != null) {
                s = b.cfg.copy();
            }
        }
        rebuild();
    }

    private EditBox edit(int x, int y, int w, double value, double min, double max, Consumer<Float> set) {
        EditBox box = new EditBox(font, left + x, top + y, w, 14, Component.empty());
        box.setValue(num(value));
        box.setFilter(str -> str.matches("-?[0-9]{0,3}([.][0-9]{0,2})?"));
        box.setResponder(str -> {
            try {
                set.accept((float) Math.max(min, Math.min(max, Float.parseFloat(str))));
            } catch (NumberFormatException ignored) {
                // half-typed
            }
        });
        return box;
    }

    private Button button(int x, int y, int w, int h, Component label, Runnable action) {
        Button btn = Button.builder(label, bt -> action.run()).bounds(left + x, top + y, w, h).build();
        addRenderableWidget(btn);
        return btn;
    }

    private void rebuild() {
        clearWidgets();
        String[] tabs = {"tab_settings", "tab_control", "tab_links"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button tb = button(8 + i * 66, 22, 62, 16, t(tabs[i]), () -> {
                tab = idx;
                rebuild();
            });
            tb.active = tab != i;
        }
        button(W - 52, 4, 44, 14, Component.translatable("gui.coastercontrolpanel.ok"), this::onClose);
        if (tab == 0) {
            int x = 200;
            int w = 124;
            labels.clear();
            int[] row = {52};
            int k = kind();
            // the name, shown on the bearing's track in an Animation Controller
            labels.add("name");
            EditBox nameBox = new EditBox(font, left + x, top + row[0], w, 14, Component.empty());
            nameBox.setMaxLength(24);
            nameBox.setValue(s.name);
            nameBox.setResponder(str -> s.name = str);
            addRenderableWidget(nameBox);
            row[0] += RH;
            if (k == 3 || k == 4) {
                labels.add("sway_amp");
                addRenderableWidget(edit(x, row[0], w, s.swayAmp, 0, 180, v -> s.swayAmp = v));
                row[0] += RH;
                labels.add("sway_period");
                addRenderableWidget(edit(x, row[0], w, s.swayPeriod, 0.5, 120, v -> s.swayPeriod = v));
                row[0] += RH;
            } else if (k == 5) {
                labels.add("lift_dist");
                addRenderableWidget(edit(x, row[0], w, s.active, -180, 180, v -> s.active = v));
                row[0] += RH;
            } else if (k == 0) {
                labels.add("rest");
                addRenderableWidget(edit(x, row[0], w, s.rest, -180, 180, v -> s.rest = v));
                row[0] += RH;
                labels.add("active");
                addRenderableWidget(edit(x, row[0], w, s.active, -180, 180, v -> s.active = v));
                row[0] += RH;
            } else if (k == 1) {
                labels.add("flip_pos");
                addRenderableWidget(edit(x, row[0], w, s.flipPos, 0, 360, v -> s.flipPos = v));
                row[0] += RH;
                labels.add("flip_neg");
                addRenderableWidget(edit(x, row[0], w, s.flipNeg, 0, 360, v -> s.flipNeg = v));
                row[0] += RH;
            } else {
                labels.add("spin_amount");
                addRenderableWidget(edit(x, row[0], w, s.spinAmount, 0, 3600, v -> s.spinAmount = v));
                row[0] += RH;
                labels.add("spin_dir");
                button(x, row[0], w, 14, t("spin_dir." + s.spinDir), () -> {
                    s.spinDir = 1 - s.spinDir;
                    rebuild();
                });
                row[0] += RH;
            }
            if (k != 3 && k != 4) {
                labels.add(k == 5 ? "lift_speed" : "speed");
                addRenderableWidget(edit(x, row[0], w, s.speed, 1, 720, v -> s.speed = v));
                row[0] += RH;
            }
            if (k == 1) {
                labels.add("pause");
                addRenderableWidget(edit(x, row[0], w, s.pause, 0, 60, v -> s.pause = v));
                row[0] += RH;
                labels.add("reps");
                addRenderableWidget(edit(x, row[0], w, s.reps, 0, 99, v -> s.reps = Math.round(v)));
                row[0] += RH;
                labels.add("return_zero");
                button(x, row[0], w, 14, t("return_zero." + (s.returnZero ? 1 : 0)), () -> {
                    s.returnZero = !s.returnZero;
                    rebuild();
                });
                row[0] += RH;
                labels.add("smooth");
                button(x, row[0], w, 14, t("smooth." + (s.smooth ? 1 : 0)), () -> {
                    s.smooth = !s.smooth;
                    rebuild();
                });
                row[0] += RH;
            }
            if (k == 2) {
                labels.add("spin_return");
                button(x, row[0], w, 14, t("spin_return." + (s.spinReturn ? 1 : 0)), () -> {
                    s.spinReturn = !s.spinReturn;
                    rebuild();
                });
                row[0] += RH;
            }
            labels.add("axis");
            button(x, row[0], w, 14, t("axis." + s.axis), () -> {
                s.axis = (s.axis + 1) % 4;
                rebuild();
            });
            row[0] += RH;
            if (k == 0) {
                labels.add("mode");
                button(x, row[0], w, 14, t("mode." + s.mode), () -> {
                    s.mode = (s.mode + 1) % SwivelSettings.MODES;
                    rebuild();
                });
                row[0] += RH;
                labels.add("signal");
                button(x, row[0], w, 14, t("signal." + (s.analog ? 1 : 0)), () -> {
                    s.analog = !s.analog;
                    rebuild();
                });
                row[0] += RH;
            }
            labels.add("carry");
            button(x, row[0], w, 14, t("carry." + (s.carryAll ? 1 : 0)), () -> {
                s.carryAll = !s.carryAll;
                rebuild();
            });
            row[0] += RH;
            labels.add("reach");
            addRenderableWidget(edit(x, row[0], w, s.reach, 2, 24, v -> s.reach = Math.round(v)));
        } else if (tab == 1) {
            button(8, 150, 100, 20, t(kind() == 0 ? "go_active" : "start"), () -> act(RideEngine.ACTION_START));
            button(120, 150, 100, 20, t(kind() == 0 ? "go_rest" : "stop"), () -> act(RideEngine.ACTION_END));
            button(232, 150, 100, 20, t("hold"), () -> act(RideEngine.ACTION_PAUSE));
            button(8, 176, 160, 20, t("assemble"), () -> act(SwivelBlockEntity.ACTION_ASSEMBLE));
            button(172, 176, 160, 20, t("disassemble"), () -> act(SwivelBlockEntity.ACTION_DISASSEMBLE));
        } else {
            for (int i = 0; i < RideLinks.COUNT; i++) {
                final int slot = i;
                int y = RideLinks.ROW_Y[i];
                button(190, y, 70, 16, Component.translatable("gui.coastercontrolpanel.ride.link_set"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, false)));
                button(264, y, 50, 16, Component.translatable("gui.coastercontrolpanel.ride.link_clear"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, true)));
            }
        }
    }

    private void act(int action) {
        sendConfig();
        PacketDistributor.sendToServer(new DropTowerControlPacket(pos, action));
    }

    private void sendConfig() {
        s.sanitize();
        PacketDistributor.sendToServer(new DropTowerConfigPacket(pos, s.toTag()));
    }

    @Override
    public void removed() {
        sendConfig();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, t("title." + kind()), left + 8, top + 8, 0xFFFFFF, false);
        int text = 0xE0E4F0;
        int dim = 0x7A8098;
        SwivelBlockEntity b = be();
        if (tab == 0) {
            for (int i = 0; i < labels.size(); i++) {
                g.drawString(font, t("set." + labels.get(i)), left + 12, top + 55 + i * RH, text, false);
            }
            g.drawString(font, t(kind() == 0 ? "settings_note" : kind() == 1 ? "settings_note_flip" : kind() == 2 ? "settings_note_spin" : kind() == 5 ? "settings_note_lift" : "settings_note_sway"), left + 12, top + H - 26, dim, false);
            g.drawString(font, t("settings_note_2"), left + 12, top + H - 14, dim, false);
        } else if (tab == 1) {
            if (b != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.swivel.angle_line",
                        String.format(Locale.ROOT, "%.1f", b.angle), String.format(Locale.ROOT, "%.1f", b.targetAngle())), left + 12, top + 52, 0xFFFFFF, false);
                g.drawString(font, t(b.holding() ? "status.hold" : b.moving ? "status.moving" : "status.still"), left + 12, top + 68, text, false);
            }
            g.drawString(font, t(kind() == 0 ? "control_note_1" : "control_note_keep"), left + 12, top + 100, dim, false);
            g.drawString(font, t("control_note_2"), left + 12, top + 112, dim, false);
            g.drawString(font, t("control_note_3"), left + 12, top + 124, dim, false);
            g.drawString(font, t("control_note_4"), left + 12, top + 204, dim, false);
        } else {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note"), left + 12, top + 44, dim, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.0"), left + 12, top + 60, 0xFFFFC040, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.1"), left + 12, top + 126, 0xFFFF6050, false);
            for (int i = 0; i < RideLinks.COUNT; i++) {
                int y = top + RideLinks.ROW_Y[i];
                g.drawString(font, t("link." + i), left + 12, y + 4, text, false);
                g.fill(left + 150, y - 1, left + 168, y + 17, 0xFF3A3E4D);
                g.fill(left + 151, y, left + 167, y + 16, 0xFF101218);
                if (b != null && !b.links().stack(i).isEmpty()) {
                    g.renderItem(b.links().stack(i), left + 151, y);
                }
            }
        }
    }
}
