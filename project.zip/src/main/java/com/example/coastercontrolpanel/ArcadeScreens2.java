package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** The seven extra arcade games: air hockey, pinball, dance machine, racing, foosball, skee-ball and darts. */
final class ArcadeScreens2 {
    private ArcadeScreens2() {
    }

    static void disc(GuiGraphics g, int cx, int cy, int r, int colour) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, colour);
        }
    }

    static boolean isLeft(int k) {
        return k == GLFW.GLFW_KEY_LEFT || k == GLFW.GLFW_KEY_A;
    }

    static boolean isRight(int k) {
        return k == GLFW.GLFW_KEY_RIGHT || k == GLFW.GLFW_KEY_D;
    }

    // ------------------------------------------------------------------ air hockey

    static class AirHockeyScreen extends ArcadeScreens.GameScreen {
        private float px;
        private float py;
        private float vx;
        private float vy;
        private float mx;
        private float my;
        private float ax;
        private int them;
        private int mouseX = 100;
        private int mouseY = 90;
        private int freeze;

        AirHockeyScreen(BlockPos pos) {
            super(ArcadeGame.AIR_HOCKEY, pos);
        }

        private void serve(int dir) {
            px = 100;
            py = 60;
            vx = (RND.nextFloat() - 0.5F) * 3.0F;
            vy = dir * 2.5F;
            freeze = 15;
        }

        @Override
        protected void begin() {
            score = 0;
            them = 0;
            mx = 100;
            my = 100;
            ax = 100;
            serve(1);
        }

        private void hit(float cx, float cy, float pvx, float pvy) {
            float dx = px - cx;
            float dy = py - cy;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < 15.0F && d > 0.001F) {
                dx /= d;
                dy /= d;
                px = cx + dx * 15.0F;
                py = cy + dy * 15.0F;
                float sp = Math.min(6.5F, Math.max(3.2F, (float) Math.sqrt(vx * vx + vy * vy) * 1.05F + Math.abs(pvx) * 0.3F + Math.abs(pvy) * 0.3F));
                vx = dx * sp;
                vy = dy * sp;
            }
        }

        @Override
        protected void gameTick() {
            float nmx = Math.max(10, Math.min(190, mouseX));
            float nmy = Math.max(70, Math.min(112, mouseY));
            float dx = Math.max(-9, Math.min(9, nmx - mx));
            float dy = Math.max(-9, Math.min(9, nmy - my));
            mx += dx;
            my += dy;
            float target = px + (py < 60 ? 0 : (RND.nextFloat() - 0.5F) * 8);
            ax += Math.max(-2.3F, Math.min(2.3F, target - ax));
            ax = Math.max(10, Math.min(190, ax));
            if (freeze > 0) {
                freeze--;
            } else {
                px += vx;
                py += vy;
                vx *= 0.995F;
                vy *= 0.995F;
                if (px < 5) {
                    px = 5;
                    vx = Math.abs(vx);
                } else if (px > 195) {
                    px = 195;
                    vx = -Math.abs(vx);
                }
                hit(mx, my, dx, dy);
                hit(ax, 14, 0, 0);
                if (py < 3 && (px < 70 || px > 130)) {
                    py = 3;
                    vy = Math.abs(vy);
                } else if (py > 117 && (px < 70 || px > 130)) {
                    py = 117;
                    vy = -Math.abs(vy);
                }
                if (py < -6) {
                    score++;
                    serve(1);
                } else if (py > 126) {
                    them++;
                    serve(-1);
                }
            }
            if (ticks >= 900 || score >= 7 || them >= 7) {
                finish(score, 0);
            }
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mxr, int myr) {
            mouseX = mxr;
            mouseY = myr;
            g.fill(x, y, x + AW, y + AH, 0xFF0F3A5A);
            g.fill(x + 98, y, x + 102, y + AH, 0x66FFFFFF);
            g.fill(x + 70, y, x + 130, y + 2, 0xFFE05050);
            g.fill(x + 70, y + AH - 2, x + 130, y + AH, 0xFF50E070);
            disc(g, x + (int) px, y + (int) py, 5, 0xFF202020);
            disc(g, x + (int) ax, y + 14, 9, 0xFFE05050);
            disc(g, x + (int) mx, y + (int) my, 9, 0xFF50E070);
            g.drawString(font, score + " : " + them, x + 3, y + 3, 0xFFFFFF, false);
            g.drawString(font, "" + Math.max(0, (900 - ticks) / 20), x + AW - 16, y + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ pinball

    static class PinballScreen extends ArcadeScreens.GameScreen {
        private float bx;
        private float by;
        private float vx;
        private float vy;
        private int balls;
        private int flipL;
        private int flipR;
        private int pause;
        private final int[] bumperFlash = new int[3];
        private static final int[][] BUMPERS = {{70, 35}, {130, 35}, {100, 62}};

        PinballScreen(BlockPos pos) {
            super(ArcadeGame.PINBALL, pos);
        }

        private void launch() {
            bx = 170;
            by = 30;
            vx = -1.5F - RND.nextFloat();
            vy = 0.5F;
        }

        @Override
        protected void begin() {
            score = 0;
            balls = 3;
            flipL = 0;
            flipR = 0;
            pause = 0;
            launch();
        }

        @Override
        protected void gameTick() {
            if (flipL > 0) {
                flipL--;
            }
            if (flipR > 0) {
                flipR--;
            }
            for (int i = 0; i < 3; i++) {
                if (bumperFlash[i] > 0) {
                    bumperFlash[i]--;
                }
            }
            if (pause > 0) {
                if (--pause == 0) {
                    if (balls <= 0) {
                        finish(Math.min(300, score), 0);
                    } else {
                        launch();
                    }
                }
                return;
            }
            vy += 0.14F;
            bx += vx;
            by += vy;
            if (bx < 4) {
                bx = 4;
                vx = Math.abs(vx) * 0.9F;
            } else if (bx > 196) {
                bx = 196;
                vx = -Math.abs(vx) * 0.9F;
            }
            if (by < 4) {
                by = 4;
                vy = Math.abs(vy) * 0.9F;
            }
            for (int i = 0; i < 3; i++) {
                float dx = bx - BUMPERS[i][0];
                float dy = by - BUMPERS[i][1];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < 13 && d > 0.01F) {
                    vx = dx / d * 4.2F;
                    vy = dy / d * 4.2F;
                    bx = BUMPERS[i][0] + dx / d * 13;
                    by = BUMPERS[i][1] + dy / d * 13;
                    score += 10;
                    bumperFlash[i] = 6;
                }
            }
            if (by > 100 && by < 112 && vy > 0) {
                if (flipL > 0 && bx > 45 && bx < 100) {
                    vy = -(5.2F + RND.nextFloat());
                    vx = (bx - 70) * 0.06F + 0.8F;
                } else if (flipR > 0 && bx >= 100 && bx < 155) {
                    vy = -(5.2F + RND.nextFloat());
                    vx = (bx - 130) * 0.06F - 0.8F;
                }
            }
            if (by > 124) {
                balls--;
                pause = 25;
            }
            if (ticks > 2400) {
                finish(Math.min(300, score), 0);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            if (mx < 100) {
                flipL = 7;
            } else {
                flipR = 7;
            }
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (isLeft(k)) {
                flipL = 7;
                return true;
            } else if (isRight(k)) {
                flipR = 7;
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mx, int my) {
            g.fill(x, y, x + AW, y + AH, 0xFF1A1030);
            for (int i = 0; i < 3; i++) {
                disc(g, x + BUMPERS[i][0], y + BUMPERS[i][1], 9, bumperFlash[i] > 0 ? 0xFFFFE070 : 0xFFD04080);
                disc(g, x + BUMPERS[i][0], y + BUMPERS[i][1], 5, 0xFF301040);
            }
            g.fill(x + 50, y + 108 - (flipL > 0 ? 8 : 0), x + 98, y + 112 - (flipL > 0 ? 4 : 0), 0xFF50C0E0);
            g.fill(x + 102, y + 108 - (flipR > 0 ? 8 : 0), x + 150, y + 112 - (flipR > 0 ? 4 : 0), 0xFF50C0E0);
            if (pause == 0) {
                disc(g, x + (int) bx, y + (int) by, 3, 0xFFE8E8F0);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), x + 3, y + 3, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.prop.balls_left", balls), x + AW - 70, y + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ dance machine

    static class DanceScreen extends ArcadeScreens.GameScreen {
        private final float[] y = new float[40];
        private final int[] lane = new int[40];
        private final boolean[] live = new boolean[40];
        private int spawned;
        private final int[] flash = new int[4];
        private static final int[] COLS = {0xFFE05080, 0xFF50C0E0, 0xFF70E070, 0xFFE0C050};
        private static final String[] ARROWS = {"<", "v", "^", ">"};

        DanceScreen(BlockPos pos) {
            super(ArcadeGame.DANCE, pos);
        }

        @Override
        protected void begin() {
            score = 0;
            spawned = 0;
            for (int i = 0; i < 40; i++) {
                live[i] = false;
            }
        }

        @Override
        protected void gameTick() {
            for (int i = 0; i < 4; i++) {
                if (flash[i] > 0) {
                    flash[i]--;
                }
            }
            if (spawned < 30 && ticks % 14 == 0) {
                y[spawned] = -8;
                lane[spawned] = RND.nextInt(4);
                live[spawned] = true;
                spawned++;
            }
            boolean any = false;
            for (int i = 0; i < 40; i++) {
                if (live[i]) {
                    y[i] += 2.2F;
                    if (y[i] > AH + 8) {
                        live[i] = false;
                    } else {
                        any = true;
                    }
                }
            }
            if (spawned >= 30 && !any) {
                finish(score, 0);
            }
        }

        private boolean press(int l) {
            flash[l] = 5;
            int best = -1;
            for (int i = 0; i < 40; i++) {
                if (live[i] && lane[i] == l && Math.abs(y[i] - 100) < 16 && (best < 0 || y[i] > y[best])) {
                    best = i;
                }
            }
            if (best >= 0) {
                live[best] = false;
                score++;
            }
            return true;
        }

        @Override
        protected boolean click(int mx, int my) {
            return press(Math.max(0, Math.min(3, mx / 50)));
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_LEFT || k == GLFW.GLFW_KEY_A) {
                return press(0);
            } else if (k == GLFW.GLFW_KEY_DOWN || k == GLFW.GLFW_KEY_S) {
                return press(1);
            } else if (k == GLFW.GLFW_KEY_UP || k == GLFW.GLFW_KEY_W) {
                return press(2);
            } else if (k == GLFW.GLFW_KEY_RIGHT || k == GLFW.GLFW_KEY_D) {
                return press(3);
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int ay, int mx, int my) {
            for (int l = 0; l < 4; l++) {
                int lx = x + l * 50;
                g.fill(lx, ay, lx + 49, ay + AH, l % 2 == 0 ? 0xFF14142A : 0xFF1A1A34);
                g.fill(lx + 4, ay + 92, lx + 46, ay + 108, flash[l] > 0 ? COLS[l] : (COLS[l] & 0x00FFFFFF) | 0x55000000);
                g.drawCenteredString(font, ARROWS[l], lx + 25, ay + 96, 0xFFFFFFFF);
            }
            for (int i = 0; i < 40; i++) {
                if (live[i]) {
                    int lx = x + lane[i] * 50;
                    g.fill(lx + 10, ay + (int) y[i] - 6, lx + 40, ay + (int) y[i] + 6, COLS[lane[i]]);
                    g.drawCenteredString(font, ARROWS[lane[i]], lx + 25, ay + (int) y[i] - 4, 0xFF000000);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), x + 3, ay + 3, 0xFFFFFF, false);
        }
    }

    // ------------------------------------------------------------------ racing

    static class RacingScreen extends ArcadeScreens.GameScreen {
        private float car;
        private int mouseX = 100;
        private int steer;
        private final float[] ox = new float[6];
        private final float[] oy = new float[6];
        private final boolean[] live = new boolean[6];
        private int spawn;
        private int crash;

        RacingScreen(BlockPos pos) {
            super(ArcadeGame.RACING, pos);
        }

        @Override
        protected void begin() {
            score = 0;
            car = 100;
            spawn = 20;
            crash = 0;
            steer = 0;
            for (int i = 0; i < 6; i++) {
                live[i] = false;
            }
        }

        @Override
        protected void gameTick() {
            if (crash > 0) {
                if (--crash == 0) {
                    finish(score, 0);
                }
                return;
            }
            float target = steer != 0 ? car + steer * 6 : mouseX;
            car += Math.max(-5, Math.min(5, target - car));
            car = Math.max(52, Math.min(148, car));
            float speed = 3.0F + ticks / 250.0F;
            if (--spawn <= 0) {
                spawn = Math.max(14, 34 - ticks / 40);
                for (int i = 0; i < 6; i++) {
                    if (!live[i]) {
                        live[i] = true;
                        ox[i] = 58 + RND.nextInt(85);
                        oy[i] = -14;
                        break;
                    }
                }
            }
            for (int i = 0; i < 6; i++) {
                if (live[i]) {
                    oy[i] += speed;
                    if (oy[i] > AH + 14) {
                        live[i] = false;
                    } else if (Math.abs(ox[i] - car) < 14 && Math.abs(oy[i] - 98) < 18) {
                        crash = 20;
                    }
                }
            }
            if (ticks % 20 == 0) {
                score = Math.min(30, score + 1);
            }
            if (ticks >= 600) {
                finish(score, 0);
            }
        }

        @Override
        protected boolean key(int k) {
            if (isLeft(k)) {
                steer = -1;
                return true;
            } else if (isRight(k)) {
                steer = 1;
                return true;
            }
            return false;
        }

        @Override
        public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
            if (isLeft(keyCode) || isRight(keyCode)) {
                steer = 0;
            }
            return super.keyReleased(keyCode, scanCode, modifiers);
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mx, int my) {
            mouseX = mx;
            g.fill(x, y, x + AW, y + AH, 0xFF1C5A1C);
            g.fill(x + 44, y, x + 156, y + AH, 0xFF404048);
            g.fill(x + 44, y, x + 47, y + AH, 0xFFE8E8E8);
            g.fill(x + 153, y, x + 156, y + AH, 0xFFE8E8E8);
            int off = (ticks * 4) % 24;
            for (int k = -1; k < 6; k++) {
                g.fill(x + 98, y + k * 24 + off, x + 102, y + k * 24 + off + 12, 0xFFE8D060);
            }
            for (int i = 0; i < 6; i++) {
                if (live[i]) {
                    g.fill(x + (int) ox[i] - 8, y + (int) oy[i] - 12, x + (int) ox[i] + 9, y + (int) oy[i] + 13, 0xFF3A6AE0);
                    g.fill(x + (int) ox[i] - 5, y + (int) oy[i] - 6, x + (int) ox[i] + 6, y + (int) oy[i] + 2, 0xFFA8D8F8);
                }
            }
            g.fill(x + (int) car - 8, y + 86, x + (int) car + 9, y + 111, crash > 0 ? 0xFFFFE070 : 0xFFE03030);
            g.fill(x + (int) car - 5, y + 92, x + (int) car + 6, y + 100, 0xFFA8D8F8);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), x + 3, y + 3, 0xFFFFFF, false);
        }
    }

    // ------------------------------------------------------------------ foosball

    static class FoosScreen extends ArcadeScreens.GameScreen {
        private float bx;
        private float by;
        private float vx;
        private float vy;
        private int rod = 60;
        private final float[] ai = {30, 60, 90};
        private int them;
        private int mouseY = 60;
        private int kick;
        private int freeze;

        FoosScreen(BlockPos pos) {
            super(ArcadeGame.FOOSBALL, pos);
        }

        private void serve() {
            bx = 100;
            by = 60;
            vx = RND.nextBoolean() ? 1.8F : -1.8F;
            vy = (RND.nextFloat() - 0.5F) * 2.0F;
            freeze = 15;
        }

        @Override
        protected void begin() {
            score = 0;
            them = 0;
            serve();
        }

        private float man(int i) {
            return rod - 36 + i * 36;
        }

        @Override
        protected void gameTick() {
            rod = Math.max(36, Math.min(84, mouseY));
            if (kick > 0) {
                kick--;
            }
            for (int i = 0; i < 3; i++) {
                float t = by - 0;
                float home = 30 + i * 30;
                float want = Math.abs(bx - 140) < 60 ? t : home;
                ai[i] += Math.max(-1.6F, Math.min(1.6F, want - ai[i]));
                ai[i] = Math.max(8, Math.min(112, ai[i]));
            }
            if (freeze > 0) {
                freeze--;
            } else {
                bx += vx;
                by += vy;
                if (by < 4 || by > 116) {
                    by = Math.max(4, Math.min(116, by));
                    vy = -vy;
                }
                if (bx < 4 && (by < 40 || by > 80)) {
                    bx = 4;
                    vx = Math.abs(vx);
                }
                if (bx > 196 && (by < 40 || by > 80)) {
                    bx = 196;
                    vx = -Math.abs(vx);
                }
                for (int i = 0; i < 3; i++) {
                    if (Math.abs(bx - 60) < 6 && Math.abs(by - man(i)) < 9) {
                        vx = kick > 0 ? 6.0F : Math.max(1.4F, Math.abs(vx) * 0.7F);
                        vy += (by - man(i)) * 0.15F;
                        bx = 67;
                    }
                    if (Math.abs(bx - 140) < 6 && Math.abs(by - ai[i]) < 9) {
                        vx = -Math.max(2.2F, Math.abs(vx) * 0.9F);
                        vy += (by - ai[i]) * 0.1F;
                        bx = 133;
                    }
                }
                vy = Math.max(-4.5F, Math.min(4.5F, vy));
                if (bx < -4) {
                    them++;
                    serve();
                } else if (bx > 204) {
                    score++;
                    serve();
                }
            }
            if (ticks >= 1200 || score >= 5 || them >= 5) {
                finish(Math.min(5, score), 0);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            kick = 5;
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                kick = 5;
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mx, int my) {
            mouseY = my;
            g.fill(x, y, x + AW, y + AH, 0xFF1E6A2E);
            g.fill(x + 99, y, x + 101, y + AH, 0x66FFFFFF);
            g.fill(x, y + 40, x + 3, y + 80, 0xFFE0E0E0);
            g.fill(x + AW - 3, y + 40, x + AW, y + 80, 0xFFE0E0E0);
            g.fill(x + 59, y, x + 61, y + AH, 0xFF9A9AA8);
            g.fill(x + 139, y, x + 141, y + AH, 0xFF9A9AA8);
            for (int i = 0; i < 3; i++) {
                g.fill(x + 55, y + (int) man(i) - 7, x + 65, y + (int) man(i) + 8, kick > 0 ? 0xFFFFE070 : 0xFF3A7AE0);
                g.fill(x + 135, y + (int) ai[i] - 7, x + 145, y + (int) ai[i] + 8, 0xFFE04040);
            }
            disc(g, x + (int) bx, y + (int) by, 3, 0xFFFFFFFF);
            g.drawString(font, score + " : " + them, x + 88, y + 3, 0xFFFFFF, false);
        }
    }

    // ------------------------------------------------------------------ skee-ball

    static class SkeeScreen extends ArcadeScreens.GameScreen {
        private int stage;
        private float lockX;
        private float lockY;
        private int balls;
        private int last;
        private int pause;

        SkeeScreen(BlockPos pos) {
            super(ArcadeGame.SKEE, pos);
        }

        private float aim() {
            return 100 + 85 * (float) Math.sin(ticks * 0.11);
        }

        private float power() {
            return (float) (Math.sin(ticks * 0.17) + 1.0) / 2.0F;
        }

        @Override
        protected void begin() {
            score = 0;
            stage = 0;
            balls = 0;
            last = -1;
            pause = 0;
        }

        @Override
        protected void gameTick() {
            if (pause > 0 && --pause == 0) {
                if (balls >= 9) {
                    finish(score, 0);
                } else {
                    stage = 0;
                }
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            if (pause > 0) {
                return true;
            }
            if (stage == 0) {
                lockX = aim();
                stage = 1;
            } else if (stage == 1) {
                lockY = 100 - power() * 90;
                float d = (float) Math.hypot(lockX - 100, lockY - 32);
                last = Math.max(0, Math.round(10 - d / 9.0F));
                score += last;
                balls++;
                stage = 2;
                pause = 22;
            }
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                return click(0, 0);
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mx, int my) {
            g.fill(x, y, x + AW, y + AH, 0xFF3A2A1A);
            int[] cols = {0xFF603820, 0xFF804A28, 0xFFA85C30, 0xFFD07038, 0xFFE8B040};
            int[] rad = {50, 38, 26, 15, 6};
            for (int i = 0; i < 5; i++) {
                disc(g, x + 100, y + 32, rad[i], cols[i]);
            }
            g.drawCenteredString(font, "10", x + 100, y + 28, 0xFF201008);
            if (stage == 0) {
                g.fill(x + (int) aim() - 1, y + 100, x + (int) aim() + 2, y + 118, 0xFFFFFFFF);
            } else {
                g.fill(x + (int) lockX - 1, y + 100, x + (int) lockX + 2, y + 118, 0xFF7CFFB0);
                if (stage == 1) {
                    int py = y + 100 - (int) (power() * 90);
                    g.fill(x + 190, y + 10, x + 196, y + 100, 0xFF202020);
                    g.fill(x + 188, py, x + 198, py + 3, 0xFFFFE070);
                }
            }
            if (stage == 2) {
                disc(g, x + (int) lockX, y + (int) lockY, 4, 0xFFFFFFFF);
                g.drawCenteredString(font, "+" + last, x + 100, y + 70, 0xFF7CFFB0);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), x + 3, y + 3, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.prop.balls_left", 9 - balls), x + AW - 70, y + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ darts

    static class DartsScreen extends ArcadeScreens.GameScreen {
        private int thrown;
        private int pause;
        private final int[] hx = new int[3];
        private final int[] hy = new int[3];
        private final int[] val = new int[3];

        DartsScreen(BlockPos pos) {
            super(ArcadeGame.DARTS, pos);
        }

        private float cx(int t) {
            return 100 + 40 * (float) Math.sin(t * 0.13) + 14 * (float) Math.sin(t * 0.31);
        }

        private float cy(int t) {
            return 60 + 32 * (float) Math.sin(t * 0.17 + 1.0) + 10 * (float) Math.cos(t * 0.29);
        }

        @Override
        protected void begin() {
            score = 0;
            thrown = 0;
            pause = 0;
        }

        @Override
        protected void gameTick() {
            if (pause > 0 && --pause == 0) {
                finish(score, 0);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            if (pause > 0 || thrown >= 3) {
                return true;
            }
            float x = cx(ticks);
            float y = cy(ticks);
            float d = (float) Math.hypot(x - 100, y - 60);
            int v = d < 5 ? 50 : d < 12 ? 25 : d < 30 ? 15 : d < 48 ? 10 : d < 56 ? 5 : 0;
            hx[thrown] = (int) x;
            hy[thrown] = (int) y;
            val[thrown] = v;
            thrown++;
            score += v;
            if (thrown >= 3) {
                pause = 30;
            }
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                return click(0, 0);
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int x, int y, int mx, int my) {
            g.fill(x, y, x + AW, y + AH, 0xFF20201C);
            disc(g, x + 100, y + 60, 56, 0xFF101010);
            disc(g, x + 100, y + 60, 48, 0xFFE8E0C0);
            disc(g, x + 100, y + 60, 30, 0xFF2A8A3A);
            disc(g, x + 100, y + 60, 12, 0xFFD03030);
            disc(g, x + 100, y + 60, 5, 0xFFF0F0F0);
            for (int i = 0; i < thrown; i++) {
                disc(g, x + hx[i], y + hy[i], 2, 0xFFFFE070);
            }
            if (thrown < 3) {
                int px = x + (int) cx(ticks);
                int py = y + (int) cy(ticks);
                g.fill(px - 6, py, px + 7, py + 1, 0xFFFFFFFF);
                g.fill(px, py - 6, px + 1, py + 7, 0xFFFFFFFF);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), x + 3, y + 3, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.prop.darts_left", 3 - thrown), x + AW - 62, y + AH - 10, 0x8A8FA3, false);
        }
    }
}
