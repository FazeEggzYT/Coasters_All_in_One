package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: build this pre-made coaster here, in this colour. */
public record CoasterPlacePacket(BlockPos origin, int dir, int layout, int colour) implements CustomPacketPayload {
    public static final Type<CoasterPlacePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "coaster_place"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CoasterPlacePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.origin);
                buf.writeVarInt(p.dir);
                buf.writeVarInt(p.layout);
                buf.writeVarInt(p.colour);
            },
            buf -> new CoasterPlacePacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(CoasterPlacePacket packet, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        boolean holding = player.getMainHandItem().is(CoasterControlPanel.COASTER_BLUEPRINT_ITEM.get())
                || player.getOffhandItem().is(CoasterControlPanel.COASTER_BLUEPRINT_ITEM.get());
        if (!holding || player.distanceToSqr(packet.origin.getX() + 0.5, packet.origin.getY(), packet.origin.getZ() + 0.5) > 64 * 64
                || !player.level().mayInteract(player, packet.origin)) {
            return;
        }
        Direction look = Direction.from2DDataValue(Math.floorMod(packet.dir, 4));
        CoasterBuilder.start(player, packet.origin, look, packet.layout, packet.colour);
    }
}
