package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.FreeOrient;
import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import dev.engine_room.flywheel.lib.transform.PoseTransformStack;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets a controlled moving structure turn about several axes at once (used by the Enterprise, Breakdance and Wave Swinger rides). */
@Mixin(value = ControlledContraptionEntity.class, remap = false)
public abstract class FreeOrientMixin implements FreeOrient {
    @Unique
    private boolean ccp$on;
    @Unique
    private final float[] ccp$cur = new float[4];
    @Unique
    private final float[] ccp$prev = new float[4];

    @Override
    public void ccp$orient(float rx, float ry, float rz, float ry2) {
        if (ccp$on) {
            System.arraycopy(ccp$cur, 0, ccp$prev, 0, 4);
        } else {
            ccp$prev[0] = rx;
            ccp$prev[1] = ry;
            ccp$prev[2] = rz;
            ccp$prev[3] = ry2;
        }
        ccp$cur[0] = rx;
        ccp$cur[1] = ry;
        ccp$cur[2] = rz;
        ccp$cur[3] = ry2;
        ccp$on = true;
    }

    @Override
    public void ccp$clearOrient() {
        ccp$on = false;
    }

    @Unique
    private float ccp$at(int i, float pt) {
        return ccp$prev[i] + (ccp$cur[i] - ccp$prev[i]) * pt;
    }

    @Inject(method = "applyRotation", at = @At("HEAD"), cancellable = true)
    private void ccp$apply(Vec3 localPos, float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        if (!ccp$on) {
            return;
        }
        Vec3 v = VecHelper.rotate(localPos, ccp$at(3, partialTicks), Direction.Axis.Y);
        v = VecHelper.rotate(v, ccp$at(2, partialTicks), Direction.Axis.Z);
        v = VecHelper.rotate(v, ccp$at(1, partialTicks), Direction.Axis.Y);
        v = VecHelper.rotate(v, ccp$at(0, partialTicks), Direction.Axis.X);
        cir.setReturnValue(v);
    }

    @Inject(method = "reverseRotation", at = @At("HEAD"), cancellable = true)
    private void ccp$reverse(Vec3 localPos, float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        if (!ccp$on) {
            return;
        }
        Vec3 v = VecHelper.rotate(localPos, -ccp$at(0, partialTicks), Direction.Axis.X);
        v = VecHelper.rotate(v, -ccp$at(1, partialTicks), Direction.Axis.Y);
        v = VecHelper.rotate(v, -ccp$at(2, partialTicks), Direction.Axis.Z);
        v = VecHelper.rotate(v, -ccp$at(3, partialTicks), Direction.Axis.Y);
        cir.setReturnValue(v);
    }

    @Inject(method = "getRotationState", at = @At("RETURN"))
    private void ccp$state(CallbackInfoReturnable<AbstractContraptionEntity.ContraptionRotationState> cir) {
        if (!ccp$on) {
            return;
        }
        AbstractContraptionEntity.ContraptionRotationState s = cir.getReturnValue();
        s.xRotation = ccp$cur[0];
        s.yRotation = ccp$cur[1];
        s.zRotation = ccp$cur[2];
        s.secondYRotation = ccp$cur[3];
    }

    @Inject(method = "applyLocalTransforms", at = @At("HEAD"), cancellable = true)
    private void ccp$local(PoseStack matrixStack, float partialTicks, CallbackInfo ci) {
        if (!ccp$on) {
            return;
        }
        AbstractContraptionEntity self = (AbstractContraptionEntity) (Object) this;
        PoseTransformStack nudge = TransformStack.of(matrixStack);
        nudge.nudge(self.getId());
        PoseTransformStack t = TransformStack.of(matrixStack);
        t.center();
        t.rotateDegrees(ccp$at(0, partialTicks), Direction.Axis.X);
        t.rotateDegrees(ccp$at(1, partialTicks), Direction.Axis.Y);
        t.rotateDegrees(ccp$at(2, partialTicks), Direction.Axis.Z);
        t.rotateDegrees(ccp$at(3, partialTicks), Direction.Axis.Y);
        t.uncenter();
        ci.cancel();
    }
}
