package com.example.coastercontrolpanel;

import it.unimi.dsi.fastutil.ints.IntList;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Behaviour of the drop 3 props (entrance, queue, transport, parades, hotel, security, utilities, maintenance, info tech). */
final class Park3 {
    private Park3() {
    }

    static final Set<String> TOGGLES = Set.of("queue_tv_screen", "misting_fan", "fuse_box");
    static final String[] SHOWS = {"show_dance", "show_band", "show_magic", "show_comedy"};
    static final String[] STOPS = {"stop_0", "stop_1", "stop_2", "stop_3"};
    static final int[] COLOURS = {0xE23B3B, 0x3B6BE2, 0x3BE26B, 0xE2C23B};
    static final String[] BANDS = {"Red Wristband", "Blue Wristband", "Green Wristband", "Gold Wristband"};

    private static Component prop(String key) {
        return Component.translatable("gui.coastercontrolpanel.prop." + key);
    }

    // ------------------------------------------------------------------ plain props

    static boolean use(String id, BlockState s, Level level, BlockPos pos, Player player, ServerLevel sl) {
        int st = s.getValue(ParkProps.ST);
        if (TOGGLES.contains(id)) {
            int n = st == 0 ? 1 : 0;
            level.setBlock(pos, s.setValue(ParkProps.ST, n), 3);
            ParkProps.sound(level, pos, id.equals("fuse_box") ? "lever" : "button", 1.0F);
            if (n == 1 && id.equals("misting_fan")) {
                level.scheduleTick(pos, s.getBlock(), 10);
            }
            return true;
        }
        switch (id) {
            case "stage_lights" -> {
                level.setBlock(pos, s.setValue(ParkProps.ST, (st + 1) % 4), 3);
                ParkProps.sound(level, pos, "lever", 1.0F + st * 0.1F);
                return true;
            }
            case "emergency_stop_button" -> {
                if (st == 0) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    level.scheduleTick(pos, s.getBlock(), 60);
                    ParkProps.sound(level, pos, "button", 0.7F);
                }
                return true;
            }
            case "bag_check_table" -> {
                ParkProps.say(player, "bag_checked");
                ParkProps.sound(level, pos, "chain", 1.0F);
                return true;
            }
            case "hand_stamp_station" -> {
                ParkProps.say(player, "stamped");
                ParkProps.sound(level, pos, "pop", 0.8F);
                return true;
            }
            case "weather_display" -> {
                ParkProps.say(player, "weather_display", Park2.weatherWord(level), Park2.temperature(level, pos));
                ParkProps.sound(level, pos, "button", 1.4F);
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    static boolean plainTick(String id, BlockState s, ServerLevel level, BlockPos pos) {
        int st = s.getValue(ParkProps.ST);
        switch (id) {
            case "emergency_stop_button" -> {
                if (st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                }
                return true;
            }
            case "misting_fan" -> {
                if (st == 1) {
                    ParkProps.puff(level, pos, "cloud", 6);
                    level.scheduleTick(pos, s.getBlock(), 20);
                }
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    // ------------------------------------------------------------------ screens

    static boolean has(ParkProps.Act blk) {
        return ParkUi.has(blk.id);
    }

    static void act(ServerPlayer p, ServerLevel level, BlockPos pos, ParkProps.Act blk, ParkProps.PropBE be, BlockState s, int action, int a, long now) {
        int st = s.getValue(ParkProps.ST);
        String name = p.getName().getString();
        switch (blk.id) {
            case "ticket_scanner_post" -> {
                if (action == 1) {
                    boolean ok = p.getAbilities().instabuild || ArcadeBlocks.count(p, CoasterControlPanel.TICKET_ITEM.get()) > 0;
                    if (ok) {
                        if (!p.getAbilities().instabuild) {
                            ArcadeBlocks.take(p, CoasterControlPanel.TICKET_ITEM.get(), 1);
                        }
                        be.v[0]++;
                        be.changed();
                        ParkProps.say(p, "scan_ok");
                    } else {
                        ParkProps.say(p, "scan_fail");
                    }
                    level.setBlock(pos, s.setValue(ParkProps.ST, ok ? 1 : 2), 3);
                    ParkProps.sound(level, pos, "bell", ok ? 1.8F : 0.6F);
                    level.scheduleTick(pos, blk, 40);
                }
            }
            case "wristband_dispenser" -> {
                if (action == 1 && a >= 0 && a < 4 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(new net.minecraft.world.item.Item[] {Items.RED_DYE, Items.BLUE_DYE, Items.GREEN_DYE, Items.YELLOW_DYE}[a], BANDS[a]));
                    ParkProps.sound(level, pos, "button", 1.4F);
                }
            }
            case "annual_pass_kiosk" -> {
                if (action == 1 && ParkProps.pay(p, 8)) {
                    ArcadeBlocks.give(p, ParkProps.named(CoasterControlPanel.TICKET_ITEM.get(), "Annual Pass: " + name));
                    ParkProps.sound(level, pos, "bell", 1.6F);
                } else if (action == 2) {
                    boolean has = false;
                    for (ItemStack it : p.getInventory().items) {
                        if (it.is(CoasterControlPanel.TICKET_ITEM.get()) && it.getHoverName().getString().startsWith("Annual Pass")) {
                            has = true;
                            break;
                        }
                    }
                    ParkProps.say(p, has ? "pass_yes" : "pass_no");
                }
            }
            case "queue_pause_sign" -> {
                if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    Park2.near(level, pos, 24, "queue_paused");
                } else if (action == 2) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    Park2.near(level, pos, 24, "queue_moving");
                } else if (action == 3) {
                    Park2.near(level, pos, 24, st == 1 ? "queue_paused" : "queue_moving");
                }
                ParkProps.sound(level, pos, "button", 1.2F);
            }
            case "monorail_station_platform" -> {
                if (action == 1) {
                    be.v[0] = (be.v[0] + 1) % 4;
                    be.changed();
                    ParkProps.sound(level, pos, "button", 1.3F);
                } else if (action == 2 && st == 0) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    level.scheduleTick(pos, blk, 100);
                    Park2.near(level, pos, 40, "train_coming", prop(STOPS[be.v[0] & 3]));
                    ParkProps.sound(level, pos, "bell", 0.8F);
                }
            }
            case "shuttle_bus_stop" -> {
                if (action == 1) {
                    Park2.near(level, pos, 40, "bus_coming");
                    ParkProps.sound(level, pos, "bell", 1.1F);
                }
            }
            case "ticket_pay_machine" -> {
                if (action == 1 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(CoasterControlPanel.TICKET_ITEM.get(), "Parking Ticket (1 hour)"));
                    ParkProps.sound(level, pos, "button", 1.6F);
                } else if (action == 2 && ParkProps.pay(p, 3)) {
                    ArcadeBlocks.give(p, ParkProps.named(CoasterControlPanel.TICKET_ITEM.get(), "Parking Ticket (all day)"));
                    ParkProps.sound(level, pos, "button", 1.2F);
                }
            }
            case "stage" -> {
                if (action == 2 && a >= 0 && a < 4) {
                    be.v[0] = a;
                    be.changed();
                    ParkProps.sound(level, pos, "button", 1.2F);
                } else if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    ParkProps.sound(level, pos, "bell", 1.0F);
                    Park2.near(level, pos, 40, "show_start", prop(SHOWS[be.v[0] & 3]));
                } else if (action == 3 && st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    Park2.near(level, pos, 40, "show_end");
                }
            }
            case "mascot_meet_spot" -> {
                if (action == 1) {
                    ParkProps.say(p, "mascot_wave");
                    ParkProps.sound(level, pos, "bell", 1.5F);
                } else if (action == 2) {
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                    ParkProps.say(p, "mascot_hug");
                    level.sendParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.6, p.getZ(), 6, 0.3, 0.2, 0.3, 0.02);
                } else if (action == 3 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Photo with the Mascot - " + name));
                    ParkProps.sound(level, pos, "button", 1.6F);
                }
            }
            case "confetti_cannon" -> {
                if (now < be.t) {
                    return;
                }
                be.t = now + 20;
                be.changed();
                int shots = action == 2 ? 3 : 1;
                for (int i = 0; i < shots; i++) {
                    level.sendParticles(ParticleTypes.FIREWORK, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 60, 0.25, 0.5, 0.25, 0.22);
                    level.sendParticles(ParticleTypes.CHERRY_LEAVES, pos.getX() + 0.5, pos.getY() + 1.4, pos.getZ() + 0.5, 30, 0.8, 0.8, 0.8, 0.02);
                }
                ParkProps.sound(level, pos, "cannon", 1.6F);
            }
            case "fireworks_launcher" -> {
                if (action == 1 && a >= 0 && a < 4) {
                    if (now < be.t) {
                        ParkProps.say(p, "reloading");
                        return;
                    }
                    be.t = now + 60;
                    be.changed();
                    ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
                    rocket.set(DataComponents.FIREWORKS, new Fireworks(2, List.of(
                            new FireworkExplosion(FireworkExplosion.Shape.LARGE_BALL, IntList.of(COLOURS[a]), IntList.of(0xFFFFFF), true, false))));
                    level.addFreshEntity(new FireworkRocketEntity(level, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, rocket));
                }
            }
            case "key_card_station" -> {
                if (action == 1) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Room Key Card: " + (101 + be.v[0])));
                    be.v[0] = (be.v[0] + 1) % 100;
                    be.changed();
                    ParkProps.sound(level, pos, "button", 1.7F);
                } else if (action == 2) {
                    be.v[0] = 0;
                    be.changed();
                }
            }
            case "security_booth" -> {
                if (action == 1) {
                    Park2.broadcast(level, "call_guard", name, pos.getX(), pos.getY(), pos.getZ());
                    ParkProps.sound(level, pos, "bell", 1.2F);
                } else if (action == 2) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    Park2.broadcast(level, "lockdown", pos.getX(), pos.getY(), pos.getZ());
                    ParkProps.sound(level, pos, "bell", 0.5F);
                } else if (action == 3) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    Park2.broadcast(level, "lockdown_end");
                }
            }
            case "cctv_camera" -> {
                if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, Math.max(0, st - 1)), 3);
                    ParkProps.sound(level, pos, "button", 1.5F);
                } else if (action == 2) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, Math.min(3, st + 1)), 3);
                    ParkProps.sound(level, pos, "button", 1.5F);
                } else if (action == 3) {
                    Park2.broadcast(level, "cctv_alert", pos.getX(), pos.getY(), pos.getZ());
                    ParkProps.sound(level, pos, "bell", 0.8F);
                }
            }
            case "control_room_desk" -> {
                if (action == 1) {
                    Park2.broadcast(level, "park_open_msg");
                    ParkProps.sound(level, pos, "bell", 1.6F);
                } else if (action == 2) {
                    Park2.broadcast(level, "park_closed_msg");
                    ParkProps.sound(level, pos, "bell", 0.7F);
                } else if (action == 3) {
                    ParkProps.say(p, "head_count", level.players().size());
                }
            }
            case "radio_base" -> {
                if (action >= 1 && action <= 4) {
                    if (now < be.t) {
                        ParkProps.say(p, "radio_wait");
                        return;
                    }
                    be.t = now + 200;
                    be.changed();
                    Park2.broadcast(level, "radio_call_" + action, name, pos.getX(), pos.getY(), pos.getZ());
                    ParkProps.sound(level, pos, "button", 1.3F);
                }
            }
            case "power_generator" -> {
                if (action == 1) {
                    ItemStack held = p.getMainHandItem();
                    int burn = held.isEmpty() ? 0 : held.getBurnTime(RecipeType.SMELTING);
                    if (burn <= 0) {
                        ParkProps.say(p, "gen_no_fuel");
                    } else {
                        if (!p.getAbilities().instabuild) {
                            held.shrink(1);
                        }
                        be.v[0] = Math.min(7200, be.v[0] + burn / 20);
                        be.changed();
                        ParkProps.sound(level, pos, "pickup", 0.8F);
                    }
                } else if (action == 2) {
                    if (be.v[0] <= 0) {
                        ParkProps.say(p, "gen_empty");
                    } else if (st == 0) {
                        level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                        level.scheduleTick(pos, blk, 20);
                        ParkProps.sound(level, pos, "lever", 1.0F);
                    }
                } else if (action == 3 && st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    ParkProps.sound(level, pos, "lever", 0.8F);
                }
            }
            case "electric_cabinet" -> {
                if (action >= 1 && action <= 3) {
                    be.v[action - 1] = be.v[action - 1] == 0 ? 1 : 0;
                    be.v[3] = be.v[0] + be.v[1] + be.v[2];
                    be.changed();
                    level.setBlock(pos, s.setValue(ParkProps.ST, be.v[3] > 0 ? 1 : 0), 3);
                    level.updateNeighborsAt(pos, blk);
                    ParkProps.sound(level, pos, "lever", 1.0F + action * 0.15F);
                }
            }
            case "speaker_control_box" -> {
                int vol = be.v[0] == 0 ? 2 : be.v[0];
                if (action >= 1 && action <= 3) {
                    float[][] chords = {{1.0F, 1.26F, 1.5F}, {1.19F, 0.89F, 1.19F}, {1.5F, 1.26F, 1.0F}};
                    for (float pitch : chords[action - 1]) {
                        level.playSound(null, pos, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, vol * 1.0F, pitch);
                    }
                } else if (action == 4) {
                    be.v[0] = Math.max(1, vol - 1);
                    be.changed();
                } else if (action == 5) {
                    be.v[0] = Math.min(3, vol + 1);
                    be.changed();
                }
            }
            case "app_kiosk" -> {
                if (action == 1) {
                    p.sendSystemMessage(Component.translatable("message.coastercontrolpanel.queue_times", 5 + level.random.nextInt(50),
                            5 + level.random.nextInt(50), 5 + level.random.nextInt(50), 5 + level.random.nextInt(50)));
                } else if (action == 2) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Park Map"));
                } else if (action == 3) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Voucher: Free Ice Cream (" + name + ")"));
                }
                ParkProps.sound(level, pos, "button", 1.5F);
            }
            case "digital_map" -> {
                if (action == 1) {
                    ParkProps.say(p, "map_here", p.getBlockX(), p.getBlockY(), p.getBlockZ());
                } else if (action == 2) {
                    be.v[0] = p.getBlockX();
                    be.v[1] = p.getBlockY();
                    be.v[2] = p.getBlockZ();
                    be.v[3] = 1;
                    be.changed();
                    ParkProps.say(p, "map_marked");
                } else if (action == 3) {
                    if (be.v[3] == 0) {
                        ParkProps.say(p, "map_no_home");
                    } else {
                        int dx = be.v[0] - p.getBlockX();
                        int dz = be.v[2] - p.getBlockZ();
                        Direction d = Direction.getNearest(dx, 0, dz);
                        ParkProps.say(p, "map_way", (int) Math.sqrt((double) dx * dx + (double) dz * dz), d.getName());
                    }
                }
                ParkProps.sound(level, pos, "button", 1.5F);
            }
            case "qr_sign" -> {
                if (action == 1) {
                    if (now < be.t) {
                        ParkProps.say(p, "qr_wait");
                    } else {
                        be.t = now + 1200;
                        be.changed();
                        ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "QR Voucher #" + (1000 + level.random.nextInt(9000))));
                        ParkProps.sound(level, pos, "button", 1.8F);
                    }
                }
            }
            case "interactive_globe" -> {
                if (action == 1) {
                    be.v[0] = level.random.nextInt(8);
                    be.changed();
                    level.setBlock(pos, s.setValue(ParkProps.ST, (st + 1) % 4), 3);
                    ParkProps.sound(level, pos, "note", 0.8F + level.random.nextFloat() * 0.8F);
                    ParkProps.say(p, "globe_stop", prop("globe_last_" + be.v[0]));
                }
            }
            default -> {
            }
        }
    }

    static boolean tick(ParkProps.Act blk, BlockState s, ServerLevel level, BlockPos pos, ParkProps.PropBE be, long now) {
        int st = s.getValue(ParkProps.ST);
        switch (blk.id) {
            case "ticket_scanner_post" -> {
                if (st != 0) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                }
                return true;
            }
            case "monorail_station_platform" -> {
                if (st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    ParkProps.sound(level, pos, "bell", 1.5F);
                    Park2.near(level, pos, 40, "train_arrived");
                }
                return true;
            }
            case "power_generator" -> {
                if (st == 1) {
                    if (be.v[0] <= 0) {
                        level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                        ParkProps.sound(level, pos, "lever", 0.6F);
                    } else {
                        be.v[0]--;
                        be.changed();
                        ParkProps.puff(level, pos, "smoke", 2);
                        level.scheduleTick(pos, blk, 20);
                    }
                }
                return true;
            }
            default -> {
                return false;
            }
        }
    }
}
