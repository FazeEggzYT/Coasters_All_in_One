package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;

/**
 * The movement of the Enterprise, Breakdance and Wave Swinger, free of Minecraft state. A ride has a few numbers (st):
 * st[0] is the power from 0 (still) to 1 (full), the others are angles in degrees. pose() gives, for one moving structure,
 * where it has moved to (dx, dy, dz, from where it started) and how it is turned (rx, ry, rz, ry2: see FreeOrient).
 */
final class FlatRidePrograms {
    static final int ENTERPRISE = 0;
    static final int BREAKDANCE = 1;
    static final int WAVE = 2;
    static final int STATE = 4;
    /** Arm length of the Enterprise: from the hinge to the wheel's hub, in blocks. */
    static final int ENTERPRISE_ARM = 10;
    static final float ENTERPRISE_FLAT_SECONDS = 20.0F;

    private FlatRidePrograms() {
    }

    static int bodies(int kind) {
        return kind == ENTERPRISE ? 2 : 9;
    }

    static float ease(float t) {
        float c = Math.max(0.0F, Math.min(1.0F, t));
        return c * c * (3.0F - 2.0F * c);
    }

    static void step(int kind, float[] st, float dt, boolean on, float rampUp, float rampDown) {
        st[0] = on ? Math.min(1.0F, st[0] + dt / rampUp) : Math.max(0.0F, st[0] - dt / rampDown);
        float p = st[0];
        switch (kind) {
            case ENTERPRISE -> {
                // st[3] = seconds of ride so far: it spins flat for 20 s, then the arm lifts and the wheel tips upright
                if (on) {
                    st[3] += dt;
                    st[1] = 85.0F * ease((st[3] - ENTERPRISE_FLAT_SECONDS) / 8.0F);
                } else {
                    st[1] = Math.max(0.0F, st[1] - dt * 85.0F / 8.0F);
                    if (p <= 0.0F) {
                        st[3] = 0.0F;
                    }
                }
                st[2] = (st[2] + 80.0F * Math.min(1.0F, p * 3.0F) * dt) % 360.0F;
            }
            case BREAKDANCE -> {
                st[1] = (st[1] + 38.0F * ease(p) * dt) % 360.0F;
                st[2] = (st[2] + 160.0F * ease(p) * dt) % 360.0F;
                st[3] = ease(p);
            }
            default -> {
                st[1] = (st[1] + 48.0F * ease(p) * dt) % 360.0F;
                st[2] = 44.0F * ease(p);
            }
        }
    }

    private static double[] rotX(double deg, double y, double z) {
        double r = Math.toRadians(deg);
        return new double[] {y * Math.cos(r) - z * Math.sin(r), y * Math.sin(r) + z * Math.cos(r)};
    }

    private static double[] rotY(double deg, double x, double z) {
        double r = Math.toRadians(deg);
        return new double[] {x * Math.cos(r) + z * Math.sin(r), -x * Math.sin(r) + z * Math.cos(r)};
    }

    /** out = {dx, dy, dz, rx, ry, rz, ry2} for structure number body. anchors[i] is where structure i starts. */
    static void pose(int kind, float[] st, int body, BlockPos[] anchors, double[] out) {
        java.util.Arrays.fill(out, 0.0);
        if (anchors == null || body >= anchors.length || anchors[0] == null || anchors[body] == null) {
            return;
        }
        double vx = anchors[body].getX() - anchors[0].getX();
        double vy = anchors[body].getY() - anchors[0].getY();
        double vz = anchors[body].getZ() - anchors[0].getZ();
        switch (kind) {
            case ENTERPRISE -> {
                double tilt = st[1];
                out[3] = tilt;
                if (body == 1) {
                    double[] r = rotX(tilt, vy, vz);
                    out[1] = r[0] - vy;
                    out[2] = r[1] - vz;
                    out[4] = st[2];
                }
            }
            case BREAKDANCE -> {
                double turn = st[1];
                out[4] = turn;
                if (body >= 1) {
                    double[] r = rotY(turn, vx, vz);
                    double azimuth = Math.atan2(-r[1], r[0]);
                    double bob = 1.5 * st[3] * Math.sin(2.0 * azimuth);
                    out[0] = r[0] - vx;
                    out[1] = bob;
                    out[2] = r[1] - vz;
                    out[4] = turn + (body % 2 == 0 ? 1.0 : -1.0) * st[2];
                }
            }
            default -> {
                double turn = st[1];
                out[4] = turn;
                if (body >= 1) {
                    double[] r = rotY(turn, vx, vz);
                    out[0] = r[0] - vx;
                    out[2] = r[1] - vz;
                    double phi = Math.toDegrees(Math.atan2(-vz, vx));
                    out[4] = turn + phi;
                    out[5] = st[2];
                    out[6] = -phi;
                }
            }
        }
    }
}
