package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.loading.FMLPaths;

/**
 * Custom pictures for the movie poster frame. The name typed on the poster is looked up as a PNG in the
 * "coaster_posters" folder of the game folder, then in resource packs under assets/coastercontrolpanel/textures/poster.
 * Client side only: other players need the same file to see the same picture.
 */
final class PosterTextures {
    private PosterTextures() {
    }

    private record Entry(ResourceLocation rl, long stamp, long checked) {
    }

    private static final Map<String, Entry> CACHE = new HashMap<>();

    static Path folder() {
        return FMLPaths.GAMEDIR.get().resolve("coaster_posters");
    }

    static void makeFolder() {
        try {
            Files.createDirectories(folder());
        } catch (Exception ignored) {
        }
    }

    private static String clean(String name) {
        String n = name.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_.\\- ]", "").replace(' ', '_');
        if (n.endsWith(".png")) {
            n = n.substring(0, n.length() - 4);
        }
        return n.replace("..", "");
    }

    /** The texture to draw for a name, or null when there is none. */
    static ResourceLocation get(String name) {
        String n = clean(name);
        if (n.isEmpty()) {
            return null;
        }
        long now = System.currentTimeMillis();
        Entry e = CACHE.get(n);
        if (e != null && now - e.checked < 3000) {
            return e.rl;
        }
        Minecraft mc = Minecraft.getInstance();
        Path file = folder().resolve(n + ".png");
        try {
            if (Files.isRegularFile(file)) {
                long stamp = Files.getLastModifiedTime(file).toMillis();
                if (e != null && e.rl != null && e.stamp == stamp) {
                    CACHE.put(n, new Entry(e.rl, stamp, now));
                    return e.rl;
                }
                try (InputStream in = Files.newInputStream(file)) {
                    NativeImage img = NativeImage.read(in);
                    ResourceLocation rl = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "poster_dyn/" + n);
                    mc.getTextureManager().register(rl, new DynamicTexture(img));
                    CACHE.put(n, new Entry(rl, stamp, now));
                    return rl;
                }
            }
        } catch (Exception ex) {
            CACHE.put(n, new Entry(null, 0, now));
            return null;
        }
        ResourceLocation pack = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/poster/" + n + ".png");
        ResourceLocation use = mc.getResourceManager().getResource(pack).isPresent() ? pack : null;
        CACHE.put(n, new Entry(use, 0, now));
        return use;
    }

    /** Draws the picture on the front of the poster. The pose is already at the front plane, centred. */
    static void draw(String name, PoseStack pose, MultiBufferSource buffers) {
        ResourceLocation rl = get(name);
        if (rl == null) {
            return;
        }
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(rl));
        PoseStack.Pose p = pose.last();
        float x = 5.0F / 16.0F;
        float y = 6.0F / 16.0F;
        int light = 15728880;
        vc.addVertex(p, -x, -y, 0).setColor(255, 255, 255, 255).setUv(0, 1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, 0, 0, 1);
        vc.addVertex(p, x, -y, 0).setColor(255, 255, 255, 255).setUv(1, 1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, 0, 0, 1);
        vc.addVertex(p, x, y, 0).setColor(255, 255, 255, 255).setUv(1, 0).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, 0, 0, 1);
        vc.addVertex(p, -x, y, 0).setColor(255, 255, 255, 255).setUv(0, 0).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, 0, 0, 1);
    }
}
