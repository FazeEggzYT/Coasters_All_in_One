package com.example.coastercontrolpanel;

/** The fifteen playable arcade machines. */
public enum ArcadeGame {
    CABINET("arcade_cabinet", 14.0F),
    CLAW("claw_machine", -1.0F),
    MOLE("whack_a_mole", 10.0F),
    STRENGTH("strength_tester", 2.0F),
    HOOPS("basketball_hoops", 8.0F),
    GALLERY("shooting_gallery", 9.0F),
    RINGS("ring_toss", 7.5F),
    COCONUT("coconut_shy", 4.0F),
    AIR_HOCKEY("air_hockey", -1.0F),
    PINBALL("pinball", -1.0F),
    DANCE("dance_machine", -1.0F),
    RACING("racing_cabinet", -1.0F),
    FOOSBALL("foosball", -1.0F),
    SKEE("skee_ball", -1.0F),
    DARTS("darts_board", -1.0F);

    public final String id;
    /** Height in 1/16 blocks of the middle of the score display on the front, or -1 for none. */
    public final float displayY;

    ArcadeGame(String id, float displayY) {
        this.id = id;
        this.displayY = displayY;
    }

    /** Highest score the server accepts. */
    public int maxScore(int sub) {
        return switch (this) {
            case CABINET -> sub == 1 ? 12 : 60;
            case CLAW -> 0;
            case MOLE -> 40;
            case STRENGTH -> 100;
            case HOOPS -> 20;
            case GALLERY -> 30;
            case RINGS -> 15;
            case COCONUT -> 5;
            case AIR_HOCKEY -> 7;
            case PINBALL -> 300;
            case DANCE -> 30;
            case RACING -> 30;
            case FOOSBALL -> 5;
            case SKEE -> 90;
            case DARTS -> 150;
        };
    }

    /** Prize tickets for a score. */
    public int tickets(int sub, int score) {
        return switch (this) {
            case CABINET -> sub == 0 ? Math.min(8, score / 2) : sub == 1 ? Math.min(6, score / 2) : Math.min(10, score / 6);
            case CLAW -> 0;
            case MOLE -> Math.min(12, score / 2);
            case STRENGTH -> score / 10;
            case HOOPS -> Math.min(10, score / 2);
            case GALLERY -> Math.min(12, score / 2);
            case RINGS -> Math.min(10, score * 2 / 3);
            case COCONUT -> score * 2;
            case AIR_HOCKEY -> Math.min(10, score * 3 / 2);
            case PINBALL -> Math.min(12, score / 25);
            case DANCE -> Math.min(12, score / 3);
            case RACING -> Math.min(10, score / 3);
            case FOOSBALL -> Math.min(10, score * 2);
            case SKEE -> Math.min(12, score / 6);
            case DARTS -> Math.min(12, score / 12);
        };
    }
}
