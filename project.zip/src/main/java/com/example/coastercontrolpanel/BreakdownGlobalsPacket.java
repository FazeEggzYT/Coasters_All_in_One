package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client: the global breakdown defaults. */
public record BreakdownGlobalsPacket(CompoundTag settings) implements CustomPacketPayload {
    public static final Type<BreakdownGlobalsPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "breakdown_globals"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BreakdownGlobalsPacket> CODEC = StreamCodec.composite(
            ByteBufCodecs.COMPOUND_TAG, BreakdownGlobalsPacket::settings, BreakdownGlobalsPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BreakdownGlobalsPacket p, IPayloadContext context) {
        BreakdownGlobals.client = BreakdownSettings.fromTag(p.settings);
    }
}
