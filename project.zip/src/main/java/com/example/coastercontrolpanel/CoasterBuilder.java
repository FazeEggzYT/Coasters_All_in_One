package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Places a pre-made coaster. It puts down Coasters Simulated anchor points at the layout positions, then joins them one by one
 * with the mod's own connect code, so the track, its checks and the path graph are the real thing. Everything from Coasters
 * Simulated is reached by name at runtime. If its code looks different, nothing is placed and the player is told.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public final class CoasterBuilder {
    public static final DyeColor[] COLOURS = {null, DyeColor.RED, DyeColor.ORANGE, DyeColor.YELLOW, DyeColor.LIME, DyeColor.CYAN,
            DyeColor.BLUE, DyeColor.PURPLE, DyeColor.BLACK};
    private static final String PLACEMENT = "dev.silvergold.simulatedcoasters.track.CoasterTrackPlacement";
    private static final int TICKS_PER_LINK = 3;
    private static final List<Job> JOBS = new ArrayList<>();

    private CoasterBuilder() {
    }

    private static final class Job {
        ServerLevel level;
        UUID player;
        List<BlockPos> anchors = new ArrayList<>();
        int next = 0;
        int links;
        int ok = 0;
        int wait = 0;
        int colour;
        int paintWait = -1;
    }

    private static Block anchorBlock() {
        ResourceLocation id = ResourceLocation.parse("simulatedcoasters:coaster_anchorpoint");
        return BuiltInRegistries.BLOCK.containsKey(id) ? BuiltInRegistries.BLOCK.get(id) : null;
    }

    private static Item trackItem() {
        ResourceLocation id = ResourceLocation.parse("simulatedcoasters:coaster_track");
        return BuiltInRegistries.ITEM.containsKey(id) ? BuiltInRegistries.ITEM.get(id) : null;
    }

    private static Direction heading(int h, Direction f) {
        return switch (h) {
            case 0 -> f;
            case 1 -> f.getOpposite();
            case 2 -> f.getCounterClockWise();
            case 3 -> f.getClockWise();
            case 4 -> Direction.UP;
            default -> Direction.DOWN;
        };
    }

    static BlockPos world(BlockPos origin, Direction f, int x, int y, int z) {
        Direction left = f.getCounterClockWise();
        return origin.offset(left.getStepX() * x + f.getStepX() * z, y, left.getStepZ() * x + f.getStepZ() * z);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static BlockState anchorState(Block block, Direction facing) {
        BlockState s = block.defaultBlockState();
        Property<?> p = block.getStateDefinition().getProperty("facing");
        if (p != null && p.getValueClass() == Direction.class) {
            s = s.setValue((Property) p, facing);
        }
        return s;
    }

    private static void say(ServerPlayer p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    public static void start(ServerPlayer player, BlockPos origin, Direction look, int layout, int colour, int station) {
        if (layout < 0 || layout >= CoasterLayouts.IDS.length) {
            return;
        }
        Block anchor = anchorBlock();
        Item track = trackItem();
        if (anchor == null || track == null) {
            say(player, "coaster_missing");
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        for (Job j : JOBS) {
            if (player.getUUID().equals(j.player)) {
                say(player, "coaster_busy");
                return;
            }
        }
        Direction f = look.getAxis().isHorizontal() ? look : Direction.NORTH;
        int[][] data = CoasterLayouts.DATA[layout];
        List<BlockPos> pos = new ArrayList<>();
        for (int[] a : data) {
            BlockPos p = world(origin, f, a[0], a[1], a[2]);
            if (!level.hasChunkAt(p)) {
                say(player, "coaster_unloaded");
                return;
            }
            if (p.getY() < level.getMinBuildHeight() + 1 || p.getY() >= level.getMaxBuildHeight() - 1) {
                say(player, "coaster_height");
                return;
            }
            BlockState now = level.getBlockState(p);
            if (!now.isAir() && !now.canBeReplaced()) {
                say(player, "coaster_blocked", p.getX(), p.getY(), p.getZ());
                return;
            }
            pos.add(p);
        }
        if (!player.getAbilities().instabuild && countTrack(player, track) < 1) {
            say(player, "coaster_need_track");
            return;
        }
        String sup = CoasterLayouts.SUPPORTS[layout];
        Block supBlock = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:" + sup));
        for (int i = 0; i < pos.size(); i++) {
            BlockPos p = pos.get(i);
            level.setBlock(p, anchorState(anchor, heading(data[i][4], f)), 3);
            if (data[i][4] == 4 && p.getY() - origin.getY() > 1) {
                BlockPos c = p.below();
                int guard = 0;
                while (guard++ < 70 && c.getY() > level.getMinBuildHeight() && (level.getBlockState(c).isAir() || level.getBlockState(c).canBeReplaced())
                        && c.getY() > origin.getY() - 1) {
                    level.setBlock(c, supBlock.defaultBlockState(), 2);
                    c = c.below();
                }
            }
        }
        Job job = new Job();
        job.level = level;
        job.player = player.getUUID();
        job.anchors = pos;
        job.links = pos.size();
        job.colour = colour;
        synchronized (JOBS) {
            JOBS.add(job);
        }
        buildStation(level, origin, f, station, colour > 0 && colour < COLOURS.length ? COLOURS[colour] : DyeColor.BLUE);
        say(player, "coaster_started", CoasterLayouts.NAMES[layout]);
    }

    private static void put(ServerLevel level, BlockPos p, BlockState s) {
        BlockState now = level.getBlockState(p);
        if (now.isAir() || now.canBeReplaced()) {
            level.setBlock(p, s, 3);
        }
    }

    /**
     * Dresses the station straight (x 0, z 0 to 16): 0 nothing, 1 platforms with a fence and an entrance gap, 2 platforms with a roof,
     * 3 roof, ride gates and lanterns.
     */
    static void buildStation(ServerLevel level, BlockPos origin, Direction f, int style, DyeColor dye) {
        if (style <= 0) {
            return;
        }
        BlockState floor = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:" + dye.getName() + "_concrete")).defaultBlockState();
        BlockState slab = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:smooth_stone_slab")).defaultBlockState();
        BlockState bars = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:iron_bars")).defaultBlockState();
        BlockState wall = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:stone_brick_wall")).defaultBlockState();
        BlockState lantern = BuiltInRegistries.BLOCK.get(ResourceLocation.parse("minecraft:lantern")).defaultBlockState();
        for (int side : new int[] {-1, 1}) {
            for (int x = 4; x <= 7; x++) {
                for (int z = 0; z <= 16; z++) {
                    put(level, world(origin, f, side * x, 0, z), x == 4 ? floor : slab);
                }
            }
            for (int z = 0; z <= 16; z++) {
                if (z < 6 || z > 10) {
                    put(level, world(origin, f, side * 7, 1, z), bars);
                }
            }
            if (style >= 2) {
                for (int z = 0; z <= 16; z += 4) {
                    for (int y = 1; y <= 4; y++) {
                        put(level, world(origin, f, side * 7, y, z), wall);
                    }
                }
            }
        }
        if (style >= 2) {
            for (int x = -7; x <= 7; x++) {
                for (int z = 0; z <= 16; z++) {
                    put(level, world(origin, f, x, 5, z), slab);
                }
            }
            if (style >= 3) {
                for (int z = 2; z <= 14; z += 6) {
                    put(level, world(origin, f, 0, 4, z), lantern.hasProperty(net.minecraft.world.level.block.LanternBlock.HANGING)
                            ? lantern.setValue(net.minecraft.world.level.block.LanternBlock.HANGING, true) : lantern);
                }
            }
        }
        if (style >= 3) {
            Block gate = CoasterControlPanel.GATE_BLOCK.get();
            for (int side : new int[] {-1, 1}) {
                BlockPos p = world(origin, f, side * 4, 1, 8);
                Direction toTrack = side > 0 ? f.getClockWise() : f.getCounterClockWise();
                BlockState gs = gate.defaultBlockState();
                Property<?> fp = gate.getStateDefinition().getProperty("facing");
                if (fp != null && fp.getValueClass() == Direction.class) {
                    gs = setDir(gs, fp, toTrack);
                }
                put(level, p, gs);
            }
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static BlockState setDir(BlockState s, Property<?> p, Direction d) {
        return s.setValue((Property) p, d);
    }

    private static int countTrack(ServerPlayer p, Item track) {
        int n = 0;
        for (ItemStack s : p.getInventory().items) {
            if (s.is(track)) {
                n += s.getCount();
            }
        }
        return n;
    }

    @SubscribeEvent
    public static void tick(ServerTickEvent.Post event) {
        synchronized (JOBS) {
            if (JOBS.isEmpty()) {
                return;
            }
            for (int i = JOBS.size() - 1; i >= 0; i--) {
                Job j = JOBS.get(i);
                ServerPlayer p = event.getServer().getPlayerList().getPlayer(j.player);
                if (p == null) {
                    JOBS.remove(i);
                    continue;
                }
                if (j.next < j.links) {
                    if (++j.wait < TICKS_PER_LINK) {
                        continue;
                    }
                    j.wait = 0;
                    BlockPos a = j.anchors.get(j.next);
                    BlockPos b = j.anchors.get((j.next + 1) % j.links);
                    j.next++;
                    if (connect(p, j.level, a, b)) {
                        j.ok++;
                    }
                    if (j.next >= j.links) {
                        j.paintWait = 50;
                    }
                } else if (--j.paintWait <= 0) {
                    if (j.colour > 0 && j.colour < COLOURS.length) {
                        paint(j);
                    }
                    p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + (j.ok == j.links ? "coaster_done" : "coaster_partial"), j.ok, j.links), false);
                    JOBS.remove(i);
                }
            }
        }
    }

    /** Joins two anchors the way the Coaster Track item does, with a track item in the main hand. */
    private static boolean connect(ServerPlayer p, ServerLevel level, BlockPos a, BlockPos b) {
        Item track = trackItem();
        Inventory inv = p.getInventory();
        int sel = inv.selected;
        ItemStack saved = inv.getItem(sel);
        int from = -1;
        for (int i = 0; i < inv.items.size(); i++) {
            if (inv.items.get(i).is(track)) {
                from = i;
                break;
            }
        }
        boolean made = false;
        boolean swapped = false;
        if (from >= 0) {
            if (from != sel) {
                ItemStack other = inv.getItem(from);
                inv.setItem(from, saved);
                inv.setItem(sel, other);
                swapped = true;
            }
        } else if (p.getAbilities().instabuild) {
            inv.setItem(sel, new ItemStack(track, 64));
            made = true;
        } else {
            return false;
        }
        boolean ok = false;
        try {
            Class<?> placement = Class.forName(PLACEMENT, true, CoasterBuilder.class.getClassLoader());
            Method first = null;
            Method second = null;
            for (Method m : placement.getMethods()) {
                if (m.getName().equals("applyAnchorFirstSelection") && m.getParameterCount() == 5) {
                    first = m;
                } else if (m.getName().equals("commitSecondAnchorOnServer") && m.getParameterCount() == 4) {
                    second = m;
                }
            }
            if (first != null && second != null) {
                ItemStack hand = p.getItemInHand(InteractionHand.MAIN_HAND);
                first.invoke(null, level, hand, a, p, InteractionHand.MAIN_HAND);
                Object r = second.invoke(null, p, InteractionHand.MAIN_HAND, a, b);
                ok = !(r instanceof Boolean bo) || bo;
            }
        } catch (Throwable t) {
            CoasterControlPanel.LOGGER.warn("Pre-made coaster link failed: {}", t.toString());
        } finally {
            if (made) {
                inv.setItem(sel, saved);
            } else if (swapped) {
                ItemStack back = inv.getItem(sel);
                inv.setItem(sel, saved);
                inv.setItem(from, back);
            }
        }
        return ok;
    }

    private static void paint(Job j) {
        int rgb = AnchorTrack.dyeRgb(COLOURS[j.colour]);
        for (int i = 0; i < j.links; i++) {
            BlockPos a = j.anchors.get(i);
            BlockPos b = j.anchors.get((i + 1) % j.links);
            AnchorTrack.tint(j.level, a, b, rgb, rgb);
            AnchorTrack.tint(j.level, b, a, rgb, rgb);
        }
    }
}
