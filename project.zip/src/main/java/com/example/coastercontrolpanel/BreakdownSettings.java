package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/**
 * Break Down Your Coaster: everything one breakdown zone can be set to, and the same shape for the global defaults.
 * A zone belongs to an existing element (a Brake Run, a chain lift, plain track...) and is stored on that element's
 * start anchor. Every value is clamped when it is read or built, so nothing a client sends can be out of range.
 */
public final class BreakdownSettings {
    public static final int T_MECH = 0, T_BRAKE = 1, T_LIFT = 2, T_GEN = 3;
    public static final int S_MINOR = 0, S_MOD = 1, S_MAJOR = 2;
    /** What the zone sits on. Used to pick sensible default weights. Station and inversion are not detected (yet). */
    public static final int E_GENERAL = 0, E_BRAKE = 1, E_LIFT = 2, E_LAUNCH = 3, E_BLOCK = 4, E_STOPPER = 5, E_TRIGGER = 6;
    public static final String[] ELEMENT_KEYS = {"general", "brake", "lift", "launch", "block", "stopper", "trigger"};
    public static final int MAX_SECONDS = 3600;

    /** The coaster this zone belongs to. Zones and Control Panels with the same name belong together. */
    public String coaster = "";
    public int element = E_GENERAL;
    /** Chance in percent (0 to 100) that a train passing through breaks down. */
    public float chance = 10.0F;
    /** Relative weights for Mechanical, Brake, Lift Hill and General. Scaled to 100% when used. */
    public final float[] types = {45.0F, 0.0F, 0.0F, 55.0F};
    /** Relative weights for Minor, Moderate, Major. Scaled to 100% when used. */
    public final float[] sev = {60.0F, 30.0F, 10.0F};
    /** Manual repair seconds, [type][severity]. */
    public final int[][] repair = {{10, 30, 60}, {15, 45, 90}, {30, 60, 120}, {10, 45, 90}};
    public boolean autoMinor = true;
    public boolean autoModerate = true;
    public int autoMinorSec = 60;
    public int autoModerateSec = 120;
    /** Operating minutes until wear reaches its full effect. */
    public int wearMinutes = 60;
    /** Extra chance at full wear, in percent of the base chance (100 = doubles). */
    public float wearBoost = 100.0F;
    /** Element reliability in percent: 100 = normal, 125 = fails a fifth less often, 80 = fails a quarter more often. */
    public float reliability = 100.0F;
    /** True where this zone uses its own values instead of the global defaults. */
    public boolean ovTypes, ovSev, ovRepair, ovAuto, ovWear;
    /** Second anchor of a zone on plain track (picked with the item). Null for a single-point zone or an element's own span. */
    public net.minecraft.core.BlockPos end;
    /** Operating seconds since the last successful manual maintenance. Never set from a client. */
    public float wear;

    public static BreakdownSettings defaults() {
        return new BreakdownSettings();
    }

    /** What a new zone starts with on a given kind of element. */
    public static BreakdownSettings forElement(int element) {
        BreakdownSettings b = new BreakdownSettings();
        b.element = Math.max(0, Math.min(ELEMENT_KEYS.length - 1, element));
        float[] t;
        switch (b.element) {
            case E_BRAKE -> {
                t = new float[] {10, 70, 0, 20};
                b.reliability = 90.0F;
            }
            case E_LIFT -> {
                t = new float[] {15, 0, 65, 20};
                b.reliability = 80.0F;
            }
            case E_LAUNCH -> t = new float[] {45, 10, 0, 45};
            case E_BLOCK -> t = new float[] {30, 40, 0, 30};
            case E_STOPPER -> t = new float[] {20, 60, 0, 20};
            case E_TRIGGER -> t = new float[] {50, 0, 0, 50};
            default -> t = new float[] {45, 0, 0, 55};
        }
        System.arraycopy(t, 0, b.types, 0, 4);
        return b;
    }

    public BreakdownSettings copy() {
        return fromTag(toTag());
    }

    private static float clamp(float v, float lo, float hi) {
        return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v));
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** The weights as fractions that add up to 1 (an all-zero list falls back to an even split over {@code allowed}). */
    public static float[] normalise(float[] w, boolean[] allowed) {
        float[] out = new float[w.length];
        float sum = 0.0F;
        for (int i = 0; i < w.length; i++) {
            out[i] = Math.max(0.0F, w[i]);
            sum += out[i];
        }
        if (sum <= 0.0F) {
            int n = 0;
            for (int i = 0; i < w.length; i++) {
                if (allowed == null || allowed[i]) {
                    n++;
                }
            }
            for (int i = 0; i < w.length; i++) {
                out[i] = n == 0 ? 1.0F / w.length : (allowed == null || allowed[i]) ? 1.0F / n : 0.0F;
            }
            return out;
        }
        for (int i = 0; i < w.length; i++) {
            out[i] /= sum;
        }
        return out;
    }

    /** This zone with the global defaults filled in for every group it does not override. */
    public BreakdownSettings resolved(BreakdownSettings g) {
        BreakdownSettings r = copy();
        if (g == null) {
            return r;
        }
        if (!ovTypes) {
            System.arraycopy(g.types, 0, r.types, 0, 4);
        }
        if (!ovSev) {
            System.arraycopy(g.sev, 0, r.sev, 0, 3);
        }
        if (!ovRepair) {
            for (int i = 0; i < 4; i++) {
                System.arraycopy(g.repair[i], 0, r.repair[i], 0, 3);
            }
        }
        if (!ovAuto) {
            r.autoMinor = g.autoMinor;
            r.autoModerate = g.autoModerate;
            r.autoMinorSec = g.autoMinorSec;
            r.autoModerateSec = g.autoModerateSec;
        }
        if (!ovWear) {
            r.wearMinutes = g.wearMinutes;
            r.wearBoost = g.wearBoost;
            r.reliability = g.reliability;
        }
        return r;
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putString("Coaster", coaster);
        t.putInt("Element", element);
        t.putFloat("Chance", chance);
        for (int i = 0; i < 4; i++) {
            t.putFloat("Type" + i, types[i]);
        }
        for (int i = 0; i < 3; i++) {
            t.putFloat("Sev" + i, sev[i]);
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                t.putInt("Rep" + i + j, repair[i][j]);
            }
        }
        t.putBoolean("AutoMinor", autoMinor);
        t.putBoolean("AutoMod", autoModerate);
        t.putInt("AutoMinorSec", autoMinorSec);
        t.putInt("AutoModSec", autoModerateSec);
        t.putInt("WearMin", wearMinutes);
        t.putFloat("WearBoost", wearBoost);
        t.putFloat("Reliab", reliability);
        t.putBoolean("OvTypes", ovTypes);
        t.putBoolean("OvSev", ovSev);
        t.putBoolean("OvRepair", ovRepair);
        t.putBoolean("OvAuto", ovAuto);
        t.putBoolean("OvWear", ovWear);
        t.putFloat("Wear", wear);
        if (end != null) {
            t.putLong("End", end.asLong());
        }
        return t;
    }

    public static BreakdownSettings fromTag(CompoundTag t) {
        BreakdownSettings b = new BreakdownSettings();
        if (t == null) {
            return b;
        }
        String name = t.getString("Coaster");
        b.coaster = name.length() > 32 ? name.substring(0, 32) : name;
        b.element = clamp(t.getInt("Element"), 0, ELEMENT_KEYS.length - 1);
        b.chance = t.contains("Chance") ? clamp(t.getFloat("Chance"), 0.0F, 100.0F) : b.chance;
        for (int i = 0; i < 4; i++) {
            if (t.contains("Type" + i)) {
                b.types[i] = clamp(t.getFloat("Type" + i), 0.0F, 100.0F);
            }
        }
        for (int i = 0; i < 3; i++) {
            if (t.contains("Sev" + i)) {
                b.sev[i] = clamp(t.getFloat("Sev" + i), 0.0F, 100.0F);
            }
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                if (t.contains("Rep" + i + j)) {
                    b.repair[i][j] = clamp(t.getInt("Rep" + i + j), 1, MAX_SECONDS);
                }
            }
        }
        if (t.contains("AutoMinor")) {
            b.autoMinor = t.getBoolean("AutoMinor");
            b.autoModerate = t.getBoolean("AutoMod");
            b.autoMinorSec = clamp(t.getInt("AutoMinorSec"), 1, MAX_SECONDS);
            b.autoModerateSec = clamp(t.getInt("AutoModSec"), 1, MAX_SECONDS);
        }
        if (t.contains("WearMin")) {
            b.wearMinutes = clamp(t.getInt("WearMin"), 1, 600);
            b.wearBoost = clamp(t.getFloat("WearBoost"), 0.0F, 1000.0F);
            b.reliability = clamp(t.getFloat("Reliab"), 10.0F, 500.0F);
        }
        b.ovTypes = t.getBoolean("OvTypes");
        b.ovSev = t.getBoolean("OvSev");
        b.ovRepair = t.getBoolean("OvRepair");
        b.ovAuto = t.getBoolean("OvAuto");
        b.ovWear = t.getBoolean("OvWear");
        b.wear = Math.max(0.0F, Float.isNaN(t.getFloat("Wear")) ? 0.0F : t.getFloat("Wear"));
        if (t.contains("End")) {
            b.end = net.minecraft.core.BlockPos.of(t.getLong("End"));
        }
        return b;
    }
}
