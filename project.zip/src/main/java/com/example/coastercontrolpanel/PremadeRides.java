package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Complete rides, placed in one go. The player stands where the ride faces; everything is built from the mod's own
 * blocks plus a seat from the player's mods (Coaster Seats when installed, Create's seats otherwise).
 */
public final class PremadeRides {
    private PremadeRides() {
    }

    public static final int DROP_TOWER = 0;
    public static final int SWING = 1;
    public static final int FERRIS = 2;
    public static final int TEACUP = 3;
    public static final int PIRATE = 4;
    public static final int GYRO = 5;
    public static final int CAROUSEL = 6;
    public static final int BUMPER = 7;
    public static final int TIMEMACHINE = 8;

    /** Maps ride coordinates (u across, v up, w along the axle) to the world. */
    private static final class Grid {
        final Level level;
        final BlockPos origin;
        final Direction.Axis axis;

        Grid(Level level, BlockPos origin, Direction.Axis axis) {
            this.level = level;
            this.origin = origin;
            this.axis = axis;
        }

        BlockPos at(int u, int v, int w) {
            return axis == Direction.Axis.X ? origin.offset(w, v, u) : origin.offset(u, v, w);
        }

        void set(int u, int v, int w, BlockState state) {
            level.setBlock(at(u, v, w), state, 3);
        }
    }

    private static BlockState seat(int towardU, int towardW) {
        BlockState state = null;
        for (String id : new String[]{"coasterfins:white_coaster_seat", "create:white_seat"}) {
            var opt = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(id));
            if (opt.isPresent()) {
                state = opt.get().defaultBlockState();
                break;
            }
        }
        if (state == null) {
            return Blocks.OAK_STAIRS.defaultBlockState();
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            Direction d = Math.abs(towardU) >= Math.abs(towardW)
                    ? (towardU >= 0 ? Direction.EAST : Direction.WEST)
                    : (towardW >= 0 ? Direction.SOUTH : Direction.NORTH);
            state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, d);
        }
        return state;
    }

    private static BlockState with(Block block, Direction.Axis axis) {
        BlockState s = block.defaultBlockState();
        if (s.hasProperty(FerrisBlocks.WheelPart.AXIS)) {
            s = s.setValue(FerrisBlocks.WheelPart.AXIS, axis);
        } else if (s.hasProperty(SwingBlocks.PivotBlock.AXIS)) {
            s = s.setValue(SwingBlocks.PivotBlock.AXIS, axis);
        }
        return s;
    }

    public static void place(Level level, BlockPos origin, Direction facing, int kind) {
        switch (kind) {
            case DROP_TOWER -> dropTower(level, origin);
            case SWING -> swing(level, origin, facing.getAxis(), 20, 16, false, 10);
            case TEACUP -> teacup(level, origin);
            case PIRATE -> pirate(level, origin, facing.getAxis(), 9, 6, false);
            case GYRO -> gyro(level, origin, facing.getAxis(), 11);
            case CAROUSEL -> carousel(level, origin, new int[]{3, 6}, new int[]{8, 14});
            case BUMPER -> bumper(level, origin);
            case TIMEMACHINE -> timeMachine(level, origin, facing.getAxis(), 1, 8, 8);
            default -> ferris(level, origin, facing.getAxis(), 12, 12, 20, 14);
        }
    }

    /** The extra flat rides. Each one is a bearing and a structure that moves in a way the other rides do not. */
    public static boolean placeVariant(String id, Level level, BlockPos origin, Direction facing) {
        switch (id) {
            case "top_spin" -> topSpin(level, origin, facing);
            case "ranger_ride" -> ranger(level, origin, facing);
            case "rocking_tug" -> rockingTug(level, origin, facing);
            case "enterprise_ride" -> enterprise(level, origin);
            case "breakdance_ride" -> breakdance(level, origin);
            case "wave_swinger" -> waveSwinger(level, origin);
            default -> {
                return false;
            }
        }
        return true;
    }

    /** Local frame for the bearing rides: a runs to the right of the player, b away from the player, v up. */
    private static final class Frame {
        final Level level;
        final BlockPos origin;
        final Direction f;
        final Direction r;

        Frame(Level level, BlockPos origin, Direction facing) {
            this.level = level;
            this.origin = origin;
            this.f = facing;
            this.r = facing.getClockWise();
        }

        BlockPos at(int a, int v, int b) {
            return origin.offset(r.getStepX() * a + f.getStepX() * b, v, r.getStepZ() * a + f.getStepZ() * b);
        }

        void set(int a, int v, int b, BlockState s) {
            level.setBlock(at(a, v, b), s, 3);
        }

        void floor(int a0, int a1, int b0, int b1) {
            for (int a = a0; a <= a1; a++) {
                for (int b = b0; b <= b1; b++) {
                    set(a, -1, b, Blocks.POLISHED_ANDESITE.defaultBlockState());
                }
            }
        }

        /** A 3 wide tower of iron, up to height h, with a footing. */
        void tower(int a, int h) {
            for (int b = -1; b <= 1; b++) {
                for (int v = 0; v <= h; v++) {
                    set(a, v, b, Blocks.IRON_BLOCK.defaultBlockState());
                }
            }
            for (int b = -2; b <= 2; b++) {
                for (int da = -1; da <= 1; da++) {
                    set(a + da, 0, b, Blocks.IRON_BLOCK.defaultBlockState());
                }
            }
        }

        /** The bearing on top of a tower at a, with its plate on the side towards the middle of the ride. */
        void bearing(int a, int v, Block bearing, int towardsMiddle, java.util.function.Consumer<SwivelSettings> cfg) {
            Direction side = towardsMiddle > 0 ? r : r.getOpposite();
            set(a, v, 0, bearing.defaultBlockState().setValue(SwivelBlocks.BearingBlock.FACING, side));
            set(a + towardsMiddle, v, 0, CoasterControlPanel.SWIVEL_PLATE_BLOCK.get().defaultBlockState());
            if (level.getBlockEntity(at(a, v, 0)) instanceof SwivelBlockEntity be) {
                SwivelSettings s = new SwivelSettings();
                cfg.accept(s);
                s.axis = r.getAxis() == Direction.Axis.X ? 1 : 3;
                s.carryAll = true;
                s.reach = 14;
                be.applyConfig(s.toTag());
            }
        }

        BlockState seat(Direction d) {
            BlockState s = PremadeRides.seat(0, 1);
            if (s.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
                s = s.setValue(BlockStateProperties.HORIZONTAL_FACING, d);
            }
            return s;
        }
    }

    // ---------------------------------------------------------------- Top Spin: a seat bank that flips right over

    private static void topSpin(Level level, BlockPos origin, Direction facing) {
        Frame g = new Frame(level, origin, facing);
        int h = 9;
        BlockState iron = Blocks.IRON_BLOCK.defaultBlockState();
        g.floor(-10, 10, -7, 7);
        g.tower(-6, h + 1);
        g.tower(6, h + 1);
        // the axle, from the plate across the whole bank
        for (int a = -4; a <= 4; a++) {
            g.set(a, h, 0, iron);
        }
        // the bank hangs under the axle: a spine, and a row of seats on each side facing outwards
        for (int a = -3; a <= 3; a++) {
            for (int v = h - 4; v <= h - 1; v++) {
                g.set(a, v, 0, iron);
            }
            g.set(a, h - 3, 1, g.seat(facing));
            g.set(a, h - 3, -1, g.seat(facing.getOpposite()));
            g.set(a, h - 4, 1, Blocks.IRON_BARS.defaultBlockState());
            g.set(a, h - 4, -1, Blocks.IRON_BARS.defaultBlockState());
        }
        g.bearing(-6, h, CoasterControlPanel.FLIP_BEARING_BLOCK.get(), 1, s -> {
            s.flipPos = 300.0F;
            s.flipNeg = 300.0F;
            s.returnZero = false;
            s.pause = 2.0F;
            s.reps = 3;
            s.speed = 70.0F;
            s.smooth = true;
        });
    }

    // ---------------------------------------------------------------- Ranger: a beam with a pod on each end, turning end over end

    private static void ranger(Level level, BlockPos origin, Direction facing) {
        Frame g = new Frame(level, origin, facing);
        int h = 11;
        BlockState iron = Blocks.IRON_BLOCK.defaultBlockState();
        g.floor(-9, 9, -8, 8);
        g.tower(-6, h + 1);
        // a brace on the far side, so the tower stands firm
        for (int v = 0; v <= 4; v++) {
            g.set(-7, v, 2, iron);
            g.set(-7, v, -2, iron);
        }
        // the beam stands up against the plate
        for (int v = h - 8; v <= h + 8; v++) {
            g.set(-4, v, 0, iron);
        }
        for (int end : new int[]{h + 8, h - 8}) {
            for (int b = -2; b <= 2; b++) {
                g.set(-4, end, b, iron);
            }
            for (int b : new int[]{-2, -1, 1, 2}) {
                g.set(-3, end, b, g.seat(g.r));
            }
        }
        g.bearing(-6, h, CoasterControlPanel.SPIN_BEARING_BLOCK.get(), 1, s -> {
            s.spinAmount = 0.0F;
            s.spinDir = 0;
            s.speed = 40.0F;
        });
    }

    // ---------------------------------------------------------------- Rocking Tug: a boat that rocks harder and harder

    private static void rockingTug(Level level, BlockPos origin, Direction facing) {
        Frame g = new Frame(level, origin, facing);
        int h = 8;
        BlockState iron = Blocks.IRON_BLOCK.defaultBlockState();
        g.floor(-10, 10, -8, 8);
        g.tower(-6, h + 1);
        g.tower(6, h + 1);
        for (int a = -4; a <= 4; a++) {
            g.set(a, h, 0, iron);
        }
        BlockState deck = Blocks.SPRUCE_PLANKS.defaultBlockState();
        for (int a : new int[]{-2, 2}) {
            for (int v = h - 4; v <= h - 1; v++) {
                g.set(a, v, 0, iron);
            }
        }
        for (int a = -3; a <= 3; a++) {
            for (int b = -5; b <= 5; b++) {
                if (Math.abs(b) < 5 || Math.abs(a) < 3) {
                    g.set(a, h - 5, b, deck);
                }
            }
        }
        for (int a : new int[]{-1, 1}) {
            for (int b : new int[]{-4, -3, -2, 2, 3, 4}) {
                g.set(a, h - 4, b, g.seat(a < 0 ? g.r : g.r.getOpposite()));
            }
        }
        g.bearing(-6, h, CoasterControlPanel.ROCK_BEARING_BLOCK.get(), 1, s -> {
            s.swayAmp = 38.0F;
            s.swayPeriod = 3.4F;
        });
    }

    // ---------------------------------------------------------------- the three rides with moving structures that tilt and spin at once
    // They are built the same way on every side (the Enterprise arm points north), because the movement is worked out from where the parts are.

    private static void ridePart(Level level, BlockPos o, int x, int y, int z, int index) {
        level.setBlock(o.offset(x, y, z), CoasterControlPanel.RIDE_PART_BLOCK.get().defaultBlockState()
                .setValue(FlatRideBlocks.PartBlock.INDEX, index), 3);
    }

    private static void rideBlock(Level level, BlockPos o, int x, int y, int z, BlockState s) {
        level.setBlock(o.offset(x, y, z), s, 3);
    }

    private static BlockState seatFacing(Direction d) {
        return seat(d.getStepX(), d.getStepZ());
    }

    private static Direction cardinal(double dx, double dz) {
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? Direction.EAST : Direction.WEST;
        }
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private static void rideFloor(Level level, BlockPos o, int x1, int z1, int x2, int z2) {
        for (int x = x1; x <= x2; x++) {
            for (int z = z1; z <= z2; z++) {
                rideBlock(level, o, x, -1, z, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    private static void startBlock(Level level, BlockPos o, int x, int z, int kind, java.util.List<BlockPos> anchors) {
        rideBlock(level, o, x, 0, z, CoasterControlPanel.FLAT_RIDE_BASE_BLOCK.get().defaultBlockState());
        if (level.getBlockEntity(o.offset(x, 0, z)) instanceof FlatRideBlockEntity be) {
            be.configure(kind, anchors);
        }
    }

    /** A line of ride part cells for a spoke: the axis directions are straight, the diagonals are a thick staircase so they stay joined. */
    private static void spoke(Level level, BlockPos o, int cx, int y, int cz, int dx, int dz, int length, int index) {
        if (dx == 0 || dz == 0) {
            for (int i = 1; i <= length; i++) {
                ridePart(level, o, cx + dx * i, y, cz + dz * i, index);
            }
        } else {
            for (int i = 1; i <= length; i++) {
                ridePart(level, o, cx + dx * i, y, cz + dz * i, index);
                ridePart(level, o, cx + dx * (i + 1), y, cz + dz * i, index);
            }
        }
    }

    private static final int[][] DIRS8 = {{1, 0}, {1, -1}, {0, -1}, {-1, -1}, {-1, 0}, {-1, 1}, {0, 1}, {1, 1}};

    /** Enterprise: a wheel on a long arm. The arm rises and the wheel tilts from lying flat to standing up, spinning all the time. */
    private static void enterprise(Level level, BlockPos o) {
        int len = FlatRidePrograms.ENTERPRISE_ARM;
        rideFloor(level, o, -11, -len - 9, 11, 6);
        for (int s : new int[]{-2, 2}) {
            ridePart(level, o, s, 0, 0, FlatRideBlocks.FIXED);
            ridePart(level, o, s, 1, 0, FlatRideBlocks.FIXED);
        }
        for (int z = -len; z <= 0; z++) {
            for (int x = -1; x <= 1; x++) {
                ridePart(level, o, x, 1, z, 0);
            }
        }
        ridePart(level, o, 0, 2, -len, 1);
        int hy = 3;
        int hz = -len;
        for (int x = -8; x <= 8; x++) {
            for (int z = -8; z <= 8; z++) {
                double r = Math.sqrt(x * x + z * z);
                if (r <= 1.5 || (r >= 6.2 && r <= 7.6)) {
                    ridePart(level, o, x, hy, hz + z, 1);
                }
            }
        }
        for (int[] d : DIRS8) {
            spoke(level, o, 0, hy, hz, d[0], d[1], d[0] == 0 || d[1] == 0 ? 6 : 4, 1);
        }
        for (int[] d : DIRS8) {
            int cx = d[0] == 0 || d[1] == 0 ? d[0] * 5 : d[0] * 4;
            int cz = d[0] == 0 || d[1] == 0 ? d[1] * 5 : d[1] * 4;
            rideBlock(level, o, cx, hy + 1, hz + cz, seatFacing(cardinal(-cx, -cz)));
            rideBlock(level, o, cx + (d[0] == 0 ? 0 : d[0]), hy + 1, hz + cz + (d[1] == 0 ? 0 : d[1]), Blocks.IRON_BARS.defaultBlockState());
        }
        java.util.List<BlockPos> anchors = new java.util.ArrayList<>();
        anchors.add(o.offset(0, 1, 0));
        anchors.add(o.offset(0, hy, hz));
        startBlock(level, o, 4, 2, FlatRidePrograms.ENTERPRISE, anchors);
    }

    /** Breakdance: a turning platform with eight cars that spin on the end of it, rising and falling as they go round. */
    private static void breakdance(Level level, BlockPos o) {
        rideFloor(level, o, -12, -12, 12, 12);
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                ridePart(level, o, x, 0, z, FlatRideBlocks.FIXED);
                ridePart(level, o, x, 1, z, FlatRideBlocks.FIXED);
            }
        }
        ridePart(level, o, 0, 2, 0, FlatRideBlocks.FIXED);
        int y = 3;
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                if (x * x + z * z <= 5) {
                    ridePart(level, o, x, y, z, 0);
                }
            }
        }
        for (int[] d : DIRS8) {
            spoke(level, o, 0, y, 0, d[0], d[1], d[0] == 0 || d[1] == 0 ? 5 : 3, 0);
        }
        java.util.List<BlockPos> anchors = new java.util.ArrayList<>();
        anchors.add(o.offset(0, y, 0));
        for (int k = 0; k < 8; k++) {
            double phi = Math.toRadians(k * 45.0);
            int cx = (int) Math.round(7.0 * Math.cos(phi));
            int cz = -(int) Math.round(7.0 * Math.sin(phi));
            int idx = k + 1;
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    ridePart(level, o, cx + x, y, cz + z, idx);
                }
            }
            ridePart(level, o, cx, y + 1, cz, idx);
            ridePart(level, o, cx, y + 2, cz, idx);
            rideBlock(level, o, cx + 1, y + 1, cz, seatFacing(Direction.EAST));
            rideBlock(level, o, cx - 1, y + 1, cz, seatFacing(Direction.WEST));
            rideBlock(level, o, cx, y + 1, cz + 1, seatFacing(Direction.SOUTH));
            rideBlock(level, o, cx, y + 1, cz - 1, seatFacing(Direction.NORTH));
            anchors.add(o.offset(cx, y, cz));
        }
        startBlock(level, o, 4, 10, FlatRidePrograms.BREAKDANCE, anchors);
    }

    /** Wave Swinger: a tall tower with a turning crown. Eight chairs hang on chains and swing out as it speeds up. */
    private static void waveSwinger(Level level, BlockPos o) {
        rideFloor(level, o, -14, -14, 14, 14);
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                ridePart(level, o, x, 0, z, FlatRideBlocks.FIXED);
                ridePart(level, o, x, 1, z, FlatRideBlocks.FIXED);
            }
        }
        for (int yy = 2; yy <= 12; yy++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    ridePart(level, o, x, yy, z, FlatRideBlocks.FIXED);
                }
            }
        }
        int y = 13;
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                ridePart(level, o, x, y, z, 0);
            }
        }
        ridePart(level, o, 0, y + 1, 0, 0);
        ridePart(level, o, 0, y + 2, 0, 0);
        for (int[] d : DIRS8) {
            spoke(level, o, 0, y, 0, d[0], d[1], d[0] == 0 || d[1] == 0 ? 6 : 3, 0);
        }
        java.util.List<BlockPos> anchors = new java.util.ArrayList<>();
        anchors.add(o.offset(0, y, 0));
        for (int k = 0; k < 8; k++) {
            double phi = Math.toRadians(k * 45.0);
            int cx = (int) Math.round(7.0 * Math.cos(phi));
            int cz = -(int) Math.round(7.0 * Math.sin(phi));
            int idx = k + 1;
            ridePart(level, o, cx, y, cz, idx);
            for (int yy = y - 1; yy >= y - 6; yy--) {
                rideBlock(level, o, cx, yy, cz, Blocks.CHAIN.defaultBlockState());
            }
            Direction tangent = cardinal(-Math.sin(phi), -Math.cos(phi));
            rideBlock(level, o, cx, y - 7, cz, seatFacing(tangent));
            anchors.add(o.offset(cx, y, cz));
        }
        startBlock(level, o, 4, 10, FlatRidePrograms.WAVE, anchors);
    }

    private static void platform(Grid g, int u0, int u1, int w0, int w1) {
        for (int u = u0; u <= u1; u++) {
            for (int w = w0; w <= w1; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    // ---------------------------------------------------------------- Drop Tower: a 32 block tower

    private static void dropTower(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Z);
        platform(g, -6, 6, -6, 6);
        g.set(0, 0, 0, CoasterControlPanel.DROP_TOWER_BASE_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.DROP_TOWER_SECTION_BLOCK.get().defaultBlockState();
        // a 3 by 3 tower: the middle column is the one that counts, the rest is the thick body
        for (int y = 1; y <= 32; y++) {
            for (int u = -1; u <= 1; u++) {
                for (int w = -1; w <= 1; w++) {
                    g.set(u, y, w, section);
                }
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, 33, w, Blocks.IRON_BLOCK.defaultBlockState());
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                if (u != 0 || w != 0) {
                    g.set(u, 0, w, Blocks.IRON_BLOCK.defaultBlockState());
                }
            }
        }
        // the carriage: a ring of 24 seats with a frame around them, three blocks tall
        BlockState frame = CoasterControlPanel.DROP_TOWER_FRAME_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 3; y++) {
            for (int u = -4; u <= 4; u++) {
                for (int w = -4; w <= 4; w++) {
                    if (Math.max(Math.abs(u), Math.abs(w)) == 4) {
                        g.set(u, y, w, frame);
                    }
                }
            }
        }
        for (int u = -3; u <= 3; u++) {
            for (int w = -3; w <= 3; w++) {
                if (Math.max(Math.abs(u), Math.abs(w)) == 3) {
                    g.set(u, 1, w, seat(u, w));
                }
            }
        }
        g.set(6, 0, -6, CoasterControlPanel.DROP_TOWER_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Swing Ride, built like Rush: long arm, gondola near the ground

    private static void swing(Level level, BlockPos origin, Direction.Axis axis, int top, int arms, boolean plusOnly, int gk) {
        Grid g = new Grid(level, origin, axis);
        int hub = top - arms - 1;
        int aw = 7; // the arm hangs outside the frame, at the end of the axle
        platform(g, -14, 14, -14, 14);
        BlockState section = CoasterControlPanel.SWING_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        // one tall A-frame in the middle, three blocks thick, like Rush
        for (int w = -1; w <= 1; w++) {
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, top - 1, leg * 8, 0)) {
                    g.set(p[0], p[1], w, section);
                    g.set(p[0] + (leg > 0 ? -1 : 1), p[1], w, section);
                }
            }
            g.set(0, top, w, section);
            g.set(1, top - 1, w, section);
            g.set(-1, top - 1, w, section);
            for (int u = -3; u <= 3; u++) {
                g.set(u, 7, w, section);
            }
        }
        BlockState frame = CoasterControlPanel.SWING_FRAME_BLOCK.get().defaultBlockState();
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        // two arms, one each side of the frame, on one axle: they swing opposite ways, like Rush
        for (int side : plusOnly ? new int[]{1} : new int[]{-1, 1}) {
            int pw = side * aw;
            for (int k = 2; k < aw; k++) {
                g.set(0, top, side * k, beam);
            }
            g.set(0, top, pw, with(CoasterControlPanel.SWING_PIVOT_BLOCK.get(), axis));
            for (int i = 1; i <= arms; i++) {
                g.set(0, top - i, pw, CoasterControlPanel.SWING_ARM_BLOCK.get().defaultBlockState());
            }
            g.set(0, hub, pw, CoasterControlPanel.SWING_HUB_BLOCK.get().defaultBlockState());
            // the gondola: 16 seats in two rows back to back, facing out, with lap bars
            for (int u = -2; u <= 2; u++) {
                for (int k = 3; k <= gk; k++) {
                    g.set(u, hub - 1, side * k, frame);
                }
            }
            for (int k = 3; k <= gk; k++) {
                int w = side * k;
                if (w != pw) {
                    g.set(0, hub, w, frame);
                }
                g.set(1, hub, w, seat(1, 0));
                g.set(-1, hub, w, seat(-1, 0));
                g.set(2, hub, w, frame);
                g.set(-2, hub, w, frame);
            }
            for (int u = -2; u <= 2; u++) {
                g.set(u, hub + 1, side * 3, frame);
                g.set(u, hub + 1, side * gk, frame);
            }
            // boarding platforms level with the gondola floor
            for (int sd : new int[]{-1, 1}) {
                for (int u = 3; u <= 6; u++) {
                    for (int k = 2; k <= gk + 1; k++) {
                        g.set(sd * u, hub - 1, side * k, stone);
                    }
                }
                for (int k = 2; k <= gk + 1; k++) {
                    g.set(sd * 7, 0, side * k, stone);
                }
            }
        }
        g.set(11, 0, 0, CoasterControlPanel.SWING_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 2, CoasterControlPanel.SWING_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Gyro Swing: one arm, a ring that turns in the swing plane

    private static void gyro(Level level, BlockPos origin, Direction.Axis axis, int arms) {
        Grid g = new Grid(level, origin, axis);
        int hub = 6;
        int top = hub + arms + 1;
        int aw = 6;
        platform(g, -14, 14, -6, 12);
        BlockState section = CoasterControlPanel.GYRO_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        for (int w = -1; w <= 1; w++) {
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, top - 1, leg * 7, 0)) {
                    g.set(p[0], p[1], w, section);
                    g.set(p[0] + (leg > 0 ? -1 : 1), p[1], w, section);
                }
            }
            g.set(0, top, w, section);
            g.set(1, top - 1, w, section);
            g.set(-1, top - 1, w, section);
            for (int u = -3; u <= 3; u++) {
                g.set(u, 6, w, section);
            }
        }
        for (int w = 2; w < aw; w++) {
            g.set(0, top, w, beam);
        }
        g.set(0, top, aw, with(CoasterControlPanel.GYRO_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, aw, CoasterControlPanel.GYRO_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, aw, CoasterControlPanel.GYRO_HUB_BLOCK.get().defaultBlockState());
        BlockState ring = CoasterControlPanel.GYRO_RING_BLOCK.get().defaultBlockState();
        java.util.Set<Long> cells = new java.util.HashSet<>();
        for (int u = -5; u <= 5; u++) {
            for (int v = -5; v <= 5; v++) {
                double d = Math.sqrt(u * u + v * v);
                if (d >= 3.5 && d < 4.5) {
                    cells.add(((long) (u + 8) << 8) | (v + 8));
                    for (int w = aw - 1; w <= aw + 1; w++) {
                        g.set(u, hub + v, w, ring);
                    }
                }
            }
        }
        for (int k = 1; k <= 2; k++) {
            for (int[] dir : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                g.set(dir[0] * k, hub + dir[1] * k, aw, ring);
            }
        }
        for (int u = -4; u <= 4; u++) {
            for (int v = -4; v <= 4; v++) {
                double d = Math.sqrt(u * u + v * v);
                if (d < 2.5 || d >= 3.5) {
                    continue;
                }
                boolean touches = cells.contains(((long) (u + 9) << 8) | (v + 8)) || cells.contains(((long) (u + 7) << 8) | (v + 8))
                        || cells.contains(((long) (u + 8) << 8) | (v + 9)) || cells.contains(((long) (u + 8) << 8) | (v + 7));
                if (touches) {
                    for (int w = aw - 1; w <= aw + 1; w++) {
                        g.set(u, hub + v, w, seat(u, 0));
                    }
                }
            }
        }
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int sd : new int[]{-1, 1}) {
            for (int u = 5; u <= 7; u++) {
                for (int w = aw - 2; w <= aw + 2; w++) {
                    g.set(sd * u, 1, w, stone);
                }
            }
            for (int w = aw - 2; w <= aw + 2; w++) {
                g.set(sd * 8, 0, w, stone);
            }
        }
        g.set(11, 0, 0, CoasterControlPanel.GYRO_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 2, CoasterControlPanel.GYRO_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Carousel: a deck of 8 blocks radius with two rings of horses

    private static void carousel(Level level, BlockPos origin, int[] radii, int[] counts) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        for (int u = -11; u <= 11; u++) {
            for (int w = -11; w <= 11; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
        BlockState deck = CoasterControlPanel.CAROUSEL_DECK_BLOCK.get().defaultBlockState();
        BlockState pole = CoasterControlPanel.CAROUSEL_POLE_BLOCK.get().defaultBlockState();
        BlockState roof = CoasterControlPanel.CAROUSEL_ROOF_BLOCK.get().defaultBlockState();
        BlockState horse = CoasterControlPanel.CAROUSEL_HORSE_BLOCK.get().defaultBlockState();
        for (int u = -9; u <= 9; u++) {
            for (int w = -9; w <= 9; w++) {
                double d = Math.sqrt(u * u + w * w);
                if (d <= 8.5) {
                    g.set(u, 0, w, deck);
                }
                if (d <= 8.5) {
                    g.set(u, 5, w, roof);
                }
            }
        }
        g.set(0, 0, 0, CoasterControlPanel.CAROUSEL_HUB_BLOCK.get().defaultBlockState());
        for (int y = 1; y <= 4; y++) {
            g.set(0, y, 0, pole);
        }
        for (int r = 0; r < 2; r++) {
            for (int i = 0; i < counts[r]; i++) {
                double a = Math.PI * 2.0 * i / counts[r];
                int hu = (int) Math.round(Math.cos(a) * radii[r]);
                int hw = (int) Math.round(Math.sin(a) * radii[r]);
                int pu = (int) Math.round(Math.cos(a) * (radii[r] - 1));
                int pw = (int) Math.round(Math.sin(a) * (radii[r] - 1));
                g.set(hu, 1, hw, horse);
                g.set(hu, 2, hw, seat((int) -Math.round(Math.sin(a) * 2), (int) Math.round(Math.cos(a) * 2)));
                for (int y = 1; y <= 4; y++) {
                    if (pu != hu || pw != hw) {
                        g.set(pu, y, pw, pole);
                    }
                }
            }
        }
        g.set(10, 0, 0, CoasterControlPanel.CAROUSEL_BASE_BLOCK.get().defaultBlockState());
        g.set(10, 0, 2, CoasterControlPanel.CAROUSEL_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Bumper Cars: a 15 by 15 arena with a padded rail and six cars

    private static void bumper(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        BlockState floor = CoasterControlPanel.BUMPER_FLOOR_BLOCK.get().defaultBlockState();
        BlockState rail = CoasterControlPanel.BUMPER_RAIL_BLOCK.get().defaultBlockState();
        BlockState post = CoasterControlPanel.BUMPER_SECTION_BLOCK.get().defaultBlockState();
        for (int u = -10; u <= 10; u++) {
            for (int w = -10; w <= 10; w++) {
                boolean inside = Math.abs(u) <= 7 && Math.abs(w) <= 7;
                g.set(u, -1, w, inside ? floor : Blocks.POLISHED_ANDESITE.defaultBlockState());
                boolean edge = Math.max(Math.abs(u), Math.abs(w)) == 8;
                if (edge) {
                    g.set(u, 0, w, rail);
                }
            }
        }
        for (int su : new int[]{-8, 8}) {
            for (int sw : new int[]{-8, 8}) {
                for (int y = 1; y <= 5; y++) {
                    g.set(su, y, sw, post);
                }
            }
        }
        // a gap in the rail for the entrance
        g.set(0, 0, -8, Blocks.AIR.defaultBlockState());
        g.set(1, 0, -8, Blocks.AIR.defaultBlockState());
        g.set(11, 0, -2, CoasterControlPanel.BUMPER_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 0, CoasterControlPanel.BUMPER_CONTROLLER_BLOCK.get().defaultBlockState());
        int[][] spots = {{-5, -4}, {0, -4}, {5, -4}, {-5, 2}, {0, 3}, {5, 2}};
        for (int i = 0; i < spots.length; i++) {
            BlockPos at = g.at(spots[i][0], 0, spots[i][1]);
            BumperCarEntity car = new BumperCarEntity(CoasterControlPanel.BUMPER_CAR.get(), level);
            car.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, 90.0F * (i % 4), 0.0F);
            level.addFreshEntity(car);
        }
    }

    // ---------------------------------------------------------------- Time Machine: eight arms round a centre, a small red cart on each, one block above the floor

    private static void timeMachine(Level level, BlockPos origin, Direction.Axis axis, int pl, int len, int n) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        platform(g, -15, 15, -15, 15);
        BlockState black = Blocks.BLACK_CONCRETE.defaultBlockState();
        for (int u = -14; u <= 14; u++) {
            for (int w = -14; w <= 14; w++) {
                if (u * u + w * w <= 13.5 * 13.5) {
                    g.set(u, -1, w, black);
                }
            }
        }
        BlockState plate = CoasterControlPanel.TEACUP_PLATE_BLOCK.get().defaultBlockState();
        BlockState section = CoasterControlPanel.TEACUP_SECTION_BLOCK.get().defaultBlockState();
        BlockState floor = CoasterControlPanel.TEACUP_FLOOR_BLOCK.get().defaultBlockState();
        BlockState red = Blocks.RED_CONCRETE.defaultBlockState();
        g.set(0, pl, 0, CoasterControlPanel.TEACUP_HUB_BLOCK.get().defaultBlockState());
        for (int y = 0; y < pl; y++) {
            g.set(0, y, 0, section);
        }
        for (int y = pl + 1; y <= pl + 3; y++) {
            g.set(0, y, 0, section);
        }
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2.0 * k / n;
            int pu = 0;
            int pw = 0;
            for (int r = 1; r <= len; r++) {
                int u = (int) Math.round(Math.cos(a) * r);
                int w = (int) Math.round(Math.sin(a) * r);
                if (u != pu && w != pw) {
                    g.set(u, pl, pw, plate); // keeps a diagonal arm joined side to side
                }
                g.set(u, pl, w, plate);
                pu = u;
                pw = w;
            }
            int cu = pu;
            int cw = pw;
            // the cart's forward direction: the main way the arm points
            int du = 0;
            int dw = 0;
            if (Math.abs(Math.cos(a)) >= Math.abs(Math.sin(a)) - 1.0E-6) {
                du = Math.cos(a) >= 0 ? 1 : -1;
            } else {
                dw = Math.sin(a) >= 0 ? 1 : -1;
            }
            int eu = dw != 0 ? 1 : 0;
            int ew = du != 0 ? 1 : 0;
            int fy = pl + 1;
            for (int t = -1; t <= 1; t++) {
                for (int rad = -1; rad <= 0; rad++) {
                    int fu = cu + du * rad + eu * t;
                    int fw = cw + dw * rad + ew * t;
                    if (rad == 0 && t == 0) {
                        g.set(fu, fy, fw, CoasterControlPanel.TEACUP_CUP_HUB_BLOCK.get().defaultBlockState());
                    } else {
                        g.set(fu, fy, fw, floor);
                    }
                    if (rad == 0) {
                        g.set(fu, fy + 1, fw, seat(du, dw));
                    } else {
                        g.set(fu, fy + 1, fw, red);
                    }
                }
            }
        }
        g.set(13, 0, -13, CoasterControlPanel.TEACUP_BASE_BLOCK.get().defaultBlockState());
        g.set(13, 0, -11, CoasterControlPanel.TEACUP_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Pirate Ship: 15 block boat on a 9 piece arm

    private static void pirate(Level level, BlockPos origin, Direction.Axis axis, int arms, int half, boolean carpet) {
        Grid g = new Grid(level, origin, axis);
        int hub = 4;
        int top = hub + arms + 1;
        platform(g, -14, 14, -11, 11);
        BlockState section = CoasterControlPanel.PIRATE_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int plane = 5; plane <= 6; plane++) {
                for (int leg : new int[]{-1, 1}) {
                    for (int[] p : RideShapes.line(0, top - 1, leg * Math.max(9, arms), 0)) {
                        g.set(p[0], p[1], side * plane, section);
                    }
                }
                g.set(0, top, side * plane, beam);
            }
        }
        for (int w = -6; w <= 6; w++) {
            if (w != 0) {
                g.set(0, top, w, beam);
            }
        }
        g.set(0, top, 0, with(CoasterControlPanel.PIRATE_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, 0, CoasterControlPanel.PIRATE_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, 0, CoasterControlPanel.PIRATE_HUB_BLOCK.get().defaultBlockState());
        BlockState hull = CoasterControlPanel.PIRATE_HULL_BLOCK.get().defaultBlockState();
        // the boat: a keel that tapers, a deck, a rail along both sides and a tall bow and stern
        for (int u = -half; u <= half; u++) {
            for (int w = -2; w <= 2; w++) {
                g.set(u, hub - 1, w, hull);
            }
        }
        for (int u = -Math.max(0, half - 2); u <= Math.max(0, half - 2); u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, hub - 2, w, hull);
            }
        }
        for (int u = -Math.max(0, half - 4); u <= Math.max(0, half - 4); u++) {
            g.set(u, hub - 3, 0, hull);
        }
        for (int u = -half; u <= half; u++) {
            g.set(u, hub, -2, hull);
            g.set(u, hub, 2, hull);
            g.set(u, hub + 1, -2, hull);
            g.set(u, hub + 1, 2, hull);
            if (u != 0) {
                g.set(u, hub, 0, hull);
            }
            for (int w : new int[]{-1, 1}) {
                g.set(u, hub, w, seat(0, w));
            }
        }
        if (!carpet) {
        for (int h = 0; h <= 3; h++) {
            g.set(-(half + 1), hub + h, 0, hull);
            g.set(half + 1, hub + h, 0, hull);
            if (h < 2) {
                g.set(-(half + 1), hub + h, -1, hull);
                g.set(-(half + 1), hub + h, 1, hull);
                g.set(half + 1, hub + h, -1, hull);
                g.set(half + 1, hub + h, 1, hull);
            }
        }
        g.set(-(half + 2), hub + 2, 0, hull);
        g.set(half + 2, hub + 2, 0, hull);
        }
        // steps up to a boarding platform at each end
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int w = -2; w <= 2; w++) {
                g.set(side * (half + 3), hub - 1, w, stone);
                g.set(side * (half + 4), hub - 2, w, stone);
                g.set(side * (half + 5), hub - 3, w, stone);
                g.set(side * (half + 2), hub - 1, w, stone);
            }
        }
        g.set(0, 0, -9, CoasterControlPanel.PIRATE_BASE_BLOCK.get().defaultBlockState());
        g.set(2, 0, -9, CoasterControlPanel.PIRATE_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Teacup Ride: a 19 block platter with four cups

    private static void teacup(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        platform(g, -12, 12, -12, 12);
        BlockState plate = CoasterControlPanel.TEACUP_PLATE_BLOCK.get().defaultBlockState();
        for (int u = -9; u <= 9; u++) {
            for (int w = -9; w <= 9; w++) {
                if (u * u + w * w <= 9.4 * 9.4) {
                    g.set(u, 0, w, plate);
                }
            }
        }
        g.set(0, 0, 0, CoasterControlPanel.TEACUP_HUB_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.TEACUP_SECTION_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 4; y++) {
            g.set(0, y, 0, section);
        }
        BlockState floor = CoasterControlPanel.TEACUP_FLOOR_BLOCK.get().defaultBlockState();
        BlockState wall = CoasterControlPanel.TEACUP_WALL_BLOCK.get().defaultBlockState();
        int[][] centres = {{5, 0}, {0, 5}, {-5, 0}, {0, -5}};
        for (int[] c : centres) {
            int ox = Integer.compare(c[0], 0);
            int oz = Integer.compare(c[1], 0);
            for (int du = -2; du <= 2; du++) {
                for (int dw = -2; dw <= 2; dw++) {
                    int cu = c[0] + du;
                    int cw = c[1] + dw;
                    int ring = Math.max(Math.abs(du), Math.abs(dw));
                    if (du == 0 && dw == 0) {
                        g.set(cu, 1, cw, CoasterControlPanel.TEACUP_CUP_HUB_BLOCK.get().defaultBlockState());
                        continue;
                    }
                    if (Math.abs(du) == 2 && Math.abs(dw) == 2) {
                        continue; // rounded corners
                    }
                    g.set(cu, 1, cw, floor);
                    boolean gap = du == 2 * ox && dw == 2 * oz && (ox != 0 || oz != 0);
                    if (ring == 2 && !gap) {
                        g.set(cu, 2, cw, wall);
                    } else if (ring == 1) {
                        g.set(cu, 2, cw, seat(-du, -dw));
                    }
                }
            }
        }
        g.set(11, 0, -11, CoasterControlPanel.TEACUP_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, -9, CoasterControlPanel.TEACUP_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Ferris Wheel: 24 block wheel, 12 cabins

    private static void ferris(Level level, BlockPos origin, Direction.Axis axis, int radius, int cabins, int ay, int leg) {
        Grid g = new Grid(level, origin, axis);
        RideShapes.Ferris f = RideShapes.ferris(radius, cabins);
        platform(g, -16, 16, -8, 8);
        g.set(0, ay, 0, with(CoasterControlPanel.FERRIS_AXLE_BLOCK.get(), axis));
        for (long k : f.spokes) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_SPOKE_BLOCK.get(), axis));
        }
        for (long k : f.rim) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        for (long k : f.hangers) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        BlockState frame = CoasterControlPanel.FERRIS_FRAME_BLOCK.get().defaultBlockState();
        for (int[] h : f.hubs) {
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    int ring = Math.max(Math.abs(du), Math.abs(dv));
                    if (ring == 2) {
                        for (int w = -1; w <= 1; w++) {
                            g.set(h[0] + du, ay + h[1] + dv, w, frame);
                        }
                    } else if (ring == 1) {
                        g.set(h[0] + du, ay + h[1] + dv, 0, seat(-du, -dv));
                    } else {
                        g.set(h[0], ay + h[1], 0, CoasterControlPanel.FERRIS_HUB_BLOCK.get().defaultBlockState());
                    }
                }
            }
        }
        // the axle pins and the two A-shaped legs, in front of and behind the wheel
        BlockState section = CoasterControlPanel.FERRIS_SECTION_BLOCK.get().defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            g.set(0, ay, side, section);
            g.set(0, ay, side * 2, section);
            for (int lg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, ay, lg * leg, 0)) {
                    g.set(p[0], p[1], side * 3, section);
                    g.set(p[0] + lg, p[1], side * 3, section);
                }
            }
            for (int u = -6; u <= 6; u++) {
                g.set(u, ay - 8, side * 3, section);
            }
        }
        g.set(-6, 0, -6, CoasterControlPanel.FERRIS_BASE_BLOCK.get().defaultBlockState());
        g.set(-4, 0, -6, CoasterControlPanel.FERRIS_CONTROLLER_BLOCK.get().defaultBlockState());
    }
}
