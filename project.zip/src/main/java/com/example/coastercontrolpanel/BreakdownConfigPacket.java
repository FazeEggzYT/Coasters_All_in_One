package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: settings from the Breakdown screen, for one zone or for the global defaults. Checked here. */
public record BreakdownConfigPacket(BlockPos start, CompoundTag settings, boolean global) implements CustomPacketPayload {
    public static final Type<BreakdownConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "breakdown_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BreakdownConfigPacket> CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BreakdownConfigPacket::start,
            ByteBufCodecs.COMPOUND_TAG, BreakdownConfigPacket::settings,
            ByteBufCodecs.BOOL, BreakdownConfigPacket::global,
            BreakdownConfigPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BreakdownConfigPacket p, IPayloadContext context) {
        Player player = context.player();
        if (!(player instanceof ServerPlayer sp)) {
            return;
        }
        if (p.global) {
            // The defaults change every zone in the world, so only a creative player or an operator may set them.
            if (sp.isCreative() || sp.hasPermissions(2)) {
                BreakdownGlobals.get(sp.server).set(sp.server, BreakdownSettings.fromTag(p.settings));
            }
            return;
        }
        if (player.distanceToSqr(p.start.getX() + 0.5, p.start.getY() + 0.5, p.start.getZ() + 0.5) > 4096.0
                || !player.level().isLoaded(p.start)) {
            return;
        }
        if (player.level().getBlockEntity(p.start) instanceof DriveTyre.Holder h && h.ccp$breakdown() != null) {
            BreakdownSettings fresh = BreakdownSettings.fromTag(p.settings);
            fresh.end = h.ccp$breakdown().end;
            fresh.element = h.ccp$breakdown().element;
            fresh.wear = h.ccp$breakdown().wear; // wear is the server's; a client can neither set nor reset it
            h.ccp$setBreakdown(fresh);
            h.ccp$sync();
        }
    }
}
