package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Ride Start Block: the ride's control panel. Dispatch runs the whole sequence: riders load, the ride runs, it slows and unloads. */
public class FlatRideScreen extends Screen {
    private static final int W = 240;
    private static final int H = 170;
    private final BlockPos pos;
    private int left;
    private int top;
    private EditBox loadBox;
    private EditBox runBox;
    private EditBox speedBox;

    public FlatRideScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.flat_ride.title"));
        this.pos = pos;
    }

    private FlatRideBlockEntity be() {
        return minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(pos) instanceof FlatRideBlockEntity b ? b : null;
    }

    private static Component t(String k) {
        return Component.translatable("gui.coastercontrolpanel.flat_ride." + k);
    }

    private EditBox box(int y, int value) {
        EditBox b = new EditBox(font, left + 150, top + y, 80, 14, Component.empty());
        b.setFilter(s -> s.matches("[0-9]{0,3}"));
        b.setValue(Integer.toString(value));
        addRenderableWidget(b);
        return b;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        FlatRideBlockEntity b = be();
        loadBox = box(46, b == null ? 10 : b.loadSecs());
        runBox = box(68, b == null ? 40 : b.runSecs());
        speedBox = box(90, b == null ? 100 : b.speedPct());
        addRenderableWidget(Button.builder(t("dispatch"), x -> send(1)).bounds(left + 10, top + 120, 105, 20).build());
        addRenderableWidget(Button.builder(t("stop"), x -> send(2)).bounds(left + 125, top + 120, 105, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), x -> {
            send(0);
            onClose();
        }).bounds(left + 10, top + 144, 220, 18).build());
    }

    private static int num(EditBox b, int def, int min, int max) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(b.getValue())));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private void send(int action) {
        PacketDistributor.sendToServer(new FlatRideControlPacket(pos, action, num(loadBox, 10, 0, 120), num(runBox, 40, 10, 300), num(speedBox, 100, 40, 150)));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        super.renderBackground(g, mx, my, pt);
        g.fill(left, top, left + W, top + H, 0xEE1B1B22);
        g.renderOutline(left, top, W, H, 0xFF5577AA);
        g.drawString(font, title, left + 10, top + 8, 0xFFFFFF, false);
        FlatRideBlockEntity b = be();
        String key = b == null ? "idle" : b.statusKey();
        g.drawString(font, t("status").getString() + " " + t("status_" + key).getString(), left + 10, top + 26, 0xFFE070, false);
        g.drawString(font, t("load_time"), left + 10, top + 49, 0xCCCCCC, false);
        g.drawString(font, t("run_time"), left + 10, top + 71, 0xCCCCCC, false);
        g.drawString(font, t("speed"), left + 10, top + 93, 0xCCCCCC, false);
        g.drawString(font, t("hint"), left + 10, top + 108, 0x8899AA, false);
    }
}
