package com.example.coastercontrolpanel;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A door the size of a normal door (one block wide, two tall) with two leaves that slide apart in the middle.
 * Airlock door and steam room door. Right-click or redstone opens it.
 */
public class ParkDoor extends Block {
    public static final DirectionProperty FACING = DecorBlocks.FACING;
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    private final String id;

    public ParkDoor(String id, Properties p) {
        super(p);
        this.id = id;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(HALF, DoubleBlockHalf.LOWER).setValue(OPEN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING, HALF, OPEN);
    }

    private static VoxelShape shape(BlockState s, boolean collision) {
        Direction f = s.getValue(FACING);
        boolean upper = s.getValue(HALF) == DoubleBlockHalf.UPPER;
        if (!s.getValue(OPEN)) {
            return DecorBlocks.dbox(f, 0, 0, 6, 16, 16, 10);
        }
        VoxelShape v = Shapes.or(DecorBlocks.dbox(f, 0, 0, 6, 3, 16, 10), DecorBlocks.dbox(f, 13, 0, 6, 16, 16, 10));
        return upper ? Shapes.or(v, DecorBlocks.dbox(f, 0, 14, 6, 16, 16, 10)) : v;
    }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return shape(s, false);
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return shape(s, true);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        BlockPos pos = c.getClickedPos();
        Level level = c.getLevel();
        if (pos.getY() >= level.getMaxBuildHeight() - 1 || !level.getBlockState(pos.above()).canBeReplaced(c)) {
            return null;
        }
        boolean powered = level.hasNeighborSignal(pos) || level.hasNeighborSignal(pos.above());
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite()).setValue(OPEN, powered);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState s, @Nullable LivingEntity by, ItemStack stack) {
        level.setBlock(pos.above(), s.setValue(HALF, DoubleBlockHalf.UPPER), 3);
    }

    @Override
    protected BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        DoubleBlockHalf half = s.getValue(HALF);
        if (d.getAxis() == Direction.Axis.Y && (half == DoubleBlockHalf.LOWER) == (d == Direction.UP)) {
            return n.is(this) && n.getValue(HALF) != half ? s.setValue(FACING, n.getValue(FACING)).setValue(OPEN, n.getValue(OPEN))
                    : Blocks.AIR.defaultBlockState();
        }
        return half == DoubleBlockHalf.LOWER && d == Direction.DOWN && !s.canSurvive(l, p) ? Blocks.AIR.defaultBlockState()
                : super.updateShape(s, d, n, l, p, np);
    }

    @Override
    protected boolean canSurvive(BlockState s, net.minecraft.world.level.LevelReader l, BlockPos p) {
        BlockPos below = p.below();
        BlockState b = l.getBlockState(below);
        return s.getValue(HALF) == DoubleBlockHalf.LOWER ? b.isFaceSturdy(l, below, Direction.UP) : b.is(this) && b.getValue(HALF) == DoubleBlockHalf.LOWER;
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState s, Player player) {
        if (!level.isClientSide && player.isCreative() && s.getValue(HALF) == DoubleBlockHalf.UPPER) {
            BlockPos below = pos.below();
            BlockState b = level.getBlockState(below);
            if (b.is(this) && b.getValue(HALF) == DoubleBlockHalf.LOWER) {
                level.setBlock(below, Blocks.AIR.defaultBlockState(), 35);
                level.levelEvent(player, 2001, below, Block.getId(b));
            }
        }
        return super.playerWillDestroy(level, pos, s, player);
    }

    private void set(Level level, BlockPos pos, BlockState s, boolean open) {
        BlockPos low = s.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        for (BlockPos q : new BlockPos[] {low, low.above()}) {
            BlockState b = level.getBlockState(q);
            if (b.is(this)) {
                level.setBlock(q, b.setValue(OPEN, open), 3);
            }
        }
        level.playSound(null, pos, id.equals("steam_room_door") ? SoundEvents.GLASS_PLACE : SoundEvents.PISTON_EXTEND, SoundSource.BLOCKS, 0.6F, open ? 1.4F : 1.1F);
        if (open && id.equals("steam_room_door") && level instanceof net.minecraft.server.level.ServerLevel sl) {
            ParkProps.puff(sl, low, "cloud", 12);
        }
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            set(level, pos, s, !s.getValue(OPEN));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
        if (level.isClientSide) {
            return;
        }
        BlockPos low = s.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        boolean powered = level.hasNeighborSignal(low) || level.hasNeighborSignal(low.above());
        if (powered != s.getValue(OPEN) && block != this) {
            set(level, pos, s, powered);
        }
    }
}
