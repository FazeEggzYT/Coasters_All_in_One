package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * BREAK DOWN YOUR COASTER, settings. Same look as the Green Screen. Tabs group the settings; the button at the top
 * switches between this zone and the global defaults. Nothing is sent until Apply; Cancel or Esc discards.
 */
public class BreakdownScreen extends Screen {
    private static final int W = 300;
    private static final int TABS = 6;
    private static final String[] TAB_KEYS = {"main", "types", "severity", "repair", "recover", "wear"};

    private final BlockPos start;
    private final BreakdownSettings zone;
    private final BreakdownSettings global;
    private final Screen parent;
    private boolean editGlobal;
    private int tab;

    /** Text drawn on the panel for the current tab: {text, x offset, y offset from the panel top, colour}. */
    private final List<Object[]> labels = new ArrayList<>();

    public BreakdownScreen(BlockPos start, BreakdownSettings zone, Screen parent) {
        super(Component.translatable("gui.coastercontrolpanel.breakdown.title"));
        this.start = start;
        this.zone = zone;
        this.global = BreakdownGlobals.client.copy();
        this.parent = parent;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.breakdown." + key);
    }

    private BreakdownSettings cur() {
        return editGlobal ? global : zone;
    }

    private int px() {
        return (width - W) / 2;
    }

    private int ph() {
        return Math.min(height - 12, 250);
    }

    private int py() {
        return (height - ph()) / 2;
    }

    @Override
    protected void init() {
        labels.clear();
        int x0 = px();
        int y0 = py();
        // who is being edited
        addRenderableWidget(Button.builder(t(editGlobal ? "editing_global" : "editing_zone"), b -> {
            editGlobal = !editGlobal;
            rebuildWidgets();
        }).bounds(x0 + 10, y0 + 22, 150, 16).build());
        if (!editGlobal) {
            labels.add(new Object[] {Component.translatable("gui.coastercontrolpanel.breakdown.on_" + BreakdownSettings.ELEMENT_KEYS[zone.element]), 168, 26, 0x8A92A8});
        } else {
            labels.add(new Object[] {t("global_note"), 168, 26, 0x8A92A8});
        }
        // tabs
        int tw = (W - 20) / TABS;
        for (int i = 0; i < TABS; i++) {
            final int idx = i;
            Button b = Button.builder(t("tab." + TAB_KEYS[i]), bb -> {
                tab = idx;
                rebuildWidgets();
            }).bounds(x0 + 10 + i * tw, y0 + 42, tw - 1, 14).build();
            b.active = tab != i;
            addRenderableWidget(b);
        }
        int y = y0 + 64;
        switch (tab) {
            case 0 -> main(x0, y);
            case 1 -> types(x0, y);
            case 2 -> severity(x0, y);
            case 3 -> repair(x0, y);
            case 4 -> recover(x0, y);
            default -> wear(x0, y);
        }
        int by = y0 + ph() - 24;
        addRenderableWidget(Button.builder(t("apply"), b -> apply()).bounds(x0 + 10, by, 136, 18).build());
        addRenderableWidget(Button.builder(t("cancel"), b -> onClose()).bounds(x0 + W - 146, by, 136, 18).build());
    }

    // ---- widgets

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.1f", v);
    }

    private void label(String key, int x, int y) {
        labels.add(new Object[] {t(key), x - px(), y - py(), 0xE0E4F0});
    }

    private void note(String key, int x, int y) {
        labels.add(new Object[] {t(key), x - px(), y - py(), 0x8A92A8});
    }

    private EditBox number(int x, int y, int w, double value, double min, double max, boolean whole, Consumer<Double> set) {
        EditBox box = new EditBox(font, x, y, w, 16, Component.empty());
        box.setValue(whole ? Long.toString((long) value) : num(value));
        box.setFilter(str -> str.matches(whole ? "[0-9]{0,4}" : "[0-9]{0,4}([.][0-9]{0,1})?"));
        box.setResponder(str -> {
            try {
                double v = Double.parseDouble(str);
                set.accept(Math.max(min, Math.min(max, v)));
            } catch (NumberFormatException ignored) {
                // an empty or half-typed number is not applied yet
            }
        });
        addRenderableWidget(box);
        return box;
    }

    /** The "use my own values / use the global defaults" switch of a group. Only for a zone, not for the globals. */
    private int override(int y, boolean on, Consumer<Boolean> set) {
        if (editGlobal) {
            return y;
        }
        addRenderableWidget(Button.builder(t(on ? "own_values" : "using_global"), b -> {
            set.accept(!on);
            rebuildWidgets();
        }).bounds(px() + 10, y, 150, 16).build());
        if (!on) {
            note("global_values_shown", px() + 168, y + 4);
        }
        return y + 22;
    }

    /** True when the group's fields can be edited: always for the globals, only with "own values" for a zone. */
    private boolean editable(boolean on) {
        return editGlobal || on;
    }

    /** The settings whose group values are shown: the zone's own, or the global ones while it uses those. */
    private BreakdownSettings shown(boolean on) {
        return editable(on) ? cur() : global;
    }

    // ---- tabs

    private void main(int x0, int y) {
        BreakdownSettings c = cur();
        if (!editGlobal) {
            label("coaster", x0 + 10, y + 4);
            EditBox name = new EditBox(font, x0 + 150, y, 140, 16, Component.empty());
            name.setMaxLength(32);
            name.setValue(zone.coaster);
            name.setResponder(str -> zone.coaster = str.trim());
            addRenderableWidget(name);
            y += 24;
            note("coaster_note", x0 + 10, y);
            y += 28;
        }
        label("chance", x0 + 10, y + 4);
        number(x0 + 150, y, 60, c.chance, 0, 100, false, v -> c.chance = v.floatValue());
        label("percent", x0 + 214, y + 4);
        y += 24;
        note("chance_note", x0 + 10, y);
    }

    private void types(int x0, int y) {
        y = override(y, zone.ovTypes, v -> zone.ovTypes = v);
        BreakdownSettings c = shown(zone.ovTypes);
        boolean ed = editable(zone.ovTypes);
        String[] keys = {"mech", "brake", "lift", "general"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            label("type." + keys[i], x0 + 10, y + 4);
            EditBox b = number(x0 + 150, y, 60, c.types[i], 0, 100, false, v -> c.types[k] = v.floatValue());
            b.setEditable(ed);
            label("percent", x0 + 214, y + 4);
            y += 20;
        }
        note("weights_note", x0 + 10, y + 2);
    }

    private void severity(int x0, int y) {
        y = override(y, zone.ovSev, v -> zone.ovSev = v);
        BreakdownSettings c = shown(zone.ovSev);
        boolean ed = editable(zone.ovSev);
        String[] keys = {"minor", "moderate", "major"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            label("sev." + keys[i], x0 + 10, y + 4);
            EditBox b = number(x0 + 150, y, 60, c.sev[i], 0, 100, false, v -> c.sev[k] = v.floatValue());
            b.setEditable(ed);
            label("percent", x0 + 214, y + 4);
            y += 20;
        }
        note("weights_note", x0 + 10, y + 2);
        note("major_note", x0 + 10, y + 24);
    }

    private void repair(int x0, int y) {
        y = override(y, zone.ovRepair, v -> zone.ovRepair = v);
        BreakdownSettings c = shown(zone.ovRepair);
        boolean ed = editable(zone.ovRepair);
        String[] types = {"mech", "brake", "lift", "general"};
        String[] sev = {"minor", "moderate", "major"};
        for (int j = 0; j < 3; j++) {
            labels.add(new Object[] {t("sev." + sev[j]), 130 + j * 54, y - py(), 0x8A92A8});
        }
        y += 12;
        for (int i = 0; i < 4; i++) {
            label("type." + types[i], x0 + 10, y + 4);
            for (int j = 0; j < 3; j++) {
                final int ti = i;
                final int sj = j;
                EditBox b = number(x0 + 130 + j * 54, y, 48, c.repair[i][j], 1, BreakdownSettings.MAX_SECONDS, true, v -> c.repair[ti][sj] = v.intValue());
                b.setEditable(ed);
            }
            y += 20;
        }
        note("seconds_note", x0 + 10, y + 2);
    }

    private void recover(int x0, int y) {
        y = override(y, zone.ovAuto, v -> zone.ovAuto = v);
        BreakdownSettings c = shown(zone.ovAuto);
        boolean ed = editable(zone.ovAuto);
        for (int i = 0; i < 2; i++) {
            final boolean minor = i == 0;
            boolean on = minor ? c.autoMinor : c.autoModerate;
            Button tog = Button.builder(t(minor ? (on ? "auto_minor_on" : "auto_minor_off") : (on ? "auto_mod_on" : "auto_mod_off")), b -> {
                if (minor) {
                    c.autoMinor = !c.autoMinor;
                } else {
                    c.autoModerate = !c.autoModerate;
                }
                rebuildWidgets();
            }).bounds(x0 + 10, y, 150, 16).build();
            tog.active = ed;
            addRenderableWidget(tog);
            EditBox b = number(x0 + 168, y, 48, minor ? c.autoMinorSec : c.autoModerateSec, 1, BreakdownSettings.MAX_SECONDS, true,
                    v -> {
                        if (minor) {
                            c.autoMinorSec = v.intValue();
                        } else {
                            c.autoModerateSec = v.intValue();
                        }
                    });
            b.setEditable(ed && on);
            label("seconds", x0 + 220, y + 4);
            y += 22;
        }
        note("auto_note", x0 + 10, y + 2);
    }

    private void wear(int x0, int y) {
        y = override(y, zone.ovWear, v -> zone.ovWear = v);
        BreakdownSettings c = shown(zone.ovWear);
        boolean ed = editable(zone.ovWear);
        label("wear_minutes", x0 + 10, y + 4);
        number(x0 + 168, y, 48, c.wearMinutes, 1, 600, true, v -> c.wearMinutes = v.intValue()).setEditable(ed);
        label("minutes", x0 + 220, y + 4);
        y += 22;
        label("wear_boost", x0 + 10, y + 4);
        number(x0 + 168, y, 48, c.wearBoost, 0, 1000, false, v -> c.wearBoost = v.floatValue()).setEditable(ed);
        label("percent", x0 + 220, y + 4);
        y += 22;
        label("reliability", x0 + 10, y + 4);
        number(x0 + 168, y, 48, c.reliability, 10, 500, false, v -> c.reliability = v.floatValue()).setEditable(ed);
        label("percent", x0 + 220, y + 4);
        y += 24;
        note("wear_note", x0 + 10, y);
    }

    // ---- send and render

    private void apply() {
        if (editGlobal) {
            PacketDistributor.sendToServer(new BreakdownConfigPacket(start, global.toTag(), true));
        }
        PacketDistributor.sendToServer(new BreakdownConfigPacket(start, zone.toTag(), false));
        onClose();
    }

    @Override
    public void onClose() {
        if (parent != null && minecraft != null) {
            minecraft.setScreen(parent);
        } else {
            super.onClose();
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderTransparentBackground(g);
        int x0 = px();
        int y0 = py();
        g.fill(x0, y0, x0 + W, y0 + ph(), 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + W - 1, y0 + ph() - 1, 0xFF1B1D24);
        g.drawString(font, title, x0 + 10, y0 + 8, 0xFFFFFF, false);
        g.fill(x0 + 4, y0 + 60, x0 + W - 4, y0 + 61, 0xFF3A3E4D);
        g.fill(x0 + 4, y0 + ph() - 30, x0 + W - 4, y0 + ph() - 29, 0xFF3A3E4D);
        for (Object[] l : labels) {
            Component text = (Component) l[0];
            int lx = (Integer) l[1];
            int ly = py() + (Integer) l[2];
            int col = (Integer) l[3];
            if (text.getString().length() > 40) {
                int yy = ly;
                for (net.minecraft.util.FormattedCharSequence line : font.split(text, W - lx - 10)) {
                    g.drawString(font, line, x0 + lx, yy, col, false);
                    yy += 10;
                }
            } else {
                g.drawString(font, text, x0 + lx, ly, col, false);
            }
        }
    }
}
