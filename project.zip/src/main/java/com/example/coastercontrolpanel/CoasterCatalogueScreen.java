package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.neoforged.neoforge.network.PacketDistributor;

/** The catalogue: pick a coaster, see its layout from above and from the side, pick a colour and place it. */
public class CoasterCatalogueScreen extends Screen {
    private static final int W = 380;
    private static final int H = 236;
    private final BlockPos origin;
    private final int dir;
    private int selected = 0;
    private int colour = 0;
    private int station = 0;
    private Button stationButton;
    private int left;
    private int top;

    public CoasterCatalogueScreen(BlockPos origin, int dir) {
        super(Component.translatable("item.coastercontrolpanel.coaster_blueprint"));
        this.origin = origin;
        this.dir = dir;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        for (int i = 0; i < CoasterLayouts.IDS.length; i++) {
            final int n = i;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.coaster." + CoasterLayouts.IDS[i]), b -> selected = n)
                    .bounds(left + 8, top + 22 + i * 13, 146, 12).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.coaster_place"), b -> {
            PacketDistributor.sendToServer(new CoasterPlacePacket(origin, dir, selected, colour, station));
            onClose();
        }).bounds(left + 162, top + H - 20, 210, 16).build());
        stationButton = addRenderableWidget(Button.builder(stationText(), b -> {
            station = (station + 1) % 4;
            b.setMessage(stationText());
        }).bounds(left + 162, top + H - 38, 210, 14).build());
    }

    private Component stationText() {
        return Component.translatable("gui.coastercontrolpanel.coaster_station", Component.translatable("gui.coastercontrolpanel.coaster_station_" + station));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sx = left + 162;
        int sy = top + 150;
        for (int i = 0; i < CoasterBuilder.COLOURS.length; i++) {
            int x = sx + i * 23;
            if (mx >= x && mx < x + 20 && my >= sy && my < sy + 14) {
                colour = i;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xEE1B1F27);
        g.fill(left, top, left + W, top + 16, 0xFF2E6FB0);
        g.drawString(font, title, left + 6, top + 4, 0xFFFFFFFF, false);
        // preview boxes
        int bx = left + 162;
        g.fill(bx, top + 22, bx + 210, top + 112, 0xFF10141A);
        g.fill(bx, top + 114, bx + 210, top + 146, 0xFF10141A);
        preview(g, bx + 4, top + 26, 202, 82, true);
        preview(g, bx + 4, top + 118, 202, 24, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.coaster_top"), bx + 3, top + 23, 0xFF6C7A8C, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.coaster_side"), bx + 3, top + 115, 0xFF6C7A8C, false);
        // swatches
        for (int i = 0; i < CoasterBuilder.COLOURS.length; i++) {
            int x = bx + i * 23;
            DyeColor d = CoasterBuilder.COLOURS[i];
            int c = d == null ? 0xFF8C96A3 : 0xFF000000 | AnchorTrack.dyeRgb(d);
            g.fill(x - 1, top + 149, x + 21, top + 165, i == colour ? 0xFFFFFFFF : 0xFF4A5666);
            g.fill(x, top + 150, x + 20, top + 164, c);
            if (d == null) {
                g.drawString(font, "-", x + 8, top + 153, 0xFF10141A, false);
            }
        }
        // text
        g.drawString(font, CoasterLayouts.BLURBS[selected], bx, top + 168, 0xFFD6DEE8, false);
        int[][] a = CoasterLayouts.DATA[selected];
        int maxY = 0;
        int minX = 0;
        int maxX = 0;
        int minZ = 0;
        int maxZ = 0;
        for (int[] p : a) {
            maxY = Math.max(maxY, p[1]);
            minX = Math.min(minX, p[0]);
            maxX = Math.max(maxX, p[0]);
            minZ = Math.min(minZ, p[2]);
            maxZ = Math.max(maxZ, p[2]);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.coaster_stats", a.length, maxY + 1, (maxX - minX + 1), (maxZ - minZ + 1)), bx, top + 180, 0xFF9AA7B6, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.coaster_note"), bx, top + 192, 0xFF6C7A8C, false);
    }

    /** Draws the curve through the anchors the way the track will bend: each anchor leaves along its heading. */
    private void preview(GuiGraphics g, int x0, int y0, int w, int h, boolean top) {
        int[][] a = CoasterLayouts.DATA[selected];
        double minA = 1e9;
        double maxA = -1e9;
        double minB = 1e9;
        double maxB = -1e9;
        for (int[] p : a) {
            double u = top ? -p[0] : p[2];
            double v = top ? -p[2] : -p[1];
            minA = Math.min(minA, u);
            maxA = Math.max(maxA, u);
            minB = Math.min(minB, v);
            maxB = Math.max(maxB, v);
        }
        double sc = Math.min((w - 6) / Math.max(1, maxA - minA), (h - 6) / Math.max(1, maxB - minB));
        if (!top) {
            sc = Math.min(sc, 3.0);
        }
        double ox = x0 + (w - (maxA - minA) * sc) / 2 - minA * sc;
        double oy = y0 + (h - (maxB - minB) * sc) / 2 - minB * sc;
        int rgb = colour == 0 ? 0xFFE8EDF3 : 0xFF000000 | AnchorTrack.dyeRgb(CoasterBuilder.COLOURS[colour]);
        if (colour == 8) {
            rgb = 0xFF555B66;
        }
        for (int i = 0; i < a.length; i++) {
            int[] p = a[i];
            int[] q = a[(i + 1) % a.length];
            double[] tp = tangent(p[3]);
            double[] tq = tangent(q[3]);
            double dist = Math.sqrt(Math.pow(q[0] - p[0], 2) + Math.pow(q[1] - p[1], 2) + Math.pow(q[2] - p[2], 2));
            double k = dist * 0.55;
            for (int s = 0; s <= 24; s++) {
                double t = s / 24.0;
                double h00 = 2 * t * t * t - 3 * t * t + 1;
                double h10 = t * t * t - 2 * t * t + t;
                double h01 = -2 * t * t * t + 3 * t * t;
                double h11 = t * t * t - t * t;
                double cx = h00 * p[0] + h10 * k * tp[0] + h01 * q[0] + h11 * k * tq[0];
                double cy = h00 * p[1] + h10 * k * tp[1] + h01 * q[1] + h11 * k * tq[1];
                double cz = h00 * p[2] + h10 * k * tp[2] + h01 * q[2] + h11 * k * tq[2];
                double u = top ? -cx : cz;
                double v = top ? -cz : -cy;
                int px = (int) Math.round(ox + u * sc);
                int py = (int) Math.round(oy + v * sc);
                g.fill(px, py, px + 1, py + 1, rgb);
            }
        }
        // the station
        double u = top ? -a[0][0] : a[0][2];
        double v = top ? -a[0][2] : -a[0][1];
        int sx = (int) Math.round(ox + u * sc);
        int sy = (int) Math.round(oy + v * sc);
        g.fill(sx - 2, sy - 2, sx + 3, sy + 3, 0xFFFFC83C);
    }

    private static double[] tangent(int h) {
        return switch (h) {
            case 0 -> new double[] {0, 0, 1};
            case 1 -> new double[] {0, 0, -1};
            case 2 -> new double[] {1, 0, 0};
            case 3 -> new double[] {-1, 0, 0};
            case 4 -> new double[] {0, 1, 0};
            default -> new double[] {0, -1, 0};
        };
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
