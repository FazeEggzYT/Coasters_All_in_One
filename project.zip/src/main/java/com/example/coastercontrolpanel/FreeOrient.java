package com.example.coastercontrolpanel;

/**
 * Added to Create's controlled moving structure by a mixin: a turn made of up to four angles, so a structure can tilt and spin at once.
 * The turn is Rx(rx) after Ry(ry) after Rz(rz) after Ry(ry2), where the last one listed is applied first. All in degrees.
 */
public interface FreeOrient {
    void ccp$orient(float rx, float ry, float rz, float ry2);

    /** Back to Create's own single-axis turning. */
    void ccp$clearOrient();
}
