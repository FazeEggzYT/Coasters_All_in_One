package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** Right-click a placed Coaster Cart with it: opens the vehicle picker and dresses the cart with the chosen vehicle body. */
public class CoasterVehicleKitItem extends Item {
    public CoasterVehicleKitItem(Properties p) {
        super(p);
    }

    static boolean isCart(net.minecraft.world.level.Level level, BlockPos pos) {
        return "simulatedcoasters:coaster_cart".equals(BuiltInRegistries.BLOCK.getKey(level.getBlockState(pos).getBlock()).toString());
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        if (!isCart(c.getLevel(), c.getClickedPos())) {
            if (c.getPlayer() != null && !c.getLevel().isClientSide) {
                c.getPlayer().displayClientMessage(net.minecraft.network.chat.Component.translatable("message.coastercontrolpanel.vehicle_need_cart"), true);
            }
            return InteractionResult.FAIL;
        }
        if (c.getLevel().isClientSide) {
            ClientHooks.openVehicles(c.getClickedPos());
        }
        return InteractionResult.SUCCESS;
    }
}
