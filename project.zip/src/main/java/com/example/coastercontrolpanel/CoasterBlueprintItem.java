package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** Right-click the ground: opens the catalogue of pre-made coasters. The one you pick is built where you clicked. */
public class CoasterBlueprintItem extends Item {
    public CoasterBlueprintItem(Properties p) {
        super(p);
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        if (c.getLevel().isClientSide) {
            BlockPos origin = c.getClickedPos().relative(c.getClickedFace());
            ClientHooks.openCoasters(origin, c.getHorizontalDirection().get2DDataValue());
        }
        return InteractionResult.SUCCESS;
    }
}
