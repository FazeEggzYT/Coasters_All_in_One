package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * The Swivel Bearing: a fixed bearing and a Swivel Plate on its face. Everything built on the plate is moved to an
 * angle you choose, and held there. Right-click the bearing for its settings.
 */
public final class SwivelBlocks {
    private SwivelBlocks() {
    }

    public static class BearingBlock extends BaseEntityBlock {
        public static final MapCodec<BearingBlock> CODEC = simpleCodec(BearingBlock::new);
        public static final DirectionProperty FACING = net.minecraft.world.level.block.state.properties.BlockStateProperties.FACING;

        public BearingBlock(Properties properties) {
            super(properties);
            registerDefaultState(stateDefinition.any().setValue(FACING, Direction.UP));
        }

        /** 0 = Swivel Bearing, 1 = Flip Bearing, 2 = Spin Bearing. */
        public int kind() {
            return 0;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(FACING);
        }

        /** The plate goes on the side you click: the bearing faces away from that surface. */
        @Nullable
        @Override
        public BlockState getStateForPlacement(BlockPlaceContext context) {
            return defaultBlockState().setValue(FACING, context.getClickedFace());
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return Shapes.block();
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new SwivelBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return createTickerHelper(type, CoasterControlPanel.SWIVEL_BE.get(), (l, p, s, be) -> {
                if (l.isClientSide) {
                    be.clientTick();
                } else {
                    be.serverTick();
                }
            });
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRide(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof SwivelBlockEntity be) {
                be.bearingRemoved();
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof SwivelBlockEntity be) {
                be.refreshRedstone();
            }
        }
    }

    /** Flip Bearing: goes back and forth between two angles and stays assembled until a wrench takes it apart. */
    public static class FlipBearing extends BearingBlock {
        public static final MapCodec<FlipBearing> FLIP_CODEC = simpleCodec(FlipBearing::new);

        public FlipBearing(Properties properties) {
            super(properties);
        }

        @Override
        public int kind() {
            return 1;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return FLIP_CODEC;
        }
    }

    /** Spin Bearing: turns round and round (or a set number of degrees) and stays assembled until a wrench takes it apart. */
    public static class SpinBearing extends BearingBlock {
        public static final MapCodec<SpinBearing> SPIN_CODEC = simpleCodec(SpinBearing::new);

        public SpinBearing(Properties properties) {
            super(properties);
        }

        @Override
        public int kind() {
            return 2;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return SPIN_CODEC;
        }
    }

    /** Sway Bearing: swings back and forth like a pendulum while the signal is on, and settles when it goes. */
    public static class SwayBearing extends BearingBlock {
        public static final MapCodec<SwayBearing> SWAY_CODEC = simpleCodec(SwayBearing::new);

        public SwayBearing(Properties properties) {
            super(properties);
        }

        @Override
        public int kind() {
            return 3;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return SWAY_CODEC;
        }
    }

    /** Rock Bearing: a small quick rocking round the line it faces along. */
    public static class RockBearing extends BearingBlock {
        public static final MapCodec<RockBearing> ROCK_CODEC = simpleCodec(RockBearing::new);

        public RockBearing(Properties properties) {
            super(properties);
        }

        @Override
        public int kind() {
            return 4;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return ROCK_CODEC;
        }
    }

    /** Lift Bearing: moves the structure straight along a line, up and down or sideways, by a distance you set. */
    public static class LiftBearing extends BearingBlock {
        public static final MapCodec<LiftBearing> LIFT_CODEC = simpleCodec(LiftBearing::new);

        public LiftBearing(Properties properties) {
            super(properties);
        }

        @Override
        public int kind() {
            return 5;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return LIFT_CODEC;
        }
    }

    /** The hinge pin: the structure turns around the middle of this block. Put it on the bearing's face. */
    public static class PlateBlock extends Block {
        private static final VoxelShape SHAPE = Block.box(1, 1, 1, 15, 15, 15);

        public PlateBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }
}
