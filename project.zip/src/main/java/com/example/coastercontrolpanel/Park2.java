package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Behaviour of the drop 2 props (space station, cinema, spa, fairground, science, kids, souvenir, theming). */
final class Park2 {
    private Park2() {
    }

    static final Set<String> TOGGLES = Set.of("hologram_globe", "stage_curtain", "spotlight", "candle_shelf", "baby_care_room_door");
    static final Set<String> DOORS = Set.of("baby_care_room_door");
    static final String[] FILMS = {"film_adv", "film_com", "film_hor", "film_car"};
    static final String[] RIDES = {"Roller Coaster", "Ferris Wheel", "Carousel", "Drop Tower"};
    static final String[] FEATURES = {"Huge Nose", "Giant Ears", "Tiny Hat", "Big Smile", "Wild Hair", "Enormous Eyebrows"};
    static final int[] LIMITS = {90, 100, 120, 140};

    // ------------------------------------------------------------------ shapes

    /** Open doors and curtains can be walked through. Null means use the normal shape. */
    static VoxelShape shape(String id, BlockState s) {
        if (s.getValue(ParkProps.ST) != 1) {
            return null;
        }
        Direction f = s.getValue(DecorBlocks.FACING);
        if (DOORS.contains(id)) {
            return Shapes.or(DecorBlocks.dbox(f, 0, 0, 6, 2, 16, 10), DecorBlocks.dbox(f, 14, 0, 6, 16, 16, 10), DecorBlocks.dbox(f, 0, 14, 6, 16, 16, 10));
        }
        if (id.equals("stage_curtain")) {
            return Shapes.or(DecorBlocks.dbox(f, 0, 0, 6, 3, 16, 10), DecorBlocks.dbox(f, 13, 0, 6, 16, 16, 10), DecorBlocks.dbox(f, 0, 14, 6, 16, 16, 10));
        }
        return null;
    }

    // ------------------------------------------------------------------ plain props

    /** Returns true when the click was handled here. */
    static boolean use(String id, BlockState s, Level level, BlockPos pos, Player player, ServerLevel sl) {
        if (id.equals("stage_curtain")) {
            int n = s.getValue(ParkProps.ST) == 0 ? 1 : 0;
            curtains(level, pos, s, n);
            return true;
        }
        if (TOGGLES.contains(id)) {
            int n = s.getValue(ParkProps.ST) == 0 ? 1 : 0;
            level.setBlock(pos, s.setValue(ParkProps.ST, n), 3);
            ParkProps.sound(level, pos, ParkData.SOUND.getOrDefault(id, "lever"), ParkData.PITCH.getOrDefault(id, 1.0F));
            if (id.equals("spotlight")) {
                if (n == 1) {
                    level.scheduleTick(pos, s.getBlock(), 10);
                }
                beam(level, pos, s.setValue(ParkProps.ST, n), n == 1);
            }
            return true;
        }
        switch (id) {
            case "popcorn_bucket_stand" -> {
                ArcadeBlocks.give(player, new ItemStack(CoasterControlPanel.POPCORN_ITEM.get()));
                ParkProps.sound(level, pos, "pickup", 1.2F);
                return true;
            }
            case "cotton_candy_cart" -> {
                ArcadeBlocks.give(player, new ItemStack(CoasterControlPanel.CANDY_FLOSS.get()));
                ParkProps.sound(level, pos, "pickup", 1.4F);
                return true;
            }
            case "fossil_dig_pit" -> {
                int r = level.random.nextInt(20);
                ItemStack out = r < 7 ? new ItemStack(Items.BONE) : r < 12 ? new ItemStack(Items.CLAY_BALL) : r < 16 ? new ItemStack(Items.FLINT)
                        : r < 19 ? new ItemStack(Items.BONE_MEAL, 2) : new ItemStack(Items.AMETHYST_SHARD);
                ArcadeBlocks.give(player, out);
                ParkProps.sound(level, pos, "sand", 0.9F);
                ParkProps.say(player, "fossil_found", out.getHoverName());
                return true;
            }
            case "rocket_prop" -> {
                ParkProps.sound(level, pos, "cannon", 0.8F);
                sl.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 0.2, pos.getZ() + 0.5, 30, 0.3, 0.05, 0.3, 0.05);
                return true;
            }
            default -> {
                return Park3.use(id, s, level, pos, player, sl);
            }
        }
    }

    static boolean plainTick(String id, BlockState s, ServerLevel level, BlockPos pos) {
        if (id.equals("spotlight")) {
            if (s.getValue(ParkProps.ST) == 1) {
                beam(level, pos, s, true);
                level.scheduleTick(pos, s.getBlock(), 20);
            }
            return true;
        }
        return Park3.plainTick(id, s, level, pos);
    }

    /** Opens or closes this curtain and every curtain joined to it (same facing, up to 64). */
    static void curtains(Level level, BlockPos start, BlockState s, int n) {
        Set<BlockPos> seen = new java.util.HashSet<>();
        java.util.ArrayDeque<BlockPos> todo = new java.util.ArrayDeque<>();
        todo.add(start);
        seen.add(start);
        Direction f = s.getValue(DecorBlocks.FACING);
        while (!todo.isEmpty() && seen.size() < 64) {
            BlockPos p = todo.poll();
            for (Direction d : Direction.values()) {
                BlockPos q = p.relative(d);
                BlockState b = level.getBlockState(q);
                if (!seen.contains(q) && b.is(s.getBlock()) && b.getValue(DecorBlocks.FACING) == f) {
                    seen.add(q);
                    todo.add(q);
                }
            }
        }
        for (BlockPos p : seen) {
            BlockState b = level.getBlockState(p);
            level.setBlock(p, b.setValue(ParkProps.ST, n), 3);
        }
        ParkProps.sound(level, start, "wool", n == 1 ? 1.2F : 0.9F);
    }

    /** The spotlight lights a spot where its beam lands: the last free block in front of it, up to 14 blocks. */
    static void beam(Level level, BlockPos pos, BlockState s, boolean on) {
        Direction f = s.getValue(DecorBlocks.FACING);
        BlockPos last = null;
        for (int i = 1; i <= 14; i++) {
            BlockPos q = pos.relative(f, i);
            BlockState b = level.getBlockState(q);
            if (b.is(Blocks.LIGHT)) {
                level.setBlock(q, Blocks.AIR.defaultBlockState(), 3);
                last = q;
            } else if (b.isAir() || b.canBeReplaced() || b.getCollisionShape(level, q).isEmpty()) {
                last = q;
            } else {
                break;
            }
        }
        if (on && last != null) {
            BlockState b = level.getBlockState(last);
            if (b.isAir()) {
                level.setBlock(last, Blocks.LIGHT.defaultBlockState().setValue(net.minecraft.world.level.block.LightBlock.LEVEL, 15), 3);
            }
        }
    }

    static void removed(String id, BlockState s, Level level, BlockPos pos) {
        if (id.equals("spotlight")) {
            beam(level, pos, s, false);
        }
    }

    // ------------------------------------------------------------------ screens, server side

    static void broadcast(ServerLevel level, String key, Object... args) {
        for (ServerPlayer sp : level.players()) {
            sp.sendSystemMessage(Component.translatable("message.coastercontrolpanel." + key, args));
        }
    }

    static void near(ServerLevel level, BlockPos pos, double r, String key, Object... args) {
        for (ServerPlayer sp : level.players()) {
            if (sp.blockPosition().distSqr(pos) <= r * r) {
                sp.sendSystemMessage(Component.translatable("message.coastercontrolpanel." + key, args));
            }
        }
    }

    static void act(ServerPlayer p, ServerLevel level, BlockPos pos, ParkProps.Act blk, ParkProps.PropBE be, BlockState s, int action, int a, long now) {
        int st = s.getValue(ParkProps.ST);
        String name = p.getName().getString();
        switch (blk.id) {
            case "control_console" -> {
                if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    ParkProps.say(p, "console_diag", 96 + level.random.nextInt(5), 88 + level.random.nextInt(13));
                    ParkProps.sound(level, pos, "button", 1.4F);
                    level.scheduleTick(pos, blk, 100);
                } else if (action == 2) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 2), 3);
                    ParkProps.sound(level, pos, "bell", 0.5F);
                    broadcast(level, "red_alert", pos.getX(), pos.getY(), pos.getZ());
                } else if (action == 3) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    ParkProps.sound(level, pos, "bell", 1.6F);
                    broadcast(level, "all_clear");
                }
            }
            case "projector" -> {
                if (action == 2 && a >= 0 && a < 4) {
                    be.v[0] = a;
                    be.changed();
                    ParkProps.sound(level, pos, "button", 1.2F);
                } else if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    ParkProps.sound(level, pos, "lever", 1.0F);
                    near(level, pos, 24, "film_start", Component.translatable("gui.coastercontrolpanel.prop." + FILMS[be.v[0] & 3]));
                } else if (action == 3 && st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    ParkProps.sound(level, pos, "lever", 0.8F);
                    near(level, pos, 24, "film_stop");
                }
            }
            case "sauna_cabin" -> {
                if (action == 1) {
                    int n = st == 0 ? 1 : 0;
                    level.setBlock(pos, s.setValue(ParkProps.ST, n), 3);
                    be.v[0] = n;
                    ParkProps.sound(level, pos, "lever", 1.0F);
                    if (n == 1) {
                        be.t = now + 2400;
                        level.scheduleTick(pos, blk, 40);
                    }
                    be.changed();
                } else if (action == 2) {
                    if (st == 0) {
                        ParkProps.say(p, "sauna_cold");
                    } else {
                        be.v[0] = 2;
                        be.changed();
                        ParkProps.sound(level, pos, "splash", 1.2F);
                        ParkProps.puff(level, pos, "cloud", 30);
                    }
                } else if (action == 3) {
                    if (st == 0) {
                        ParkProps.say(p, "sauna_cold");
                    } else if (p.blockPosition().distSqr(pos) > 25) {
                        ParkProps.say(p, "too_far");
                    } else {
                        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, be.v[0] == 2 ? 1200 : 600, 0));
                        ParkProps.say(p, "sweated");
                    }
                }
            }
            case "duck_pond_game" -> {
                if (action == 1 && a >= 0 && a < 4 && ParkProps.pay(p, 1)) {
                    int win = be.v[0] & 3;
                    ParkProps.sound(level, pos, "splash", 1.3F);
                    if (a == win) {
                        ArcadeBlocks.give(p, new ItemStack(CoasterControlPanel.PRIZE_TICKET.get(), 3));
                        ParkProps.say(p, "duck_win");
                    } else if (level.random.nextInt(4) == 0) {
                        ArcadeBlocks.give(p, new ItemStack(CoasterControlPanel.PRIZE_TICKET.get(), 1));
                        ParkProps.say(p, "duck_small");
                    } else {
                        ParkProps.say(p, "duck_blank");
                    }
                    be.v[0] = level.random.nextInt(4);
                    be.changed();
                }
            }
            case "fortune_teller_booth" -> {
                if (action == 1 && ParkProps.pay(p, 1)) {
                    p.sendSystemMessage(Component.translatable("message.coastercontrolpanel.fortune_" + level.random.nextInt(8)));
                    ParkProps.sound(level, pos, "bell", 1.5F);
                    if (level.random.nextInt(5) == 0) {
                        p.addEffect(new MobEffectInstance(MobEffects.LUCK, 3600, 0));
                        ParkProps.say(p, "fortune_lucky");
                    }
                }
            }
            case "tesla_coil" -> {
                if (action == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                    ParkProps.sound(level, pos, "lever", 1.4F);
                    level.scheduleTick(pos, blk, 20);
                } else if (action == 2) {
                    if (st == 0) {
                        ParkProps.say(p, "tesla_off");
                    } else {
                        level.setBlock(pos, s.setValue(ParkProps.ST, 2), 3);
                        AABB box = new AABB(pos).inflate(5);
                        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> !(e instanceof Player))) {
                            e.hurt(level.damageSources().lightningBolt(), 6.0F);
                            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY() + 1, e.getZ(), 12, 0.3, 0.5, 0.3, 0.1);
                        }
                        level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 0.7F, 1.6F);
                        level.scheduleTick(pos, blk, 10);
                    }
                } else if (action == 3) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                    ParkProps.sound(level, pos, "lever", 0.8F);
                }
            }
            case "magnet_table" -> {
                if (action >= 1 && action <= 3) {
                    int mode = action == 3 ? 0 : action;
                    be.v[0] = mode;
                    be.changed();
                    level.setBlock(pos, s.setValue(ParkProps.ST, mode == 0 ? 0 : 1), 3);
                    ParkProps.sound(level, pos, "lever", 1.2F);
                    if (mode != 0) {
                        level.scheduleTick(pos, blk, 4);
                    }
                }
            }
            case "weather_station" -> {
                if (action == 1) {
                    broadcast(level, "weather_announce", weatherWord(level), temperature(level, pos), name);
                    ParkProps.sound(level, pos, "bell", 1.4F);
                }
            }
            case "height_measure_post" -> {
                if (action == 1 && a >= 0 && a < 4) {
                    be.v[0] = a;
                    be.changed();
                    level.setBlock(pos, s.setValue(ParkProps.ST, a), 3);
                    ParkProps.sound(level, pos, "wood", 1.2F);
                } else if (action == 2) {
                    ParkProps.say(p, "height_pass", LIMITS[be.v[0] & 3]);
                    ParkProps.sound(level, pos, "bell", 1.8F);
                }
            }
            case "kids_ticket_window" -> {
                if (action == 1 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(CoasterControlPanel.TICKET_ITEM.get(), "Kids' Ticket"));
                    ParkProps.sound(level, pos, "bell", 1.6F);
                } else if (action == 2 && ParkProps.pay(p, 2)) {
                    ItemStack t = ParkProps.named(CoasterControlPanel.TICKET_ITEM.get(), "Kids' Ticket");
                    t.setCount(3);
                    ArcadeBlocks.give(p, t);
                    ParkProps.sound(level, pos, "bell", 1.3F);
                }
            }
            case "ride_photo_kiosk" -> {
                if (action == 1 && a >= 0 && a < 4 && ParkProps.pay(p, 2)) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Ride Photo: " + RIDES[a] + " - " + name));
                    ParkProps.sound(level, pos, "button", 1.6F);
                }
            }
            case "caricature_stand" -> {
                if (action == 1 && ParkProps.pay(p, 2)) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.PAPER, "Caricature of " + name + " (" + FEATURES[level.random.nextInt(FEATURES.length)] + ")"));
                    ParkProps.sound(level, pos, "wood", 1.5F);
                }
            }
            case "name_badge_printer" -> {
                if (action == 1 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.NAME_TAG, "Guest: " + name));
                    ParkProps.sound(level, pos, "button", 1.0F);
                } else if (action == 2 && ParkProps.pay(p, 1)) {
                    ArcadeBlocks.give(p, ParkProps.named(Items.NAME_TAG, "Hero " + name));
                    ParkProps.sound(level, pos, "button", 1.8F);
                }
            }
            default -> Park3.act(p, level, pos, blk, be, s, action, a, now);
        }
    }

    // ------------------------------------------------------------------ scheduled ticks of screen props

    static boolean tick(ParkProps.Act blk, BlockState s, ServerLevel level, BlockPos pos, ParkProps.PropBE be, long now) {
        int st = s.getValue(ParkProps.ST);
        switch (blk.id) {
            case "control_console" -> {
                if (st == 1) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                }
                return true;
            }
            case "sauna_cabin" -> {
                if (st == 1) {
                    if (now >= be.t) {
                        level.setBlock(pos, s.setValue(ParkProps.ST, 0), 3);
                        be.v[0] = 0;
                        be.changed();
                        ParkProps.sound(level, pos, "lever", 0.7F);
                    } else {
                        ParkProps.puff(level, pos, "cloud", be.v[0] == 2 ? 4 : 1);
                        level.scheduleTick(pos, blk, 40);
                    }
                }
                return true;
            }
            case "tesla_coil" -> {
                if (st == 2) {
                    level.setBlock(pos, s.setValue(ParkProps.ST, 1), 3);
                }
                if (st >= 1) {
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.2, 0.2, 0.2, 0.05);
                    level.scheduleTick(pos, blk, 20);
                }
                return true;
            }
            case "magnet_table" -> {
                int mode = be.v[0];
                if (mode != 0) {
                    Vec3 c = new Vec3(pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5);
                    for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(5))) {
                        Vec3 d = c.subtract(ie.position());
                        if (d.lengthSqr() < 0.04) {
                            continue;
                        }
                        Vec3 dir = d.normalize().scale(mode == 1 ? 0.08 : -0.08);
                        ie.setDeltaMovement(ie.getDeltaMovement().add(dir).add(0, 0.02, 0));
                        ie.hasImpulse = true;
                    }
                    level.scheduleTick(pos, blk, 4);
                }
                return true;
            }
            default -> {
                return Park3.tick(blk, s, level, pos, be, now);
            }
        }
    }

    // ------------------------------------------------------------------ weather

    static Component weatherWord(Level level) {
        String k = level.isThundering() ? "weather_storm" : level.isRaining() ? "weather_rain" : "weather_clear";
        return Component.translatable("gui.coastercontrolpanel.prop." + k);
    }

    static int temperature(Level level, BlockPos pos) {
        float t = level.getBiome(pos).value().getBaseTemperature();
        return Math.round(t * 20.0F - 2.0F - (level.isRaining() ? 4 : 0) - (isNight(level) ? 5 : 0));
    }

    static boolean isNight(Level level) {
        long d = level.getDayTime() % 24000L;
        return d >= 13000L;
    }

    /** Lines shown on the weather station screen (client side). */
    static List<Component> weatherLines(Level level, BlockPos pos) {
        List<Component> out = new ArrayList<>();
        out.add(Component.translatable("gui.coastercontrolpanel.prop.weather_now", weatherWord(level)));
        long d = (level.getDayTime() + 6000L) % 24000L;
        out.add(Component.translatable("gui.coastercontrolpanel.prop.weather_time", String.format("%02d:%02d", d / 1000L, (d % 1000L) * 60L / 1000L)));
        out.add(Component.translatable("gui.coastercontrolpanel.prop.weather_temp", temperature(level, pos)));
        return out;
    }
}
