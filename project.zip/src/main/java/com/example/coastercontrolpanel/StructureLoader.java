package com.example.coastercontrolpanel;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Reads a building from data/coastercontrolpanel/structures/(id).txt and places it. The file is written by props/structs.py.
 * Lines: P index state | B x1 y1 z1 x2 y2 z2 index | S x y z index | F x1 z1 x2 z2 (foundation) | H height.
 * The building grows towards +z with its front at z = 0; ParkStructure.B turns it to face the player.
 */
final class StructureLoader {
    private StructureLoader() {
    }

    static boolean build(ParkStructure.B b, ServerLevel lv, String id) {
        List<String> lines = new ArrayList<>();
        try {
            ResourceLocation rl = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "structures/" + id + ".txt");
            var res = lv.getServer().getResourceManager().getResource(rl);
            if (res.isEmpty()) {
                return false;
            }
            try (BufferedReader r = new BufferedReader(new InputStreamReader(res.get().open(), StandardCharsets.UTF_8))) {
                String ln;
                while ((ln = r.readLine()) != null) {
                    lines.add(ln);
                }
            }
        } catch (Exception e) {
            return false;
        }
        List<BlockState> pal = new ArrayList<>();
        int height = 0;
        for (String ln : lines) {
            if (ln.startsWith("H ")) {
                height = Integer.parseInt(ln.substring(2).trim());
            }
        }
        if (b.at(0, height, 0).getY() >= lv.getMaxBuildHeight() || b.at(0, -6, 0).getY() < lv.getMinBuildHeight()) {
            return false;
        }
        for (String ln : lines) {
            String[] t = ln.split(" ");
            switch (t[0]) {
                case "P" -> {
                    int idx = Integer.parseInt(t[1]);
                    while (pal.size() <= idx) {
                        pal.add(null);
                    }
                    pal.set(idx, parse(t[2], b.rot));
                }
                case "B" -> {
                    BlockState s = pal.get(Integer.parseInt(t[7]));
                    if (s != null) {
                        b.fill(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3]),
                                Integer.parseInt(t[4]), Integer.parseInt(t[5]), Integer.parseInt(t[6]), s);
                    }
                }
                case "S" -> {
                    BlockState s = pal.get(Integer.parseInt(t[4]));
                    if (s != null) {
                        b.set(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3]), s);
                    }
                }
                case "F" -> b.foundation(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3]), Integer.parseInt(t[4]));
                default -> {
                }
            }
        }
        return true;
    }

    /** "namespace:block[a=b,c=d]" to a state. Horizontal facings are turned with the building. Returns null if the block is not installed. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static BlockState parse(String s, Rotation rot) {
        String name = s;
        String props = "";
        int i = s.indexOf('[');
        if (i >= 0) {
            name = s.substring(0, i);
            props = s.substring(i + 1, s.length() - 1);
        }
        Optional<Block> ob = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(name));
        if (ob.isEmpty()) {
            return null;
        }
        BlockState st = ob.get().defaultBlockState();
        if (props.isEmpty()) {
            return st;
        }
        for (String kv : props.split(",")) {
            String[] p = kv.split("=");
            Property<?> prop = ob.get().getStateDefinition().getProperty(p[0]);
            if (prop == null) {
                continue;
            }
            Optional<?> v = prop.getValue(p[1]);
            if (v.isEmpty()) {
                continue;
            }
            Object val = v.get();
            if (val instanceof Direction d && d.getAxis().isHorizontal()) {
                val = rot.rotate(d);
            } else if (val instanceof Direction.Axis ax && (rot == Rotation.CLOCKWISE_90 || rot == Rotation.COUNTERCLOCKWISE_90)) {
                val = ax == Direction.Axis.X ? Direction.Axis.Z : ax == Direction.Axis.Z ? Direction.Axis.X : ax;
            }
            if (prop.getPossibleValues().contains(val)) {
                st = st.setValue((Property) prop, (Comparable) val);
            }
        }
        return st;
    }
}
