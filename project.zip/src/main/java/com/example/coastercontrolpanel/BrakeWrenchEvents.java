package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * Right-click an anchor of a Brake Run with the Create Wrench (not sneaking) to open its settings. Works on both of
 * its anchors. Sneak-right-click is left alone, so the base mod's wrench actions (removing a span) still work, and
 * anchors that are not part of a Brake Run are never touched.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class BrakeWrenchEvents {
    /** Once a second: tyres that no cart is on any more stop turning. */
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel sl) {
            TriggerSignal.tick(sl);
            if (sl.getGameTime() % 20 == 0) {
                BrakeController.idleSweep(sl);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || event.getEntity().isShiftKeyDown()
                || !(event.getItemStack().getItem() instanceof WrenchItem)) {
            return;
        }
        BlockPos start = BrakeController.findStart(event.getLevel(), event.getPos());
        if (start == null) {
            // Not a Brake Run: a Break Down Your Coaster zone on this anchor opens its own screen instead.
            BlockPos zone = BreakdownEvents.zoneStart(event.getLevel(), event.getPos());
            if (zone != null) {
                event.setCanceled(true);
                event.setCancellationResult(InteractionResult.SUCCESS);
                if (event.getLevel().isClientSide) {
                    ClientHooks.openBreakdown(zone);
                }
            }
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            ClientHooks.openBrakeRun(start);
        }
    }
}
