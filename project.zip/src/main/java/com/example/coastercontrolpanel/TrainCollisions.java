package com.example.coastercontrolpanel;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Two trains hitting each other. A cart of one train that comes within two blocks of a cart of another, closing fast,
 * is a crash: every rider of both trains is hurt by how hard the hit was, and both trains are held still for a while.
 * If the Coaster Injuries (Sable) mod is installed its damage types and blood effect are used, through reflection.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public final class TrainCollisions {
    /** Closing speed in blocks per second: below MINOR nothing happens. */
    private static final double MINOR = 4.0;
    private static final double MAJOR = 10.0;
    private static final double FATAL = 20.0;
    private static final double HIT_DISTANCE = 2.0;
    private static final double SAME_TRAIN = 5.0;
    private static final int HOLD_TICKS = 300;

    private static final Map<Object, Vec3> LAST = new WeakHashMap<>();
    private static final Map<Object, Integer> GROUP = new WeakHashMap<>();
    private static final Map<Object, Long> HELD_UNTIL = new WeakHashMap<>();
    private static final Map<Long, Long> COOLDOWN = new HashMap<>();
    private static int nextGroup = 1;

    private TrainCollisions() {
    }

    public static boolean isHeld(Object body) {
        Long until = HELD_UNTIL.get(body);
        return until != null && until > lastTick;
    }

    private static long lastTick;

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel sl)) {
            return;
        }
        long tick = sl.getGameTime();
        lastTick = tick;
        if (tick % 2 != 0 || sl.players().isEmpty()) {
            return;
        }
        try {
            List<Object[]> carts = CartScanner.carts(sl);
            if (carts.size() < 2) {
                for (Object[] c : carts) {
                    remember(c);
                }
                return;
            }
            assignGroups(carts);
            Object system = null;
            boolean any = false;
            for (Object[] c : carts) {
                Long until = HELD_UNTIL.get(c[0]);
                if (until != null && until > tick) {
                    if (system == null) {
                        system = CartScanner.systemFor(sl);
                    }
                    if (system != null) {
                        BrakeController.damp(c[0], system, 0.4);
                    }
                    any = true;
                }
            }
            if (!any) {
                detect(sl, carts, tick);
            }
            for (Object[] c : carts) {
                remember(c);
            }
        } catch (Throwable t) {
            CoasterControlPanel.LOGGER.error("Train collisions: error in the tick", t);
        }
    }

    private static void remember(Object[] c) {
        Vector3d v = (Vector3d) c[1];
        LAST.put(c[0], new Vec3(v.x(), v.y(), v.z()));
    }

    private static Vec3 pos(Object[] c) {
        Vector3d v = (Vector3d) c[1];
        return new Vec3(v.x(), v.y(), v.z());
    }

    /** Carts close together belong to one train. A new cart joins the train of the nearest known cart. */
    private static void assignGroups(List<Object[]> carts) {
        for (Object[] c : carts) {
            if (GROUP.containsKey(c[0])) {
                continue;
            }
            Vec3 p = pos(c);
            Integer found = null;
            double best = SAME_TRAIN;
            for (Object[] o : carts) {
                Integer g = GROUP.get(o[0]);
                if (o != c && g != null) {
                    double d = pos(o).distanceTo(p);
                    if (d < best) {
                        best = d;
                        found = g;
                    }
                }
            }
            GROUP.put(c[0], found != null ? found : nextGroup++);
        }
    }

    private static void detect(ServerLevel sl, List<Object[]> carts, long tick) {
        for (int i = 0; i < carts.size(); i++) {
            for (int j = i + 1; j < carts.size(); j++) {
                Object[] a = carts.get(i);
                Object[] b = carts.get(j);
                Integer ga = GROUP.get(a[0]);
                Integer gb = GROUP.get(b[0]);
                if (ga == null || gb == null || ga.equals(gb)) {
                    continue;
                }
                Vec3 pa = pos(a);
                Vec3 pb = pos(b);
                if (pa.distanceTo(pb) > HIT_DISTANCE) {
                    continue;
                }
                Vec3 la = LAST.get(a[0]);
                Vec3 lb = LAST.get(b[0]);
                if (la == null || lb == null) {
                    continue;
                }
                Vec3 va = pa.subtract(la).scale(10.0); // blocks per second: two ticks per step
                Vec3 vb = pb.subtract(lb).scale(10.0);
                Vec3 line = pb.subtract(pa);
                if (line.lengthSqr() < 1.0E-6) {
                    continue;
                }
                double closing = va.subtract(vb).dot(line.normalize());
                if (closing < MINOR) {
                    continue;
                }
                long key = ((long) Math.min(ga, gb) << 32) | Math.max(ga, gb);
                Long cd = COOLDOWN.get(key);
                if (cd != null && cd > tick) {
                    continue;
                }
                COOLDOWN.put(key, tick + 200);
                crash(sl, carts, ga, gb, pa.add(pb).scale(0.5), closing, tick);
                return;
            }
        }
    }

    private static void crash(ServerLevel sl, List<Object[]> carts, int ga, int gb, Vec3 where, double speed, long tick) {
        for (Object[] c : carts) {
            Integer g = GROUP.get(c[0]);
            if (g != null && (g == ga || g == gb)) {
                HELD_UNTIL.put(c[0], tick + HOLD_TICKS);
            }
        }
        int level = speed >= FATAL ? 3 : speed >= MAJOR ? 2 : 1;
        sl.sendParticles(ParticleTypes.EXPLOSION, where.x, where.y + 0.5, where.z, 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, where.x, where.y + 0.8, where.z, 12, 0.6, 0.4, 0.6, 0.02);
        sl.playSound(null, net.minecraft.core.BlockPos.containing(where), net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE.value(),
                net.minecraft.sounds.SoundSource.BLOCKS, 1.5F, 0.7F);
        boolean jar = ModList.get().isLoaded("sable_injuries");
        for (ServerPlayer p : new ArrayList<>(sl.players())) {
            if (!p.isPassenger() || !nearTrain(p, carts, ga, gb)) {
                continue;
            }
            hurt(sl, p, level, speed, jar);
        }
    }

    private static boolean nearTrain(ServerPlayer p, List<Object[]> carts, int ga, int gb) {
        Vec3 pp = p.position();
        for (Object[] c : carts) {
            Integer g = GROUP.get(c[0]);
            if (g != null && (g == ga || g == gb) && pos(c).distanceTo(pp) < 6.0) {
                return true;
            }
        }
        return false;
    }

    private static void hurt(ServerLevel sl, ServerPlayer p, int level, double speed, boolean jar) {
        DamageSource src = null;
        if (jar) {
            src = injuryDamage(sl, level >= 3 ? "pillarCollision" : "whiplash");
        }
        if (src == null) {
            src = sl.damageSources().flyIntoWall();
        }
        float amount = level == 1 ? 4.0F : level == 2 ? 12.0F : 1000.0F;
        p.hurt(src, amount);
        if (level >= 2) {
            blood(sl, p, jar, level >= 3);
        }
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel.crash_" + level), false);
    }

    private static DamageSource injuryDamage(ServerLevel sl, String method) {
        try {
            Class<?> c = Class.forName("com.sable.injuries.damage.InjuryDamageTypes");
            Object o = c.getMethod(method, ServerLevel.class).invoke(null, sl);
            return o instanceof DamageSource d ? d : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void blood(ServerLevel sl, ServerPlayer p, boolean jar, boolean heavy) {
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
                p.getX(), p.getY() + 1.2, p.getZ(), heavy ? 40 : 16, 0.3, 0.4, 0.3, 0.1);
        if (!jar) {
            return;
        }
        try {
            Class<?> c = Class.forName("com.sable.injuries.network.InjurySyncPayload");
            Object payload = c.getConstructor(boolean.class, float.class).newInstance(true, 0.0F);
            if (payload instanceof CustomPacketPayload cp) {
                PacketDistributor.sendToPlayer(p, cp);
            }
        } catch (Throwable t) {
            // the blood effect is only decoration
        }
    }
}
