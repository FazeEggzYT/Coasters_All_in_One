package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * The Arcade pack. A game machine takes one Arcade Token to start a game; the score is worked out in the game screen,
 * and the server checks it, caps it, and pays Prize Tickets. Tickets are spent at the Prize Counter.
 */
public final class ArcadeBlocks {
    private ArcadeBlocks() {
    }

    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 8);
    public static final BooleanProperty[] KNOCKED = {
            BooleanProperty.create("c0"), BooleanProperty.create("c1"), BooleanProperty.create("c2"),
            BooleanProperty.create("c3"), BooleanProperty.create("c4")};

    public static int count(Player p, Item item) {
        int n = 0;
        for (ItemStack s : p.getInventory().items) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        return n;
    }

    public static void take(Player p, Item item, int amount) {
        for (ItemStack s : p.getInventory().items) {
            if (amount <= 0) {
                return;
            }
            if (s.is(item)) {
                int t = Math.min(amount, s.getCount());
                s.shrink(t);
                amount -= t;
            }
        }
    }

    public static void give(Player p, ItemStack stack) {
        if (!p.getInventory().add(stack)) {
            p.drop(stack, false);
        }
    }

    // ------------------------------------------------------------------ the game machine's memory

    public static class ArcadeBlockEntity extends RestaurantBlocks.Syncing {
        public static final int SESSION_TICKS = 20 * 180;
        public UUID session;
        public long sessionEnd;
        public int sub;
        public final int[] highs = new int[3];
        public final String[] highNames = {"", "", ""};
        public int lastSub;
        public int last;
        public final ItemStack[] stock = {ItemStack.EMPTY, ItemStack.EMPTY, ItemStack.EMPTY, ItemStack.EMPTY, ItemStack.EMPTY};

        public ArcadeBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.ARCADE_BE.get(), pos, state);
        }

        public ArcadeGame game() {
            return getBlockState().getBlock() instanceof ArcadeBlock b ? b.game : ArcadeGame.CABINET;
        }

        private long now() {
            return level == null ? 0 : level.getGameTime();
        }

        public boolean sessionActive(@Nullable Player p) {
            return session != null && now() < sessionEnd && (p == null || session.equals(p.getUUID()));
        }

        public void start(ServerPlayer p, int sub) {
            if (sessionActive(null) && !session.equals(p.getUUID())) {
                p.displayClientMessage(Component.translatable("message.coastercontrolpanel.arcade_busy"), true);
                return;
            }
            if (!p.getAbilities().instabuild) {
                if (count(p, CoasterControlPanel.ARCADE_TOKEN.get()) < 1) {
                    p.displayClientMessage(Component.translatable("message.coastercontrolpanel.arcade_no_token"), true);
                    return;
                }
                take(p, CoasterControlPanel.ARCADE_TOKEN.get(), 1);
            }
            session = p.getUUID();
            sessionEnd = now() + SESSION_TICKS;
            this.sub = Math.max(0, Math.min(2, sub));
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.BLOCKS, 0.8F, 1.6F);
            }
            changed();
        }

        public void finish(ServerPlayer p, int score, int extra) {
            if (!sessionActive(p) || level == null) {
                return;
            }
            ArcadeGame g = game();
            int s = Math.max(0, Math.min(g.maxScore(sub), score));
            int tickets = g.tickets(sub, s);
            int slot = g == ArcadeGame.CABINET ? sub : 0;
            if (s > highs[slot]) {
                highs[slot] = s;
                highNames[slot] = p.getName().getString();
            }
            lastSub = slot;
            last = s;
            session = null;
            BlockState st = getBlockState();
            if (g == ArcadeGame.STRENGTH) {
                level.setBlock(worldPosition, st.setValue(LEVEL, Math.min(8, (s * 8 + 99) / 100)), 3);
                level.scheduleTick(worldPosition, st.getBlock(), 120);
            } else if (g == ArcadeGame.COCONUT) {
                BlockState n = st;
                for (int i = 0; i < 5; i++) {
                    n = n.setValue(KNOCKED[i], (extra & (1 << i)) != 0);
                }
                level.setBlock(worldPosition, n, 3);
                level.scheduleTick(worldPosition, st.getBlock(), 600);
            }
            if (tickets > 0) {
                give(p, new ItemStack(CoasterControlPanel.PRIZE_TICKET.get(), tickets));
                level.playSound(null, worldPosition, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.arcade_result", s, tickets), true);
            changed();
        }

        /** Claw machine: the player aimed at a prize slot; closeness 0..100 sets the chance of a grab. */
        public void claw(ServerPlayer p, int slot, int closeness) {
            if (!sessionActive(p) || level == null) {
                return;
            }
            session = null;
            changed();
            if (slot < 0 || slot >= 5 || stock[slot].isEmpty()) {
                p.displayClientMessage(Component.translatable("message.coastercontrolpanel.claw_miss"), true);
                return;
            }
            float chance = 0.2F + 0.5F * Math.max(0, Math.min(100, closeness)) / 100.0F;
            if (level.random.nextFloat() < chance) {
                ItemStack prize = stock[slot].copyWithCount(1);
                stock[slot].shrink(1);
                if (stock[slot].isEmpty()) {
                    stock[slot] = ItemStack.EMPTY;
                }
                give(p, prize);
                level.playSound(null, worldPosition, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.7F, 1.4F);
                p.displayClientMessage(Component.translatable("message.coastercontrolpanel.claw_win", prize.getHoverName()), true);
            } else {
                p.displayClientMessage(Component.translatable("message.coastercontrolpanel.claw_slip"), true);
            }
            changed();
        }

        public int addStock(ItemStack held) {
            for (int i = 0; i < 5; i++) {
                if (!stock[i].isEmpty() && ItemStack.isSameItemSameComponents(stock[i], held) && stock[i].getCount() < 16) {
                    stock[i].grow(1);
                    changed();
                    return 0;
                }
            }
            for (int i = 0; i < 5; i++) {
                if (stock[i].isEmpty()) {
                    stock[i] = held.copyWithCount(1);
                    changed();
                    return 0;
                }
            }
            return 1;
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (session != null) {
                tag.putUUID("Session", session);
            }
            tag.putLong("End", sessionEnd);
            tag.putInt("Sub", sub);
            tag.putInt("LastSub", lastSub);
            tag.putInt("Last", last);
            tag.putIntArray("Highs", highs);
            for (int i = 0; i < 3; i++) {
                tag.putString("HN" + i, highNames[i]);
            }
            ListTag list = new ListTag();
            for (int i = 0; i < 5; i++) {
                list.add(stock[i].saveOptional(registries));
            }
            tag.put("Stock", list);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            session = tag.hasUUID("Session") ? tag.getUUID("Session") : null;
            sessionEnd = tag.getLong("End");
            sub = tag.getInt("Sub");
            lastSub = tag.getInt("LastSub");
            last = tag.getInt("Last");
            int[] h = tag.getIntArray("Highs");
            for (int i = 0; i < 3 && i < h.length; i++) {
                highs[i] = h[i];
            }
            for (int i = 0; i < 3; i++) {
                highNames[i] = tag.getString("HN" + i);
            }
            ListTag list = tag.getList("Stock", Tag.TAG_COMPOUND);
            for (int i = 0; i < 5; i++) {
                stock[i] = i < list.size() ? ItemStack.parseOptional(registries, list.getCompound(i)) : ItemStack.EMPTY;
            }
        }
    }

    // ------------------------------------------------------------------ the game machine block

    /** Right-click for the game screen. The claw machine is stocked by right-clicking with an item. */
    public static class ArcadeBlock extends BaseEntityBlock {
        public static final MapCodec<ArcadeBlock> CODEC = simpleCodec(p -> new ArcadeBlock(ArcadeGame.CABINET, p));
        public final ArcadeGame game;

        public ArcadeBlock(ArcadeGame game, Properties p) {
            super(p);
            this.game = game;
            BlockState s = stateDefinition.any().setValue(DecorBlocks.FACING, Direction.NORTH);
            if (game == ArcadeGame.STRENGTH) {
                s = s.setValue(LEVEL, 0);
            }
            if (game == ArcadeGame.COCONUT) {
                for (BooleanProperty b : KNOCKED) {
                    s = s.setValue(b, false);
                }
            }
            registerDefaultState(s);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(DecorBlocks.FACING);
            b.add(LEVEL);
            b.add(KNOCKED);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return defaultBlockState().setValue(DecorBlocks.FACING, c.getHorizontalDirection().getOpposite());
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return switch (game) {
                case MOLE -> Block.box(1, 0, 1, 15, 14, 15);
                case RINGS -> Block.box(1, 0, 1, 15, 16, 15);
                case AIR_HOCKEY, PINBALL, DANCE, RACING, FOOSBALL, SKEE, DARTS -> ParkProps.shape0(game.id, s.getValue(DecorBlocks.FACING));
                default -> Block.box(1, 0, 1, 15, 16, 15);
            };
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ArcadeBlockEntity(pos, state);
        }

        @Override
        protected boolean isSignalSource(BlockState state) {
            return game == ArcadeGame.STRENGTH;
        }

        @Override
        protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
            return game == ArcadeGame.STRENGTH ? state.getValue(LEVEL) * 15 / 8 : 0;
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (game == ArcadeGame.STRENGTH && s.getValue(LEVEL) != 0) {
                level.setBlock(pos, s.setValue(LEVEL, 0), 3);
            } else if (game == ArcadeGame.COCONUT) {
                BlockState n = s;
                for (BooleanProperty b : KNOCKED) {
                    n = n.setValue(b, false);
                }
                level.setBlock(pos, n, 3);
            }
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (game != ArcadeGame.CLAW || stack.isEmpty()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof ArcadeBlockEntity be) {
                if (be.addStock(stack) == 0) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.claw_stocked", stack.getHoverName()), true);
                } else {
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.claw_full"), true);
                }
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openArcade(game.ordinal(), pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && game == ArcadeGame.CLAW && level.getBlockEntity(pos) instanceof ArcadeBlockEntity be) {
                for (ItemStack st : be.stock) {
                    if (!st.isEmpty()) {
                        Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, st.copy());
                    }
                }
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    // ------------------------------------------------------------------ token machine and prize counter

    public static class TokenBlockEntity extends RestaurantBlocks.Syncing {
        public int rate = 2;

        public TokenBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.TOKEN_BE.get(), pos, state);
        }

        public void exchange(ServerPlayer p, int nuggets) {
            int have = count(p, Items.GOLD_NUGGET);
            int n = nuggets <= 0 ? Math.min(have, 64) : Math.min(nuggets, have);
            if (n <= 0) {
                p.displayClientMessage(Component.translatable("message.coastercontrolpanel.token_none"), true);
                return;
            }
            take(p, Items.GOLD_NUGGET, n);
            int tokens = n * rate;
            while (tokens > 0) {
                int t = Math.min(64, tokens);
                give(p, new ItemStack(CoasterControlPanel.ARCADE_TOKEN.get(), t));
                tokens -= t;
            }
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.8F, 1.3F);
            }
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.token_ok", n * rate), true);
        }

        public void changeRate(int d) {
            rate = Math.max(1, Math.min(8, rate + d));
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Rate", rate);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            if (tag.contains("Rate")) {
                rate = Math.max(1, tag.getInt("Rate"));
            }
        }
    }

    public static class TokenBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<TokenBlock> CODEC = simpleCodec(TokenBlock::new);

        public TokenBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(2, 0, 2, 14, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new TokenBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openArcade(100, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    public static class PrizeBlockEntity extends RestaurantBlocks.Syncing {
        public static final int SLOTS = 6;
        public final ItemStack[] offers = new ItemStack[SLOTS];
        public final int[] prices = new int[SLOTS];

        public PrizeBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PRIZE_BE.get(), pos, state);
            for (int i = 0; i < SLOTS; i++) {
                offers[i] = ItemStack.EMPTY;
                prices[i] = 5;
            }
        }

        public int addOffer(ItemStack held) {
            for (int i = 0; i < SLOTS; i++) {
                if (!offers[i].isEmpty() && ItemStack.isSameItem(offers[i], held)) {
                    return 1;
                }
            }
            for (int i = 0; i < SLOTS; i++) {
                if (offers[i].isEmpty()) {
                    offers[i] = held.copyWithCount(1);
                    prices[i] = 5;
                    changed();
                    return 0;
                }
            }
            return 2;
        }

        public void clearOffer(int i) {
            if (i >= 0 && i < SLOTS) {
                offers[i] = ItemStack.EMPTY;
                changed();
            }
        }

        public void changePrice(int i, int d) {
            if (i >= 0 && i < SLOTS && !offers[i].isEmpty()) {
                prices[i] = Math.max(1, Math.min(99, prices[i] + d));
                changed();
            }
        }

        public void buy(ServerPlayer p, int i) {
            if (i < 0 || i >= SLOTS || offers[i].isEmpty()) {
                return;
            }
            if (!p.getAbilities().instabuild) {
                if (count(p, CoasterControlPanel.PRIZE_TICKET.get()) < prices[i]) {
                    p.displayClientMessage(Component.translatable("message.coastercontrolpanel.prize_poor", prices[i]), true);
                    return;
                }
                take(p, CoasterControlPanel.PRIZE_TICKET.get(), prices[i]);
            }
            give(p, offers[i].copy());
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 0.9F, 1.4F);
            }
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.prize_bought", offers[i].getHoverName()), true);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag list = new ListTag();
            for (int i = 0; i < SLOTS; i++) {
                CompoundTag t = new CompoundTag();
                t.put("Item", offers[i].saveOptional(registries));
                t.putInt("Price", prices[i]);
                list.add(t);
            }
            tag.put("Offers", list);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ListTag list = tag.getList("Offers", Tag.TAG_COMPOUND);
            for (int i = 0; i < SLOTS && i < list.size(); i++) {
                CompoundTag t = list.getCompound(i);
                offers[i] = ItemStack.parseOptional(registries, t.getCompound("Item"));
                prices[i] = Math.max(1, t.getInt("Price"));
            }
        }
    }

    /** Spend Prize Tickets on prizes. Hold an item and right-click to add it to the shelf. */
    public static class PrizeBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<PrizeBlock> CODEC = simpleCodec(PrizeBlock::new);

        public PrizeBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(0, 0, 2, 16, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PrizeBlockEntity(pos, state);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.isEmpty()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof PrizeBlockEntity be) {
                int r = be.addOffer(stack);
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.prize_add_" + r, stack.getHoverName()), true);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openArcade(101, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
