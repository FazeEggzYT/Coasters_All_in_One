package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Break Down Your Coaster, the running part (server only).
 *
 * Zones live on anchors (see {@link BreakdownSettings}). Here we keep a list of them, watch the carts near each one,
 * and roll the dice once per train pass. A breakdown belongs to a coaster, which is a name: the zones' coaster name must
 * match the ride name of the Control Panel. While a breakdown is active every cart near that coaster's zones is held
 * still, light smoke rises where it happened, the operator gets an alarm and a message, and the Control Panel shows
 * the repair steps. Breakdowns are not saved: a world that is reloaded starts with no active breakdown (wear is saved).
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public final class BreakdownController {
    public static final int T_MECH = BreakdownSettings.T_MECH;
    /** True while any breakdown is active. Read by the cart drive hook. */
    public static volatile boolean active;

    private static final double COASTER_RANGE = 96.0;
    private static final Set<Object> HELD = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));

    private record ZKey(ResourceKey<Level> dim, long pos) {
    }

    private static final class Zone {
        Vec3 a = Vec3.ZERO;
        Vec3 b = Vec3.ZERO;
        double radius = 7.0;
        long refreshed = Long.MIN_VALUE / 2;
        boolean rolled;
        int emptyTicks = 1000;
        long lastSave;
    }

    /** One running breakdown. */
    static final class Breakdown {
        String key;
        String coaster;
        ResourceKey<Level> dim;
        Vec3 where;
        int type;
        int sev;
        int element;
        boolean autoAvail;
        int autoLeft;
        boolean repairing;
        int repairLeft;
        int repairTotal;
        boolean ready;
        UUID operator;
        long started;
    }

    private static final Map<ZKey, Zone> ZONES = new ConcurrentHashMap<>();
    private static final Map<String, Breakdown> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<String, UUID> OPERATORS = new ConcurrentHashMap<>();
    private static final Map<Object, Vec3> LAST = new WeakHashMap<>();
    /** Chunks that were just loaded: their anchors are looked at a moment later, once their block entities exist. */
    private static final Queue<Object[]> PENDING = new ConcurrentLinkedQueue<>();
    private static boolean warnedHold;

    private BreakdownController() {
    }

    // ---- keys and registry

    private static String keyOf(Level level, String coaster) {
        return level.dimension().location() + "|" + coaster.trim().toLowerCase(Locale.ROOT);
    }

    public static boolean isHeld(Object body) {
        return HELD.contains(body) || TrainCollisions.isHeld(body);
    }

    public static void register(Level level, BlockPos pos) {
        ZONES.putIfAbsent(new ZKey(level.dimension(), pos.asLong()), new Zone());
    }

    public static void unregister(Level level, BlockPos pos) {
        ZONES.remove(new ZKey(level.dimension(), pos.asLong()));
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel sl && event.getChunk() instanceof LevelChunk) {
            PENDING.add(new Object[] {sl, event.getChunk().getPos(), sl.getGameTime() + 40});
        }
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel sl && !ZONES.isEmpty()) {
            ChunkPos cp = event.getChunk().getPos();
            ZONES.keySet().removeIf(k -> k.dim().equals(sl.dimension())
                    && (BlockPos.getX(k.pos()) >> 4) == cp.x && (BlockPos.getZ(k.pos()) >> 4) == cp.z);
        }
    }

    private static void scanPending(ServerLevel sl, long tick) {
        int n = PENDING.size();
        for (int i = 0; i < n; i++) {
            Object[] p = PENDING.poll();
            if (p == null) {
                break;
            }
            if (p[0] != sl) {
                PENDING.add(p);
                continue;
            }
            if ((Long) p[2] > tick) {
                PENDING.add(p);
                continue;
            }
            ChunkPos cp = (ChunkPos) p[1];
            LevelChunk chunk = sl.getChunkSource().getChunkNow(cp.x, cp.z);
            if (chunk == null) {
                continue;
            }
            for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                if (be instanceof DriveTyre.Holder h && h.ccp$breakdown() != null) {
                    register(sl, be.getBlockPos());
                }
            }
        }
    }

    // ---- the tick

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel sl)) {
            return;
        }
        if (ZONES.isEmpty() && ACTIVE.isEmpty() && PENDING.isEmpty()) {
            return;
        }
        try {
            long tick = sl.getGameTime();
            scanPending(sl, tick);
            boolean broken = false;
            for (Breakdown b : ACTIVE.values()) {
                if (b.dim.equals(sl.dimension())) {
                    broken = true;
                }
            }
            if (broken) {
                runBreakdowns(sl, tick);
            }
            if (tick % 2 == 0 && !ZONES.isEmpty()) {
                watchZones(sl, tick);
            }
        } catch (Throwable e) {
            CoasterControlPanel.LOGGER.error("Breakdown: error in the tick", e);
        }
    }

    private static double distToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double l2 = ab.lengthSqr();
        double t = l2 < 1.0E-9 ? 0.0 : Math.max(0.0, Math.min(1.0, p.subtract(a).dot(ab) / l2));
        return p.distanceTo(a.add(ab.scale(t)));
    }

    private static void refresh(ServerLevel sl, BlockPos pos, BlockEntity be, BreakdownSettings st, Zone z, long tick) {
        if (tick - z.refreshed < 100) {
            return;
        }
        z.refreshed = tick;
        BlockPos end = st.end != null ? st.end : BrakeController.endOfAnchor(be);
        z.a = Vec3.atCenterOf(pos);
        z.b = end == null ? z.a : Vec3.atCenterOf(end);
        double len = z.a.distanceTo(z.b);
        z.radius = end == null ? 4.5 : Math.max(4.0, Math.min(10.0, len * 0.15));
    }

    private static void watchZones(ServerLevel sl, long tick) {
        boolean any = false;
        for (ZKey k : ZONES.keySet()) {
            if (k.dim().equals(sl.dimension())) {
                any = true;
                break;
            }
        }
        if (!any) {
            return;
        }
        List<Object[]> carts = CartScanner.carts(sl);
        BreakdownSettings globals = null;
        for (Map.Entry<ZKey, Zone> e : ZONES.entrySet()) {
            ZKey k = e.getKey();
            if (!k.dim().equals(sl.dimension())) {
                continue;
            }
            BlockPos pos = BlockPos.of(k.pos());
            BlockEntity be = sl.isLoaded(pos) ? sl.getBlockEntity(pos) : null;
            if (!(be instanceof DriveTyre.Holder h) || h.ccp$breakdown() == null) {
                ZONES.remove(k);
                continue;
            }
            BreakdownSettings st = h.ccp$breakdown();
            Zone z = e.getValue();
            refresh(sl, pos, be, st, z, tick);
            String key = keyOf(sl, st.coaster);
            boolean broken = ACTIVE.containsKey(key);
            boolean inside = false;
            boolean moving = false;
            Vec3 where = null;
            for (Object[] c : carts) {
                Vector3d v = (Vector3d) c[1];
                Vec3 p = new Vec3(v.x(), v.y(), v.z());
                if (distToSegment(p, z.a, z.b) > z.radius) {
                    continue;
                }
                inside = true;
                Vec3 last = LAST.get(c[0]);
                if (last != null && last.distanceToSqr(p) > 0.0009) { // more than 0.3 blocks a second
                    moving = true;
                    where = p;
                }
            }
            if (!inside) {
                z.emptyTicks += 2;
                if (z.emptyTicks >= 30) {
                    z.rolled = false; // the train has gone: the next one is a new pass
                }
                continue;
            }
            z.emptyTicks = 0;
            if (!moving || broken) {
                continue;
            }
            st.wear += 0.1F; // two ticks of operating time
            if (tick - z.lastSave > 200) {
                z.lastSave = tick;
                be.setChanged();
            }
            if (!z.rolled) {
                z.rolled = true; // one roll per pass, however many carts the train has
                if (globals == null) {
                    globals = BreakdownGlobals.get(sl.getServer()).value();
                }
                roll(sl, key, pos, st, globals, where, tick);
            }
        }
        for (Object[] c : carts) {
            Vector3d v = (Vector3d) c[1];
            LAST.put(c[0], new Vec3(v.x(), v.y(), v.z()));
        }
    }

    // ---- the dice

    /** The chance for one pass, 0 to 1, with reliability and wear worked in. */
    public static double effectiveChance(BreakdownSettings st, BreakdownSettings resolved) {
        if (resolved.chance <= 0.0F) {
            return 0.0;
        }
        if (resolved.chance >= 100.0F) {
            return 1.0;
        }
        double wearFrac = Math.min(1.0, st.wear / (resolved.wearMinutes * 60.0));
        double p = resolved.chance / 100.0 * (100.0 / resolved.reliability) * (1.0 + resolved.wearBoost / 100.0 * wearFrac);
        return Math.max(0.0, Math.min(1.0, p));
    }

    private static int pick(float[] weights, java.util.Random rnd) {
        float[] f = BreakdownSettings.normalise(weights, null);
        double r = rnd.nextDouble();
        double acc = 0.0;
        for (int i = 0; i < f.length; i++) {
            acc += f[i];
            if (r < acc && f[i] > 0.0F) {
                return i;
            }
        }
        for (int i = f.length - 1; i >= 0; i--) {
            if (f[i] > 0.0F) {
                return i;
            }
        }
        return 0;
    }

    private static void roll(ServerLevel sl, String key, BlockPos zone, BreakdownSettings st, BreakdownSettings globals, Vec3 where, long tick) {
        BreakdownSettings r = st.resolved(globals);
        if (sl.random.nextDouble() >= effectiveChance(st, r)) {
            return;
        }
        int type = pick(r.types, new java.util.Random(sl.random.nextLong()));
        int sev = pick(r.sev, new java.util.Random(sl.random.nextLong()));
        start(sl, key, zone, st, r, where, type, sev, tick);
    }

    /** Starts a breakdown on a coaster (also used for testing with a 100% zone). */
    static void start(ServerLevel sl, String key, BlockPos zone, BreakdownSettings st, BreakdownSettings r, Vec3 where, int type, int sev, long tick) {
        if (ACTIVE.containsKey(key)) {
            return;
        }
        Breakdown b = new Breakdown();
        b.key = key;
        b.coaster = st.coaster.isBlank() ? "" : st.coaster.trim();
        b.dim = sl.dimension();
        b.where = where == null ? Vec3.atCenterOf(zone) : where;
        b.type = type;
        b.sev = sev;
        b.element = st.element;
        b.started = tick;
        b.repairTotal = Math.max(1, r.repair[type][sev]);
        boolean auto = sev == BreakdownSettings.S_MINOR ? r.autoMinor : sev == BreakdownSettings.S_MOD && r.autoModerate;
        b.autoAvail = auto && sev != BreakdownSettings.S_MAJOR; // a Major breakdown never recovers by itself
        b.autoLeft = (sev == BreakdownSettings.S_MINOR ? r.autoMinorSec : r.autoModerateSec) * 20;
        b.operator = operatorFor(sl, key, b.where);
        ACTIVE.put(key, b);
        active = true;
        ServerPlayer op = player(sl, b.operator);
        if (op != null) {
            Component msg = Component.translatable("message.coastercontrolpanel.breakdown_alert",
                    b.coaster.isEmpty() ? Component.translatable("message.coastercontrolpanel.breakdown_unnamed") : Component.literal(b.coaster),
                    Component.translatable("gui.coastercontrolpanel.breakdown.type." + typeKey(type)),
                    Component.translatable("gui.coastercontrolpanel.breakdown.sev." + sevKey(sev)),
                    Component.translatable("gui.coastercontrolpanel.breakdown.element." + BreakdownSettings.ELEMENT_KEYS[b.element]));
            op.displayClientMessage(msg, false);
            op.displayClientMessage(msg, true);
        }
        CoasterControlPanel.LOGGER.info("Breakdown on '{}': {} / {} at {}", b.coaster, typeKey(type), sevKey(sev), zone);
    }

    static String typeKey(int t) {
        return new String[] {"mech", "brake", "lift", "general"}[Math.max(0, Math.min(3, t))];
    }

    static String sevKey(int s) {
        return new String[] {"minor", "moderate", "major"}[Math.max(0, Math.min(2, s))];
    }

    private static ServerPlayer player(ServerLevel sl, UUID id) {
        return id == null ? null : sl.getServer().getPlayerList().getPlayer(id);
    }

    /** The player at the coaster's Control Panel; if nobody has used it, the nearest player within 48 blocks. */
    private static UUID operatorFor(ServerLevel sl, String key, Vec3 where) {
        UUID id = OPERATORS.get(key);
        if (id != null && player(sl, id) != null) {
            return id;
        }
        ServerPlayer best = null;
        double bd = 48.0 * 48.0;
        for (ServerPlayer sp : sl.players()) {
            double d = sp.position().distanceToSqr(where);
            if (d < bd) {
                bd = d;
                best = sp;
            }
        }
        return best == null ? null : best.getUUID();
    }

    // ---- while broken

    private static void runBreakdowns(ServerLevel sl, long tick) {
        Object system = null;
        List<Object[]> carts = null;
        for (Breakdown b : new ArrayList<>(ACTIVE.values())) {
            if (!b.dim.equals(sl.dimension())) {
                continue;
            }
            // timers
            if (b.repairing) {
                if (--b.repairLeft <= 0) {
                    b.repairing = false;
                    b.ready = true;
                }
            } else if (!b.ready && b.autoAvail && --b.autoLeft <= 0) {
                clear(sl, b, false);
                continue;
            }
            // hold every cart of this coaster
            if (carts == null) {
                carts = CartScanner.carts(sl);
                system = CartScanner.systemFor(sl);
            }
            for (Object[] c : carts) {
                Vector3d v = (Vector3d) c[1];
                Vec3 p = new Vec3(v.x(), v.y(), v.z());
                if (belongs(sl, b, p)) {
                    HELD.add(c[0]);
                    if (system != null) {
                        BrakeController.damp(c[0], system, 0.4);
                    } else if (!warnedHold) {
                        warnedHold = true;
                        CoasterControlPanel.LOGGER.warn("Breakdown: could not find Sable's physics system; carts are only held where a chain drive reaches them.");
                    }
                }
            }
            // smoke, light and rising from where it broke down
            if (tick % 6 == 0) {
                sl.sendParticles(ParticleTypes.SMOKE, b.where.x, b.where.y + 0.6, b.where.z, 2, 0.25, 0.1, 0.25, 0.01);
            }
            // alarm, to the operator only, a different pattern for each type
            if (tick % 40 == 0) {
                ServerPlayer op = player(sl, b.operator);
                if (op != null) {
                    alarm(op, b.type);
                }
            }
        }
    }

    private static boolean belongs(ServerLevel sl, Breakdown b, Vec3 p) {
        if (b.coaster.isEmpty()) {
            // an unnamed coaster: every unnamed zone is one coaster
            for (Map.Entry<ZKey, Zone> e : ZONES.entrySet()) {
                if (e.getKey().dim().equals(sl.dimension()) && sameName(sl, e.getKey(), "") && near(e.getValue(), p)) {
                    return true;
                }
            }
            return p.distanceToSqr(b.where) < COASTER_RANGE * COASTER_RANGE;
        }
        for (Map.Entry<ZKey, Zone> e : ZONES.entrySet()) {
            if (e.getKey().dim().equals(sl.dimension()) && sameName(sl, e.getKey(), b.coaster) && near(e.getValue(), p)) {
                return true;
            }
        }
        return p.distanceToSqr(b.where) < 16.0 * 16.0;
    }

    private static boolean near(Zone z, Vec3 p) {
        return distToSegment(p, z.a, z.b) <= COASTER_RANGE;
    }

    private static boolean sameName(ServerLevel sl, ZKey k, String name) {
        BlockPos pos = BlockPos.of(k.pos());
        if (sl.isLoaded(pos) && sl.getBlockEntity(pos) instanceof DriveTyre.Holder h && h.ccp$breakdown() != null) {
            return h.ccp$breakdown().coaster.trim().equalsIgnoreCase(name.trim());
        }
        return false;
    }

    private static void alarm(ServerPlayer op, int type) {
        SoundEvent s;
        float pitch;
        switch (type) {
            case BreakdownSettings.T_BRAKE -> {
                s = SoundEvents.NOTE_BLOCK_BASS.value();
                pitch = 0.6F;
            }
            case BreakdownSettings.T_LIFT -> {
                s = SoundEvents.BELL_BLOCK;
                pitch = 0.8F;
            }
            case BreakdownSettings.T_GEN -> {
                s = SoundEvents.NOTE_BLOCK_PLING.value();
                pitch = 1.5F;
            }
            default -> {
                s = SoundEvents.NOTE_BLOCK_BIT.value();
                pitch = 1.2F;
            }
        }
        op.playNotifySound(s, SoundSource.MASTER, 1.0F, pitch);
        if (type == BreakdownSettings.T_MECH || type == BreakdownSettings.T_GEN) {
            op.playNotifySound(s, SoundSource.MASTER, 1.0F, pitch * 0.7F); // a two-tone pattern
        }
    }

    /** Ends a breakdown: the carts are let go, the smoke and alarm stop. A manual repair also resets all wear. */
    private static void clear(ServerLevel sl, Breakdown b, boolean manual) {
        ACTIVE.remove(b.key);
        HELD.clear();
        active = !ACTIVE.isEmpty();
        if (manual) {
            for (Map.Entry<ZKey, Zone> e : ZONES.entrySet()) {
                if (!e.getKey().dim().equals(sl.dimension())) {
                    continue;
                }
                BlockPos pos = BlockPos.of(e.getKey().pos());
                if (sl.isLoaded(pos) && sl.getBlockEntity(pos) instanceof DriveTyre.Holder h && h.ccp$breakdown() != null
                        && keyOf(sl, h.ccp$breakdown().coaster).equals(b.key)) {
                    h.ccp$breakdown().wear = 0.0F;
                    ((BlockEntity) h).setChanged();
                }
            }
        }
    }

    // ---- the Control Panel

    /** The Control Panel's buttons. Action 0 = ask for the state, 1 = start the repair, 2 = reset the coaster. */
    public static void panelAction(ServerPlayer sp, BlockPos panel, int action) {
        ServerLevel sl = sp.serverLevel();
        if (sp.distanceToSqr(panel.getX() + 0.5, panel.getY() + 0.5, panel.getZ() + 0.5) > 64.0 * 64.0 || !sl.isLoaded(panel)
                || !(sl.getBlockEntity(panel) instanceof PanelBlockEntity pb)) {
            return;
        }
        String key = keyOf(sl, pb.getRideName());
        OPERATORS.put(key, sp.getUUID());
        Breakdown b = ACTIVE.get(key);
        if (b != null) {
            b.operator = sp.getUUID();
            if (action == 1 && !b.repairing && !b.ready) {
                b.repairing = true;
                b.repairLeft = b.repairTotal * 20;
            } else if (action == 2 && b.ready) {
                clear(sl, b, true);
                b = null;
            }
        }
        PacketDistributor.sendToPlayer(sp, state(b, pb.getRideName()));
    }

    private static BreakdownStatePacket state(Breakdown b, String ride) {
        if (b == null) {
            return new BreakdownStatePacket(false, ride, 0, 0, 0, false, 0, false, 0, false, 0);
        }
        return new BreakdownStatePacket(true, b.coaster.isEmpty() ? ride : b.coaster, b.type, b.sev, b.element, b.autoAvail && !b.ready,
                Math.max(0, b.autoLeft / 20), b.repairing, Math.max(0, b.repairLeft / 20), b.ready, b.repairTotal);
    }
}
