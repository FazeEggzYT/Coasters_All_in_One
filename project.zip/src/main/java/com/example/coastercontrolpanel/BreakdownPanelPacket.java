package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server, from the Control Panel screen: 0 = ask for the breakdown state, 1 = start the repair, 2 = reset the coaster. */
public record BreakdownPanelPacket(BlockPos panel, int action) implements CustomPacketPayload {
    public static final Type<BreakdownPanelPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "breakdown_panel"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BreakdownPanelPacket> CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BreakdownPanelPacket::panel,
            ByteBufCodecs.VAR_INT, BreakdownPanelPacket::action,
            BreakdownPanelPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BreakdownPanelPacket p, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer sp && p.action >= 0 && p.action <= 2) {
            BreakdownController.panelAction(sp, p.panel, p.action);
        }
    }
}
