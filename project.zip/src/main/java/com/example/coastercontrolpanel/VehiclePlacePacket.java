package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: dress this Coaster Cart with this vehicle body in this colour. */
public record VehiclePlacePacket(BlockPos pos, int vehicle, int colour) implements CustomPacketPayload {
    public static final Type<VehiclePlacePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "vehicle_place"));

    public static final StreamCodec<RegistryFriendlyByteBuf, VehiclePlacePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.vehicle);
                buf.writeVarInt(p.colour);
            },
            buf -> new VehiclePlacePacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(VehiclePlacePacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        boolean holding = player.getMainHandItem().is(CoasterControlPanel.COASTER_VEHICLE_KIT_ITEM.get())
                || player.getOffhandItem().is(CoasterControlPanel.COASTER_VEHICLE_KIT_ITEM.get());
        Level level = player.level();
        if (!holding || p.vehicle < 0 || p.vehicle >= CoasterVehicles.IDS.length || !level.hasChunkAt(p.pos)
                || !CoasterVehicleKitItem.isCart(level, p.pos)) {
            return;
        }
        DyeColor dye = p.colour > 0 && p.colour < CoasterBuilder.COLOURS.length ? CoasterBuilder.COLOURS[p.colour] : DyeColor.byName(CoasterVehicles.DYES[p.vehicle], DyeColor.RED);
        int placed = 0;
        int blocked = 0;
        for (String cell : CoasterVehicles.CELLS[p.vehicle]) {
            String[] f = cell.split(",", 4);
            BlockPos at = p.pos.offset(Integer.parseInt(f[0]), Integer.parseInt(f[1]), Integer.parseInt(f[2]));
            BlockState state = parse(f[3].replace("{c}", dye.getName()));
            if (state == null) {
                continue;
            }
            BlockState now = level.getBlockState(at);
            if (!now.isAir() && !now.canBeReplaced()) {
                blocked++;
                continue;
            }
            level.setBlock(at, state, 3);
            placed++;
        }
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel." + (blocked == 0 ? "vehicle_done" : "vehicle_partial"),
                CoasterVehicles.NAMES[p.vehicle], blocked), true);
    }

    /** "namespace:block[prop=value,prop=value]" to a block state. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static BlockState parse(String text) {
        String id = text;
        String props = "";
        int br = text.indexOf('[');
        if (br >= 0) {
            id = text.substring(0, br);
            props = text.substring(br + 1, text.length() - 1);
        }
        ResourceLocation rl = ResourceLocation.parse(id);
        if (!BuiltInRegistries.BLOCK.containsKey(rl)) {
            return null;
        }
        Block block = BuiltInRegistries.BLOCK.get(rl);
        BlockState s = block.defaultBlockState();
        if (!props.isEmpty()) {
            for (String kv : props.split(",")) {
                String[] a = kv.split("=");
                Property<?> prop = block.getStateDefinition().getProperty(a[0]);
                if (prop != null) {
                    java.util.Optional<?> v = prop.getValue(a[1]);
                    if (v.isPresent()) {
                        s = s.setValue((Property) prop, (Comparable) v.get());
                    }
                }
            }
        }
        return s;
    }
}
