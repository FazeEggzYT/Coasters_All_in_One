package com.example.coastercontrolpanel;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one console block. Right-click it for the operator panel,
 * right-click with a Create wrench to set it up.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, MOD_ID);

    /** Custom 1 to 10: sounds you replace with your own .ogg files (see the resource pack). */
    public static final java.util.List<DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent>> CUSTOM_SOUNDS =
            new java.util.ArrayList<>();

    static {
        for (int i = 1; i <= 10; i++) {
            final net.minecraft.resources.ResourceLocation id =
                    net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, "custom_" + i);
            CUSTOM_SOUNDS.add(SOUND_EVENTS.register("custom_" + i,
                    () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id)));
        }
    }

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_CHAIN =
            ride("ride_chain");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_BRAKE =
            ride("ride_brake");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_HUM =
            ride("ride_hum");

    private static DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> ride(String name) {
        final net.minecraft.resources.ResourceLocation id =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id));
    }

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredBlock<PanelBlock> EFFECTS_PANEL_BLOCK = BLOCKS.register("effects_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECTS_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("effects_panel", EFFECTS_PANEL_BLOCK);

    public static final DeferredBlock<EffectBlock> EFFECT_BLOCK = BLOCKS.register("effect_machine",
            () -> new EffectBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECT_ITEM =
            ITEMS.registerSimpleBlockItem("effect_machine", EFFECT_BLOCK);

    public static final DeferredBlock<CameraBlock> CAMERA_BLOCK = BLOCKS.register("ride_camera",
            () -> new CameraBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(CameraBlock.LIT) ? 15 : 0)));

    public static final DeferredItem<BlockItem> CAMERA_ITEM =
            ITEMS.registerSimpleBlockItem("ride_camera", CAMERA_BLOCK);

    public static final DeferredItem<Item> CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("camera_connector", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<PhotoScreenBlock> PHOTO_SCREEN_BLOCK = BLOCKS.register("photo_screen",
            () -> new PhotoScreenBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PHOTO_SCREEN_ITEM =
            ITEMS.registerSimpleBlockItem("photo_screen", PHOTO_SCREEN_BLOCK);

    public static final DeferredBlock<GuestSpawnerBlock> SPAWNER_BLOCK = BLOCKS.register("guest_spawner",
            () -> new GuestSpawnerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> SPAWNER_ITEM =
            ITEMS.registerSimpleBlockItem("guest_spawner", SPAWNER_BLOCK);

    // ---- Drop Tower
    public static final DeferredBlock<DropTowerBlocks.BaseBlock> DROP_TOWER_BASE_BLOCK = BLOCKS.register("drop_tower_base",
            () -> new DropTowerBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> DROP_TOWER_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("drop_tower_base", DROP_TOWER_BASE_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> DROP_TOWER_SECTION_BLOCK = BLOCKS.register("drop_tower_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> DROP_TOWER_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("drop_tower_section", DROP_TOWER_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.FrameBlock> DROP_TOWER_FRAME_BLOCK = BLOCKS.register("drop_tower_frame",
            () -> new DropTowerBlocks.FrameBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()
                    .isViewBlocking((s, l, p) -> false).isSuffocating((s, l, p) -> false)));
    public static final DeferredItem<BlockItem> DROP_TOWER_FRAME_ITEM =
            ITEMS.registerSimpleBlockItem("drop_tower_frame", DROP_TOWER_FRAME_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> DROP_TOWER_CONTROLLER_BLOCK = BLOCKS.register("drop_tower_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> DROP_TOWER_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("drop_tower_controller", DROP_TOWER_CONTROLLER_BLOCK);
    public static final DeferredBlock<SwingBlocks.BaseBlock> SWING_BASE_BLOCK = BLOCKS.register("swing_base",
            () -> new SwingBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("swing_base", SWING_BASE_BLOCK);
    public static final DeferredBlock<SwingBlocks.PivotBlock> SWING_PIVOT_BLOCK = BLOCKS.register("swing_pivot",
            () -> new SwingBlocks.PivotBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_PIVOT_ITEM =
            ITEMS.registerSimpleBlockItem("swing_pivot", SWING_PIVOT_BLOCK);
    public static final DeferredBlock<SwingBlocks.ArmBlock> SWING_ARM_BLOCK = BLOCKS.register("swing_arm",
            () -> new SwingBlocks.ArmBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_ARM_ITEM =
            ITEMS.registerSimpleBlockItem("swing_arm", SWING_ARM_BLOCK);
    public static final DeferredBlock<SwingBlocks.HubBlock> SWING_HUB_BLOCK = BLOCKS.register("swing_hub",
            () -> new SwingBlocks.HubBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("swing_hub", SWING_HUB_BLOCK);
    public static final DeferredBlock<SwingBlocks.GondolaFrameBlock> SWING_FRAME_BLOCK = BLOCKS.register("swing_frame",
            () -> new SwingBlocks.GondolaFrameBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion().isViewBlocking((s, l, p) -> false).isSuffocating((s, l, p) -> false)));
    public static final DeferredItem<BlockItem> SWING_FRAME_ITEM =
            ITEMS.registerSimpleBlockItem("swing_frame", SWING_FRAME_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> SWING_SECTION_BLOCK = BLOCKS.register("swing_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("swing_section", SWING_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> SWING_CONTROLLER_BLOCK = BLOCKS.register("swing_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWING_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("swing_controller", SWING_CONTROLLER_BLOCK);
    public static final DeferredBlock<FerrisBlocks.BaseBlock> FERRIS_BASE_BLOCK = BLOCKS.register("ferris_base",
            () -> new FerrisBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_base", FERRIS_BASE_BLOCK);
    public static final DeferredBlock<FerrisBlocks.AxleBlock> FERRIS_AXLE_BLOCK = BLOCKS.register("ferris_axle",
            () -> new FerrisBlocks.AxleBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_AXLE_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_axle", FERRIS_AXLE_BLOCK);
    public static final DeferredBlock<FerrisBlocks.SpokeBlock> FERRIS_SPOKE_BLOCK = BLOCKS.register("ferris_spoke",
            () -> new FerrisBlocks.SpokeBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_SPOKE_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_spoke", FERRIS_SPOKE_BLOCK);
    public static final DeferredBlock<FerrisBlocks.RimBlock> FERRIS_RIM_BLOCK = BLOCKS.register("ferris_rim",
            () -> new FerrisBlocks.RimBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_RIM_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_rim", FERRIS_RIM_BLOCK);
    public static final DeferredBlock<FerrisBlocks.HubBlock> FERRIS_HUB_BLOCK = BLOCKS.register("ferris_hub",
            () -> new FerrisBlocks.HubBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_hub", FERRIS_HUB_BLOCK);
    public static final DeferredBlock<FerrisBlocks.CabinFrameBlock> FERRIS_FRAME_BLOCK = BLOCKS.register("ferris_frame",
            () -> new FerrisBlocks.CabinFrameBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion().isViewBlocking((s, l, p) -> false).isSuffocating((s, l, p) -> false)));
    public static final DeferredItem<BlockItem> FERRIS_FRAME_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_frame", FERRIS_FRAME_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> FERRIS_SECTION_BLOCK = BLOCKS.register("ferris_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_section", FERRIS_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> FERRIS_CONTROLLER_BLOCK = BLOCKS.register("ferris_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FERRIS_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("ferris_controller", FERRIS_CONTROLLER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FerrisBlockEntity>> FERRIS_BE =
            BLOCK_ENTITIES.register("ferris_wheel",
                    () -> BlockEntityType.Builder.of(FerrisBlockEntity::new, FERRIS_BASE_BLOCK.get()).build(null));
    public static final DeferredBlock<PirateBlocks.BaseBlock> PIRATE_BASE_BLOCK = BLOCKS.register("pirate_base",
            () -> new PirateBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_base", PIRATE_BASE_BLOCK);
    public static final DeferredBlock<PirateBlocks.PivotBlock> PIRATE_PIVOT_BLOCK = BLOCKS.register("pirate_pivot",
            () -> new PirateBlocks.PivotBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_PIVOT_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_pivot", PIRATE_PIVOT_BLOCK);
    public static final DeferredBlock<PirateBlocks.ArmBlock> PIRATE_ARM_BLOCK = BLOCKS.register("pirate_arm",
            () -> new PirateBlocks.ArmBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_ARM_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_arm", PIRATE_ARM_BLOCK);
    public static final DeferredBlock<PirateBlocks.HubBlock> PIRATE_HUB_BLOCK = BLOCKS.register("pirate_hub",
            () -> new PirateBlocks.HubBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_hub", PIRATE_HUB_BLOCK);
    public static final DeferredBlock<PirateBlocks.HullBlock> PIRATE_HULL_BLOCK = BLOCKS.register("pirate_hull",
            () -> new PirateBlocks.HullBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_HULL_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_hull", PIRATE_HULL_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> PIRATE_SECTION_BLOCK = BLOCKS.register("pirate_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_section", PIRATE_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> PIRATE_CONTROLLER_BLOCK = BLOCKS.register("pirate_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> PIRATE_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("pirate_controller", PIRATE_CONTROLLER_BLOCK);
    public static final DeferredBlock<SwivelBlocks.BearingBlock> SWIVEL_BEARING_BLOCK = BLOCKS.register("swivel_bearing",
            () -> new SwivelBlocks.BearingBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWIVEL_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("swivel_bearing", SWIVEL_BEARING_BLOCK);
    public static final DeferredBlock<SwivelBlocks.PlateBlock> SWIVEL_PLATE_BLOCK = BLOCKS.register("swivel_plate",
            () -> new SwivelBlocks.PlateBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWIVEL_PLATE_ITEM =
            ITEMS.registerSimpleBlockItem("swivel_plate", SWIVEL_PLATE_BLOCK);
    public static final DeferredBlock<SwivelBlocks.FlipBearing> FLIP_BEARING_BLOCK = BLOCKS.register("flip_bearing",
            () -> new SwivelBlocks.FlipBearing(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FLIP_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("flip_bearing", FLIP_BEARING_BLOCK);
    public static final DeferredBlock<SwivelBlocks.SpinBearing> SPIN_BEARING_BLOCK = BLOCKS.register("spin_bearing",
            () -> new SwivelBlocks.SpinBearing(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SPIN_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("spin_bearing", SPIN_BEARING_BLOCK);
    public static final DeferredBlock<SwivelBlocks.SwayBearing> SWAY_BEARING_BLOCK = BLOCKS.register("sway_bearing",
            () -> new SwivelBlocks.SwayBearing(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> SWAY_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("sway_bearing", SWAY_BEARING_BLOCK);
    public static final DeferredBlock<SwivelBlocks.RockBearing> ROCK_BEARING_BLOCK = BLOCKS.register("rock_bearing",
            () -> new SwivelBlocks.RockBearing(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> ROCK_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("rock_bearing", ROCK_BEARING_BLOCK);
    public static final DeferredBlock<SwivelBlocks.LiftBearing> LIFT_BEARING_BLOCK = BLOCKS.register("lift_bearing",
            () -> new SwivelBlocks.LiftBearing(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> LIFT_BEARING_ITEM =
            ITEMS.registerSimpleBlockItem("lift_bearing", LIFT_BEARING_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SwivelBlockEntity>> SWIVEL_BE =
            BLOCK_ENTITIES.register("swivel_bearing",
                    () -> BlockEntityType.Builder.of(SwivelBlockEntity::new, SWIVEL_BEARING_BLOCK.get(), FLIP_BEARING_BLOCK.get(), SPIN_BEARING_BLOCK.get(), SWAY_BEARING_BLOCK.get(), ROCK_BEARING_BLOCK.get(), LIFT_BEARING_BLOCK.get()).build(null));
    public static final DeferredBlock<TeacupBlocks.BaseBlock> TEACUP_BASE_BLOCK = BLOCKS.register("teacup_base",
            () -> new TeacupBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_base", TEACUP_BASE_BLOCK);
    public static final DeferredBlock<TeacupBlocks.PlatterHub> TEACUP_HUB_BLOCK = BLOCKS.register("teacup_platter_hub",
            () -> new TeacupBlocks.PlatterHub(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_platter_hub", TEACUP_HUB_BLOCK);
    public static final DeferredBlock<TeacupBlocks.PlatterPlate> TEACUP_PLATE_BLOCK = BLOCKS.register("teacup_platter_plate",
            () -> new TeacupBlocks.PlatterPlate(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_PLATE_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_platter_plate", TEACUP_PLATE_BLOCK);
    public static final DeferredBlock<TeacupBlocks.CupHub> TEACUP_CUP_HUB_BLOCK = BLOCKS.register("teacup_cup_hub",
            () -> new TeacupBlocks.CupHub(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_CUP_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_cup_hub", TEACUP_CUP_HUB_BLOCK);
    public static final DeferredBlock<TeacupBlocks.CupFloor> TEACUP_FLOOR_BLOCK = BLOCKS.register("teacup_cup_floor",
            () -> new TeacupBlocks.CupFloor(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_FLOOR_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_cup_floor", TEACUP_FLOOR_BLOCK);
    public static final DeferredBlock<TeacupBlocks.CupWall> TEACUP_WALL_BLOCK = BLOCKS.register("teacup_cup_wall",
            () -> new TeacupBlocks.CupWall(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_WALL_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_cup_wall", TEACUP_WALL_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> TEACUP_SECTION_BLOCK = BLOCKS.register("teacup_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_section", TEACUP_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> TEACUP_CONTROLLER_BLOCK = BLOCKS.register("teacup_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TEACUP_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("teacup_controller", TEACUP_CONTROLLER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TeacupBlockEntity>> TEACUP_BE =
            BLOCK_ENTITIES.register("teacup_ride",
                    () -> BlockEntityType.Builder.of(TeacupBlockEntity::new, TEACUP_BASE_BLOCK.get(), CoasterControlPanel.CAROUSEL_BASE_BLOCK.get()).build(null));
    public static final DeferredItem<Item> PREMADE_TEACUP_ITEM =
            ITEMS.register("premade_teacup", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.TEACUP));
    public static final DeferredItem<Item> PREMADE_PIRATE_ITEM =
            ITEMS.register("premade_pirate_ship", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.PIRATE));
    public static final DeferredBlock<GyroBlocks.BaseBlock> GYRO_BASE_BLOCK = BLOCKS.register("gyro_base",
            () -> new GyroBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_base", GYRO_BASE_BLOCK);
    public static final DeferredBlock<GyroBlocks.PivotBlock> GYRO_PIVOT_BLOCK = BLOCKS.register("gyro_pivot",
            () -> new GyroBlocks.PivotBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_PIVOT_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_pivot", GYRO_PIVOT_BLOCK);
    public static final DeferredBlock<GyroBlocks.ArmBlock> GYRO_ARM_BLOCK = BLOCKS.register("gyro_arm",
            () -> new GyroBlocks.ArmBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_ARM_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_arm", GYRO_ARM_BLOCK);
    public static final DeferredBlock<GyroBlocks.HubBlock> GYRO_HUB_BLOCK = BLOCKS.register("gyro_hub",
            () -> new GyroBlocks.HubBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_hub", GYRO_HUB_BLOCK);
    public static final DeferredBlock<GyroBlocks.RingBlock> GYRO_RING_BLOCK = BLOCKS.register("gyro_ring",
            () -> new GyroBlocks.RingBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_RING_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_ring", GYRO_RING_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> GYRO_SECTION_BLOCK = BLOCKS.register("gyro_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_section", GYRO_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> GYRO_CONTROLLER_BLOCK = BLOCKS.register("gyro_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> GYRO_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("gyro_controller", GYRO_CONTROLLER_BLOCK);
    public static final DeferredBlock<CarouselBlocks.BaseBlock> CAROUSEL_BASE_BLOCK = BLOCKS.register("carousel_base",
            () -> new CarouselBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_base", CAROUSEL_BASE_BLOCK);
    public static final DeferredBlock<CarouselBlocks.Hub> CAROUSEL_HUB_BLOCK = BLOCKS.register("carousel_hub",
            () -> new CarouselBlocks.Hub(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_hub", CAROUSEL_HUB_BLOCK);
    public static final DeferredBlock<CarouselBlocks.Deck> CAROUSEL_DECK_BLOCK = BLOCKS.register("carousel_deck",
            () -> new CarouselBlocks.Deck(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_DECK_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_deck", CAROUSEL_DECK_BLOCK);
    public static final DeferredBlock<CarouselBlocks.Horse> CAROUSEL_HORSE_BLOCK = BLOCKS.register("carousel_horse",
            () -> new CarouselBlocks.Horse(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_HORSE_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_horse", CAROUSEL_HORSE_BLOCK);
    public static final DeferredBlock<CarouselBlocks.Pole> CAROUSEL_POLE_BLOCK = BLOCKS.register("carousel_pole",
            () -> new CarouselBlocks.Pole(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_POLE_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_pole", CAROUSEL_POLE_BLOCK);
    public static final DeferredBlock<CarouselBlocks.Roof> CAROUSEL_ROOF_BLOCK = BLOCKS.register("carousel_roof",
            () -> new CarouselBlocks.Roof(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_ROOF_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_roof", CAROUSEL_ROOF_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> CAROUSEL_SECTION_BLOCK = BLOCKS.register("carousel_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_section", CAROUSEL_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> CAROUSEL_CONTROLLER_BLOCK = BLOCKS.register("carousel_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAROUSEL_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("carousel_controller", CAROUSEL_CONTROLLER_BLOCK);
    public static final DeferredBlock<BumperBlocks.BaseBlock> BUMPER_BASE_BLOCK = BLOCKS.register("bumper_base",
            () -> new BumperBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> BUMPER_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("bumper_base", BUMPER_BASE_BLOCK);
    public static final DeferredBlock<BumperBlocks.Floor> BUMPER_FLOOR_BLOCK = BLOCKS.register("bumper_floor",
            () -> new BumperBlocks.Floor(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).friction(0.85F)));
    public static final DeferredItem<BlockItem> BUMPER_FLOOR_ITEM =
            ITEMS.registerSimpleBlockItem("bumper_floor", BUMPER_FLOOR_BLOCK);
    public static final DeferredBlock<BumperBlocks.Rail> BUMPER_RAIL_BLOCK = BLOCKS.register("bumper_rail",
            () -> new BumperBlocks.Rail(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> BUMPER_RAIL_ITEM =
            ITEMS.registerSimpleBlockItem("bumper_rail", BUMPER_RAIL_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> BUMPER_SECTION_BLOCK = BLOCKS.register("bumper_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> BUMPER_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("bumper_section", BUMPER_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> BUMPER_CONTROLLER_BLOCK = BLOCKS.register("bumper_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> BUMPER_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("bumper_controller", BUMPER_CONTROLLER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BumperBlockEntity>> BUMPER_BE =
            BLOCK_ENTITIES.register("bumper_cars",
                    () -> BlockEntityType.Builder.of(BumperBlockEntity::new, BUMPER_BASE_BLOCK.get()).build(null));
    public static final DeferredItem<Item> BUMPER_CAR_ITEM =
            ITEMS.register("bumper_car", () -> new BumperCarItem(new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> PREMADE_GYRO_ITEM =
            ITEMS.register("premade_gyro_swing", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.GYRO));
    public static final DeferredItem<Item> PREMADE_CAROUSEL_ITEM =
            ITEMS.register("premade_carousel", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.CAROUSEL));
    public static final DeferredItem<Item> PREMADE_BUMPER_ITEM =
            ITEMS.register("premade_bumper_cars", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.BUMPER));
    public static final DeferredBlock<TimeMachineBlocks.BaseBlock> TIMEMACHINE_BASE_BLOCK = BLOCKS.register("timemachine_base",
            () -> new TimeMachineBlocks.BaseBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_BASE_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_base", TIMEMACHINE_BASE_BLOCK);
    public static final DeferredBlock<TimeMachineBlocks.PivotBlock> TIMEMACHINE_PIVOT_BLOCK = BLOCKS.register("timemachine_pivot",
            () -> new TimeMachineBlocks.PivotBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_PIVOT_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_pivot", TIMEMACHINE_PIVOT_BLOCK);
    public static final DeferredBlock<TimeMachineBlocks.ArmBlock> TIMEMACHINE_ARM_BLOCK = BLOCKS.register("timemachine_arm",
            () -> new TimeMachineBlocks.ArmBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_ARM_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_arm", TIMEMACHINE_ARM_BLOCK);
    public static final DeferredBlock<TimeMachineBlocks.HubBlock> TIMEMACHINE_HUB_BLOCK = BLOCKS.register("timemachine_hub",
            () -> new TimeMachineBlocks.HubBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_HUB_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_hub", TIMEMACHINE_HUB_BLOCK);
    public static final DeferredBlock<TimeMachineBlocks.PodBlock> TIMEMACHINE_POD_BLOCK = BLOCKS.register("timemachine_pod",
            () -> new TimeMachineBlocks.PodBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_POD_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_pod", TIMEMACHINE_POD_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.SectionBlock> TIMEMACHINE_SECTION_BLOCK = BLOCKS.register("timemachine_section",
            () -> new DropTowerBlocks.SectionBlock(BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_section", TIMEMACHINE_SECTION_BLOCK);
    public static final DeferredBlock<DropTowerBlocks.ControllerBlock> TIMEMACHINE_CONTROLLER_BLOCK = BLOCKS.register("timemachine_controller",
            () -> new DropTowerBlocks.ControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 4.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TIMEMACHINE_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("timemachine_controller", TIMEMACHINE_CONTROLLER_BLOCK);
    public static final DeferredItem<Item> PREMADE_TIMEMACHINE_ITEM =
            ITEMS.register("premade_time_machine", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.TIMEMACHINE));
    public static final DeferredItem<Item> PREMADE_DROP_TOWER_ITEM =
            ITEMS.register("premade_drop_tower", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.DROP_TOWER));
    public static final DeferredItem<Item> PREMADE_SWING_ITEM =
            ITEMS.register("premade_swing_ride", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.SWING));
    public static final DeferredItem<Item> PREMADE_FERRIS_ITEM =
            ITEMS.register("premade_ferris_wheel", () -> new PremadeRideItem(new Item.Properties().stacksTo(1), PremadeRides.FERRIS));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SwingBlockEntity>> SWING_BE =
            BLOCK_ENTITIES.register("swing_ride",
                    () -> BlockEntityType.Builder.of(SwingBlockEntity::new, SWING_BASE_BLOCK.get(), PIRATE_BASE_BLOCK.get(), GYRO_BASE_BLOCK.get(), TIMEMACHINE_BASE_BLOCK.get()).build(null));

    public static final DeferredBlock<MarkerBlock> QUEUE_MARKER_BLOCK = BLOCKS.register("queue_marker",
            () -> new MarkerBlock(MarkerKind.QUEUE, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> QUEUE_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("queue_marker", QUEUE_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> STATION_MARKER_BLOCK = BLOCKS.register("station_marker",
            () -> new MarkerBlock(MarkerKind.STATION, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> STATION_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("station_marker", STATION_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> EXIT_MARKER_BLOCK = BLOCKS.register("exit_marker",
            () -> new MarkerBlock(MarkerKind.EXIT, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> EXIT_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("exit_marker", EXIT_MARKER_BLOCK);

    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<GuestEntity>> GUEST = ENTITIES.register("guest",
            () -> net.minecraft.world.entity.EntityType.Builder.of(GuestEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("guest"));

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<BumperCarEntity>> BUMPER_CAR = ENTITIES.register("bumper_car",
            () -> net.minecraft.world.entity.EntityType.Builder.<BumperCarEntity>of(BumperCarEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(1.375F, 0.5625F).clientTrackingRange(10).updateInterval(3).build("bumper_car"));

    public static final DeferredBlock<AnnouncePanelBlock> ANNOUNCE_PANEL_BLOCK = BLOCKS.register("announcement_panel",
            () -> new AnnouncePanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> ANNOUNCE_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("announcement_panel", ANNOUNCE_PANEL_BLOCK);

    public static final DeferredBlock<AnnouncerBlock> ANNOUNCER_BLOCK = BLOCKS.register("announcer",
            () -> new AnnouncerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> ANNOUNCER_ITEM =
            ITEMS.registerSimpleBlockItem("announcer", ANNOUNCER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_BLOCK = BLOCKS.register("ride_gate",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> GATE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate", GATE_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_SILVER_BLOCK = BLOCKS.register("ride_gate_silver",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_silver", GATE_SILVER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_RED_BLOCK = BLOCKS.register("ride_gate_red",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_red", GATE_RED_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_DOUBLE_BLOCK = BLOCKS.register("ride_gate_double",
            () -> new RideDoubleGateBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.WOOD).noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_DOUBLE_ITEM = ITEMS.registerSimpleBlockItem("ride_gate_double", GATE_DOUBLE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_BLOCK = BLOCKS.register("ride_fence",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence", RIDE_FENCE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_SILVER_BLOCK = BLOCKS.register("ride_fence_silver",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_silver", RIDE_FENCE_SILVER_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_RED_BLOCK = BLOCKS.register("ride_fence_red",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_red", RIDE_FENCE_RED_BLOCK);

    public static final DeferredBlock<Block> GATE_SILVER_LEAF = BLOCKS.register("ride_gate_silver_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> GATE_RED_LEAF = BLOCKS.register("ride_gate_red_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    /** Picks the leaf block (and so the colour) that goes with a gate block. */
    public static Block leafFor(Block gate) {
        if (gate instanceof ParkGates.Leafed l) {
            return l.leaf();
        }
        if (gate == GATE_SILVER_BLOCK.get()) {
            return GATE_SILVER_LEAF.get();
        }
        if (gate == GATE_RED_BLOCK.get()) {
            return GATE_RED_LEAF.get();
        }
        return GATE_LEAF_BLOCK.get();
    }

    public static final DeferredBlock<SectionControllerBlock> SECTION_BLOCK = BLOCKS.register("section_controller",
            () -> new SectionControllerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(SectionControllerBlock.OCCUPIED) ? 7 : 0)));

    public static final DeferredItem<BlockItem> SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("section_controller", SECTION_BLOCK);

    public static final DeferredItem<Item> SECTION_LINKER_ITEM =
            ITEMS.registerSimpleItem("section_linker", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_PAINTER_ITEM =
            ITEMS.registerSimpleItem("track_painter", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> COASTER_SMOOTHER_ITEM =
            ITEMS.registerSimpleItem("coaster_smoother", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_UNRESTRICTOR_ITEM =
            ITEMS.registerSimpleItem("track_unrestrictor", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<AnimatronicBlock> ANIMATRONIC_BLOCK = BLOCKS.register("animatronic",
            () -> new AnimatronicBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ANIMATRONIC_ITEM = ITEMS.registerSimpleBlockItem("animatronic", ANIMATRONIC_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnimatronicBlockEntity>> ANIMATRONIC_BE =
            BLOCK_ENTITIES.register("animatronic",
                    () -> BlockEntityType.Builder.of(AnimatronicBlockEntity::new, ANIMATRONIC_BLOCK.get()).build(null));
    public static final DeferredItem<Item> ANIMATRONIC_TOOL_ITEM =
            ITEMS.registerSimpleItem("animatronic_tool", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<AnimationControllerBlock> ANIMATION_CONTROLLER_BLOCK = BLOCKS.register("animation_controller",
            () -> new AnimationControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ANIMATION_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("animation_controller", ANIMATION_CONTROLLER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnimationControllerBlockEntity>> ANIMATION_CONTROLLER_BE =
            BLOCK_ENTITIES.register("animation_controller",
                    () -> BlockEntityType.Builder.of(AnimationControllerBlockEntity::new, ANIMATION_CONTROLLER_BLOCK.get()).build(null));
    public static final DeferredItem<Item> ANIMATION_CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("animation_connector", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> DRIVE_TYRE_ITEM =
            ITEMS.registerSimpleItem("drive_tyre", new Item.Properties());
    public static final DeferredItem<Item> BRAKE_RUN_ITEM =
            ITEMS.registerSimpleItem("brake_run", new Item.Properties());
    public static final DeferredItem<Item> TRAIN_STOPPER_ITEM =
            ITEMS.registerSimpleItem("train_stopper", new Item.Properties());
    public static final DeferredItem<Item> LAUNCH_RUN_ITEM =
            ITEMS.registerSimpleItem("launch_run", new Item.Properties());
    public static final DeferredItem<Item> BLOCK_RUN_ITEM =
            ITEMS.registerSimpleItem("block_run", new Item.Properties());
    public static final DeferredItem<Item> CHAIN_TIMER_ITEM =
            ITEMS.registerSimpleItem("chain_timer", new Item.Properties().stacksTo(1));
    public static final DeferredItem<Item> REDSTONE_TRIGGER_ITEM =
            ITEMS.registerSimpleItem("redstone_trigger", new Item.Properties());

    public static final DeferredItem<Item> TRACK_ELEMENT_SELECTOR_ITEM =
            ITEMS.registerSimpleItem("track_element_selector", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_TOOL_ITEM =
            ITEMS.registerSimpleItem("support_tool", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_ERASER_ITEM =
            ITEMS.registerSimpleItem("support_eraser", new Item.Properties().stacksTo(1));

    // ---------------------------------------------------------------- queues and signs

    private static DeferredBlock<RideSignBlock> sign(SignKind kind) {
        return BLOCKS.register(kind.id, () -> new RideSignBlock(kind, BlockBehaviour.Properties.of()
                .strength(1.0F, 3.0F).sound(SoundType.WOOD).noOcclusion()));
    }

    public static final DeferredBlock<RideSignBlock> RIDE_SIGN_BLOCK = sign(SignKind.RIDE);
    public static final DeferredBlock<RideSignBlock> OPEN_SIGN_BLOCK = sign(SignKind.OPEN);
    public static final DeferredBlock<RideSignBlock> HEIGHT_SIGN_BLOCK = sign(SignKind.HEIGHT);
    public static final DeferredBlock<RideSignBlock> WAIT_SIGN_BLOCK = sign(SignKind.WAIT);

    public static final DeferredItem<BlockItem> RIDE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("ride_sign", RIDE_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> OPEN_SIGN_ITEM = ITEMS.registerSimpleBlockItem("open_sign", OPEN_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> HEIGHT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("height_sign", HEIGHT_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> WAIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wait_sign", WAIT_SIGN_BLOCK);

    public static final DeferredBlock<RideSignBlock> ENTRANCE_SIGN_BLOCK = sign(SignKind.ENTRANCE);
    public static final DeferredItem<BlockItem> ENTRANCE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("entrance_sign", ENTRANCE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> EXIT_SIGN_BLOCK = sign(SignKind.EXIT);
    public static final DeferredItem<BlockItem> EXIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("exit_sign", EXIT_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> NOTICE_SIGN_BLOCK = sign(SignKind.NOTICE);
    public static final DeferredItem<BlockItem> NOTICE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("notice_sign", NOTICE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> DIRECTION_SIGN_BLOCK = sign(SignKind.DIRECTION);
    public static final DeferredItem<BlockItem> DIRECTION_SIGN_ITEM = ITEMS.registerSimpleBlockItem("direction_sign", DIRECTION_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> CROWD_SIGN_BLOCK = sign(SignKind.CROWD);
    public static final DeferredItem<BlockItem> CROWD_SIGN_ITEM = ITEMS.registerSimpleBlockItem("queue_status_sign", CROWD_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> COUNTER_SIGN_BLOCK = sign(SignKind.COUNTER);
    public static final DeferredItem<BlockItem> COUNTER_SIGN_ITEM = ITEMS.registerSimpleBlockItem("rides_today_sign", COUNTER_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> FLOOR_SIGN_BLOCK = sign(SignKind.FLOOR);
    public static final DeferredItem<BlockItem> FLOOR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("floor_sign", FLOOR_SIGN_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideSignBlockEntity>> SIGN_BE =
            BLOCK_ENTITIES.register("ride_sign", () -> BlockEntityType.Builder.of(RideSignBlockEntity::new,
                    RIDE_SIGN_BLOCK.get(), OPEN_SIGN_BLOCK.get(), HEIGHT_SIGN_BLOCK.get(), WAIT_SIGN_BLOCK.get(),
                    ENTRANCE_SIGN_BLOCK.get(), EXIT_SIGN_BLOCK.get(), NOTICE_SIGN_BLOCK.get(), DIRECTION_SIGN_BLOCK.get(),
                    CROWD_SIGN_BLOCK.get(), COUNTER_SIGN_BLOCK.get(), FLOOR_SIGN_BLOCK.get()).build(null));

    public static final DeferredBlock<RopePostBlock> ROPE_POST_BLOCK = BLOCKS.register("rope_post",
            () -> new RopePostBlock(BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> ROPE_POST_ITEM = ITEMS.registerSimpleBlockItem("rope_post", ROPE_POST_BLOCK);

    public static final DeferredBlock<FloorArrowBlock> FLOOR_ARROW_BLOCK = BLOCKS.register("floor_arrow",
            () -> new FloorArrowBlock(BlockBehaviour.Properties.of().strength(0.3F).sound(SoundType.STONE).noOcclusion()));
    public static final DeferredItem<BlockItem> FLOOR_ARROW_ITEM = ITEMS.registerSimpleBlockItem("floor_arrow", FLOOR_ARROW_BLOCK);

    // ---------------------------------------------------------------- park decor

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<SeatEntity>> SEAT = ENTITIES.register("seat",
            () -> net.minecraft.world.entity.EntityType.Builder.<SeatEntity>of(SeatEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.1F, 0.1F).noSave().noSummon().fireImmune().clientTrackingRange(8).build("seat"));

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> PARK_JINGLE =
            ride("park_jingle");

    private static BlockBehaviour.Properties decor(SoundType sound) {
        return BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(sound).noOcclusion().isViewBlocking((s, l, p) -> false).isSuffocating((s, l, p) -> false);
    }

    private static final net.minecraft.world.item.ItemStack[] SNACKS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.COOKIE, 2),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.APPLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BREAD),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BAKED_POTATO),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.PUMPKIN_PIE)};
    private static final net.minecraft.world.item.ItemStack[] SWEETS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.HONEY_BOTTLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SWEET_BERRIES, 3),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SUGAR, 2)};

    public static final DeferredBlock<Block> BENCH_BLOCK = BLOCKS.register("bench", () -> new DecorBlocks.BenchBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> DECK_CHAIR_BLOCK = BLOCKS.register("deck_chair", () -> new DecorBlocks.SeatBlock(true, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BIN_BLOCK = BLOCKS.register("litter_bin", () -> new DecorBlocks.BinBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> LAMP_POST_BLOCK = BLOCKS.register("lamp_post", () -> new DecorBlocks.LampBlock(true,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 15 : 0)));
    public static final DeferredBlock<Block> GARDEN_LIGHT_BLOCK = BLOCKS.register("garden_light", () -> new DecorBlocks.LampBlock(false,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 13 : 0)));
    public static final DeferredBlock<Block> CLOCK_BLOCK = BLOCKS.register("park_clock", () -> new DecorBlocks.ClockBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> MAP_BOARD_BLOCK = BLOCKS.register("park_map", () -> new DecorBlocks.MapBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BOOTH_BLOCK = BLOCKS.register("ticket_booth", () -> new DecorBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> SNACK_BLOCK = BLOCKS.register("snack_machine", () -> new DecorBlocks.VendingBlock(SNACKS, decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CANDY_BLOCK = BLOCKS.register("candy_stand", () -> new DecorBlocks.VendingBlock(SWEETS, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FOUNTAIN_BLOCK = BLOCKS.register("drinking_fountain", () -> new DecorBlocks.FountainBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> PLANTER_BLOCK = BLOCKS.register("flower_planter", () -> new DecorBlocks.PlanterBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FLAG_BLOCK = BLOCKS.register("park_flag", () -> new DecorBlocks.FlagBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SPEAKER_BLOCK = BLOCKS.register("park_speaker", () -> new DecorBlocks.SpeakerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> BOUNCY_BLOCK = BLOCKS.register("bouncy_pad", () -> new DecorBlocks.BouncyPadBlock(decor(SoundType.SLIME_BLOCK)));
    public static final DeferredBlock<Block> MISTER_BLOCK = BLOCKS.register("cooling_mister", () -> new DecorBlocks.MisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BENCH_ITEM = ITEMS.registerSimpleBlockItem("bench", BENCH_BLOCK);
    public static final DeferredItem<BlockItem> DECK_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("deck_chair", DECK_CHAIR_BLOCK);
    public static final DeferredItem<BlockItem> BIN_ITEM = ITEMS.registerSimpleBlockItem("litter_bin", BIN_BLOCK);
    public static final DeferredItem<BlockItem> LAMP_POST_ITEM = ITEMS.registerSimpleBlockItem("lamp_post", LAMP_POST_BLOCK);
    public static final DeferredItem<BlockItem> GARDEN_LIGHT_ITEM = ITEMS.registerSimpleBlockItem("garden_light", GARDEN_LIGHT_BLOCK);
    public static final DeferredItem<BlockItem> CLOCK_ITEM = ITEMS.registerSimpleBlockItem("park_clock", CLOCK_BLOCK);
    public static final DeferredItem<BlockItem> MAP_BOARD_ITEM = ITEMS.registerSimpleBlockItem("park_map", MAP_BOARD_BLOCK);
    public static final DeferredItem<BlockItem> BOOTH_ITEM = ITEMS.registerSimpleBlockItem("ticket_booth", BOOTH_BLOCK);
    public static final DeferredItem<BlockItem> SNACK_ITEM = ITEMS.registerSimpleBlockItem("snack_machine", SNACK_BLOCK);
    public static final DeferredItem<BlockItem> CANDY_ITEM = ITEMS.registerSimpleBlockItem("candy_stand", CANDY_BLOCK);
    public static final DeferredItem<BlockItem> FOUNTAIN_ITEM = ITEMS.registerSimpleBlockItem("drinking_fountain", FOUNTAIN_BLOCK);
    public static final DeferredItem<BlockItem> PLANTER_ITEM = ITEMS.registerSimpleBlockItem("flower_planter", PLANTER_BLOCK);
    public static final DeferredItem<BlockItem> FLAG_ITEM = ITEMS.registerSimpleBlockItem("park_flag", FLAG_BLOCK);
    public static final DeferredItem<BlockItem> SPEAKER_ITEM = ITEMS.registerSimpleBlockItem("park_speaker", SPEAKER_BLOCK);
    public static final DeferredItem<BlockItem> BOUNCY_ITEM = ITEMS.registerSimpleBlockItem("bouncy_pad", BOUNCY_BLOCK);
    public static final DeferredItem<BlockItem> MISTER_ITEM = ITEMS.registerSimpleBlockItem("cooling_mister", MISTER_BLOCK);

    // ---- Bathroom pack
    public static final DeferredBlock<Block> TOILET_BLOCK = BLOCKS.register("toilet", () -> new BathroomBlocks.FlushBlock(false, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> URINAL_BLOCK = BLOCKS.register("urinal", () -> new BathroomBlocks.FlushBlock(true, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> SINK_BLOCK = BLOCKS.register("sink", () -> new BathroomBlocks.SinkBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> HAND_DRYER_BLOCK = BLOCKS.register("hand_dryer", () -> new BathroomBlocks.DryerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SOAP_DISPENSER_BLOCK = BLOCKS.register("soap_dispenser", () -> new BathroomBlocks.SoapDispenserBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> ROLL_HOLDER_BLOCK = BLOCKS.register("toilet_roll_holder", () -> new BathroomBlocks.RollHolderBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CUBICLE_BLOCK = BLOCKS.register("toilet_cubicle", () -> new BathroomBlocks.CubicleBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SIGN_MEN_BLOCK = BLOCKS.register("toilet_sign_men", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_WOMEN_BLOCK = BLOCKS.register("toilet_sign_women", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_ACCESS_BLOCK = BLOCKS.register("toilet_sign_accessible", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_BABY_BLOCK = BLOCKS.register("toilet_sign_baby", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredItem<BlockItem> TOILET_ITEM = ITEMS.registerSimpleBlockItem("toilet", TOILET_BLOCK);
    public static final DeferredBlock<Block> SINK_TOP = BLOCKS.register("sink_top", () -> TallBlocks.Top.create(SINK_BLOCK, (st, part) -> BathroomBlocks.sinkTopShape(st.getValue(DecorBlocks.FACING)), decor(SoundType.STONE), BathroomBlocks.RUNNING));
    public static final DeferredBlock<Block> URINAL_TOP = BLOCKS.register("urinal_top", () -> TallBlocks.Top.create(URINAL_BLOCK, (st, part) -> BathroomBlocks.urinalTopShape(st.getValue(DecorBlocks.FACING)), decor(SoundType.STONE), BathroomBlocks.FLUSH));
    public static final DeferredItem<BlockItem> URINAL_ITEM = ITEMS.<BlockItem>register("urinal", () -> new TallBlocks.Item(URINAL_BLOCK.get(), new Item.Properties(), URINAL_TOP, 2));
    public static final DeferredItem<BlockItem> SINK_ITEM = ITEMS.<BlockItem>register("sink", () -> new TallBlocks.Item(SINK_BLOCK.get(), new Item.Properties(), SINK_TOP, 2));
    public static final DeferredBlock<Block> CUBICLE_PANEL_BLOCK = BLOCKS.register("cubicle_panel", () -> new BathroomBlocks.CubiclePanelBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CUBICLE_PANEL_ITEM = ITEMS.registerSimpleBlockItem("cubicle_panel", CUBICLE_PANEL_BLOCK);
    public static final DeferredItem<Item> CUBICLE_KIT_ITEM = ITEMS.<Item>register("cubicle_kit", () -> new BathroomBlocks.CubicleKitItem(new Item.Properties()));
    public static final DeferredItem<BlockItem> HAND_DRYER_ITEM = ITEMS.registerSimpleBlockItem("hand_dryer", HAND_DRYER_BLOCK);
    public static final DeferredItem<BlockItem> SOAP_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("soap_dispenser", SOAP_DISPENSER_BLOCK);
    public static final DeferredItem<BlockItem> ROLL_HOLDER_ITEM = ITEMS.registerSimpleBlockItem("toilet_roll_holder", ROLL_HOLDER_BLOCK);
    public static final DeferredBlock<Block> CUBICLE_TOP = BLOCKS.register("toilet_cubicle_top", () -> TallBlocks.Top.create(CUBICLE_BLOCK, null, decor(SoundType.METAL), net.minecraft.world.level.block.state.properties.BlockStateProperties.OPEN));
    public static final DeferredItem<BlockItem> CUBICLE_ITEM = ITEMS.<BlockItem>register("toilet_cubicle", () -> new TallBlocks.Item(CUBICLE_BLOCK.get(), new Item.Properties(), CUBICLE_TOP, 2));
    public static final DeferredItem<BlockItem> SIGN_MEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_men", SIGN_MEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_WOMEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_women", SIGN_WOMEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_ACCESS_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_accessible", SIGN_ACCESS_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_BABY_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_baby", SIGN_BABY_BLOCK);
    public static final DeferredItem<Item> SOAP_ITEM = ITEMS.registerSimpleItem("soap", new Item.Properties());
    public static final java.util.List<DeferredItem<? extends Item>> BATH_ITEMS = java.util.List.of(
            CUBICLE_KIT_ITEM, CUBICLE_ITEM, CUBICLE_PANEL_ITEM, TOILET_ITEM, URINAL_ITEM, SINK_ITEM, HAND_DRYER_ITEM, SOAP_DISPENSER_ITEM, SOAP_ITEM,
            ROLL_HOLDER_ITEM, SIGN_MEN_ITEM, SIGN_WOMEN_ITEM, SIGN_ACCESS_ITEM, SIGN_BABY_ITEM);

    // ---- Kitchen pack
    public static final DeferredItem<Item> BUN = ITEMS.registerSimpleItem("bun", new Item.Properties());
    public static final DeferredItem<Item> RAW_PATTY = ITEMS.registerSimpleItem("raw_patty", new Item.Properties());
    public static final DeferredItem<Item> COOKED_PATTY = ITEMS.registerSimpleItem("cooked_patty", new Item.Properties());
    public static final DeferredItem<Item> RAW_SAUSAGE = ITEMS.registerSimpleItem("raw_sausage", new Item.Properties());
    public static final DeferredItem<Item> COOKED_SAUSAGE = ITEMS.registerSimpleItem("cooked_sausage", new Item.Properties());
    public static final DeferredItem<Item> DOUGH = ITEMS.registerSimpleItem("dough", new Item.Properties());
    public static final DeferredItem<Item> POTATO_STRIPS = ITEMS.registerSimpleItem("potato_strips", new Item.Properties());
    public static final DeferredItem<Item> BURGER = ITEMS.registerSimpleItem("burger", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> HOT_DOG = ITEMS.registerSimpleItem("hot_dog", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> CHIPS = ITEMS.registerSimpleItem("chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).fast().build()));
    public static final DeferredItem<Item> DOUGHNUT = ITEMS.registerSimpleItem("doughnut", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> PIZZA_SLICE = ITEMS.registerSimpleItem("pizza_slice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> ICE_CREAM = ITEMS.registerSimpleItem("ice_cream", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> POPCORN_ITEM = ITEMS.registerSimpleItem("popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).fast().build()));
    public static final DeferredItem<Item> APPLE_JUICE = ITEMS.register("apple_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.REGENERATION, 5));
    public static final DeferredItem<Item> BERRY_FIZZ = ITEMS.register("berry_fizz", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.JUMP, 15));
    public static final DeferredItem<Item> MELON_JUICE = ITEMS.register("melon_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.WATER_BREATHING, 20));
    public static final DeferredItem<Item> COLA = ITEMS.register("cola", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 10));
    public static final DeferredItem<Item> CHEESE = ITEMS.registerSimpleItem("cheese", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.4F).build()));
    public static final DeferredItem<Item> SALAD = ITEMS.registerSimpleItem("salad", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> CHEESEBURGER = ITEMS.registerSimpleItem("cheeseburger", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(10).saturationModifier(0.9F).build()));
    public static final DeferredItem<Item> CHICKEN_SANDWICH = ITEMS.registerSimpleItem("chicken_sandwich", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> HAM_SANDWICH = ITEMS.registerSimpleItem("ham_sandwich", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> TORTILLA = ITEMS.registerSimpleItem("tortilla", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).build()));
    public static final DeferredItem<Item> TACO = ITEMS.registerSimpleItem("taco", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> BURRITO = ITEMS.registerSimpleItem("burrito", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(9).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> TORTILLA_CHIPS = ITEMS.registerSimpleItem("tortilla_chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> NACHOS = ITEMS.registerSimpleItem("nachos", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> FRUIT_CUP = ITEMS.registerSimpleItem("fruit_cup", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).fast().build()));
    public static final DeferredItem<Item> CANDY_FLOSS = ITEMS.registerSimpleItem("candy_floss", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).fast().build()));
    public static final DeferredItem<Item> CARAMEL_POPCORN = ITEMS.registerSimpleItem("caramel_popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> CHOCOLATE_POPCORN = ITEMS.registerSimpleItem("chocolate_popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> FRIED_CHICKEN = ITEMS.registerSimpleItem("fried_chicken", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> CHURRO = ITEMS.registerSimpleItem("churro", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> FISH_AND_CHIPS = ITEMS.registerSimpleItem("fish_and_chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(10).saturationModifier(0.9F).build()));
    public static final DeferredItem<Item> FISH_FINGERS = ITEMS.registerSimpleItem("fish_fingers", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> NUGGETS = ITEMS.registerSimpleItem("nuggets", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).fast().build()));
    public static final DeferredItem<Item> CORN_DOG = ITEMS.registerSimpleItem("corn_dog", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> CHEESE_PIZZA = ITEMS.registerSimpleItem("cheese_pizza", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> APPLE_PIE = ITEMS.registerSimpleItem("apple_pie", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> CHOC_COOKIE = ITEMS.registerSimpleItem("choc_cookie", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> CAKE_SLICE = ITEMS.registerSimpleItem("cake_slice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.4F).build()));
    public static final DeferredItem<Item> MUFFIN = ITEMS.registerSimpleItem("muffin", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> LOADED_POTATO = ITEMS.registerSimpleItem("loaded_potato", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(9).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> SAUSAGE_ROLL = ITEMS.registerSimpleItem("sausage_roll", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> PASTY = ITEMS.registerSimpleItem("pasty", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> PRETZEL = ITEMS.registerSimpleItem("pretzel", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> CHOC_ICE_CREAM = ITEMS.registerSimpleItem("choc_ice_cream", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> ICE_LOLLY = ITEMS.registerSimpleItem("ice_lolly", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> SUNDAE = ITEMS.registerSimpleItem("sundae", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> FROZEN_YOGURT = ITEMS.registerSimpleItem("frozen_yogurt", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> MILKSHAKE = ITEMS.register("milkshake", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.ABSORPTION, 30));
    public static final DeferredItem<Item> HOT_CHOCOLATE = ITEMS.register("hot_chocolate", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, 30));
    public static final DeferredItem<Item> CARROT_JUICE = ITEMS.register("carrot_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.NIGHT_VISION, 30));
    public static final DeferredItem<Item> GLOW_SMOOTHIE = ITEMS.register("glow_smoothie", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.GLOWING, 20));
    public static final DeferredBlock<Block> PREP_BLOCK = BLOCKS.register("prep_counter", () -> new KitchenBlock(KitchenKind.PREP, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PREP_ITEM = ITEMS.registerSimpleBlockItem("prep_counter", PREP_BLOCK);
    public static final DeferredBlock<Block> GRILL_BLOCK = BLOCKS.register("park_grill", () -> new KitchenBlock(KitchenKind.GRILL, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> GRILL_ITEM = ITEMS.registerSimpleBlockItem("park_grill", GRILL_BLOCK);
    public static final DeferredBlock<Block> FRYER_BLOCK = BLOCKS.register("deep_fryer", () -> new KitchenBlock(KitchenKind.FRYER, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> FRYER_ITEM = ITEMS.registerSimpleBlockItem("deep_fryer", FRYER_BLOCK);
    public static final DeferredBlock<Block> OVEN_BLOCK = BLOCKS.register("pizza_oven", () -> new KitchenBlock(KitchenKind.OVEN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredBlock<Block> OVEN_TOP = BLOCKS.register("pizza_oven_top", () -> TallBlocks.Top.create(OVEN_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 10), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> OVEN_ITEM = ITEMS.<BlockItem>register("pizza_oven", () -> new TallBlocks.Item(OVEN_BLOCK.get(), new Item.Properties(), OVEN_TOP, 2));
    public static final DeferredBlock<Block> SOFT_SERVE_BLOCK = BLOCKS.register("soft_serve_machine", () -> new KitchenBlock(KitchenKind.SOFT_SERVE, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredItem<BlockItem> SOFT_SERVE_ITEM = ITEMS.registerSimpleBlockItem("soft_serve_machine", SOFT_SERVE_BLOCK);
    public static final DeferredBlock<Block> POPCORN_MACHINE_BLOCK = BLOCKS.register("popcorn_machine", () -> new KitchenBlock(KitchenKind.POPCORN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredBlock<Block> POPCORN_MACHINE_TOP = BLOCKS.register("popcorn_machine_top", () -> TallBlocks.Top.create(POPCORN_MACHINE_BLOCK, null, decor(SoundType.METAL), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> POPCORN_MACHINE_ITEM = ITEMS.<BlockItem>register("popcorn_machine", () -> new TallBlocks.Item(POPCORN_MACHINE_BLOCK.get(), new Item.Properties(), POPCORN_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> DRINKS_BLOCK = BLOCKS.register("drinks_dispenser", () -> new KitchenBlock(KitchenKind.DRINKS, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredBlock<Block> DRINKS_TOP = BLOCKS.register("drinks_dispenser_top", () -> TallBlocks.Top.create(DRINKS_BLOCK, null, decor(SoundType.METAL), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> DRINKS_ITEM = ITEMS.<BlockItem>register("drinks_dispenser", () -> new TallBlocks.Item(DRINKS_BLOCK.get(), new Item.Properties(), DRINKS_TOP, 2));
    public static final DeferredBlock<Block> FRIDGE_BLOCK = BLOCKS.register("fridge", () -> new KitchenExtras.FridgeBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> FRIDGE_TOP = BLOCKS.register("fridge_top", () -> TallBlocks.Top.create(FRIDGE_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FRIDGE_ITEM = ITEMS.<BlockItem>register("fridge", () -> new TallBlocks.Item(FRIDGE_BLOCK.get(), new Item.Properties(), FRIDGE_TOP, 2));
    public static final DeferredBlock<Block> BELL_BLOCK = BLOCKS.register("order_bell", () -> new KitchenExtras.BellBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BELL_ITEM = ITEMS.registerSimpleBlockItem("order_bell", BELL_BLOCK);
    public static final DeferredBlock<Block> FAN_BLOCK = BLOCKS.register("extractor_fan", () -> new KitchenExtras.FanBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FAN_ITEM = ITEMS.registerSimpleBlockItem("extractor_fan", FAN_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenBlockEntity>> KITCHEN_BE =
            BLOCK_ENTITIES.register("kitchen_machine", () -> BlockEntityType.Builder.of(KitchenBlockEntity::new,
                    PREP_BLOCK.get(), GRILL_BLOCK.get(), FRYER_BLOCK.get(), OVEN_BLOCK.get(), SOFT_SERVE_BLOCK.get(),
                    POPCORN_MACHINE_BLOCK.get(), DRINKS_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.FridgeBlockEntity>> FRIDGE_BE =
            BLOCK_ENTITIES.register("fridge", () -> BlockEntityType.Builder.of(KitchenExtras.FridgeBlockEntity::new, FRIDGE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.BellBlockEntity>> BELL_BE =
            BLOCK_ENTITIES.register("order_bell", () -> BlockEntityType.Builder.of(KitchenExtras.BellBlockEntity::new, BELL_BLOCK.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<KitchenMenu>> KITCHEN_MENU =
            MENUS.register("kitchen_machine", () -> IMenuTypeExtension.create(KitchenMenu::new));
    public static final java.util.List<DeferredItem<? extends Item>> KITCHEN_ITEMS = java.util.List.of(
            PREP_ITEM, GRILL_ITEM, FRYER_ITEM, OVEN_ITEM, SOFT_SERVE_ITEM, POPCORN_MACHINE_ITEM, DRINKS_ITEM,
            FRIDGE_ITEM, BELL_ITEM, FAN_ITEM,
            BUN, RAW_PATTY, COOKED_PATTY, RAW_SAUSAGE, COOKED_SAUSAGE, DOUGH, POTATO_STRIPS,
            BURGER, HOT_DOG, CHIPS, DOUGHNUT, PIZZA_SLICE, ICE_CREAM, POPCORN_ITEM,
            APPLE_JUICE, BERRY_FIZZ, MELON_JUICE, COLA,
            CHEESE, SALAD, CHEESEBURGER, CHICKEN_SANDWICH, HAM_SANDWICH, TORTILLA, TACO, BURRITO, TORTILLA_CHIPS, NACHOS, FRUIT_CUP, CANDY_FLOSS, CARAMEL_POPCORN, CHOCOLATE_POPCORN, FRIED_CHICKEN, CHURRO, FISH_AND_CHIPS, FISH_FINGERS, NUGGETS, CORN_DOG, CHEESE_PIZZA, APPLE_PIE, CHOC_COOKIE, CAKE_SLICE, MUFFIN, LOADED_POTATO, SAUSAGE_ROLL, PASTY, PRETZEL, CHOC_ICE_CREAM, ICE_LOLLY, SUNDAE, FROZEN_YOGURT, MILKSHAKE, HOT_CHOCOLATE, CARROT_JUICE, GLOW_SMOOTHIE);

    private static final TallBlocks.ShapeFn TALL_PARASOL_SHAPE = (st, part) -> st.getValue(DiningBlocks.PARASOL_OPEN)
            ? net.minecraft.world.phys.shapes.Shapes.or(Block.box(7, 0, 7, 9, 16, 9), Block.box(1, 14, 1, 15, 16, 15))
            : Block.box(6, 0, 6, 10, 16, 10);
    // ---- Restaurant and cafe pack
    public static final DeferredBlock<Block> DINING_TABLE_BLOCK = BLOCKS.register("dining_table", () -> new DiningBlocks.TableBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_TABLE_ITEM = ITEMS.registerSimpleBlockItem("dining_table", DINING_TABLE_BLOCK);
    public static final DeferredBlock<Block> DINING_CHAIR_BLOCK = BLOCKS.register("dining_chair", () -> new DiningBlocks.ChairBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("dining_chair", DINING_CHAIR_BLOCK);
    public static final DeferredBlock<Block> DINING_BOOTH_BLOCK = BLOCKS.register("dining_booth", () -> new DiningBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("dining_booth", DINING_BOOTH_BLOCK);
    public static final DeferredBlock<Block> MENU_BOARD_BLOCK = BLOCKS.register("menu_board", () -> new RestaurantBlocks.MenuBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> MENU_BOARD_ITEM = ITEMS.registerSimpleBlockItem("menu_board", MENU_BOARD_BLOCK);
    public static final DeferredBlock<Block> ORDER_KIOSK_BLOCK = BLOCKS.register("order_kiosk", () -> new RestaurantBlocks.KioskBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ORDER_KIOSK_TOP = BLOCKS.register("order_kiosk_top", () -> TallBlocks.Top.create(ORDER_KIOSK_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ORDER_KIOSK_ITEM = ITEMS.<BlockItem>register("order_kiosk", () -> new TallBlocks.Item(ORDER_KIOSK_BLOCK.get(), new Item.Properties(), ORDER_KIOSK_TOP, 2));
    public static final DeferredBlock<Block> PICKUP_DISPLAY_BLOCK = BLOCKS.register("pickup_display", () -> new RestaurantBlocks.PickupBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> PICKUP_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("pickup_display", PICKUP_DISPLAY_BLOCK);
    public static final DeferredBlock<Block> CASH_REGISTER_BLOCK = BLOCKS.register("cash_register", () -> new RestaurantBlocks.RegisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CASH_REGISTER_ITEM = ITEMS.registerSimpleBlockItem("cash_register", CASH_REGISTER_BLOCK);
    public static final DeferredBlock<Block> CONDIMENT_STAND_BLOCK = BLOCKS.register("condiment_stand", () -> new RestaurantBlocks.CondimentBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CONDIMENT_STAND_ITEM = ITEMS.registerSimpleBlockItem("condiment_stand", CONDIMENT_STAND_BLOCK);
    public static final DeferredBlock<Block> PARASOL_BLOCK = BLOCKS.register("parasol", () -> new DiningBlocks.ParasolBlock(decor(SoundType.WOOL)));
    public static final DeferredBlock<Block> PARASOL_TOP = BLOCKS.register("parasol_top", () -> TallBlocks.Top.create(PARASOL_BLOCK, TALL_PARASOL_SHAPE, decor(SoundType.WOOL), DiningBlocks.PARASOL_OPEN, DecorBlocks.COLOR));
    public static final DeferredItem<BlockItem> PARASOL_ITEM = ITEMS.<BlockItem>register("parasol", () -> new TallBlocks.Item(PARASOL_BLOCK.get(), new Item.Properties(), PARASOL_TOP, 2));
    public static final DeferredBlock<Block> TRAY_TROLLEY_BLOCK = BLOCKS.register("tray_trolley", () -> new RestaurantBlocks.TrolleyBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TRAY_TROLLEY_ITEM = ITEMS.registerSimpleBlockItem("tray_trolley", TRAY_TROLLEY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.KioskBlockEntity>> KIOSK_BE =
            BLOCK_ENTITIES.register("order_kiosk", () -> BlockEntityType.Builder.of(RestaurantBlocks.KioskBlockEntity::new, ORDER_KIOSK_BLOCK.get()).build(null));
    public static final DeferredBlock<Block> ORDER_DISPLAY_BLOCK = BLOCKS.register("order_display", () -> new RestaurantBlocks.OrderDisplayBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> ORDER_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("order_display", ORDER_DISPLAY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.PickupBlockEntity>> PICKUP_BE =
            BLOCK_ENTITIES.register("pickup_display", () -> BlockEntityType.Builder.of(RestaurantBlocks.PickupBlockEntity::new, PICKUP_DISPLAY_BLOCK.get(), ORDER_DISPLAY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.MenuBoardBlockEntity>> MENU_BOARD_BE =
            BLOCK_ENTITIES.register("menu_board", () -> BlockEntityType.Builder.of(RestaurantBlocks.MenuBoardBlockEntity::new, MENU_BOARD_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.CondimentBlockEntity>> CONDIMENT_BE =
            BLOCK_ENTITIES.register("condiment_stand", () -> BlockEntityType.Builder.of(RestaurantBlocks.CondimentBlockEntity::new, CONDIMENT_STAND_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.TrolleyBlockEntity>> TROLLEY_BE =
            BLOCK_ENTITIES.register("tray_trolley", () -> BlockEntityType.Builder.of(RestaurantBlocks.TrolleyBlockEntity::new, TRAY_TROLLEY_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> RESTAURANT_ITEMS = java.util.List.of(
            DINING_TABLE_ITEM, DINING_CHAIR_ITEM, DINING_BOOTH_ITEM, MENU_BOARD_ITEM, ORDER_KIOSK_ITEM, ORDER_DISPLAY_ITEM, PICKUP_DISPLAY_ITEM,
            CASH_REGISTER_ITEM, CONDIMENT_STAND_ITEM, PARASOL_ITEM, TRAY_TROLLEY_ITEM);
    // ---- Arcade pack
    public static final DeferredItem<Item> ARCADE_TOKEN = ITEMS.registerSimpleItem("arcade_token", new Item.Properties());
    public static final DeferredItem<Item> PRIZE_TICKET = ITEMS.registerSimpleItem("prize_ticket", new Item.Properties());
    public static final DeferredBlock<Block> TOKEN_MACHINE_BLOCK = BLOCKS.register("token_machine", () -> new ArcadeBlocks.TokenBlock(decor(SoundType.METAL).lightLevel(st -> 7)));
    public static final DeferredBlock<Block> TOKEN_MACHINE_TOP = BLOCKS.register("token_machine_top", () -> TallBlocks.Top.create(TOKEN_MACHINE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 7)));
    public static final DeferredItem<BlockItem> TOKEN_MACHINE_ITEM = ITEMS.<BlockItem>register("token_machine", () -> new TallBlocks.Item(TOKEN_MACHINE_BLOCK.get(), new Item.Properties(), TOKEN_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> PRIZE_COUNTER_BLOCK = BLOCKS.register("prize_counter", () -> new ArcadeBlocks.PrizeBlock(decor(SoundType.WOOD).lightLevel(st -> 5)));
    public static final DeferredBlock<Block> PRIZE_COUNTER_TOP = BLOCKS.register("prize_counter_top", () -> TallBlocks.Top.create(PRIZE_COUNTER_BLOCK, null, decor(SoundType.WOOD).lightLevel(st -> 5)));
    public static final DeferredItem<BlockItem> PRIZE_COUNTER_ITEM = ITEMS.<BlockItem>register("prize_counter", () -> new TallBlocks.Item(PRIZE_COUNTER_BLOCK.get(), new Item.Properties(), PRIZE_COUNTER_TOP, 2));
    public static final DeferredBlock<Block> ARCADE_CABINET_BLOCK = BLOCKS.register("arcade_cabinet", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CABINET, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ARCADE_CABINET_TOP = BLOCKS.register("arcade_cabinet_top", () -> TallBlocks.Top.create(ARCADE_CABINET_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ARCADE_CABINET_ITEM = ITEMS.<BlockItem>register("arcade_cabinet", () -> new TallBlocks.Item(ARCADE_CABINET_BLOCK.get(), new Item.Properties(), ARCADE_CABINET_TOP, 2));
    public static final DeferredBlock<Block> CLAW_MACHINE_BLOCK = BLOCKS.register("claw_machine", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CLAW, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> CLAW_MACHINE_TOP = BLOCKS.register("claw_machine_top", () -> TallBlocks.Top.create(CLAW_MACHINE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> CLAW_MACHINE_ITEM = ITEMS.<BlockItem>register("claw_machine", () -> new TallBlocks.Item(CLAW_MACHINE_BLOCK.get(), new Item.Properties(), CLAW_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> WHACK_A_MOLE_BLOCK = BLOCKS.register("whack_a_mole", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.MOLE, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> WHACK_A_MOLE_ITEM = ITEMS.registerSimpleBlockItem("whack_a_mole", WHACK_A_MOLE_BLOCK);
    public static final DeferredBlock<Block> STRENGTH_TESTER_BLOCK = BLOCKS.register("strength_tester", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.STRENGTH, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> STRENGTH_TESTER_TOP = BLOCKS.register("strength_tester_top", () -> TallBlocks.Top.create(STRENGTH_TESTER_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6), ArcadeBlocks.LEVEL));
    public static final DeferredItem<BlockItem> STRENGTH_TESTER_ITEM = ITEMS.<BlockItem>register("strength_tester", () -> new TallBlocks.Item(STRENGTH_TESTER_BLOCK.get(), new Item.Properties(), STRENGTH_TESTER_TOP, 2));
    public static final DeferredBlock<Block> BASKETBALL_HOOPS_BLOCK = BLOCKS.register("basketball_hoops", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.HOOPS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> BASKETBALL_HOOPS_TOP = BLOCKS.register("basketball_hoops_top", () -> TallBlocks.Top.create(BASKETBALL_HOOPS_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> BASKETBALL_HOOPS_ITEM = ITEMS.<BlockItem>register("basketball_hoops", () -> new TallBlocks.Item(BASKETBALL_HOOPS_BLOCK.get(), new Item.Properties(), BASKETBALL_HOOPS_TOP, 2));
    public static final DeferredBlock<Block> SHOOTING_GALLERY_BLOCK = BLOCKS.register("shooting_gallery", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.GALLERY, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> SHOOTING_GALLERY_TOP = BLOCKS.register("shooting_gallery_top", () -> TallBlocks.Top.create(SHOOTING_GALLERY_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> SHOOTING_GALLERY_ITEM = ITEMS.<BlockItem>register("shooting_gallery", () -> new TallBlocks.Item(SHOOTING_GALLERY_BLOCK.get(), new Item.Properties(), SHOOTING_GALLERY_TOP, 2));
    public static final DeferredBlock<Block> RING_TOSS_BLOCK = BLOCKS.register("ring_toss", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.RINGS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> RING_TOSS_ITEM = ITEMS.registerSimpleBlockItem("ring_toss", RING_TOSS_BLOCK);
    public static final DeferredBlock<Block> COCONUT_SHY_BLOCK = BLOCKS.register("coconut_shy", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.COCONUT, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> COCONUT_SHY_TOP = BLOCKS.register("coconut_shy_top", () -> TallBlocks.Top.create(COCONUT_SHY_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> COCONUT_SHY_ITEM = ITEMS.<BlockItem>register("coconut_shy", () -> new TallBlocks.Item(COCONUT_SHY_BLOCK.get(), new Item.Properties(), COCONUT_SHY_TOP, 2));
    // ---- Park props: second round of the amenity packs (generated by props/gen_props.py)
    public static final DeferredBlock<Block> VANITY_MIRROR_BLOCK = BLOCKS.register("vanity_mirror", () -> new ParkProps.Plain("vanity_mirror", decor(SoundType.STONE).lightLevel(s -> ParkProps.light("vanity_mirror", s))));
    public static final DeferredItem<BlockItem> VANITY_MIRROR_ITEM = ITEMS.registerSimpleBlockItem("vanity_mirror", VANITY_MIRROR_BLOCK);
    public static final DeferredBlock<Block> BIDET_BLOCK = BLOCKS.register("bidet", () -> new ParkProps.Plain("bidet", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> BIDET_ITEM = ITEMS.registerSimpleBlockItem("bidet", BIDET_BLOCK);
    public static final DeferredBlock<Block> BATHTUB_BLOCK = BLOCKS.register("bathtub", () -> new ParkProps.Act("bathtub", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> BATHTUB_ITEM = ITEMS.registerSimpleBlockItem("bathtub", BATHTUB_BLOCK);
    public static final DeferredBlock<Block> SHOWER_CURTAIN_RAIL_BLOCK = BLOCKS.register("shower_curtain_rail", () -> new ParkProps.Plain("shower_curtain_rail", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> SHOWER_CURTAIN_RAIL_ITEM = ITEMS.registerSimpleBlockItem("shower_curtain_rail", SHOWER_CURTAIN_RAIL_BLOCK);
    public static final DeferredBlock<Block> TOILET_BRUSH_HOLDER_BLOCK = BLOCKS.register("toilet_brush_holder", () -> new ParkProps.Plain("toilet_brush_holder", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> TOILET_BRUSH_HOLDER_ITEM = ITEMS.registerSimpleBlockItem("toilet_brush_holder", TOILET_BRUSH_HOLDER_BLOCK);
    public static final DeferredBlock<Block> AIR_FRESHENER_BLOCK = BLOCKS.register("air_freshener", () -> new ParkProps.Act("air_freshener", decor(SoundType.STONE).lightLevel(s -> ParkProps.light("air_freshener", s))));
    public static final DeferredItem<BlockItem> AIR_FRESHENER_ITEM = ITEMS.registerSimpleBlockItem("air_freshener", AIR_FRESHENER_BLOCK);
    public static final DeferredBlock<Block> VANITY_CABINET_BLOCK = BLOCKS.register("vanity_cabinet", () -> new ParkProps.Store("vanity_cabinet", decor(SoundType.WOOD), 1));
    public static final DeferredItem<BlockItem> VANITY_CABINET_ITEM = ITEMS.registerSimpleBlockItem("vanity_cabinet", VANITY_CABINET_BLOCK);
    public static final DeferredBlock<Block> HEATED_TOWEL_RAIL_BLOCK = BLOCKS.register("heated_towel_rail", () -> new ParkProps.Plain("heated_towel_rail", decor(SoundType.STONE).lightLevel(s -> ParkProps.light("heated_towel_rail", s))));
    public static final DeferredItem<BlockItem> HEATED_TOWEL_RAIL_ITEM = ITEMS.registerSimpleBlockItem("heated_towel_rail", HEATED_TOWEL_RAIL_BLOCK);
    public static final DeferredBlock<Block> HOB_BLOCK = BLOCKS.register("hob", () -> new ParkProps.Act("hob", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("hob", s))));
    public static final DeferredItem<BlockItem> HOB_ITEM = ITEMS.registerSimpleBlockItem("hob", HOB_BLOCK);
    public static final DeferredBlock<Block> STEAMER_BLOCK = BLOCKS.register("steamer", () -> new ParkProps.Plain("steamer", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> STEAMER_ITEM = ITEMS.registerSimpleBlockItem("steamer", STEAMER_BLOCK);
    public static final DeferredBlock<Block> RICE_COOKER_BLOCK = BLOCKS.register("rice_cooker", () -> new ParkProps.Act("rice_cooker", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("rice_cooker", s))));
    public static final DeferredItem<BlockItem> RICE_COOKER_ITEM = ITEMS.registerSimpleBlockItem("rice_cooker", RICE_COOKER_BLOCK);
    public static final DeferredBlock<Block> BLENDER_BLOCK = BLOCKS.register("blender", () -> new ParkProps.Act("blender", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BLENDER_ITEM = ITEMS.registerSimpleBlockItem("blender", BLENDER_BLOCK);
    public static final DeferredBlock<Block> TOASTER_BLOCK = BLOCKS.register("toaster", () -> new ParkProps.Plain("toaster", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("toaster", s))));
    public static final DeferredItem<BlockItem> TOASTER_ITEM = ITEMS.registerSimpleBlockItem("toaster", TOASTER_BLOCK);
    public static final DeferredBlock<Block> ICE_MACHINE_BLOCK = BLOCKS.register("ice_machine", () -> new ParkProps.Act("ice_machine", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ICE_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("ice_machine", ICE_MACHINE_BLOCK);
    public static final DeferredBlock<Block> DISH_RACK_BLOCK = BLOCKS.register("dish_rack", () -> new ParkProps.Plain("dish_rack", decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> DISH_RACK_ITEM = ITEMS.registerSimpleBlockItem("dish_rack", DISH_RACK_BLOCK);
    public static final DeferredBlock<Block> HANGING_POT_RACK_BLOCK = BLOCKS.register("hanging_pot_rack", () -> new ParkProps.Plain("hanging_pot_rack", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> HANGING_POT_RACK_ITEM = ITEMS.registerSimpleBlockItem("hanging_pot_rack", HANGING_POT_RACK_BLOCK);
    public static final DeferredBlock<Block> SPICE_SHELF_BLOCK = BLOCKS.register("spice_shelf", () -> new ParkProps.Store("spice_shelf", decor(SoundType.METAL), 1));
    public static final DeferredItem<BlockItem> SPICE_SHELF_ITEM = ITEMS.registerSimpleBlockItem("spice_shelf", SPICE_SHELF_BLOCK);
    public static final DeferredBlock<Block> CHOPPING_BOARD_BLOCK = BLOCKS.register("chopping_board", () -> new ParkProps.Act("chopping_board", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CHOPPING_BOARD_ITEM = ITEMS.registerSimpleBlockItem("chopping_board", CHOPPING_BOARD_BLOCK);
    public static final DeferredBlock<Block> BUFFET_COUNTER_BLOCK = BLOCKS.register("buffet_counter", () -> new ParkProps.Store("buffet_counter", decor(SoundType.WOOD), 3));
    public static final DeferredItem<BlockItem> BUFFET_COUNTER_ITEM = ITEMS.registerSimpleBlockItem("buffet_counter", BUFFET_COUNTER_BLOCK);
    public static final DeferredBlock<Block> COFFEE_MACHINE_BLOCK = BLOCKS.register("coffee_machine", () -> new ParkProps.Act("coffee_machine", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("coffee_machine", s))));
    public static final DeferredItem<BlockItem> COFFEE_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("coffee_machine", COFFEE_MACHINE_BLOCK);
    public static final DeferredBlock<Block> CAKE_CABINET_BLOCK = BLOCKS.register("cake_cabinet", () -> new ParkProps.Store("cake_cabinet", decor(SoundType.GLASS), 1));
    public static final DeferredItem<BlockItem> CAKE_CABINET_ITEM = ITEMS.registerSimpleBlockItem("cake_cabinet", CAKE_CABINET_BLOCK);
    public static final DeferredBlock<Block> BAR_STOOL_BLOCK = BLOCKS.register("bar_stool", () -> new ParkProps.Seat("bar_stool", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BAR_STOOL_ITEM = ITEMS.registerSimpleBlockItem("bar_stool", BAR_STOOL_BLOCK);
    public static final DeferredBlock<Block> BOOTH_DIVIDER_BLOCK = BLOCKS.register("booth_divider", () -> new ParkProps.Plain("booth_divider", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BOOTH_DIVIDER_ITEM = ITEMS.registerSimpleBlockItem("booth_divider", BOOTH_DIVIDER_BLOCK);
    public static final DeferredBlock<Block> HIGH_CHAIR_BLOCK = BLOCKS.register("high_chair", () -> new ParkProps.Seat("high_chair", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> HIGH_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("high_chair", HIGH_CHAIR_BLOCK);
    public static final DeferredBlock<Block> NAPKIN_DISPENSER_BLOCK = BLOCKS.register("napkin_dispenser", () -> new ParkProps.Plain("napkin_dispenser", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> NAPKIN_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("napkin_dispenser", NAPKIN_DISPENSER_BLOCK);
    public static final DeferredBlock<Block> RESERVED_SIGN_BLOCK = BLOCKS.register("reserved_sign", () -> new ParkProps.TextProp("reserved_sign", decor(SoundType.WOOD), 2, false));
    public static final DeferredItem<BlockItem> RESERVED_SIGN_ITEM = ITEMS.registerSimpleBlockItem("reserved_sign", RESERVED_SIGN_BLOCK);
    public static final DeferredBlock<Block> POSTCARD_WRITER_BLOCK = BLOCKS.register("postcard_writer", () -> new ParkProps.TextProp("postcard_writer", decor(SoundType.WOOD), 6, false));
    public static final DeferredItem<BlockItem> POSTCARD_WRITER_ITEM = ITEMS.registerSimpleBlockItem("postcard_writer", POSTCARD_WRITER_BLOCK);
    public static final DeferredBlock<Block> KEYRING_SPINNER_BLOCK = BLOCKS.register("keyring_spinner", () -> new ParkProps.Plain("keyring_spinner", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> KEYRING_SPINNER_ITEM = ITEMS.registerSimpleBlockItem("keyring_spinner", KEYRING_SPINNER_BLOCK);
    public static final DeferredBlock<Block> PHOTO_BOOTH_BLOCK = BLOCKS.register("photo_booth", () -> new ParkProps.Act("photo_booth", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("photo_booth", s))));
    public static final DeferredItem<BlockItem> PHOTO_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("photo_booth", PHOTO_BOOTH_BLOCK);
    public static final DeferredBlock<Block> BALLOON_STAND_BLOCK = BLOCKS.register("balloon_stand", () -> new ParkProps.Act("balloon_stand", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BALLOON_STAND_ITEM = ITEMS.registerSimpleBlockItem("balloon_stand", BALLOON_STAND_BLOCK);
    public static final DeferredBlock<Block> COIN_PRESS_BLOCK = BLOCKS.register("coin_press", () -> new ParkProps.Act("coin_press", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> COIN_PRESS_ITEM = ITEMS.registerSimpleBlockItem("coin_press", COIN_PRESS_BLOCK);
    public static final DeferredBlock<Block> SNOW_GLOBE_BLOCK = BLOCKS.register("snow_globe", () -> new ParkProps.Plain("snow_globe", decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> SNOW_GLOBE_ITEM = ITEMS.registerSimpleBlockItem("snow_globe", SNOW_GLOBE_BLOCK);
    public static final DeferredBlock<Block> FACE_PAINT_STATION_BLOCK = BLOCKS.register("face_paint_station", () -> new ParkProps.Act("face_paint_station", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> FACE_PAINT_STATION_ITEM = ITEMS.registerSimpleBlockItem("face_paint_station", FACE_PAINT_STATION_BLOCK);
    public static final DeferredBlock<Block> EYEWASH_STATION_BLOCK = BLOCKS.register("eyewash_station", () -> new ParkProps.Plain("eyewash_station", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> EYEWASH_STATION_ITEM = ITEMS.registerSimpleBlockItem("eyewash_station", EYEWASH_STATION_BLOCK);
    public static final DeferredBlock<Block> BLOOD_PRESSURE_MONITOR_BLOCK = BLOCKS.register("blood_pressure_monitor", () -> new ParkProps.Act("blood_pressure_monitor", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BLOOD_PRESSURE_MONITOR_ITEM = ITEMS.registerSimpleBlockItem("blood_pressure_monitor", BLOOD_PRESSURE_MONITOR_BLOCK);
    public static final DeferredBlock<Block> STRETCHER_BLOCK = BLOCKS.register("stretcher", () -> new ParkProps.Seat("stretcher", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> STRETCHER_ITEM = ITEMS.registerSimpleBlockItem("stretcher", STRETCHER_BLOCK);
    public static final DeferredBlock<Block> FIRE_ALARM_PULL_BLOCK = BLOCKS.register("fire_alarm_pull", () -> new ParkProps.Act("fire_alarm_pull", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("fire_alarm_pull", s))));
    public static final DeferredItem<BlockItem> FIRE_ALARM_PULL_ITEM = ITEMS.registerSimpleBlockItem("fire_alarm_pull", FIRE_ALARM_PULL_BLOCK);
    public static final DeferredBlock<Block> SPRINKLER_HEAD_BLOCK = BLOCKS.register("sprinkler_head", () -> new ParkProps.Plain("sprinkler_head", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SPRINKLER_HEAD_ITEM = ITEMS.registerSimpleBlockItem("sprinkler_head", SPRINKLER_HEAD_BLOCK);
    public static final DeferredBlock<Block> SAFETY_RAIL_BLOCK = BLOCKS.register("safety_rail", () -> new ParkProps.Plain("safety_rail", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SAFETY_RAIL_ITEM = ITEMS.registerSimpleBlockItem("safety_rail", SAFETY_RAIL_BLOCK);
    public static final DeferredBlock<Block> EVACUATION_MAP_BLOCK = BLOCKS.register("evacuation_map", () -> new ParkProps.TextProp("evacuation_map", decor(SoundType.METAL), 6, false));
    public static final DeferredItem<BlockItem> EVACUATION_MAP_ITEM = ITEMS.registerSimpleBlockItem("evacuation_map", EVACUATION_MAP_BLOCK);
    public static final DeferredBlock<Block> AIR_HOCKEY_BLOCK = BLOCKS.register("air_hockey", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.AIR_HOCKEY, decor(SoundType.METAL).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> AIR_HOCKEY_ITEM = ITEMS.registerSimpleBlockItem("air_hockey", AIR_HOCKEY_BLOCK);
    public static final DeferredBlock<Block> PINBALL_BLOCK = BLOCKS.register("pinball", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.PINBALL, decor(SoundType.METAL).lightLevel(s -> ParkProps.light("pinball", s)).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> PINBALL_ITEM = ITEMS.registerSimpleBlockItem("pinball", PINBALL_BLOCK);
    public static final DeferredBlock<Block> DANCE_MACHINE_BLOCK = BLOCKS.register("dance_machine", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.DANCE, decor(SoundType.METAL).lightLevel(s -> ParkProps.light("dance_machine", s)).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> DANCE_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("dance_machine", DANCE_MACHINE_BLOCK);
    public static final DeferredBlock<Block> RACING_CABINET_BLOCK = BLOCKS.register("racing_cabinet", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.RACING, decor(SoundType.METAL).lightLevel(s -> ParkProps.light("racing_cabinet", s)).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> RACING_CABINET_ITEM = ITEMS.registerSimpleBlockItem("racing_cabinet", RACING_CABINET_BLOCK);
    public static final DeferredBlock<Block> FOOSBALL_BLOCK = BLOCKS.register("foosball", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.FOOSBALL, decor(SoundType.METAL).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> FOOSBALL_ITEM = ITEMS.registerSimpleBlockItem("foosball", FOOSBALL_BLOCK);
    public static final DeferredBlock<Block> SKEE_BALL_BLOCK = BLOCKS.register("skee_ball", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.SKEE, decor(SoundType.METAL).lightLevel(s -> ParkProps.light("skee_ball", s)).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> SKEE_BALL_ITEM = ITEMS.registerSimpleBlockItem("skee_ball", SKEE_BALL_BLOCK);
    public static final DeferredBlock<Block> DARTS_BOARD_BLOCK = BLOCKS.register("darts_board", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.DARTS, decor(SoundType.METAL).lightLevel(s -> 6)));
    public static final DeferredItem<BlockItem> DARTS_BOARD_ITEM = ITEMS.registerSimpleBlockItem("darts_board", DARTS_BOARD_BLOCK);
    public static final DeferredBlock<Block> JUKEBOX_BLOCK = BLOCKS.register("jukebox", () -> new ParkProps.Act("jukebox", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("jukebox", s))));
    public static final DeferredItem<BlockItem> JUKEBOX_ITEM = ITEMS.registerSimpleBlockItem("jukebox", JUKEBOX_BLOCK);
    public static final DeferredBlock<Block> MINI_GOLF_HOLE_BLOCK = BLOCKS.register("mini_golf_hole", () -> new ParkProps.Plain("mini_golf_hole", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> MINI_GOLF_HOLE_ITEM = ITEMS.registerSimpleBlockItem("mini_golf_hole", MINI_GOLF_HOLE_BLOCK);
    public static final DeferredBlock<Block> PHOTO_OP_FRAME_BLOCK = BLOCKS.register("photo_op_frame", () -> new ParkProps.Plain("photo_op_frame", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PHOTO_OP_FRAME_ITEM = ITEMS.registerSimpleBlockItem("photo_op_frame", PHOTO_OP_FRAME_BLOCK);
    public static final DeferredBlock<Block> LOST_PROPERTY_BOX_BLOCK = BLOCKS.register("lost_property_box", () -> new ParkProps.Store("lost_property_box", decor(SoundType.WOOD), 3));
    public static final DeferredItem<BlockItem> LOST_PROPERTY_BOX_ITEM = ITEMS.registerSimpleBlockItem("lost_property_box", LOST_PROPERTY_BOX_BLOCK);
    public static final DeferredBlock<Block> CHARGING_STATION_BLOCK = BLOCKS.register("charging_station", () -> new ParkProps.Act("charging_station", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("charging_station", s))));
    public static final DeferredItem<BlockItem> CHARGING_STATION_ITEM = ITEMS.registerSimpleBlockItem("charging_station", CHARGING_STATION_BLOCK);
    public static final DeferredBlock<Block> YOU_ARE_HERE_PILLAR_BLOCK = BLOCKS.register("you_are_here_pillar", () -> new ParkProps.Plain("you_are_here_pillar", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> YOU_ARE_HERE_PILLAR_ITEM = ITEMS.registerSimpleBlockItem("you_are_here_pillar", YOU_ARE_HERE_PILLAR_BLOCK);
    public static final DeferredBlock<Block> PHOTO_SPOT_STAND_BLOCK = BLOCKS.register("photo_spot_stand", () -> new ParkProps.Plain("photo_spot_stand", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PHOTO_SPOT_STAND_ITEM = ITEMS.registerSimpleBlockItem("photo_spot_stand", PHOTO_SPOT_STAND_BLOCK);
    public static final DeferredBlock<Block> MEMORIAL_BENCH_BLOCK = BLOCKS.register("memorial_bench", () -> new ParkProps.TextProp("memorial_bench", decor(SoundType.WOOD), 2, true));
    public static final DeferredItem<BlockItem> MEMORIAL_BENCH_ITEM = ITEMS.registerSimpleBlockItem("memorial_bench", MEMORIAL_BENCH_BLOCK);
    public static final DeferredBlock<Block> MOP_BUCKET_BLOCK = BLOCKS.register("mop_bucket", () -> new ParkProps.Plain("mop_bucket", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> MOP_BUCKET_ITEM = ITEMS.registerSimpleBlockItem("mop_bucket", MOP_BUCKET_BLOCK);
    public static final DeferredBlock<Block> TRASH_COMPACTOR_BLOCK = BLOCKS.register("trash_compactor", () -> new ParkProps.Store("trash_compactor", decor(SoundType.METAL), 3));
    public static final DeferredItem<BlockItem> TRASH_COMPACTOR_ITEM = ITEMS.registerSimpleBlockItem("trash_compactor", TRASH_COMPACTOR_BLOCK);
    public static final DeferredBlock<Block> CANTEEN_TABLE_BLOCK = BLOCKS.register("canteen_table", () -> new ParkProps.Plain("canteen_table", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CANTEEN_TABLE_ITEM = ITEMS.registerSimpleBlockItem("canteen_table", CANTEEN_TABLE_BLOCK);
    public static final DeferredBlock<Block> UNIFORM_RACK_BLOCK = BLOCKS.register("uniform_rack", () -> new ParkProps.Store("uniform_rack", decor(SoundType.WOOL), 1));
    public static final DeferredItem<BlockItem> UNIFORM_RACK_ITEM = ITEMS.registerSimpleBlockItem("uniform_rack", UNIFORM_RACK_BLOCK);
    public static final DeferredBlock<Block> WALKIE_TALKIE_CHARGER_BLOCK = BLOCKS.register("walkie_talkie_charger", () -> new ParkProps.Act("walkie_talkie_charger", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WALKIE_TALKIE_CHARGER_ITEM = ITEMS.registerSimpleBlockItem("walkie_talkie_charger", WALKIE_TALKIE_CHARGER_BLOCK);
    public static final DeferredBlock<Block> TOOLBOX_BLOCK = BLOCKS.register("toolbox", () -> new ParkProps.Store("toolbox", decor(SoundType.METAL), 1));
    public static final DeferredItem<BlockItem> TOOLBOX_ITEM = ITEMS.registerSimpleBlockItem("toolbox", TOOLBOX_BLOCK);
    public static final DeferredBlock<Block> BREAK_ROOM_SOFA_BLOCK = BLOCKS.register("break_room_sofa", () -> new ParkProps.Seat("break_room_sofa", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> BREAK_ROOM_SOFA_ITEM = ITEMS.registerSimpleBlockItem("break_room_sofa", BREAK_ROOM_SOFA_BLOCK);
    public static final DeferredBlock<Block> SIGN_IN_TERMINAL_BLOCK = BLOCKS.register("sign_in_terminal", () -> new ParkProps.Act("sign_in_terminal", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("sign_in_terminal", s))));
    public static final DeferredItem<BlockItem> SIGN_IN_TERMINAL_ITEM = ITEMS.registerSimpleBlockItem("sign_in_terminal", SIGN_IN_TERMINAL_BLOCK);
    public static final DeferredBlock<Block> ANIMAL_ENCLOSURE_FENCE_BLOCK = BLOCKS.register("animal_enclosure_fence", () -> new ParkProps.Plain("animal_enclosure_fence", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ANIMAL_ENCLOSURE_FENCE_ITEM = ITEMS.registerSimpleBlockItem("animal_enclosure_fence", ANIMAL_ENCLOSURE_FENCE_BLOCK);
    public static final DeferredBlock<Block> FEEDING_TROUGH_BLOCK = BLOCKS.register("feeding_trough", () -> new ParkProps.Act("feeding_trough", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FEEDING_TROUGH_ITEM = ITEMS.registerSimpleBlockItem("feeding_trough", FEEDING_TROUGH_BLOCK);
    public static final DeferredBlock<Block> HABITAT_SIGN_BLOCK = BLOCKS.register("habitat_sign", () -> new ParkProps.TextProp("habitat_sign", decor(SoundType.METAL), 3, false));
    public static final DeferredItem<BlockItem> HABITAT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("habitat_sign", HABITAT_SIGN_BLOCK);
    public static final DeferredBlock<Block> VIEWING_WINDOW_BLOCK = BLOCKS.register("viewing_window", () -> new ParkProps.Plain("viewing_window", decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> VIEWING_WINDOW_ITEM = ITEMS.registerSimpleBlockItem("viewing_window", VIEWING_WINDOW_BLOCK);
    public static final DeferredBlock<Block> BIRD_AVIARY_BLOCK = BLOCKS.register("bird_aviary", () -> new ParkProps.Plain("bird_aviary", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BIRD_AVIARY_ITEM = ITEMS.registerSimpleBlockItem("bird_aviary", BIRD_AVIARY_BLOCK);
    public static final DeferredBlock<Block> HAY_BALE_BLOCK = BLOCKS.register("hay_bale", () -> new ParkProps.Seat("hay_bale", decor(SoundType.GRASS)));
    public static final DeferredItem<BlockItem> HAY_BALE_ITEM = ITEMS.registerSimpleBlockItem("hay_bale", HAY_BALE_BLOCK);
    public static final DeferredBlock<Block> MILK_CHURN_BLOCK = BLOCKS.register("milk_churn", () -> new ParkProps.Plain("milk_churn", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> MILK_CHURN_ITEM = ITEMS.registerSimpleBlockItem("milk_churn", MILK_CHURN_BLOCK);
    public static final DeferredBlock<Block> SCARECROW_POST_BLOCK = BLOCKS.register("scarecrow_post", () -> new ParkProps.Plain("scarecrow_post", decor(SoundType.GRASS)));
    public static final DeferredItem<BlockItem> SCARECROW_POST_ITEM = ITEMS.registerSimpleBlockItem("scarecrow_post", SCARECROW_POST_BLOCK);
    public static final DeferredBlock<Block> CHICKEN_COOP_BLOCK = BLOCKS.register("chicken_coop", () -> new ParkProps.Act("chicken_coop", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CHICKEN_COOP_ITEM = ITEMS.registerSimpleBlockItem("chicken_coop", CHICKEN_COOP_BLOCK);
    public static final DeferredBlock<Block> WATER_PUMP_BLOCK = BLOCKS.register("water_pump", () -> new ParkProps.Plain("water_pump", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> WATER_PUMP_ITEM = ITEMS.registerSimpleBlockItem("water_pump", WATER_PUMP_BLOCK);
    public static final DeferredBlock<Block> TRACTOR_PROP_BLOCK = BLOCKS.register("tractor_prop", () -> new ParkProps.Seat("tractor_prop", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> TRACTOR_PROP_ITEM = ITEMS.registerSimpleBlockItem("tractor_prop", TRACTOR_PROP_BLOCK);
    public static final DeferredBlock<Block> SEED_DISPENSER_BLOCK = BLOCKS.register("seed_dispenser", () -> new ParkProps.Act("seed_dispenser", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SEED_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("seed_dispenser", SEED_DISPENSER_BLOCK);
    public static final DeferredBlock<Block> FARM_GATE_BLOCK = BLOCKS.register("farm_gate", () -> new ParkProps.Plain("farm_gate", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> FARM_GATE_ITEM = ITEMS.registerSimpleBlockItem("farm_gate", FARM_GATE_BLOCK);
    public static final DeferredBlock<Block> TREASURE_CHEST_BLOCK = BLOCKS.register("treasure_chest", () -> new ParkProps.Store("treasure_chest", decor(SoundType.WOOD), 3));
    public static final DeferredItem<BlockItem> TREASURE_CHEST_ITEM = ITEMS.registerSimpleBlockItem("treasure_chest", TREASURE_CHEST_BLOCK);
    public static final DeferredBlock<Block> SHIP_WHEEL_BLOCK = BLOCKS.register("ship_wheel", () -> new ParkProps.Plain("ship_wheel", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SHIP_WHEEL_ITEM = ITEMS.registerSimpleBlockItem("ship_wheel", SHIP_WHEEL_BLOCK);
    public static final DeferredBlock<Block> CANNON_PROP_BLOCK = BLOCKS.register("cannon_prop", () -> new ParkProps.Plain("cannon_prop", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CANNON_PROP_ITEM = ITEMS.registerSimpleBlockItem("cannon_prop", CANNON_PROP_BLOCK);
    public static final DeferredBlock<Block> ROPE_NET_BLOCK = BLOCKS.register("rope_net", () -> new ParkProps.Plain("rope_net", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> ROPE_NET_ITEM = ITEMS.registerSimpleBlockItem("rope_net", ROPE_NET_BLOCK);
    public static final DeferredBlock<Block> PLANK_WALK_BLOCK = BLOCKS.register("plank_walk", () -> new ParkProps.Plain("plank_walk", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PLANK_WALK_ITEM = ITEMS.registerSimpleBlockItem("plank_walk", PLANK_WALK_BLOCK);
    public static final DeferredBlock<Block> PARROT_PERCH_BLOCK = BLOCKS.register("parrot_perch", () -> new ParkProps.Plain("parrot_perch", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PARROT_PERCH_ITEM = ITEMS.registerSimpleBlockItem("parrot_perch", PARROT_PERCH_BLOCK);
    public static final DeferredBlock<Block> SKULL_FLAG_BLOCK = BLOCKS.register("skull_flag", () -> new ParkProps.Plain("skull_flag", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> SKULL_FLAG_ITEM = ITEMS.registerSimpleBlockItem("skull_flag", SKULL_FLAG_BLOCK);
    public static final DeferredBlock<Block> MAP_TABLE_BLOCK = BLOCKS.register("map_table", () -> new ParkProps.Act("map_table", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("map_table", s))));
    public static final DeferredItem<BlockItem> MAP_TABLE_ITEM = ITEMS.registerSimpleBlockItem("map_table", MAP_TABLE_BLOCK);
    public static final DeferredBlock<Block> LANTERN_POST_BLOCK = BLOCKS.register("lantern_post", () -> new ParkProps.Plain("lantern_post", decor(SoundType.LANTERN).lightLevel(s -> ParkProps.light("lantern_post", s))));
    public static final DeferredItem<BlockItem> LANTERN_POST_ITEM = ITEMS.registerSimpleBlockItem("lantern_post", LANTERN_POST_BLOCK);
    public static final DeferredBlock<Block> CANOE_PROP_BLOCK = BLOCKS.register("canoe_prop", () -> new ParkProps.Seat("canoe_prop", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CANOE_PROP_ITEM = ITEMS.registerSimpleBlockItem("canoe_prop", CANOE_PROP_BLOCK);
    public static final DeferredBlock<Block> FISHING_DOCK_BLOCK = BLOCKS.register("fishing_dock", () -> new ParkProps.Plain("fishing_dock", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> FISHING_DOCK_ITEM = ITEMS.registerSimpleBlockItem("fishing_dock", FISHING_DOCK_BLOCK);
    public static final DeferredBlock<Block> CAMP_STOVE_BLOCK = BLOCKS.register("camp_stove", () -> new ParkProps.Plain("camp_stove", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("camp_stove", s))));
    public static final DeferredItem<BlockItem> CAMP_STOVE_ITEM = ITEMS.registerSimpleBlockItem("camp_stove", CAMP_STOVE_BLOCK);
    public static final DeferredBlock<Block> LOG_SEAT_BLOCK = BLOCKS.register("log_seat", () -> new ParkProps.Seat("log_seat", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> LOG_SEAT_ITEM = ITEMS.registerSimpleBlockItem("log_seat", LOG_SEAT_BLOCK);
    public static final DeferredBlock<Block> TRAIL_MARKER_BLOCK = BLOCKS.register("trail_marker", () -> new ParkProps.TextProp("trail_marker", decor(SoundType.WOOD), 2, false));
    public static final DeferredItem<BlockItem> TRAIL_MARKER_ITEM = ITEMS.registerSimpleBlockItem("trail_marker", TRAIL_MARKER_BLOCK);
    public static final DeferredBlock<Block> SKI_RACK_BLOCK = BLOCKS.register("ski_rack", () -> new ParkProps.Plain("ski_rack", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SKI_RACK_ITEM = ITEMS.registerSimpleBlockItem("ski_rack", SKI_RACK_BLOCK);
    public static final DeferredBlock<Block> SKI_LIFT_CHAIR_BLOCK = BLOCKS.register("ski_lift_chair", () -> new ParkProps.Seat("ski_lift_chair", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SKI_LIFT_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("ski_lift_chair", SKI_LIFT_CHAIR_BLOCK);
    public static final DeferredBlock<Block> ICE_RINK_BARRIER_BLOCK = BLOCKS.register("ice_rink_barrier", () -> new ParkProps.Plain("ice_rink_barrier", decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> ICE_RINK_BARRIER_ITEM = ITEMS.registerSimpleBlockItem("ice_rink_barrier", ICE_RINK_BARRIER_BLOCK);
    public static final DeferredBlock<Block> SKATE_HIRE_COUNTER_BLOCK = BLOCKS.register("skate_hire_counter", () -> new ParkProps.Act("skate_hire_counter", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SKATE_HIRE_COUNTER_ITEM = ITEMS.registerSimpleBlockItem("skate_hire_counter", SKATE_HIRE_COUNTER_BLOCK);
    public static final DeferredBlock<Block> TOBOGGAN_BLOCK = BLOCKS.register("toboggan", () -> new ParkProps.Seat("toboggan", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> TOBOGGAN_ITEM = ITEMS.registerSimpleBlockItem("toboggan", TOBOGGAN_BLOCK);
    public static final DeferredBlock<Block> FROZEN_FOUNTAIN_BLOCK = BLOCKS.register("frozen_fountain", () -> new ParkProps.Plain("frozen_fountain", decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> FROZEN_FOUNTAIN_ITEM = ITEMS.registerSimpleBlockItem("frozen_fountain", FROZEN_FOUNTAIN_BLOCK);
    public static final DeferredBlock<Block> SALOON_DOORS_BLOCK = BLOCKS.register("saloon_doors", () -> new ParkProps.Plain("saloon_doors", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SALOON_DOORS_ITEM = ITEMS.registerSimpleBlockItem("saloon_doors", SALOON_DOORS_BLOCK);
    public static final DeferredBlock<Block> HITCHING_POST_BLOCK = BLOCKS.register("hitching_post", () -> new ParkProps.Plain("hitching_post", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> HITCHING_POST_ITEM = ITEMS.registerSimpleBlockItem("hitching_post", HITCHING_POST_BLOCK);
    public static final DeferredBlock<Block> WATER_TROUGH_BLOCK = BLOCKS.register("water_trough", () -> new ParkProps.Plain("water_trough", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> WATER_TROUGH_ITEM = ITEMS.registerSimpleBlockItem("water_trough", WATER_TROUGH_BLOCK);
    public static final DeferredBlock<Block> WANTED_BOARD_BLOCK = BLOCKS.register("wanted_board", () -> new ParkProps.TextProp("wanted_board", decor(SoundType.WOOD), 3, false));
    public static final DeferredItem<BlockItem> WANTED_BOARD_ITEM = ITEMS.registerSimpleBlockItem("wanted_board", WANTED_BOARD_BLOCK);
    public static final DeferredBlock<Block> BANK_VAULT_BLOCK = BLOCKS.register("bank_vault", () -> new ParkProps.Store("bank_vault", decor(SoundType.METAL), 3));
    public static final DeferredItem<BlockItem> BANK_VAULT_ITEM = ITEMS.registerSimpleBlockItem("bank_vault", BANK_VAULT_BLOCK);
    public static final DeferredBlock<Block> WAGON_WHEEL_BLOCK = BLOCKS.register("wagon_wheel", () -> new ParkProps.Plain("wagon_wheel", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> WAGON_WHEEL_ITEM = ITEMS.registerSimpleBlockItem("wagon_wheel", WAGON_WHEEL_BLOCK);
    public static final DeferredBlock<Block> TUMBLEWEED_BLOCK = BLOCKS.register("tumbleweed", () -> new ParkProps.Plain("tumbleweed", decor(SoundType.GRASS)));
    public static final DeferredItem<BlockItem> TUMBLEWEED_ITEM = ITEMS.registerSimpleBlockItem("tumbleweed", TUMBLEWEED_BLOCK);
    public static final DeferredBlock<Block> BEACH_HUT_BLOCK = BLOCKS.register("beach_hut", () -> new ParkProps.Plain("beach_hut", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BEACH_HUT_ITEM = ITEMS.registerSimpleBlockItem("beach_hut", BEACH_HUT_BLOCK);
    public static final DeferredBlock<Block> SANDCASTLE_MOULD_BLOCK = BLOCKS.register("sandcastle_mould", () -> new ParkProps.Plain("sandcastle_mould", decor(SoundType.SAND)));
    public static final DeferredItem<BlockItem> SANDCASTLE_MOULD_ITEM = ITEMS.registerSimpleBlockItem("sandcastle_mould", SANDCASTLE_MOULD_BLOCK);
    public static final DeferredBlock<Block> DECK_UMBRELLA_STAND_BLOCK = BLOCKS.register("deck_umbrella_stand", () -> new ParkProps.Plain("deck_umbrella_stand", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> DECK_UMBRELLA_STAND_ITEM = ITEMS.registerSimpleBlockItem("deck_umbrella_stand", DECK_UMBRELLA_STAND_BLOCK);
    public static final DeferredBlock<Block> BOARDWALK_PLANK_BLOCK = BLOCKS.register("boardwalk_plank", () -> new ParkProps.Plain("boardwalk_plank", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BOARDWALK_PLANK_ITEM = ITEMS.registerSimpleBlockItem("boardwalk_plank", BOARDWALK_PLANK_BLOCK);
    public static final DeferredBlock<Block> LIFEBUOY_BLOCK = BLOCKS.register("lifebuoy", () -> new ParkProps.Plain("lifebuoy", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> LIFEBUOY_ITEM = ITEMS.registerSimpleBlockItem("lifebuoy", LIFEBUOY_BLOCK);
    public static final DeferredBlock<Block> ICE_CREAM_VAN_WINDOW_BLOCK = BLOCKS.register("ice_cream_van_window", () -> new ParkProps.Act("ice_cream_van_window", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("ice_cream_van_window", s))));
    public static final DeferredItem<BlockItem> ICE_CREAM_VAN_WINDOW_ITEM = ITEMS.registerSimpleBlockItem("ice_cream_van_window", ICE_CREAM_VAN_WINDOW_BLOCK);
    public static final DeferredBlock<Block> SEASIDE_TELESCOPE_BLOCK = BLOCKS.register("seaside_telescope", () -> new ParkProps.Act("seaside_telescope", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SEASIDE_TELESCOPE_ITEM = ITEMS.registerSimpleBlockItem("seaside_telescope", SEASIDE_TELESCOPE_BLOCK);
    public static final DeferredBlock<Block> SEA_WALL_STEPS_BLOCK = BLOCKS.register("sea_wall_steps", () -> new ParkProps.Plain("sea_wall_steps", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> SEA_WALL_STEPS_ITEM = ITEMS.registerSimpleBlockItem("sea_wall_steps", SEA_WALL_STEPS_BLOCK);
    public static final DeferredBlock<Block> HOT_CHOCOLATE_COUNTER_BLOCK = BLOCKS.register("hot_chocolate_counter", () -> new ParkProps.Act("hot_chocolate_counter", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> HOT_CHOCOLATE_COUNTER_ITEM = ITEMS.registerSimpleBlockItem("hot_chocolate_counter", HOT_CHOCOLATE_COUNTER_BLOCK);
    public static final DeferredBlock<Block> SHERIFF_DESK_BLOCK = BLOCKS.register("sheriff_desk", () -> new ParkProps.Act("sheriff_desk", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SHERIFF_DESK_ITEM = ITEMS.registerSimpleBlockItem("sheriff_desk", SHERIFF_DESK_BLOCK);
    public static final DeferredBlock<Block> CONTROL_CONSOLE_BLOCK = BLOCKS.register("control_console", () -> new ParkProps.Act("control_console", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("control_console", s))));
    public static final DeferredItem<BlockItem> CONTROL_CONSOLE_ITEM = ITEMS.registerSimpleBlockItem("control_console", CONTROL_CONSOLE_BLOCK);
    public static final DeferredBlock<Block> ROCKET_PROP_BLOCK = BLOCKS.register("rocket_prop", () -> new ParkProps.Plain("rocket_prop", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ROCKET_PROP_ITEM = ITEMS.registerSimpleBlockItem("rocket_prop", ROCKET_PROP_BLOCK);
    public static final DeferredBlock<Block> HOLOGRAM_GLOBE_BLOCK = BLOCKS.register("hologram_globe", () -> new ParkProps.Plain("hologram_globe", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("hologram_globe", s))));
    public static final DeferredItem<BlockItem> HOLOGRAM_GLOBE_ITEM = ITEMS.registerSimpleBlockItem("hologram_globe", HOLOGRAM_GLOBE_BLOCK);
    public static final DeferredBlock<Block> OXYGEN_TANK_BLOCK = BLOCKS.register("oxygen_tank", () -> new ParkProps.Plain("oxygen_tank", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> OXYGEN_TANK_ITEM = ITEMS.registerSimpleBlockItem("oxygen_tank", OXYGEN_TANK_BLOCK);
    public static final DeferredBlock<Block> PLANET_MOBILE_BLOCK = BLOCKS.register("planet_mobile", () -> new ParkProps.Plain("planet_mobile", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PLANET_MOBILE_ITEM = ITEMS.registerSimpleBlockItem("planet_mobile", PLANET_MOBILE_BLOCK);
    public static final DeferredBlock<Block> MOON_ROVER_PROP_BLOCK = BLOCKS.register("moon_rover_prop", () -> new ParkProps.Seat("moon_rover_prop", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> MOON_ROVER_PROP_ITEM = ITEMS.registerSimpleBlockItem("moon_rover_prop", MOON_ROVER_PROP_BLOCK);
    public static final DeferredBlock<Block> LAUNCH_COUNTDOWN_BOARD_BLOCK = BLOCKS.register("launch_countdown_board", () -> new ParkProps.TextProp("launch_countdown_board", decor(SoundType.METAL), 3, false));
    public static final DeferredItem<BlockItem> LAUNCH_COUNTDOWN_BOARD_ITEM = ITEMS.registerSimpleBlockItem("launch_countdown_board", LAUNCH_COUNTDOWN_BOARD_BLOCK);
    public static final DeferredBlock<Block> MOVIE_POSTER_FRAME_BLOCK = BLOCKS.register("movie_poster_frame", () -> new ParkProps.TextProp("movie_poster_frame", decor(SoundType.WOOL), 1, false));
    public static final DeferredItem<BlockItem> MOVIE_POSTER_FRAME_ITEM = ITEMS.registerSimpleBlockItem("movie_poster_frame", MOVIE_POSTER_FRAME_BLOCK);
    public static final DeferredBlock<Block> PROJECTOR_BLOCK = BLOCKS.register("projector", () -> new ParkProps.Act("projector", decor(SoundType.WOOL).lightLevel(s -> ParkProps.light("projector", s))));
    public static final DeferredItem<BlockItem> PROJECTOR_ITEM = ITEMS.registerSimpleBlockItem("projector", PROJECTOR_BLOCK);
    public static final DeferredBlock<Block> CINEMA_SEATS_BLOCK = BLOCKS.register("cinema_seats", () -> new ParkProps.Seat("cinema_seats", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> CINEMA_SEATS_ITEM = ITEMS.registerSimpleBlockItem("cinema_seats", CINEMA_SEATS_BLOCK);
    public static final DeferredBlock<Block> STAGE_CURTAIN_BLOCK = BLOCKS.register("stage_curtain", () -> new ParkProps.Plain("stage_curtain", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> STAGE_CURTAIN_ITEM = ITEMS.registerSimpleBlockItem("stage_curtain", STAGE_CURTAIN_BLOCK);
    public static final DeferredBlock<Block> SPOTLIGHT_BLOCK = BLOCKS.register("spotlight", () -> new ParkProps.Plain("spotlight", decor(SoundType.WOOL).lightLevel(s -> ParkProps.light("spotlight", s))));
    public static final DeferredItem<BlockItem> SPOTLIGHT_ITEM = ITEMS.registerSimpleBlockItem("spotlight", SPOTLIGHT_BLOCK);
    public static final DeferredBlock<Block> POPCORN_BUCKET_STAND_BLOCK = BLOCKS.register("popcorn_bucket_stand", () -> new ParkProps.Plain("popcorn_bucket_stand", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> POPCORN_BUCKET_STAND_ITEM = ITEMS.registerSimpleBlockItem("popcorn_bucket_stand", POPCORN_BUCKET_STAND_BLOCK);
    public static final DeferredBlock<Block> RED_CARPET_BLOCK = BLOCKS.register("red_carpet", () -> new ParkProps.Plain("red_carpet", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> RED_CARPET_ITEM = ITEMS.registerSimpleBlockItem("red_carpet", RED_CARPET_BLOCK);
    public static final DeferredBlock<Block> MASSAGE_BED_BLOCK = BLOCKS.register("massage_bed", () -> new ParkProps.Seat("massage_bed", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> MASSAGE_BED_ITEM = ITEMS.registerSimpleBlockItem("massage_bed", MASSAGE_BED_BLOCK);
    public static final DeferredBlock<Block> SAUNA_CABIN_BLOCK = BLOCKS.register("sauna_cabin", () -> new ParkProps.Act("sauna_cabin", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("sauna_cabin", s))));
    public static final DeferredItem<BlockItem> SAUNA_CABIN_ITEM = ITEMS.registerSimpleBlockItem("sauna_cabin", SAUNA_CABIN_BLOCK);
    public static final DeferredBlock<Block> FOOT_SPA_BLOCK = BLOCKS.register("foot_spa", () -> new ParkProps.Plain("foot_spa", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> FOOT_SPA_ITEM = ITEMS.registerSimpleBlockItem("foot_spa", FOOT_SPA_BLOCK);
    public static final DeferredBlock<Block> ZEN_ROCK_GARDEN_BLOCK = BLOCKS.register("zen_rock_garden", () -> new ParkProps.Plain("zen_rock_garden", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> ZEN_ROCK_GARDEN_ITEM = ITEMS.registerSimpleBlockItem("zen_rock_garden", ZEN_ROCK_GARDEN_BLOCK);
    public static final DeferredBlock<Block> CANDLE_SHELF_BLOCK = BLOCKS.register("candle_shelf", () -> new ParkProps.Plain("candle_shelf", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("candle_shelf", s))));
    public static final DeferredItem<BlockItem> CANDLE_SHELF_ITEM = ITEMS.registerSimpleBlockItem("candle_shelf", CANDLE_SHELF_BLOCK);
    public static final DeferredBlock<Block> RELAXATION_POD_BLOCK = BLOCKS.register("relaxation_pod", () -> new ParkProps.Seat("relaxation_pod", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("relaxation_pod", s))));
    public static final DeferredItem<BlockItem> RELAXATION_POD_ITEM = ITEMS.registerSimpleBlockItem("relaxation_pod", RELAXATION_POD_BLOCK);
    public static final DeferredBlock<Block> DUCK_POND_GAME_BLOCK = BLOCKS.register("duck_pond_game", () -> new ParkProps.Act("duck_pond_game", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DUCK_POND_GAME_ITEM = ITEMS.registerSimpleBlockItem("duck_pond_game", DUCK_POND_GAME_BLOCK);
    public static final DeferredBlock<Block> BOTTLE_TOSS_BLOCK = BLOCKS.register("bottle_toss", () -> new ParkProps.Plain("bottle_toss", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BOTTLE_TOSS_ITEM = ITEMS.registerSimpleBlockItem("bottle_toss", BOTTLE_TOSS_BLOCK);
    public static final DeferredBlock<Block> FORTUNE_TELLER_BOOTH_BLOCK = BLOCKS.register("fortune_teller_booth", () -> new ParkProps.Act("fortune_teller_booth", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("fortune_teller_booth", s))));
    public static final DeferredItem<BlockItem> FORTUNE_TELLER_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("fortune_teller_booth", FORTUNE_TELLER_BOOTH_BLOCK);
    public static final DeferredBlock<Block> HALL_OF_MIRRORS_BLOCK = BLOCKS.register("hall_of_mirrors", () -> new ParkProps.Plain("hall_of_mirrors", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> HALL_OF_MIRRORS_ITEM = ITEMS.registerSimpleBlockItem("hall_of_mirrors", HALL_OF_MIRRORS_BLOCK);
    public static final DeferredBlock<Block> COTTON_CANDY_CART_BLOCK = BLOCKS.register("cotton_candy_cart", () -> new ParkProps.Plain("cotton_candy_cart", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> COTTON_CANDY_CART_ITEM = ITEMS.registerSimpleBlockItem("cotton_candy_cart", COTTON_CANDY_CART_BLOCK);
    public static final DeferredBlock<Block> BALLOON_DART_BOARD_BLOCK = BLOCKS.register("balloon_dart_board", () -> new ParkProps.Plain("balloon_dart_board", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BALLOON_DART_BOARD_ITEM = ITEMS.registerSimpleBlockItem("balloon_dart_board", BALLOON_DART_BOARD_BLOCK);
    public static final DeferredBlock<Block> TEST_YOUR_AIM_CANNON_BLOCK = BLOCKS.register("test_your_aim_cannon", () -> new ParkProps.Plain("test_your_aim_cannon", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> TEST_YOUR_AIM_CANNON_ITEM = ITEMS.registerSimpleBlockItem("test_your_aim_cannon", TEST_YOUR_AIM_CANNON_BLOCK);
    public static final DeferredBlock<Block> TESLA_COIL_BLOCK = BLOCKS.register("tesla_coil", () -> new ParkProps.Act("tesla_coil", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("tesla_coil", s))));
    public static final DeferredItem<BlockItem> TESLA_COIL_ITEM = ITEMS.registerSimpleBlockItem("tesla_coil", TESLA_COIL_BLOCK);
    public static final DeferredBlock<Block> DINOSAUR_SKELETON_BLOCK = BLOCKS.register("dinosaur_skeleton", () -> new ParkProps.Plain("dinosaur_skeleton", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> DINOSAUR_SKELETON_ITEM = ITEMS.registerSimpleBlockItem("dinosaur_skeleton", DINOSAUR_SKELETON_BLOCK);
    public static final DeferredBlock<Block> PLANETARIUM_DOME_BLOCK = BLOCKS.register("planetarium_dome", () -> new ParkProps.Plain("planetarium_dome", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("planetarium_dome", s))));
    public static final DeferredItem<BlockItem> PLANETARIUM_DOME_ITEM = ITEMS.registerSimpleBlockItem("planetarium_dome", PLANETARIUM_DOME_BLOCK);
    public static final DeferredBlock<Block> MAGNET_TABLE_BLOCK = BLOCKS.register("magnet_table", () -> new ParkProps.Act("magnet_table", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("magnet_table", s))));
    public static final DeferredItem<BlockItem> MAGNET_TABLE_ITEM = ITEMS.registerSimpleBlockItem("magnet_table", MAGNET_TABLE_BLOCK);
    public static final DeferredBlock<Block> PERISCOPE_BLOCK = BLOCKS.register("periscope", () -> new ParkProps.Plain("periscope", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PERISCOPE_ITEM = ITEMS.registerSimpleBlockItem("periscope", PERISCOPE_BLOCK);
    public static final DeferredBlock<Block> EXHIBIT_PLINTH_BLOCK = BLOCKS.register("exhibit_plinth", () -> new ParkProps.Store("exhibit_plinth", decor(SoundType.METAL), 1));
    public static final DeferredItem<BlockItem> EXHIBIT_PLINTH_ITEM = ITEMS.registerSimpleBlockItem("exhibit_plinth", EXHIBIT_PLINTH_BLOCK);
    public static final DeferredBlock<Block> WEATHER_STATION_BLOCK = BLOCKS.register("weather_station", () -> new ParkProps.Act("weather_station", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WEATHER_STATION_ITEM = ITEMS.registerSimpleBlockItem("weather_station", WEATHER_STATION_BLOCK);
    public static final DeferredBlock<Block> FOSSIL_DIG_PIT_BLOCK = BLOCKS.register("fossil_dig_pit", () -> new ParkProps.Plain("fossil_dig_pit", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FOSSIL_DIG_PIT_ITEM = ITEMS.registerSimpleBlockItem("fossil_dig_pit", FOSSIL_DIG_PIT_BLOCK);
    public static final DeferredBlock<Block> HEIGHT_MEASURE_POST_BLOCK = BLOCKS.register("height_measure_post", () -> new ParkProps.Act("height_measure_post", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> HEIGHT_MEASURE_POST_ITEM = ITEMS.registerSimpleBlockItem("height_measure_post", HEIGHT_MEASURE_POST_BLOCK);
    public static final DeferredBlock<Block> KIDDIE_RIDE_BASE_BLOCK = BLOCKS.register("kiddie_ride_base", () -> new ParkProps.Seat("kiddie_ride_base", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> KIDDIE_RIDE_BASE_ITEM = ITEMS.registerSimpleBlockItem("kiddie_ride_base", KIDDIE_RIDE_BASE_BLOCK);
    public static final DeferredBlock<Block> BABY_CARE_ROOM_DOOR_BLOCK = BLOCKS.register("baby_care_room_door", () -> new ParkProps.Plain("baby_care_room_door", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> BABY_CARE_ROOM_DOOR_ITEM = ITEMS.registerSimpleBlockItem("baby_care_room_door", BABY_CARE_ROOM_DOOR_BLOCK);
    public static final DeferredBlock<Block> PLAY_MAZE_BLOCK = BLOCKS.register("play_maze", () -> new ParkProps.Plain("play_maze", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> PLAY_MAZE_ITEM = ITEMS.registerSimpleBlockItem("play_maze", PLAY_MAZE_BLOCK);
    public static final DeferredBlock<Block> KIDS_TICKET_WINDOW_BLOCK = BLOCKS.register("kids_ticket_window", () -> new ParkProps.Act("kids_ticket_window", decor(SoundType.WOOL).lightLevel(s -> ParkProps.light("kids_ticket_window", s))));
    public static final DeferredItem<BlockItem> KIDS_TICKET_WINDOW_ITEM = ITEMS.registerSimpleBlockItem("kids_ticket_window", KIDS_TICKET_WINDOW_BLOCK);
    public static final DeferredBlock<Block> STORY_CORNER_BLOCK = BLOCKS.register("story_corner", () -> new ParkProps.Seat("story_corner", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> STORY_CORNER_ITEM = ITEMS.registerSimpleBlockItem("story_corner", STORY_CORNER_BLOCK);
    public static final DeferredBlock<Block> MINI_TRAIN_STATION_BLOCK = BLOCKS.register("mini_train_station", () -> new ParkProps.Plain("mini_train_station", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> MINI_TRAIN_STATION_ITEM = ITEMS.registerSimpleBlockItem("mini_train_station", MINI_TRAIN_STATION_BLOCK);
    public static final DeferredBlock<Block> BALLOON_ARCH_BLOCK = BLOCKS.register("balloon_arch", () -> new ParkProps.Plain("balloon_arch", decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> BALLOON_ARCH_ITEM = ITEMS.registerSimpleBlockItem("balloon_arch", BALLOON_ARCH_BLOCK);
    public static final DeferredBlock<Block> RIDE_PHOTO_KIOSK_BLOCK = BLOCKS.register("ride_photo_kiosk", () -> new ParkProps.Act("ride_photo_kiosk", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("ride_photo_kiosk", s))));
    public static final DeferredItem<BlockItem> RIDE_PHOTO_KIOSK_ITEM = ITEMS.registerSimpleBlockItem("ride_photo_kiosk", RIDE_PHOTO_KIOSK_BLOCK);
    public static final DeferredBlock<Block> CARICATURE_STAND_BLOCK = BLOCKS.register("caricature_stand", () -> new ParkProps.Act("caricature_stand", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CARICATURE_STAND_ITEM = ITEMS.registerSimpleBlockItem("caricature_stand", CARICATURE_STAND_BLOCK);
    public static final DeferredBlock<Block> SOUVENIR_CUP_STAND_BLOCK = BLOCKS.register("souvenir_cup_stand", () -> new ParkProps.Plain("souvenir_cup_stand", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SOUVENIR_CUP_STAND_ITEM = ITEMS.registerSimpleBlockItem("souvenir_cup_stand", SOUVENIR_CUP_STAND_BLOCK);
    public static final DeferredBlock<Block> NAME_BADGE_PRINTER_BLOCK = BLOCKS.register("name_badge_printer", () -> new ParkProps.Act("name_badge_printer", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> NAME_BADGE_PRINTER_ITEM = ITEMS.registerSimpleBlockItem("name_badge_printer", NAME_BADGE_PRINTER_BLOCK);
    public static final DeferredBlock<Block> SOUVENIR_MUG_RACK_BLOCK = BLOCKS.register("souvenir_mug_rack", () -> new ParkProps.Plain("souvenir_mug_rack", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SOUVENIR_MUG_RACK_ITEM = ITEMS.registerSimpleBlockItem("souvenir_mug_rack", SOUVENIR_MUG_RACK_BLOCK);
    public static final DeferredBlock<Block> CHARACTER_PLUSH_BIN_BLOCK = BLOCKS.register("character_plush_bin", () -> new ParkProps.Plain("character_plush_bin", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CHARACTER_PLUSH_BIN_ITEM = ITEMS.registerSimpleBlockItem("character_plush_bin", CHARACTER_PLUSH_BIN_BLOCK);
    public static final DeferredBlock<Block> ROCKWORK_PANEL_BLOCK = BLOCKS.register("rockwork_panel", () -> new ParkProps.Plain("rockwork_panel", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> ROCKWORK_PANEL_ITEM = ITEMS.registerSimpleBlockItem("rockwork_panel", ROCKWORK_PANEL_BLOCK);
    public static final DeferredBlock<Block> THEMED_FACADE_BLOCK = BLOCKS.register("themed_facade", () -> new ParkProps.Plain("themed_facade", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> THEMED_FACADE_ITEM = ITEMS.registerSimpleBlockItem("themed_facade", THEMED_FACADE_BLOCK);
    public static final DeferredBlock<Block> GIANT_STATUE_BASE_BLOCK = BLOCKS.register("giant_statue_base", () -> new ParkProps.Plain("giant_statue_base", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> GIANT_STATUE_BASE_ITEM = ITEMS.registerSimpleBlockItem("giant_statue_base", GIANT_STATUE_BASE_BLOCK);
    public static final DeferredBlock<Block> WATERFALL_PROP_BLOCK = BLOCKS.register("waterfall_prop", () -> new ParkProps.Plain("waterfall_prop", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> WATERFALL_PROP_ITEM = ITEMS.registerSimpleBlockItem("waterfall_prop", WATERFALL_PROP_BLOCK);
    public static final DeferredBlock<Block> JUNGLE_FOLIAGE_BLOCK = BLOCKS.register("jungle_foliage", () -> new ParkProps.Plain("jungle_foliage", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> JUNGLE_FOLIAGE_ITEM = ITEMS.registerSimpleBlockItem("jungle_foliage", JUNGLE_FOLIAGE_BLOCK);
    public static final DeferredBlock<Block> CASTLE_WALL_BLOCK = BLOCKS.register("castle_wall", () -> new ParkProps.Plain("castle_wall", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> CASTLE_WALL_ITEM = ITEMS.registerSimpleBlockItem("castle_wall", CASTLE_WALL_BLOCK);
    public static final DeferredBlock<Block> WESTERN_FALSE_FRONT_BLOCK = BLOCKS.register("western_false_front", () -> new ParkProps.Plain("western_false_front", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> WESTERN_FALSE_FRONT_ITEM = ITEMS.registerSimpleBlockItem("western_false_front", WESTERN_FALSE_FRONT_BLOCK);
    public static final DeferredBlock<Block> SPACE_PANEL_BLOCK = BLOCKS.register("space_panel", () -> new ParkProps.Plain("space_panel", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> SPACE_PANEL_ITEM = ITEMS.registerSimpleBlockItem("space_panel", SPACE_PANEL_BLOCK);
    public static final DeferredBlock<Block> STEAM_PIPE_PROP_BLOCK = BLOCKS.register("steam_pipe_prop", () -> new ParkProps.Plain("steam_pipe_prop", decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> STEAM_PIPE_PROP_ITEM = ITEMS.registerSimpleBlockItem("steam_pipe_prop", STEAM_PIPE_PROP_BLOCK);
    public static final DeferredBlock<Block> PARK_NAME_SIGN_BLOCK = BLOCKS.register("park_name_sign", () -> new ParkProps.TextProp("park_name_sign", decor(SoundType.METAL), 2, false));
    public static final DeferredItem<BlockItem> PARK_NAME_SIGN_ITEM = ITEMS.registerSimpleBlockItem("park_name_sign", PARK_NAME_SIGN_BLOCK);
    public static final DeferredBlock<Block> TICKET_SCANNER_POST_BLOCK = BLOCKS.register("ticket_scanner_post", () -> new ParkProps.Act("ticket_scanner_post", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("ticket_scanner_post", s))));
    public static final DeferredItem<BlockItem> TICKET_SCANNER_POST_ITEM = ITEMS.registerSimpleBlockItem("ticket_scanner_post", TICKET_SCANNER_POST_BLOCK);
    public static final DeferredBlock<Block> BAG_CHECK_TABLE_BLOCK = BLOCKS.register("bag_check_table", () -> new ParkProps.Plain("bag_check_table", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BAG_CHECK_TABLE_ITEM = ITEMS.registerSimpleBlockItem("bag_check_table", BAG_CHECK_TABLE_BLOCK);
    public static final DeferredBlock<Block> HAND_STAMP_STATION_BLOCK = BLOCKS.register("hand_stamp_station", () -> new ParkProps.Plain("hand_stamp_station", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> HAND_STAMP_STATION_ITEM = ITEMS.registerSimpleBlockItem("hand_stamp_station", HAND_STAMP_STATION_BLOCK);
    public static final DeferredBlock<Block> WRISTBAND_DISPENSER_BLOCK = BLOCKS.register("wristband_dispenser", () -> new ParkProps.Act("wristband_dispenser", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WRISTBAND_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("wristband_dispenser", WRISTBAND_DISPENSER_BLOCK);
    public static final DeferredBlock<Block> ANNUAL_PASS_KIOSK_BLOCK = BLOCKS.register("annual_pass_kiosk", () -> new ParkProps.Act("annual_pass_kiosk", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("annual_pass_kiosk", s))));
    public static final DeferredItem<BlockItem> ANNUAL_PASS_KIOSK_ITEM = ITEMS.registerSimpleBlockItem("annual_pass_kiosk", ANNUAL_PASS_KIOSK_BLOCK);
    public static final DeferredBlock<Block> WELCOME_MAT_BLOCK = BLOCKS.register("welcome_mat", () -> new ParkProps.Plain("welcome_mat", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WELCOME_MAT_ITEM = ITEMS.registerSimpleBlockItem("welcome_mat", WELCOME_MAT_BLOCK);
    public static final DeferredBlock<Block> QUEUE_LINE_BARRIER_BLOCK = BLOCKS.register("queue_line_barrier", () -> new ParkProps.Plain("queue_line_barrier", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> QUEUE_LINE_BARRIER_ITEM = ITEMS.registerSimpleBlockItem("queue_line_barrier", QUEUE_LINE_BARRIER_BLOCK);
    public static final DeferredBlock<Block> QUEUE_PAUSE_SIGN_BLOCK = BLOCKS.register("queue_pause_sign", () -> new ParkProps.Act("queue_pause_sign", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("queue_pause_sign", s))));
    public static final DeferredItem<BlockItem> QUEUE_PAUSE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("queue_pause_sign", QUEUE_PAUSE_SIGN_BLOCK);
    public static final DeferredBlock<Block> QUEUE_TV_SCREEN_BLOCK = BLOCKS.register("queue_tv_screen", () -> new ParkProps.Plain("queue_tv_screen", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("queue_tv_screen", s))));
    public static final DeferredItem<BlockItem> QUEUE_TV_SCREEN_ITEM = ITEMS.registerSimpleBlockItem("queue_tv_screen", QUEUE_TV_SCREEN_BLOCK);
    public static final DeferredBlock<Block> SHADE_CANOPY_BLOCK = BLOCKS.register("shade_canopy", () -> new ParkProps.Plain("shade_canopy", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SHADE_CANOPY_ITEM = ITEMS.registerSimpleBlockItem("shade_canopy", SHADE_CANOPY_BLOCK);
    public static final DeferredBlock<Block> MISTING_FAN_BLOCK = BLOCKS.register("misting_fan", () -> new ParkProps.Plain("misting_fan", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> MISTING_FAN_ITEM = ITEMS.registerSimpleBlockItem("misting_fan", MISTING_FAN_BLOCK);
    public static final DeferredBlock<Block> MONORAIL_STATION_PLATFORM_BLOCK = BLOCKS.register("monorail_station_platform", () -> new ParkProps.Act("monorail_station_platform", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("monorail_station_platform", s))));
    public static final DeferredItem<BlockItem> MONORAIL_STATION_PLATFORM_ITEM = ITEMS.registerSimpleBlockItem("monorail_station_platform", MONORAIL_STATION_PLATFORM_BLOCK);
    public static final DeferredBlock<Block> SHUTTLE_BUS_STOP_BLOCK = BLOCKS.register("shuttle_bus_stop", () -> new ParkProps.Act("shuttle_bus_stop", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SHUTTLE_BUS_STOP_ITEM = ITEMS.registerSimpleBlockItem("shuttle_bus_stop", SHUTTLE_BUS_STOP_BLOCK);
    public static final DeferredBlock<Block> PARK_TRAIN_STOP_BLOCK = BLOCKS.register("park_train_stop", () -> new ParkProps.Plain("park_train_stop", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PARK_TRAIN_STOP_ITEM = ITEMS.registerSimpleBlockItem("park_train_stop", PARK_TRAIN_STOP_BLOCK);
    public static final DeferredBlock<Block> BUS_SHELTER_BLOCK = BLOCKS.register("bus_shelter", () -> new ParkProps.Seat("bus_shelter", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BUS_SHELTER_ITEM = ITEMS.registerSimpleBlockItem("bus_shelter", BUS_SHELTER_BLOCK);
    public static final DeferredBlock<Block> TICKET_PAY_MACHINE_BLOCK = BLOCKS.register("ticket_pay_machine", () -> new ParkProps.Act("ticket_pay_machine", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("ticket_pay_machine", s))));
    public static final DeferredItem<BlockItem> TICKET_PAY_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("ticket_pay_machine", TICKET_PAY_MACHINE_BLOCK);
    public static final DeferredBlock<Block> BICYCLE_RACK_BLOCK = BLOCKS.register("bicycle_rack", () -> new ParkProps.Plain("bicycle_rack", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BICYCLE_RACK_ITEM = ITEMS.registerSimpleBlockItem("bicycle_rack", BICYCLE_RACK_BLOCK);
    public static final DeferredBlock<Block> TAXI_RANK_SIGN_BLOCK = BLOCKS.register("taxi_rank_sign", () -> new ParkProps.Plain("taxi_rank_sign", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TAXI_RANK_SIGN_ITEM = ITEMS.registerSimpleBlockItem("taxi_rank_sign", TAXI_RANK_SIGN_BLOCK);
    public static final DeferredBlock<Block> PARADE_FLOAT_BASE_BLOCK = BLOCKS.register("parade_float_base", () -> new ParkProps.Seat("parade_float_base", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PARADE_FLOAT_BASE_ITEM = ITEMS.registerSimpleBlockItem("parade_float_base", PARADE_FLOAT_BASE_BLOCK);
    public static final DeferredBlock<Block> STAGE_BLOCK = BLOCKS.register("stage", () -> new ParkProps.Act("stage", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("stage", s))));
    public static final DeferredItem<BlockItem> STAGE_ITEM = ITEMS.registerSimpleBlockItem("stage", STAGE_BLOCK);
    public static final DeferredBlock<Block> STAGE_LIGHTS_BLOCK = BLOCKS.register("stage_lights", () -> new ParkProps.Plain("stage_lights", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("stage_lights", s))));
    public static final DeferredItem<BlockItem> STAGE_LIGHTS_ITEM = ITEMS.registerSimpleBlockItem("stage_lights", STAGE_LIGHTS_BLOCK);
    public static final DeferredBlock<Block> SPEAKER_TOWER_BLOCK = BLOCKS.register("speaker_tower", () -> new ParkProps.Plain("speaker_tower", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SPEAKER_TOWER_ITEM = ITEMS.registerSimpleBlockItem("speaker_tower", SPEAKER_TOWER_BLOCK);
    public static final DeferredBlock<Block> MASCOT_MEET_SPOT_BLOCK = BLOCKS.register("mascot_meet_spot", () -> new ParkProps.Act("mascot_meet_spot", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> MASCOT_MEET_SPOT_ITEM = ITEMS.registerSimpleBlockItem("mascot_meet_spot", MASCOT_MEET_SPOT_BLOCK);
    public static final DeferredBlock<Block> STREET_PERFORMER_PITCH_BLOCK = BLOCKS.register("street_performer_pitch", () -> new ParkProps.Plain("street_performer_pitch", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> STREET_PERFORMER_PITCH_ITEM = ITEMS.registerSimpleBlockItem("street_performer_pitch", STREET_PERFORMER_PITCH_BLOCK);
    public static final DeferredBlock<Block> CONFETTI_CANNON_BLOCK = BLOCKS.register("confetti_cannon", () -> new ParkProps.Act("confetti_cannon", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> CONFETTI_CANNON_ITEM = ITEMS.registerSimpleBlockItem("confetti_cannon", CONFETTI_CANNON_BLOCK);
    public static final DeferredBlock<Block> FIREWORKS_LAUNCHER_BLOCK = BLOCKS.register("fireworks_launcher", () -> new ParkProps.Act("fireworks_launcher", decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> FIREWORKS_LAUNCHER_ITEM = ITEMS.registerSimpleBlockItem("fireworks_launcher", FIREWORKS_LAUNCHER_BLOCK);
    public static final DeferredBlock<Block> ROOM_KEY_CARD_BLOCK = BLOCKS.register("room_key_card", () -> new ParkProps.Act("room_key_card", decor(SoundType.WOOD).lightLevel(s -> ParkProps.light("room_key_card", s))));
    public static final DeferredItem<BlockItem> ROOM_KEY_CARD_ITEM = ITEMS.registerSimpleBlockItem("room_key_card", ROOM_KEY_CARD_BLOCK);
    public static final DeferredBlock<Block> SECURITY_BOOTH_BLOCK = BLOCKS.register("security_booth", () -> new ParkProps.Act("security_booth", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("security_booth", s))));
    public static final DeferredItem<BlockItem> SECURITY_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("security_booth", SECURITY_BOOTH_BLOCK);
    public static final DeferredBlock<Block> CCTV_CAMERA_BLOCK = BLOCKS.register("cctv_camera", () -> new ParkProps.Act("cctv_camera", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CCTV_CAMERA_ITEM = ITEMS.registerSimpleBlockItem("cctv_camera", CCTV_CAMERA_BLOCK);
    public static final DeferredBlock<Block> CONTROL_ROOM_DESK_BLOCK = BLOCKS.register("control_room_desk", () -> new ParkProps.Act("control_room_desk", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("control_room_desk", s))));
    public static final DeferredItem<BlockItem> CONTROL_ROOM_DESK_ITEM = ITEMS.registerSimpleBlockItem("control_room_desk", CONTROL_ROOM_DESK_BLOCK);
    public static final DeferredBlock<Block> RADIO_BASE_BLOCK = BLOCKS.register("radio_base", () -> new ParkProps.Act("radio_base", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> RADIO_BASE_ITEM = ITEMS.registerSimpleBlockItem("radio_base", RADIO_BASE_BLOCK);
    public static final DeferredBlock<Block> EMERGENCY_STOP_BUTTON_BLOCK = BLOCKS.register("emergency_stop_button", () -> new ParkProps.Plain("emergency_stop_button", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("emergency_stop_button", s))));
    public static final DeferredItem<BlockItem> EMERGENCY_STOP_BUTTON_ITEM = ITEMS.registerSimpleBlockItem("emergency_stop_button", EMERGENCY_STOP_BUTTON_BLOCK);
    public static final DeferredBlock<Block> PATROL_SIGN_BLOCK = BLOCKS.register("patrol_sign", () -> new ParkProps.Plain("patrol_sign", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PATROL_SIGN_ITEM = ITEMS.registerSimpleBlockItem("patrol_sign", PATROL_SIGN_BLOCK);
    public static final DeferredBlock<Block> POWER_GENERATOR_BLOCK = BLOCKS.register("power_generator", () -> new ParkProps.Act("power_generator", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("power_generator", s))));
    public static final DeferredItem<BlockItem> POWER_GENERATOR_ITEM = ITEMS.registerSimpleBlockItem("power_generator", POWER_GENERATOR_BLOCK);
    public static final DeferredBlock<Block> WATER_TANK_BLOCK = BLOCKS.register("water_tank", () -> new ParkProps.Plain("water_tank", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WATER_TANK_ITEM = ITEMS.registerSimpleBlockItem("water_tank", WATER_TANK_BLOCK);
    public static final DeferredBlock<Block> PIPE_JUNCTION_BLOCK = BLOCKS.register("pipe_junction", () -> new ParkProps.Plain("pipe_junction", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PIPE_JUNCTION_ITEM = ITEMS.registerSimpleBlockItem("pipe_junction", PIPE_JUNCTION_BLOCK);
    public static final DeferredBlock<Block> ELECTRIC_CABINET_BLOCK = BLOCKS.register("electric_cabinet", () -> new ParkProps.Act("electric_cabinet", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("electric_cabinet", s))));
    public static final DeferredItem<BlockItem> ELECTRIC_CABINET_ITEM = ITEMS.registerSimpleBlockItem("electric_cabinet", ELECTRIC_CABINET_BLOCK);
    public static final DeferredBlock<Block> CABLE_TRENCH_COVER_BLOCK = BLOCKS.register("cable_trench_cover", () -> new ParkProps.Plain("cable_trench_cover", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CABLE_TRENCH_COVER_ITEM = ITEMS.registerSimpleBlockItem("cable_trench_cover", CABLE_TRENCH_COVER_BLOCK);
    public static final DeferredBlock<Block> SPEAKER_CONTROL_BOX_BLOCK = BLOCKS.register("speaker_control_box", () -> new ParkProps.Act("speaker_control_box", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SPEAKER_CONTROL_BOX_ITEM = ITEMS.registerSimpleBlockItem("speaker_control_box", SPEAKER_CONTROL_BOX_BLOCK);
    public static final DeferredBlock<Block> FUSE_BOX_BLOCK = BLOCKS.register("fuse_box", () -> new ParkProps.Plain("fuse_box", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FUSE_BOX_ITEM = ITEMS.registerSimpleBlockItem("fuse_box", FUSE_BOX_BLOCK);
    public static final DeferredBlock<Block> UTILITY_SHED_BLOCK = BLOCKS.register("utility_shed", () -> new ParkProps.Plain("utility_shed", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> UTILITY_SHED_ITEM = ITEMS.registerSimpleBlockItem("utility_shed", UTILITY_SHED_BLOCK);
    public static final DeferredBlock<Block> INSPECTION_PIT_BLOCK = BLOCKS.register("inspection_pit", () -> new ParkProps.Plain("inspection_pit", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> INSPECTION_PIT_ITEM = ITEMS.registerSimpleBlockItem("inspection_pit", INSPECTION_PIT_BLOCK);
    public static final DeferredBlock<Block> TOOL_WALL_BLOCK = BLOCKS.register("tool_wall", () -> new ParkProps.Plain("tool_wall", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TOOL_WALL_ITEM = ITEMS.registerSimpleBlockItem("tool_wall", TOOL_WALL_BLOCK);
    public static final DeferredBlock<Block> APP_KIOSK_BLOCK = BLOCKS.register("app_kiosk", () -> new ParkProps.Act("app_kiosk", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("app_kiosk", s))));
    public static final DeferredItem<BlockItem> APP_KIOSK_ITEM = ITEMS.registerSimpleBlockItem("app_kiosk", APP_KIOSK_BLOCK);
    public static final DeferredBlock<Block> DIGITAL_MAP_BLOCK = BLOCKS.register("digital_map", () -> new ParkProps.Act("digital_map", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("digital_map", s))));
    public static final DeferredItem<BlockItem> DIGITAL_MAP_ITEM = ITEMS.registerSimpleBlockItem("digital_map", DIGITAL_MAP_BLOCK);
    public static final DeferredBlock<Block> RIDE_STATUS_BOARD_BLOCK = BLOCKS.register("ride_status_board", () -> new ParkProps.TextProp("ride_status_board", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("ride_status_board", s)), 4, false));
    public static final DeferredItem<BlockItem> RIDE_STATUS_BOARD_ITEM = ITEMS.registerSimpleBlockItem("ride_status_board", RIDE_STATUS_BOARD_BLOCK);
    public static final DeferredBlock<Block> LOUDSPEAKER_POLE_BLOCK = BLOCKS.register("loudspeaker_pole", () -> new ParkProps.Plain("loudspeaker_pole", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> LOUDSPEAKER_POLE_ITEM = ITEMS.registerSimpleBlockItem("loudspeaker_pole", LOUDSPEAKER_POLE_BLOCK);
    public static final DeferredBlock<Block> QR_SIGN_BLOCK = BLOCKS.register("qr_sign", () -> new ParkProps.Act("qr_sign", decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> QR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("qr_sign", QR_SIGN_BLOCK);
    public static final DeferredBlock<Block> INTERACTIVE_GLOBE_BLOCK = BLOCKS.register("interactive_globe", () -> new ParkProps.Act("interactive_globe", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("interactive_globe", s))));
    public static final DeferredItem<BlockItem> INTERACTIVE_GLOBE_ITEM = ITEMS.registerSimpleBlockItem("interactive_globe", INTERACTIVE_GLOBE_BLOCK);
    public static final DeferredBlock<Block> WEATHER_DISPLAY_BLOCK = BLOCKS.register("weather_display", () -> new ParkProps.Plain("weather_display", decor(SoundType.METAL).lightLevel(s -> ParkProps.light("weather_display", s))));
    public static final DeferredItem<BlockItem> WEATHER_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("weather_display", WEATHER_DISPLAY_BLOCK);
    public static final DeferredBlock<Block> AQUARIUM_TANK_BLOCK = BLOCKS.register("aquarium_tank", () -> new ParkConnect.Tile(ParkConnect.AQUARIUM, decor(SoundType.GLASS)));
    public static final DeferredItem<BlockItem> AQUARIUM_TANK_ITEM = ITEMS.registerSimpleBlockItem("aquarium_tank", AQUARIUM_TANK_BLOCK);
    public static final DeferredBlock<Block> PETTING_PEN_BLOCK = BLOCKS.register("petting_pen", () -> new ParkConnect.Tile(ParkConnect.PEN, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PETTING_PEN_ITEM = ITEMS.registerSimpleBlockItem("petting_pen", PETTING_PEN_BLOCK);
    public static final DeferredBlock<Block> PENGUIN_POOL_BLOCK = BLOCKS.register("penguin_pool", () -> new ParkConnect.Tile(ParkConnect.POOL, decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> PENGUIN_POOL_ITEM = ITEMS.registerSimpleBlockItem("penguin_pool", PENGUIN_POOL_BLOCK);
    public static final DeferredBlock<Block> CAMPFIRE_PIT_BLOCK = BLOCKS.register("campfire_pit", () -> new ParkConnect.Tile(ParkConnect.FIRE, decor(SoundType.STONE).lightLevel(s -> s.getValue(ParkConnect.LIT) ? 15 : 0)));
    public static final DeferredItem<BlockItem> CAMPFIRE_PIT_ITEM = ITEMS.registerSimpleBlockItem("campfire_pit", CAMPFIRE_PIT_BLOCK);
    public static final DeferredBlock<Block> HOT_TUB_BLOCK = BLOCKS.register("hot_tub", () -> new ParkConnect.Tile(ParkConnect.HOTTUB, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> HOT_TUB_ITEM = ITEMS.registerSimpleBlockItem("hot_tub", HOT_TUB_BLOCK);
    public static final DeferredBlock<Block> FAST_PASS_LANE_GATE_BLOCK = BLOCKS.register("fast_pass_lane_gate", () -> new ParkGates.LaneGate(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> FAST_PASS_LANE_GATE_ITEM = ITEMS.registerSimpleBlockItem("fast_pass_lane_gate", FAST_PASS_LANE_GATE_BLOCK);
    public static final DeferredBlock<Block> FAST_PASS_LANE_GATE_LEAF = BLOCKS.register("fast_pass_lane_gate_leaf", () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> BARRIER_GATE_BLOCK = BLOCKS.register("barrier_gate", () -> new ParkGates.BarrierGate(false, BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> BARRIER_GATE_ITEM = ITEMS.registerSimpleBlockItem("barrier_gate", BARRIER_GATE_BLOCK);
    public static final DeferredBlock<Block> BARRIER_GATE_LEAF = BLOCKS.register("barrier_gate_leaf", () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> CAR_PARK_BARRIER_BLOCK = BLOCKS.register("car_park_barrier", () -> new ParkGates.BarrierGate(true, BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> CAR_PARK_BARRIER_ITEM = ITEMS.registerSimpleBlockItem("car_park_barrier", CAR_PARK_BARRIER_BLOCK);
    public static final DeferredBlock<Block> CAR_PARK_BARRIER_LEAF = BLOCKS.register("car_park_barrier_leaf", () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> AIRLOCK_DOOR_BLOCK = BLOCKS.register("airlock_door", () -> new ParkDoor("airlock_door", decor(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> AIRLOCK_DOOR_ITEM = ITEMS.registerSimpleBlockItem("airlock_door", AIRLOCK_DOOR_BLOCK);
    public static final DeferredBlock<Block> STEAM_ROOM_DOOR_BLOCK = BLOCKS.register("steam_room_door", () -> new ParkDoor("steam_room_door", decor(SoundType.GLASS).noOcclusion()));
    public static final DeferredItem<BlockItem> STEAM_ROOM_DOOR_ITEM = ITEMS.registerSimpleBlockItem("steam_room_door", STEAM_ROOM_DOOR_BLOCK);
    public static final DeferredBlock<Block> SLEEPING_BAG_BLOCK = BLOCKS.register("sleeping_bag", () -> new ParkConnect.Bag(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> SLEEPING_BAG_ITEM = ITEMS.registerSimpleBlockItem("sleeping_bag", SLEEPING_BAG_BLOCK);
    public static final DeferredItem<Item> KEEPER_HUT_ITEM = ITEMS.register("keeper_hut", () -> new ParkStructure.Kit("keeper_hut", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> SNOW_CABIN_ITEM = ITEMS.register("snow_cabin", () -> new ParkStructure.Kit("snow_cabin", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> HOT_CHOCOLATE_HUT_ITEM = ITEMS.register("hot_chocolate_hut", () -> new ParkStructure.Kit("hot_chocolate_hut", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> SHERIFF_OFFICE_ITEM = ITEMS.register("sheriff_office", () -> new ParkStructure.Kit("sheriff_office", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> TENT_ITEM = ITEMS.register("tent", () -> new ParkStructure.Kit("tent", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> PARK_GATE_ARCH_ITEM = ITEMS.register("park_gate_arch", () -> new ParkStructure.Kit("park_gate_arch", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> SECURITY_BOOTH_BUILDING_ITEM = ITEMS.register("security_booth_building", () -> new ParkStructure.Kit("security_booth_building", new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> COOKED_RICE = ITEMS.registerSimpleItem("cooked_rice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> TOAST = ITEMS.registerSimpleItem("toast", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> COFFEE = ITEMS.register("coffee", () -> new KitchenExtras.DrinkItem(new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16), () -> net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 20));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ParkProps.PropBE>> PROP_BE =
            BLOCK_ENTITIES.register("prop_state", () -> BlockEntityType.Builder.of(ParkProps.PropBE::new, BATHTUB_BLOCK.get(), AIR_FRESHENER_BLOCK.get(), HOB_BLOCK.get(), RICE_COOKER_BLOCK.get(), BLENDER_BLOCK.get(), ICE_MACHINE_BLOCK.get(), CHOPPING_BOARD_BLOCK.get(), COFFEE_MACHINE_BLOCK.get(), PHOTO_BOOTH_BLOCK.get(), BALLOON_STAND_BLOCK.get(), COIN_PRESS_BLOCK.get(), FACE_PAINT_STATION_BLOCK.get(), BLOOD_PRESSURE_MONITOR_BLOCK.get(), FIRE_ALARM_PULL_BLOCK.get(), JUKEBOX_BLOCK.get(), CHARGING_STATION_BLOCK.get(), WALKIE_TALKIE_CHARGER_BLOCK.get(), SIGN_IN_TERMINAL_BLOCK.get(), FEEDING_TROUGH_BLOCK.get(), CHICKEN_COOP_BLOCK.get(), SEED_DISPENSER_BLOCK.get(), MAP_TABLE_BLOCK.get(), SKATE_HIRE_COUNTER_BLOCK.get(), ICE_CREAM_VAN_WINDOW_BLOCK.get(), SEASIDE_TELESCOPE_BLOCK.get(), HOT_CHOCOLATE_COUNTER_BLOCK.get(), SHERIFF_DESK_BLOCK.get(), CONTROL_CONSOLE_BLOCK.get(), PROJECTOR_BLOCK.get(), SAUNA_CABIN_BLOCK.get(), DUCK_POND_GAME_BLOCK.get(), FORTUNE_TELLER_BOOTH_BLOCK.get(), TESLA_COIL_BLOCK.get(), MAGNET_TABLE_BLOCK.get(), WEATHER_STATION_BLOCK.get(), HEIGHT_MEASURE_POST_BLOCK.get(), KIDS_TICKET_WINDOW_BLOCK.get(), RIDE_PHOTO_KIOSK_BLOCK.get(), CARICATURE_STAND_BLOCK.get(), NAME_BADGE_PRINTER_BLOCK.get(), TICKET_SCANNER_POST_BLOCK.get(), WRISTBAND_DISPENSER_BLOCK.get(), ANNUAL_PASS_KIOSK_BLOCK.get(), QUEUE_PAUSE_SIGN_BLOCK.get(), MONORAIL_STATION_PLATFORM_BLOCK.get(), SHUTTLE_BUS_STOP_BLOCK.get(), TICKET_PAY_MACHINE_BLOCK.get(), STAGE_BLOCK.get(), MASCOT_MEET_SPOT_BLOCK.get(), CONFETTI_CANNON_BLOCK.get(), FIREWORKS_LAUNCHER_BLOCK.get(), ROOM_KEY_CARD_BLOCK.get(), SECURITY_BOOTH_BLOCK.get(), CCTV_CAMERA_BLOCK.get(), CONTROL_ROOM_DESK_BLOCK.get(), RADIO_BASE_BLOCK.get(), POWER_GENERATOR_BLOCK.get(), ELECTRIC_CABINET_BLOCK.get(), SPEAKER_CONTROL_BOX_BLOCK.get(), APP_KIOSK_BLOCK.get(), DIGITAL_MAP_BLOCK.get(), QR_SIGN_BLOCK.get(), INTERACTIVE_GLOBE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ParkProps.StoreBE>> STORE_BE =
            BLOCK_ENTITIES.register("prop_store", () -> BlockEntityType.Builder.of(ParkProps.StoreBE::new, VANITY_CABINET_BLOCK.get(), SPICE_SHELF_BLOCK.get(), BUFFET_COUNTER_BLOCK.get(), CAKE_CABINET_BLOCK.get(), LOST_PROPERTY_BOX_BLOCK.get(), TRASH_COMPACTOR_BLOCK.get(), UNIFORM_RACK_BLOCK.get(), TOOLBOX_BLOCK.get(), TREASURE_CHEST_BLOCK.get(), BANK_VAULT_BLOCK.get(), EXHIBIT_PLINTH_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> PROP_ITEMS = java.util.List.of(
            VANITY_MIRROR_ITEM, BIDET_ITEM, BATHTUB_ITEM, SHOWER_CURTAIN_RAIL_ITEM, TOILET_BRUSH_HOLDER_ITEM, AIR_FRESHENER_ITEM, VANITY_CABINET_ITEM, HEATED_TOWEL_RAIL_ITEM, HOB_ITEM, STEAMER_ITEM, RICE_COOKER_ITEM, BLENDER_ITEM, TOASTER_ITEM, ICE_MACHINE_ITEM, DISH_RACK_ITEM, HANGING_POT_RACK_ITEM, SPICE_SHELF_ITEM, CHOPPING_BOARD_ITEM, BUFFET_COUNTER_ITEM, COFFEE_MACHINE_ITEM, CAKE_CABINET_ITEM, BAR_STOOL_ITEM, BOOTH_DIVIDER_ITEM, HIGH_CHAIR_ITEM, NAPKIN_DISPENSER_ITEM, RESERVED_SIGN_ITEM, POSTCARD_WRITER_ITEM, KEYRING_SPINNER_ITEM, PHOTO_BOOTH_ITEM, BALLOON_STAND_ITEM, COIN_PRESS_ITEM, SNOW_GLOBE_ITEM, FACE_PAINT_STATION_ITEM, EYEWASH_STATION_ITEM, BLOOD_PRESSURE_MONITOR_ITEM, STRETCHER_ITEM, FIRE_ALARM_PULL_ITEM, SPRINKLER_HEAD_ITEM, SAFETY_RAIL_ITEM, EVACUATION_MAP_ITEM, AIR_HOCKEY_ITEM, PINBALL_ITEM, DANCE_MACHINE_ITEM, RACING_CABINET_ITEM, FOOSBALL_ITEM, SKEE_BALL_ITEM, DARTS_BOARD_ITEM, JUKEBOX_ITEM, MINI_GOLF_HOLE_ITEM, PHOTO_OP_FRAME_ITEM, LOST_PROPERTY_BOX_ITEM, CHARGING_STATION_ITEM, YOU_ARE_HERE_PILLAR_ITEM, PHOTO_SPOT_STAND_ITEM, MEMORIAL_BENCH_ITEM, MOP_BUCKET_ITEM, TRASH_COMPACTOR_ITEM, CANTEEN_TABLE_ITEM, UNIFORM_RACK_ITEM, WALKIE_TALKIE_CHARGER_ITEM, TOOLBOX_ITEM, BREAK_ROOM_SOFA_ITEM, SIGN_IN_TERMINAL_ITEM, ANIMAL_ENCLOSURE_FENCE_ITEM, FEEDING_TROUGH_ITEM, HABITAT_SIGN_ITEM, VIEWING_WINDOW_ITEM, BIRD_AVIARY_ITEM, HAY_BALE_ITEM, MILK_CHURN_ITEM, SCARECROW_POST_ITEM, CHICKEN_COOP_ITEM, WATER_PUMP_ITEM, TRACTOR_PROP_ITEM, SEED_DISPENSER_ITEM, FARM_GATE_ITEM, TREASURE_CHEST_ITEM, SHIP_WHEEL_ITEM, CANNON_PROP_ITEM, ROPE_NET_ITEM, PLANK_WALK_ITEM, PARROT_PERCH_ITEM, SKULL_FLAG_ITEM, MAP_TABLE_ITEM, LANTERN_POST_ITEM, CANOE_PROP_ITEM, FISHING_DOCK_ITEM, CAMP_STOVE_ITEM, LOG_SEAT_ITEM, TRAIL_MARKER_ITEM, SKI_RACK_ITEM, SKI_LIFT_CHAIR_ITEM, ICE_RINK_BARRIER_ITEM, SKATE_HIRE_COUNTER_ITEM, TOBOGGAN_ITEM, FROZEN_FOUNTAIN_ITEM, SALOON_DOORS_ITEM, HITCHING_POST_ITEM, WATER_TROUGH_ITEM, WANTED_BOARD_ITEM, BANK_VAULT_ITEM, WAGON_WHEEL_ITEM, TUMBLEWEED_ITEM, BEACH_HUT_ITEM, SANDCASTLE_MOULD_ITEM, DECK_UMBRELLA_STAND_ITEM, BOARDWALK_PLANK_ITEM, LIFEBUOY_ITEM, ICE_CREAM_VAN_WINDOW_ITEM, SEASIDE_TELESCOPE_ITEM, SEA_WALL_STEPS_ITEM, HOT_CHOCOLATE_COUNTER_ITEM, SHERIFF_DESK_ITEM, CONTROL_CONSOLE_ITEM, ROCKET_PROP_ITEM, HOLOGRAM_GLOBE_ITEM, OXYGEN_TANK_ITEM, PLANET_MOBILE_ITEM, MOON_ROVER_PROP_ITEM, LAUNCH_COUNTDOWN_BOARD_ITEM, MOVIE_POSTER_FRAME_ITEM, PROJECTOR_ITEM, CINEMA_SEATS_ITEM, STAGE_CURTAIN_ITEM, SPOTLIGHT_ITEM, POPCORN_BUCKET_STAND_ITEM, RED_CARPET_ITEM, MASSAGE_BED_ITEM, SAUNA_CABIN_ITEM, FOOT_SPA_ITEM, ZEN_ROCK_GARDEN_ITEM, CANDLE_SHELF_ITEM, RELAXATION_POD_ITEM, DUCK_POND_GAME_ITEM, BOTTLE_TOSS_ITEM, FORTUNE_TELLER_BOOTH_ITEM, HALL_OF_MIRRORS_ITEM, COTTON_CANDY_CART_ITEM, BALLOON_DART_BOARD_ITEM, TEST_YOUR_AIM_CANNON_ITEM, TESLA_COIL_ITEM, DINOSAUR_SKELETON_ITEM, PLANETARIUM_DOME_ITEM, MAGNET_TABLE_ITEM, PERISCOPE_ITEM, EXHIBIT_PLINTH_ITEM, WEATHER_STATION_ITEM, FOSSIL_DIG_PIT_ITEM, HEIGHT_MEASURE_POST_ITEM, KIDDIE_RIDE_BASE_ITEM, BABY_CARE_ROOM_DOOR_ITEM, PLAY_MAZE_ITEM, KIDS_TICKET_WINDOW_ITEM, STORY_CORNER_ITEM, MINI_TRAIN_STATION_ITEM, BALLOON_ARCH_ITEM, RIDE_PHOTO_KIOSK_ITEM, CARICATURE_STAND_ITEM, SOUVENIR_CUP_STAND_ITEM, NAME_BADGE_PRINTER_ITEM, SOUVENIR_MUG_RACK_ITEM, CHARACTER_PLUSH_BIN_ITEM, ROCKWORK_PANEL_ITEM, THEMED_FACADE_ITEM, GIANT_STATUE_BASE_ITEM, WATERFALL_PROP_ITEM, JUNGLE_FOLIAGE_ITEM, CASTLE_WALL_ITEM, WESTERN_FALSE_FRONT_ITEM, SPACE_PANEL_ITEM, STEAM_PIPE_PROP_ITEM, PARK_NAME_SIGN_ITEM, TICKET_SCANNER_POST_ITEM, BAG_CHECK_TABLE_ITEM, HAND_STAMP_STATION_ITEM, WRISTBAND_DISPENSER_ITEM, ANNUAL_PASS_KIOSK_ITEM, WELCOME_MAT_ITEM, QUEUE_LINE_BARRIER_ITEM, QUEUE_PAUSE_SIGN_ITEM, QUEUE_TV_SCREEN_ITEM, SHADE_CANOPY_ITEM, MISTING_FAN_ITEM, MONORAIL_STATION_PLATFORM_ITEM, SHUTTLE_BUS_STOP_ITEM, PARK_TRAIN_STOP_ITEM, BUS_SHELTER_ITEM, TICKET_PAY_MACHINE_ITEM, BICYCLE_RACK_ITEM, TAXI_RANK_SIGN_ITEM, PARADE_FLOAT_BASE_ITEM, STAGE_ITEM, STAGE_LIGHTS_ITEM, SPEAKER_TOWER_ITEM, MASCOT_MEET_SPOT_ITEM, STREET_PERFORMER_PITCH_ITEM, CONFETTI_CANNON_ITEM, FIREWORKS_LAUNCHER_ITEM, ROOM_KEY_CARD_ITEM, SECURITY_BOOTH_ITEM, CCTV_CAMERA_ITEM, CONTROL_ROOM_DESK_ITEM, RADIO_BASE_ITEM, EMERGENCY_STOP_BUTTON_ITEM, PATROL_SIGN_ITEM, POWER_GENERATOR_ITEM, WATER_TANK_ITEM, PIPE_JUNCTION_ITEM, ELECTRIC_CABINET_ITEM, CABLE_TRENCH_COVER_ITEM, SPEAKER_CONTROL_BOX_ITEM, FUSE_BOX_ITEM, UTILITY_SHED_ITEM, INSPECTION_PIT_ITEM, TOOL_WALL_ITEM, APP_KIOSK_ITEM, DIGITAL_MAP_ITEM, RIDE_STATUS_BOARD_ITEM, LOUDSPEAKER_POLE_ITEM, QR_SIGN_ITEM, INTERACTIVE_GLOBE_ITEM, WEATHER_DISPLAY_ITEM, AQUARIUM_TANK_ITEM, PETTING_PEN_ITEM, PENGUIN_POOL_ITEM, CAMPFIRE_PIT_ITEM, HOT_TUB_ITEM, SLEEPING_BAG_ITEM, KEEPER_HUT_ITEM, SNOW_CABIN_ITEM, HOT_CHOCOLATE_HUT_ITEM, SHERIFF_OFFICE_ITEM, TENT_ITEM, PARK_GATE_ARCH_ITEM, SECURITY_BOOTH_BUILDING_ITEM, AIRLOCK_DOOR_ITEM, STEAM_ROOM_DOOR_ITEM, FAST_PASS_LANE_GATE_ITEM, BARRIER_GATE_ITEM, CAR_PARK_BARRIER_ITEM, COOKED_RICE, TOAST, COFFEE);
    // ---- end of park props
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.ArcadeBlockEntity>> ARCADE_BE =
            BLOCK_ENTITIES.register("arcade_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.ArcadeBlockEntity::new,
                    ARCADE_CABINET_BLOCK.get(), CLAW_MACHINE_BLOCK.get(), WHACK_A_MOLE_BLOCK.get(), STRENGTH_TESTER_BLOCK.get(), BASKETBALL_HOOPS_BLOCK.get(), SHOOTING_GALLERY_BLOCK.get(), RING_TOSS_BLOCK.get(), COCONUT_SHY_BLOCK.get(), AIR_HOCKEY_BLOCK.get(), PINBALL_BLOCK.get(), DANCE_MACHINE_BLOCK.get(), RACING_CABINET_BLOCK.get(), FOOSBALL_BLOCK.get(), SKEE_BALL_BLOCK.get(), DARTS_BOARD_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.TokenBlockEntity>> TOKEN_BE =
            BLOCK_ENTITIES.register("token_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.TokenBlockEntity::new, TOKEN_MACHINE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.PrizeBlockEntity>> PRIZE_BE =
            BLOCK_ENTITIES.register("prize_counter", () -> BlockEntityType.Builder.of(ArcadeBlocks.PrizeBlockEntity::new, PRIZE_COUNTER_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> ARCADE_ITEMS = java.util.List.of(
            TOKEN_MACHINE_ITEM, ARCADE_TOKEN, ARCADE_CABINET_ITEM, CLAW_MACHINE_ITEM, WHACK_A_MOLE_ITEM, STRENGTH_TESTER_ITEM,
            BASKETBALL_HOOPS_ITEM, SHOOTING_GALLERY_ITEM, RING_TOSS_ITEM, COCONUT_SHY_ITEM, PRIZE_COUNTER_ITEM, PRIZE_TICKET);
    // ---- Gift Shop pack
    public static final DeferredBlock<Block> SHOP_SHELF_BLOCK = BLOCKS.register("shop_shelf", () -> new GiftBlocks.ShopBlock(decor(SoundType.WOOD), false));
    public static final DeferredBlock<Block> SHOP_SHELF_TOP = BLOCKS.register("shop_shelf_top", () -> TallBlocks.Top.create(SHOP_SHELF_BLOCK, null, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SHOP_SHELF_ITEM = ITEMS.<BlockItem>register("shop_shelf", () -> new TallBlocks.Item(SHOP_SHELF_BLOCK.get(), new Item.Properties(), SHOP_SHELF_TOP, 2));
    public static final DeferredBlock<Block> SOUVENIR_RACK_BLOCK = BLOCKS.register("souvenir_rack", () -> new GiftBlocks.RackBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SOUVENIR_RACK_TOP = BLOCKS.register("souvenir_rack_top", () -> TallBlocks.Top.create(SOUVENIR_RACK_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SOUVENIR_RACK_ITEM = ITEMS.<BlockItem>register("souvenir_rack", () -> new TallBlocks.Item(SOUVENIR_RACK_BLOCK.get(), new Item.Properties(), SOUVENIR_RACK_TOP, 2));
    public static final DeferredBlock<Block> PLUSH_TOY_BLOCK = BLOCKS.register("plush_toy", () -> new GiftBlocks.PlushBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> PLUSH_TOY_ITEM = ITEMS.registerSimpleBlockItem("plush_toy", PLUSH_TOY_BLOCK);
    public static final DeferredBlock<Block> SHOP_TILL_BLOCK = BLOCKS.register("shop_till", () -> new GiftBlocks.ShopBlock(decor(SoundType.WOOD), true));
    public static final DeferredItem<BlockItem> SHOP_TILL_ITEM = ITEMS.registerSimpleBlockItem("shop_till", SHOP_TILL_BLOCK);
    public static final DeferredBlock<Block> PRICE_TAG_BLOCK = BLOCKS.register("price_tag", () -> new GiftBlocks.PriceTagBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PRICE_TAG_ITEM = ITEMS.registerSimpleBlockItem("price_tag", PRICE_TAG_BLOCK);
    public static final DeferredBlock<Block> WINDOW_DISPLAY_BLOCK = BLOCKS.register("window_display", () -> new GiftBlocks.WindowBlock(decor(SoundType.GLASS).lightLevel(st -> 8)));
    public static final DeferredBlock<Block> WINDOW_DISPLAY_TOP = BLOCKS.register("window_display_top", () -> TallBlocks.Top.create(WINDOW_DISPLAY_BLOCK, null, decor(SoundType.GLASS).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> WINDOW_DISPLAY_ITEM = ITEMS.<BlockItem>register("window_display", () -> new TallBlocks.Item(WINDOW_DISPLAY_BLOCK.get(), new Item.Properties(), WINDOW_DISPLAY_TOP, 2));
    public static final DeferredBlock<Block> SHOPPING_BASKET_BLOCK = BLOCKS.register("shopping_basket", () -> new GiftBlocks.BasketBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> SHOPPING_BASKET_ITEM = ITEMS.registerSimpleBlockItem("shopping_basket", SHOPPING_BASKET_BLOCK);
    public static final DeferredItem<Item> GIFT_BAG = ITEMS.register("gift_bag", () -> new GiftBlocks.GiftBagItem(new Item.Properties()));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.ShopBlockEntity>> SHOP_BE =
            BLOCK_ENTITIES.register("shop", () -> BlockEntityType.Builder.of(GiftBlocks.ShopBlockEntity::new, SHOP_SHELF_BLOCK.get(), SHOP_TILL_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.PriceTagBlockEntity>> PRICE_TAG_BE =
            BLOCK_ENTITIES.register("price_tag", () -> BlockEntityType.Builder.of(GiftBlocks.PriceTagBlockEntity::new, PRICE_TAG_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.WindowBlockEntity>> WINDOW_BE =
            BLOCK_ENTITIES.register("window_display", () -> BlockEntityType.Builder.of(GiftBlocks.WindowBlockEntity::new, WINDOW_DISPLAY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.BasketBlockEntity>> BASKET_BE =
            BLOCK_ENTITIES.register("shopping_basket", () -> BlockEntityType.Builder.of(GiftBlocks.BasketBlockEntity::new, SHOPPING_BASKET_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> GIFT_ITEMS = java.util.List.of(
            SHOP_SHELF_ITEM, SOUVENIR_RACK_ITEM, PLUSH_TOY_ITEM, SHOP_TILL_ITEM, PRICE_TAG_ITEM, WINDOW_DISPLAY_ITEM, SHOPPING_BASKET_ITEM, GIFT_BAG);
    // ---- First Aid and Safety pack
    public static final DeferredBlock<Block> FIRST_AID_STATION_BLOCK = BLOCKS.register("first_aid_station", () -> new SafetyBlocks.FirstAidBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> FIRST_AID_STATION_TOP = BLOCKS.register("first_aid_station_top", () -> TallBlocks.Top.create(FIRST_AID_STATION_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> FIRST_AID_STATION_ITEM = ITEMS.<BlockItem>register("first_aid_station", () -> new TallBlocks.Item(FIRST_AID_STATION_BLOCK.get(), new Item.Properties(), FIRST_AID_STATION_TOP, 2));
    public static final DeferredBlock<Block> DEFIBRILLATOR_CABINET_BLOCK = BLOCKS.register("defibrillator_cabinet", () -> new SafetyBlocks.DefibBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> DEFIBRILLATOR_CABINET_ITEM = ITEMS.registerSimpleBlockItem("defibrillator_cabinet", DEFIBRILLATOR_CABINET_BLOCK);
    public static final DeferredBlock<Block> LOST_CHILD_POINT_BLOCK = BLOCKS.register("lost_child_point", () -> new SafetyBlocks.ChildPointBlock(decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 15 : 4)));
    public static final DeferredBlock<Block> LOST_CHILD_POINT_TOP = BLOCKS.register("lost_child_point_top", () -> TallBlocks.Top.create(LOST_CHILD_POINT_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 15 : 4), SafetyBlocks.LIT));
    public static final DeferredItem<BlockItem> LOST_CHILD_POINT_ITEM = ITEMS.<BlockItem>register("lost_child_point", () -> new TallBlocks.Item(LOST_CHILD_POINT_BLOCK.get(), new Item.Properties(), LOST_CHILD_POINT_TOP, 2));
    public static final DeferredBlock<Block> FIRE_EXTINGUISHER_BLOCK = BLOCKS.register("fire_extinguisher", () -> new SafetyBlocks.ExtinguisherBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FIRE_EXTINGUISHER_ITEM = ITEMS.registerSimpleBlockItem("fire_extinguisher", FIRE_EXTINGUISHER_BLOCK);
    public static final DeferredBlock<Block> EXIT_LIGHT_BLOCK = BLOCKS.register("exit_light", () -> new SafetyBlocks.ExitLightBlock(decor(SoundType.METAL).lightLevel(st -> 9)));
    public static final DeferredItem<BlockItem> EXIT_LIGHT_ITEM = ITEMS.registerSimpleBlockItem("exit_light", EXIT_LIGHT_BLOCK);
    public static final DeferredBlock<Block> EMERGENCY_PHONE_BLOCK = BLOCKS.register("emergency_phone", () -> new SafetyBlocks.PhoneBlock(decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 13 : 5)));
    public static final DeferredBlock<Block> EMERGENCY_PHONE_TOP = BLOCKS.register("emergency_phone_top", () -> TallBlocks.Top.create(EMERGENCY_PHONE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 13 : 5), SafetyBlocks.LIT));
    public static final DeferredItem<BlockItem> EMERGENCY_PHONE_ITEM = ITEMS.<BlockItem>register("emergency_phone", () -> new TallBlocks.Item(EMERGENCY_PHONE_BLOCK.get(), new Item.Properties(), EMERGENCY_PHONE_TOP, 2));
    public static final DeferredBlock<Block> PRAM_PARKING_BLOCK = BLOCKS.register("pram_parking", () -> new SafetyBlocks.BayBlock(decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> PRAM_PARKING_ITEM = ITEMS.registerSimpleBlockItem("pram_parking", PRAM_PARKING_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.FirstAidBlockEntity>> FIRST_AID_BE =
            BLOCK_ENTITIES.register("first_aid_station", () -> BlockEntityType.Builder.of(SafetyBlocks.FirstAidBlockEntity::new, FIRST_AID_STATION_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.DefibBlockEntity>> DEFIB_BE =
            BLOCK_ENTITIES.register("defibrillator_cabinet", () -> BlockEntityType.Builder.of(SafetyBlocks.DefibBlockEntity::new, DEFIBRILLATOR_CABINET_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.ChildPointBlockEntity>> CHILD_POINT_BE =
            BLOCK_ENTITIES.register("lost_child_point", () -> BlockEntityType.Builder.of(SafetyBlocks.ChildPointBlockEntity::new, LOST_CHILD_POINT_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.ExtinguisherBlockEntity>> EXTINGUISHER_BE =
            BLOCK_ENTITIES.register("fire_extinguisher", () -> BlockEntityType.Builder.of(SafetyBlocks.ExtinguisherBlockEntity::new, FIRE_EXTINGUISHER_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.PhoneBlockEntity>> PHONE_BE =
            BLOCK_ENTITIES.register("emergency_phone", () -> BlockEntityType.Builder.of(SafetyBlocks.PhoneBlockEntity::new, EMERGENCY_PHONE_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> SAFETY_ITEMS = java.util.List.of(
            FIRST_AID_STATION_ITEM, DEFIBRILLATOR_CABINET_ITEM, LOST_CHILD_POINT_ITEM, FIRE_EXTINGUISHER_ITEM, EXIT_LIGHT_ITEM, EMERGENCY_PHONE_ITEM, PRAM_PARKING_ITEM);
    // ---- Guest Services pack
    public static final DeferredBlock<Block> INFORMATION_DESK_BLOCK = BLOCKS.register("information_desk", () -> new GuestBlocks.InfoDeskBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> INFORMATION_DESK_ITEM = ITEMS.registerSimpleBlockItem("information_desk", INFORMATION_DESK_BLOCK);
    public static final DeferredBlock<Block> LOCKER_BLOCK = BLOCKS.register("locker", () -> new GuestBlocks.LockerBlock(decor(SoundType.METAL), false));
    public static final DeferredBlock<Block> LOCKER_TOP = BLOCKS.register("locker_top", () -> TallBlocks.Top.create(LOCKER_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> LOCKER_ITEM = ITEMS.<BlockItem>register("locker", () -> new TallBlocks.Item(LOCKER_BLOCK.get(), new Item.Properties(), LOCKER_TOP, 2));
    public static final DeferredItem<Item> LOCKER_KEY = ITEMS.register("locker_key", () -> new GuestBlocks.LockerKeyItem(new Item.Properties()));
    public static final DeferredBlock<Block> ATM_BLOCK = BLOCKS.register("atm", () -> new GuestBlocks.AtmBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ATM_TOP = BLOCKS.register("atm_top", () -> TallBlocks.Top.create(ATM_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ATM_ITEM = ITEMS.<BlockItem>register("atm", () -> new TallBlocks.Item(ATM_BLOCK.get(), new Item.Properties(), ATM_TOP, 2));
    public static final DeferredBlock<Block> PHOTO_FRAME_WALL_BLOCK = BLOCKS.register("photo_frame_wall", () -> new GuestBlocks.PhotoWallBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PHOTO_FRAME_WALL_ITEM = ITEMS.registerSimpleBlockItem("photo_frame_wall", PHOTO_FRAME_WALL_BLOCK);
    public static final DeferredBlock<Block> BROCHURE_STAND_BLOCK = BLOCKS.register("brochure_stand", () -> new GuestBlocks.BrochureBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BROCHURE_STAND_ITEM = ITEMS.registerSimpleBlockItem("brochure_stand", BROCHURE_STAND_BLOCK);
    public static final DeferredBlock<Block> STROLLER_HIRE_RACK_BLOCK = BLOCKS.register("stroller_hire_rack", () -> new GuestBlocks.StrollerBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> STROLLER_HIRE_RACK_ITEM = ITEMS.registerSimpleBlockItem("stroller_hire_rack", STROLLER_HIRE_RACK_BLOCK);
    public static final DeferredItem<Item> STROLLER = ITEMS.register("stroller", () -> new GuestBlocks.StrollerItem(new Item.Properties()));
    public static final DeferredBlock<Block> FEEDBACK_BOX_BLOCK = BLOCKS.register("feedback_box", () -> new GuestBlocks.FeedbackBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FEEDBACK_BOX_ITEM = ITEMS.registerSimpleBlockItem("feedback_box", FEEDBACK_BOX_BLOCK);
    // ---- Staff and Cleaning pack
    public static final DeferredItem<Item> STAFF_BADGE = ITEMS.register("staff_badge", () -> new StaffBlocks.BadgeItem(new Item.Properties()));
    public static final DeferredBlock<Block> STAFF_DOOR_BLOCK = BLOCKS.register("staff_door", () -> new StaffBlocks.StaffDoorBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> STAFF_DOOR_TOP = BLOCKS.register("staff_door_top", () -> TallBlocks.Top.create(STAFF_DOOR_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> STAFF_DOOR_ITEM = ITEMS.<BlockItem>register("staff_door", () -> new TallBlocks.Item(STAFF_DOOR_BLOCK.get(), new Item.Properties(), STAFF_DOOR_TOP, 2));
    public static final DeferredBlock<Block> JANITOR_CART_BLOCK = BLOCKS.register("janitor_cart", () -> new StaffBlocks.CartBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> JANITOR_CART_ITEM = ITEMS.registerSimpleBlockItem("janitor_cart", JANITOR_CART_BLOCK);
    public static final DeferredItem<Item> SWEEPER_BRUSH = ITEMS.register("sweeper_brush", () -> new StaffBlocks.SweeperItem(new Item.Properties()));
    public static final DeferredBlock<Block> WET_FLOOR_SIGN_BLOCK = BLOCKS.register("wet_floor_sign", () -> new StaffBlocks.WetFloorBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WET_FLOOR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wet_floor_sign", WET_FLOOR_SIGN_BLOCK);
    public static final DeferredItem<Item> LITTER_PICKER = ITEMS.register("litter_picker", () -> new StaffBlocks.PickerItem(new Item.Properties()));
    public static final DeferredBlock<Block> STAFF_LOCKER_BLOCK = BLOCKS.register("staff_locker", () -> new GuestBlocks.LockerBlock(decor(SoundType.METAL), true));
    public static final DeferredBlock<Block> STAFF_LOCKER_TOP = BLOCKS.register("staff_locker_top", () -> TallBlocks.Top.create(STAFF_LOCKER_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> STAFF_LOCKER_ITEM = ITEMS.<BlockItem>register("staff_locker", () -> new TallBlocks.Item(STAFF_LOCKER_BLOCK.get(), new Item.Properties(), STAFF_LOCKER_TOP, 2));
    public static final DeferredBlock<Block> STAFF_ROTA_BOARD_BLOCK = BLOCKS.register("staff_rota_board", () -> new StaffBlocks.RotaBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> STAFF_ROTA_BOARD_ITEM = ITEMS.registerSimpleBlockItem("staff_rota_board", STAFF_ROTA_BOARD_BLOCK);
    public static final DeferredBlock<Block> LITTER_BLOCK = BLOCKS.register("litter", () -> new StaffBlocks.LitterBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties.of().instabreak().noCollission().noOcclusion().sound(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> LITTER_ITEM = ITEMS.registerSimpleBlockItem("litter", LITTER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<StaffBlocks.CartBlockEntity>> CART_BE =
            BLOCK_ENTITIES.register("janitor_cart", () -> BlockEntityType.Builder.of(StaffBlocks.CartBlockEntity::new, JANITOR_CART_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.LockerBlockEntity>> LOCKER_BE =
            BLOCK_ENTITIES.register("locker", () -> BlockEntityType.Builder.of(GuestBlocks.LockerBlockEntity::new, LOCKER_BLOCK.get(), STAFF_LOCKER_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.PhotoWallBlockEntity>> PHOTO_WALL_BE =
            BLOCK_ENTITIES.register("photo_frame_wall", () -> BlockEntityType.Builder.of(GuestBlocks.PhotoWallBlockEntity::new, PHOTO_FRAME_WALL_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.StrollerBlockEntity>> STROLLER_BE =
            BLOCK_ENTITIES.register("stroller_hire_rack", () -> BlockEntityType.Builder.of(GuestBlocks.StrollerBlockEntity::new, STROLLER_HIRE_RACK_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.FeedbackBlockEntity>> FEEDBACK_BE =
            BLOCK_ENTITIES.register("feedback_box", () -> BlockEntityType.Builder.of(GuestBlocks.FeedbackBlockEntity::new, FEEDBACK_BOX_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> GUEST_ITEMS = java.util.List.of(
            INFORMATION_DESK_ITEM, LOCKER_ITEM, LOCKER_KEY, ATM_ITEM, PHOTO_FRAME_WALL_ITEM, BROCHURE_STAND_ITEM, STROLLER_HIRE_RACK_ITEM, FEEDBACK_BOX_ITEM, STROLLER);
    public static final java.util.List<DeferredItem<? extends Item>> STAFF_ITEMS = java.util.List.of(
            STAFF_DOOR_ITEM, STAFF_BADGE, JANITOR_CART_ITEM, SWEEPER_BRUSH, WET_FLOOR_SIGN_ITEM, LITTER_PICKER, STAFF_LOCKER_ITEM, STAFF_ROTA_BOARD_ITEM, LITTER_ITEM);
    // ---- Ride Maintenance pack
    public static final DeferredBlock<Block> WORKSHOP_BENCH_BLOCK = BLOCKS.register("workshop_bench", () -> new MaintBlocks.WorkshopBenchBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> WORKSHOP_BENCH_ITEM = ITEMS.registerSimpleBlockItem("workshop_bench", WORKSHOP_BENCH_BLOCK);
    public static final DeferredBlock<Block> PARTS_SHELF_BLOCK = BLOCKS.register("parts_shelf", () -> new ResortBlocks.PartsShelfBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> PARTS_SHELF_TOP = BLOCKS.register("parts_shelf_top", () -> TallBlocks.Top.create(PARTS_SHELF_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PARTS_SHELF_ITEM = ITEMS.<BlockItem>register("parts_shelf", () -> new TallBlocks.Item(PARTS_SHELF_BLOCK.get(), new Item.Properties(), PARTS_SHELF_TOP, 2));
    public static final DeferredBlock<Block> INSPECTION_PIT_BLOCK = BLOCKS.register("inspection_pit", () -> new MaintBlocks.PitBlock(decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> INSPECTION_PIT_ITEM = ITEMS.registerSimpleBlockItem("inspection_pit", INSPECTION_PIT_BLOCK);
    public static final DeferredBlock<Block> TOOL_WALL_BLOCK = BLOCKS.register("tool_wall", () -> new MaintBlocks.ToolWallBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TOOL_WALL_ITEM = ITEMS.registerSimpleBlockItem("tool_wall", TOOL_WALL_BLOCK);
    public static final DeferredBlock<Block> TEST_DUMMY_BLOCK = BLOCKS.register("test_dummy", () -> new MaintBlocks.DummyBlock(decor(SoundType.WOOL)));
    public static final DeferredBlock<Block> TEST_DUMMY_TOP = BLOCKS.register("test_dummy_top", () -> TallBlocks.Top.create(TEST_DUMMY_BLOCK, null, decor(SoundType.WOOL), MaintBlocks.LOCKED));
    public static final DeferredItem<BlockItem> TEST_DUMMY_ITEM = ITEMS.<BlockItem>register("test_dummy", () -> new TallBlocks.Item(TEST_DUMMY_BLOCK.get(), new Item.Properties(), TEST_DUMMY_TOP, 2));
    public static final DeferredBlock<Block> SAFETY_CHECKLIST_BOARD_BLOCK = BLOCKS.register("safety_checklist_board", () -> new MaintBlocks.ChecklistBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SAFETY_CHECKLIST_BOARD_ITEM = ITEMS.registerSimpleBlockItem("safety_checklist_board", SAFETY_CHECKLIST_BOARD_BLOCK);
    public static final DeferredBlock<Block> GREASE_STATION_BLOCK = BLOCKS.register("grease_station", () -> new MaintBlocks.GreaseBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> GREASE_STATION_ITEM = ITEMS.registerSimpleBlockItem("grease_station", GREASE_STATION_BLOCK);
    public static final DeferredBlock<Block> LIFT_JACK_BLOCK = BLOCKS.register("lift_jack", () -> new MaintBlocks.JackBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> LIFT_JACK_ITEM = ITEMS.registerSimpleBlockItem("lift_jack", LIFT_JACK_BLOCK);
    // ---- Park Hotel and Resort pack
    public static final DeferredBlock<Block> RECEPTION_DESK_BLOCK = BLOCKS.register("reception_desk", () -> new ResortBlocks.ReceptionBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> RECEPTION_DESK_ITEM = ITEMS.registerSimpleBlockItem("reception_desk", RECEPTION_DESK_BLOCK);
    public static final DeferredBlock<Block> HOTEL_ROOM_DOOR_BLOCK = BLOCKS.register("hotel_room_door", () -> new ResortBlocks.RoomDoorBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> HOTEL_ROOM_DOOR_TOP = BLOCKS.register("hotel_room_door_top", () -> TallBlocks.Top.create(HOTEL_ROOM_DOOR_BLOCK, null, decor(SoundType.WOOD), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> HOTEL_ROOM_DOOR_ITEM = ITEMS.<BlockItem>register("hotel_room_door", () -> new TallBlocks.Item(HOTEL_ROOM_DOOR_BLOCK.get(), new Item.Properties(), HOTEL_ROOM_DOOR_TOP, 2));
    public static final DeferredItem<Item> ROOM_KEY = ITEMS.register("room_key_card", () -> new ResortBlocks.RoomKeyItem(new Item.Properties()));
    public static final DeferredBlock<Block> LUGGAGE_TROLLEY_BLOCK = BLOCKS.register("luggage_trolley", () -> new ResortBlocks.LuggageBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> LUGGAGE_TROLLEY_ITEM = ITEMS.registerSimpleBlockItem("luggage_trolley", LUGGAGE_TROLLEY_BLOCK);
    public static final DeferredBlock<Block> BELLHOP_STAND_BLOCK = BLOCKS.register("bellhop_stand", () -> new ResortBlocks.BellStandBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BELLHOP_STAND_ITEM = ITEMS.registerSimpleBlockItem("bellhop_stand", BELLHOP_STAND_BLOCK);
    public static final DeferredBlock<Block> POOL_BAR_BLOCK = BLOCKS.register("pool_bar", () -> new ResortBlocks.PoolBarBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> POOL_BAR_ITEM = ITEMS.registerSimpleBlockItem("pool_bar", POOL_BAR_BLOCK);
    public static final DeferredBlock<Block> RESORT_SIGN_BLOCK = BLOCKS.register("resort_sign", () -> new ResortBlocks.ResortSignBlock(decor(SoundType.WOOD).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> RESORT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("resort_sign", RESORT_SIGN_BLOCK);
    public static final DeferredBlock<Block> HOTEL_BED_BLOCK = BLOCKS.register("hotel_bed", () -> new ResortBlocks.HotelBedBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> HOTEL_BED_ITEM = ITEMS.registerSimpleBlockItem("hotel_bed", HOTEL_BED_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.TextBlockEntity>> TEXT_BE =
            BLOCK_ENTITIES.register("service_text", () -> BlockEntityType.Builder.of(GuestBlocks.TextBlockEntity::new, INFORMATION_DESK_BLOCK.get(), BROCHURE_STAND_BLOCK.get(), STAFF_ROTA_BOARD_BLOCK.get(), RESORT_SIGN_BLOCK.get(), RESERVED_SIGN_BLOCK.get(), POSTCARD_WRITER_BLOCK.get(), EVACUATION_MAP_BLOCK.get(), MEMORIAL_BENCH_BLOCK.get(), HABITAT_SIGN_BLOCK.get(), TRAIL_MARKER_BLOCK.get(), WANTED_BOARD_BLOCK.get(), LAUNCH_COUNTDOWN_BOARD_BLOCK.get(), MOVIE_POSTER_FRAME_BLOCK.get(), PARK_NAME_SIGN_BLOCK.get(), RIDE_STATUS_BOARD_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.RoomDoorBlockEntity>> ROOM_DOOR_BE =
            BLOCK_ENTITIES.register("room_door", () -> BlockEntityType.Builder.of(ResortBlocks.RoomDoorBlockEntity::new, HOTEL_ROOM_DOOR_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.ReceptionBlockEntity>> RECEPTION_BE =
            BLOCK_ENTITIES.register("reception_desk", () -> BlockEntityType.Builder.of(ResortBlocks.ReceptionBlockEntity::new, RECEPTION_DESK_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.StorageBlockEntity>> STORAGE_BE =
            BLOCK_ENTITIES.register("resort_storage", () -> BlockEntityType.Builder.of(ResortBlocks.StorageBlockEntity::new, PARTS_SHELF_BLOCK.get(), LUGGAGE_TROLLEY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MaintBlocks.ChecklistBlockEntity>> CHECKLIST_BE =
            BLOCK_ENTITIES.register("safety_checklist", () -> BlockEntityType.Builder.of(MaintBlocks.ChecklistBlockEntity::new, SAFETY_CHECKLIST_BOARD_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> MAINT_ITEMS = java.util.List.of(
            WORKSHOP_BENCH_ITEM, PARTS_SHELF_ITEM, INSPECTION_PIT_ITEM, TOOL_WALL_ITEM, TEST_DUMMY_ITEM, SAFETY_CHECKLIST_BOARD_ITEM, GREASE_STATION_ITEM, LIFT_JACK_ITEM);
    public static final java.util.List<DeferredItem<? extends Item>> RESORT_ITEMS = java.util.List.of(
            RECEPTION_DESK_ITEM, HOTEL_ROOM_DOOR_ITEM, ROOM_KEY, LUGGAGE_TROLLEY_ITEM, BELLHOP_STAND_ITEM, POOL_BAR_ITEM, RESORT_SIGN_ITEM, HOTEL_BED_ITEM);
    public static final java.util.List<DeferredItem<BlockItem>> DECOR_ITEMS = java.util.List.of(
            BENCH_ITEM,
            DECK_CHAIR_ITEM,
            BIN_ITEM,
            LAMP_POST_ITEM,
            GARDEN_LIGHT_ITEM,
            CLOCK_ITEM,
            MAP_BOARD_ITEM,
            BOOTH_ITEM,
            SNACK_ITEM,
            CANDY_ITEM,
            FOUNTAIN_ITEM,
            PLANTER_ITEM,
            FLAG_ITEM,
            SPEAKER_ITEM,
            BOUNCY_ITEM,
            MISTER_ITEM);

    // ---------------------------------------------------------------- tickets and turnstile

    public static final DeferredItem<Item> TICKET_ITEM = ITEMS.registerSimpleItem("park_ticket", new Item.Properties());

    public static final DeferredBlock<TurnstileBlock> TURNSTILE_BLOCK = BLOCKS.register("turnstile",
            () -> new TurnstileBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TURNSTILE_ITEM = ITEMS.registerSimpleBlockItem("turnstile", TURNSTILE_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TurnstileBlockEntity>> TURNSTILE_BE =
            BLOCK_ENTITIES.register("turnstile",
                    () -> BlockEntityType.Builder.of(TurnstileBlockEntity::new, TURNSTILE_BLOCK.get()).build(null));

    public static final DeferredItem<Item> STATION_TRACK_ITEM =
            ITEMS.registerSimpleItem("station_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LAUNCH_TRACK_ITEM =
            ITEMS.registerSimpleItem("launch_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> BRAKE_TRACK_ITEM =
            ITEMS.registerSimpleItem("brake_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LIFT_TRACK_ITEM =
            ITEMS.registerSimpleItem("lift_track", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<ZoneBlock> STATION_ZONE_BLOCK = BLOCKS.register("station_controller",
            () -> new ZoneBlock(ZoneType.STATION, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> STATION_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("station_controller", STATION_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LAUNCH_ZONE_BLOCK = BLOCKS.register("launch_controller",
            () -> new ZoneBlock(ZoneType.LAUNCH, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LAUNCH_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("launch_controller", LAUNCH_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> BRAKE_ZONE_BLOCK = BLOCKS.register("brake_controller",
            () -> new ZoneBlock(ZoneType.BRAKE, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> BRAKE_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("brake_controller", BRAKE_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LIFT_ZONE_BLOCK = BLOCKS.register("lift_controller",
            () -> new ZoneBlock(ZoneType.LIFT, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LIFT_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("lift_controller", LIFT_ZONE_BLOCK);

    /** Never placed. Only used by the renderer to draw the swinging gate leaf. */
    public static final DeferredBlock<Block> GATE_LEAF_BLOCK = BLOCKS.register("ride_gate_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    public static final DeferredItem<Item> SEAT_TIMER_ITEM =
            ITEMS.registerSimpleItem("seat_timer", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SEAT_SPEED_ITEM =
            ITEMS.registerSimpleItem("seat_speed", new Item.Properties().stacksTo(1));

    /** Placeholder logo, only used as the creative tab icon. Replace textures/item/panel_logo.png to change it. */
    public static final DeferredItem<Item> PANEL_LOGO = ITEMS.registerSimpleItem("panel_logo");

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get(), EFFECTS_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncePanelBlockEntity>> ANNOUNCE_PANEL_BE =
            BLOCK_ENTITIES.register("announcement_panel",
                    () -> BlockEntityType.Builder.of(AnnouncePanelBlockEntity::new, ANNOUNCE_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncerBlockEntity>> ANNOUNCER_BE =
            BLOCK_ENTITIES.register("announcer",
                    () -> BlockEntityType.Builder.of(AnnouncerBlockEntity::new, ANNOUNCER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideGateBlockEntity>> GATE_BE =
            BLOCK_ENTITIES.register("ride_gate",
                    () -> BlockEntityType.Builder.of(RideGateBlockEntity::new, GATE_BLOCK.get(), GATE_SILVER_BLOCK.get(), GATE_RED_BLOCK.get(), GATE_DOUBLE_BLOCK.get(), FAST_PASS_LANE_GATE_BLOCK.get(), BARRIER_GATE_BLOCK.get(), CAR_PARK_BARRIER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SectionControllerBlockEntity>> SECTION_BE =
            BLOCK_ENTITIES.register("section_controller",
                    () -> BlockEntityType.Builder.of(SectionControllerBlockEntity::new, SECTION_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<SectionMenu>> SECTION_MENU =
            MENUS.register("section_controller", () -> IMenuTypeExtension.create(SectionMenu::new));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZoneBlockEntity>> ZONE_BE =
            BLOCK_ENTITIES.register("zone_controller",
                    () -> BlockEntityType.Builder.of(ZoneBlockEntity::new, STATION_ZONE_BLOCK.get(),
                            LAUNCH_ZONE_BLOCK.get(), BRAKE_ZONE_BLOCK.get(), LIFT_ZONE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EffectBlockEntity>> EFFECT_BE =
            BLOCK_ENTITIES.register("effect_machine",
                    () -> BlockEntityType.Builder.of(EffectBlockEntity::new, EFFECT_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CameraBlockEntity>> CAMERA_BE =
            BLOCK_ENTITIES.register("ride_camera",
                    () -> BlockEntityType.Builder.of(CameraBlockEntity::new, CAMERA_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhotoScreenBlockEntity>> PHOTO_SCREEN_BE =
            BLOCK_ENTITIES.register("photo_screen",
                    () -> BlockEntityType.Builder.of(PhotoScreenBlockEntity::new, PHOTO_SCREEN_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestSpawnerBlockEntity>> SPAWNER_BE =
            BLOCK_ENTITIES.register("guest_spawner",
                    () -> BlockEntityType.Builder.of(GuestSpawnerBlockEntity::new, SPAWNER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DropTowerBlockEntity>> DROP_TOWER_BE =
            BLOCK_ENTITIES.register("drop_tower",
                    () -> BlockEntityType.Builder.of(DropTowerBlockEntity::new, DROP_TOWER_BASE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MarkerBlockEntity>> MARKER_BE =
            BLOCK_ENTITIES.register("guest_marker",
                    () -> BlockEntityType.Builder.of(MarkerBlockEntity::new, QUEUE_MARKER_BLOCK.get(),
                            STATION_MARKER_BLOCK.get(), EXIT_MARKER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<GuestSpawnerMenu>> SPAWNER_MENU =
            MENUS.register("guest_spawner", () -> IMenuTypeExtension.create(GuestSpawnerMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<EffectMenu>> EFFECT_MENU =
            MENUS.register("effect_machine", () -> IMenuTypeExtension.create(EffectMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<ZoneMenu>> ZONE_MENU =
            MENUS.register("zone_controller", () -> IMenuTypeExtension.create(ZoneMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<RideGateMenu>> GATE_MENU =
            MENUS.register("ride_gate", () -> IMenuTypeExtension.create(RideGateMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<AnnouncerMenu>> ANNOUNCER_MENU =
            MENUS.register("announcer", () -> IMenuTypeExtension.create(AnnouncerMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.coastercontrolpanel"))
                    .icon(() -> PANEL_LOGO.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(PANEL_ITEM.get());
                        output.accept(COASTER_SMOOTHER_ITEM.get());
                        output.accept(TRACK_UNRESTRICTOR_ITEM.get());
                        output.accept(TRACK_ELEMENT_SELECTOR_ITEM.get());
                        output.accept(DRIVE_TYRE_ITEM.get());
                        output.accept(BRAKE_RUN_ITEM.get());
                        output.accept(TRAIN_STOPPER_ITEM.get());
                        output.accept(COASTER_BLUEPRINT_ITEM.get());
                        output.accept(LAUNCH_RUN_ITEM.get());
                        output.accept(BLOCK_RUN_ITEM.get());
                        output.accept(REDSTONE_TRIGGER_ITEM.get());
                        output.accept(CHAIN_TIMER_ITEM.get());
                        output.accept(DROP_TOWER_BASE_ITEM.get());
                        output.accept(DROP_TOWER_SECTION_ITEM.get());
                        output.accept(DROP_TOWER_FRAME_ITEM.get());
                        output.accept(DROP_TOWER_CONTROLLER_ITEM.get());
                        output.accept(SWING_BASE_ITEM.get());
                        output.accept(SWING_PIVOT_ITEM.get());
                        output.accept(SWING_ARM_ITEM.get());
                        output.accept(SWING_HUB_ITEM.get());
                        output.accept(SWING_FRAME_ITEM.get());
                        output.accept(SWING_SECTION_ITEM.get());
                        output.accept(SWING_CONTROLLER_ITEM.get());
                        output.accept(FERRIS_BASE_ITEM.get());
                        output.accept(FERRIS_AXLE_ITEM.get());
                        output.accept(FERRIS_SPOKE_ITEM.get());
                        output.accept(FERRIS_RIM_ITEM.get());
                        output.accept(FERRIS_HUB_ITEM.get());
                        output.accept(FERRIS_FRAME_ITEM.get());
                        output.accept(FERRIS_SECTION_ITEM.get());
                        output.accept(FERRIS_CONTROLLER_ITEM.get());
                        output.accept(PIRATE_BASE_ITEM.get());
                        output.accept(PIRATE_PIVOT_ITEM.get());
                        output.accept(PIRATE_ARM_ITEM.get());
                        output.accept(PIRATE_HUB_ITEM.get());
                        output.accept(PIRATE_HULL_ITEM.get());
                        output.accept(PIRATE_SECTION_ITEM.get());
                        output.accept(PIRATE_CONTROLLER_ITEM.get());
                        output.accept(SWIVEL_BEARING_ITEM.get());
                        output.accept(SWIVEL_PLATE_ITEM.get());
                        output.accept(FLIP_BEARING_ITEM.get());
                        output.accept(SPIN_BEARING_ITEM.get());
                        output.accept(SWAY_BEARING_ITEM.get());
                        output.accept(ROCK_BEARING_ITEM.get());
                        output.accept(LIFT_BEARING_ITEM.get());
                        output.accept(TEACUP_BASE_ITEM.get());
                        output.accept(TEACUP_HUB_ITEM.get());
                        output.accept(TEACUP_PLATE_ITEM.get());
                        output.accept(TEACUP_CUP_HUB_ITEM.get());
                        output.accept(TEACUP_FLOOR_ITEM.get());
                        output.accept(TEACUP_WALL_ITEM.get());
                        output.accept(TEACUP_SECTION_ITEM.get());
                        output.accept(TEACUP_CONTROLLER_ITEM.get());
                        output.accept(PREMADE_TEACUP_ITEM.get());
                        output.accept(PREMADE_PIRATE_ITEM.get());
                        output.accept(TIMEMACHINE_BASE_ITEM.get());
                        output.accept(TIMEMACHINE_PIVOT_ITEM.get());
                        output.accept(TIMEMACHINE_ARM_ITEM.get());
                        output.accept(TIMEMACHINE_HUB_ITEM.get());
                        output.accept(TIMEMACHINE_POD_ITEM.get());
                        output.accept(TIMEMACHINE_SECTION_ITEM.get());
                        output.accept(TIMEMACHINE_CONTROLLER_ITEM.get());
                        output.accept(PREMADE_TIMEMACHINE_ITEM.get());
                        output.accept(GYRO_BASE_ITEM.get());
                        output.accept(GYRO_PIVOT_ITEM.get());
                        output.accept(GYRO_ARM_ITEM.get());
                        output.accept(GYRO_HUB_ITEM.get());
                        output.accept(GYRO_RING_ITEM.get());
                        output.accept(GYRO_SECTION_ITEM.get());
                        output.accept(GYRO_CONTROLLER_ITEM.get());
                        output.accept(CAROUSEL_BASE_ITEM.get());
                        output.accept(CAROUSEL_HUB_ITEM.get());
                        output.accept(CAROUSEL_DECK_ITEM.get());
                        output.accept(CAROUSEL_HORSE_ITEM.get());
                        output.accept(CAROUSEL_POLE_ITEM.get());
                        output.accept(CAROUSEL_ROOF_ITEM.get());
                        output.accept(CAROUSEL_SECTION_ITEM.get());
                        output.accept(CAROUSEL_CONTROLLER_ITEM.get());
                        output.accept(BUMPER_BASE_ITEM.get());
                        output.accept(BUMPER_FLOOR_ITEM.get());
                        output.accept(BUMPER_RAIL_ITEM.get());
                        output.accept(BUMPER_SECTION_ITEM.get());
                        output.accept(BUMPER_CONTROLLER_ITEM.get());
                        output.accept(BUMPER_CAR_ITEM.get());
                        output.accept(PREMADE_GYRO_ITEM.get());
                        output.accept(PREMADE_CAROUSEL_ITEM.get());
                        output.accept(PREMADE_BUMPER_ITEM.get());
                        output.accept(PREMADE_DROP_TOWER_ITEM.get());
                        output.accept(PREMADE_SWING_ITEM.get());
                        output.accept(PREMADE_FERRIS_ITEM.get());
                        output.accept(ANIMATRONIC_ITEM.get());
                        output.accept(ANIMATRONIC_TOOL_ITEM.get());
                        output.accept(ANIMATION_CONTROLLER_ITEM.get());
                        output.accept(ANIMATION_CONNECTOR_ITEM.get());
                        output.accept(ANNOUNCER_ITEM.get());
                        output.accept(ANNOUNCE_PANEL_ITEM.get());
                        output.accept(GATE_ITEM.get());
                        output.accept(GATE_SILVER_ITEM.get());
                        output.accept(GATE_RED_ITEM.get());
                        output.accept(GATE_DOUBLE_ITEM.get());
                        output.accept(RIDE_FENCE_ITEM.get());
                        output.accept(RIDE_FENCE_SILVER_ITEM.get());
                        output.accept(RIDE_FENCE_RED_ITEM.get());
                        output.accept(SEAT_TIMER_ITEM.get());
                        output.accept(SEAT_SPEED_ITEM.get());
                        output.accept(SECTION_ITEM.get());
                        output.accept(SECTION_LINKER_ITEM.get());
                        output.accept(TRACK_PAINTER_ITEM.get());
                        output.accept(SUPPORT_TOOL_ITEM.get());
                        output.accept(SUPPORT_ERASER_ITEM.get());
                        output.accept(RIDE_SIGN_ITEM.get());
                        output.accept(OPEN_SIGN_ITEM.get());
                        output.accept(HEIGHT_SIGN_ITEM.get());
                        output.accept(WAIT_SIGN_ITEM.get());
                        output.accept(ROPE_POST_ITEM.get());
                        output.accept(FLOOR_ARROW_ITEM.get());
                        output.accept(TURNSTILE_ITEM.get());
                        output.accept(TICKET_ITEM.get());
                        output.accept(ENTRANCE_SIGN_ITEM.get());
                        output.accept(EXIT_SIGN_ITEM.get());
                        output.accept(NOTICE_SIGN_ITEM.get());
                        output.accept(DIRECTION_SIGN_ITEM.get());
                        output.accept(CROWD_SIGN_ITEM.get());
                        output.accept(COUNTER_SIGN_ITEM.get());
                        output.accept(FLOOR_SIGN_ITEM.get());
                        for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                            output.accept(decorItem.get());
                        }
                        for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                            output.accept(bathItem.get());
                        }
                        for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                            output.accept(kitchenItem.get());
                        }
                        for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                            output.accept(restaurantItem.get());
                        }
                        for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                            output.accept(arcadeItem.get());
                        }
                        for (DeferredItem<? extends Item> propItem : PROP_ITEMS) {
                            output.accept(propItem.get());
                        }
                        for (DeferredItem<? extends Item> giftItem : GIFT_ITEMS) {
                            output.accept(giftItem.get());
                        }
                        for (DeferredItem<? extends Item> safetyItem : SAFETY_ITEMS) {
                            output.accept(safetyItem.get());
                        }
                        for (DeferredItem<? extends Item> guestItem : GUEST_ITEMS) {
                            output.accept(guestItem.get());
                        }
                        for (DeferredItem<? extends Item> staffItem : STAFF_ITEMS) {
                            output.accept(staffItem.get());
                        }
                        for (DeferredItem<? extends Item> maintItem : MAINT_ITEMS) {
                            output.accept(maintItem.get());
                        }
                        for (DeferredItem<? extends Item> resortItem : RESORT_ITEMS) {
                            output.accept(resortItem.get());
                        }
                        output.accept(STATION_TRACK_ITEM.get());
                        output.accept(LAUNCH_TRACK_ITEM.get());
                        output.accept(BRAKE_TRACK_ITEM.get());
                        output.accept(LIFT_TRACK_ITEM.get());
                        output.accept(STATION_ZONE_ITEM.get());
                        output.accept(LAUNCH_ZONE_ITEM.get());
                        output.accept(BRAKE_ZONE_ITEM.get());
                        output.accept(LIFT_ZONE_ITEM.get());
                        output.accept(EFFECT_ITEM.get());
                        output.accept(EFFECTS_PANEL_ITEM.get());
                        output.accept(CAMERA_ITEM.get());
                        output.accept(CONNECTOR_ITEM.get());
                        output.accept(PHOTO_SCREEN_ITEM.get());
                        output.accept(SPAWNER_ITEM.get());
                        output.accept(QUEUE_MARKER_ITEM.get());
                        output.accept(STATION_MARKER_ITEM.get());
                        output.accept(EXIT_MARKER_ITEM.get());
                    })
                    .build());

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ENTITIES.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);
        SOUND_EVENTS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(this::registerPayloads);
        modBus.addListener(DropTowerCarriage::onCommonSetup);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
            event.accept(COASTER_SMOOTHER_ITEM);
            event.accept(TRACK_UNRESTRICTOR_ITEM);
            event.accept(TRACK_ELEMENT_SELECTOR_ITEM);
            event.accept(DRIVE_TYRE_ITEM);
            event.accept(BRAKE_RUN_ITEM);
            event.accept(TRAIN_STOPPER_ITEM);
            event.accept(LAUNCH_RUN_ITEM);
            event.accept(BLOCK_RUN_ITEM);
            event.accept(REDSTONE_TRIGGER_ITEM);
            event.accept(CHAIN_TIMER_ITEM);
            event.accept(DROP_TOWER_BASE_ITEM);
            event.accept(DROP_TOWER_SECTION_ITEM);
            event.accept(DROP_TOWER_FRAME_ITEM);
            event.accept(DROP_TOWER_CONTROLLER_ITEM);
            event.accept(SWING_BASE_ITEM);
            event.accept(SWING_PIVOT_ITEM);
            event.accept(SWING_ARM_ITEM);
            event.accept(SWING_HUB_ITEM);
            event.accept(SWING_FRAME_ITEM);
            event.accept(SWING_SECTION_ITEM);
            event.accept(SWING_CONTROLLER_ITEM);
            event.accept(FERRIS_BASE_ITEM);
            event.accept(FERRIS_AXLE_ITEM);
            event.accept(FERRIS_SPOKE_ITEM);
            event.accept(FERRIS_RIM_ITEM);
            event.accept(FERRIS_HUB_ITEM);
            event.accept(FERRIS_FRAME_ITEM);
            event.accept(FERRIS_SECTION_ITEM);
            event.accept(FERRIS_CONTROLLER_ITEM);
            event.accept(PIRATE_BASE_ITEM);
            event.accept(PIRATE_PIVOT_ITEM);
            event.accept(PIRATE_ARM_ITEM);
            event.accept(PIRATE_HUB_ITEM);
            event.accept(PIRATE_HULL_ITEM);
            event.accept(PIRATE_SECTION_ITEM);
            event.accept(PIRATE_CONTROLLER_ITEM);
            event.accept(SWIVEL_BEARING_ITEM);
            event.accept(SWIVEL_PLATE_ITEM);
            event.accept(FLIP_BEARING_ITEM);
            event.accept(SPIN_BEARING_ITEM);
            event.accept(SWAY_BEARING_ITEM);
            event.accept(ROCK_BEARING_ITEM);
            event.accept(LIFT_BEARING_ITEM);
            event.accept(TEACUP_BASE_ITEM);
            event.accept(TEACUP_HUB_ITEM);
            event.accept(TEACUP_PLATE_ITEM);
            event.accept(TEACUP_CUP_HUB_ITEM);
            event.accept(TEACUP_FLOOR_ITEM);
            event.accept(TEACUP_WALL_ITEM);
            event.accept(TEACUP_SECTION_ITEM);
            event.accept(TEACUP_CONTROLLER_ITEM);
            event.accept(PREMADE_TEACUP_ITEM);
            event.accept(PREMADE_PIRATE_ITEM);
            event.accept(TIMEMACHINE_BASE_ITEM);
            event.accept(TIMEMACHINE_PIVOT_ITEM);
            event.accept(TIMEMACHINE_ARM_ITEM);
            event.accept(TIMEMACHINE_HUB_ITEM);
            event.accept(TIMEMACHINE_POD_ITEM);
            event.accept(TIMEMACHINE_SECTION_ITEM);
            event.accept(TIMEMACHINE_CONTROLLER_ITEM);
            event.accept(PREMADE_TIMEMACHINE_ITEM);
            event.accept(GYRO_BASE_ITEM);
            event.accept(GYRO_PIVOT_ITEM);
            event.accept(GYRO_ARM_ITEM);
            event.accept(GYRO_HUB_ITEM);
            event.accept(GYRO_RING_ITEM);
            event.accept(GYRO_SECTION_ITEM);
            event.accept(GYRO_CONTROLLER_ITEM);
            event.accept(CAROUSEL_BASE_ITEM);
            event.accept(CAROUSEL_HUB_ITEM);
            event.accept(CAROUSEL_DECK_ITEM);
            event.accept(CAROUSEL_HORSE_ITEM);
            event.accept(CAROUSEL_POLE_ITEM);
            event.accept(CAROUSEL_ROOF_ITEM);
            event.accept(CAROUSEL_SECTION_ITEM);
            event.accept(CAROUSEL_CONTROLLER_ITEM);
            event.accept(BUMPER_BASE_ITEM);
            event.accept(BUMPER_FLOOR_ITEM);
            event.accept(BUMPER_RAIL_ITEM);
            event.accept(BUMPER_SECTION_ITEM);
            event.accept(BUMPER_CONTROLLER_ITEM);
            event.accept(BUMPER_CAR_ITEM);
            event.accept(PREMADE_GYRO_ITEM);
            event.accept(PREMADE_CAROUSEL_ITEM);
            event.accept(PREMADE_BUMPER_ITEM);
            event.accept(PREMADE_DROP_TOWER_ITEM);
            event.accept(PREMADE_SWING_ITEM);
            event.accept(PREMADE_FERRIS_ITEM);
            event.accept(ANIMATRONIC_ITEM);
            event.accept(ANIMATRONIC_TOOL_ITEM);
            event.accept(ANIMATION_CONTROLLER_ITEM);
            event.accept(ANIMATION_CONNECTOR_ITEM);
            event.accept(ANNOUNCER_ITEM);
            event.accept(ANNOUNCE_PANEL_ITEM);
            event.accept(GATE_ITEM);
            event.accept(GATE_SILVER_ITEM);
            event.accept(GATE_RED_ITEM);
            event.accept(GATE_DOUBLE_ITEM);
            event.accept(RIDE_FENCE_ITEM);
            event.accept(RIDE_FENCE_SILVER_ITEM);
            event.accept(RIDE_FENCE_RED_ITEM);
            event.accept(SEAT_TIMER_ITEM);
            event.accept(SEAT_SPEED_ITEM);
            event.accept(SECTION_ITEM);
            event.accept(SECTION_LINKER_ITEM);
            event.accept(TRACK_PAINTER_ITEM);
            event.accept(SUPPORT_TOOL_ITEM);
            event.accept(SUPPORT_ERASER_ITEM);
            event.accept(RIDE_SIGN_ITEM);
            event.accept(OPEN_SIGN_ITEM);
            event.accept(HEIGHT_SIGN_ITEM);
            event.accept(WAIT_SIGN_ITEM);
            event.accept(ROPE_POST_ITEM);
            event.accept(FLOOR_ARROW_ITEM);
            event.accept(TURNSTILE_ITEM);
            event.accept(TICKET_ITEM);
            event.accept(ENTRANCE_SIGN_ITEM);
            event.accept(EXIT_SIGN_ITEM);
            event.accept(NOTICE_SIGN_ITEM);
            event.accept(DIRECTION_SIGN_ITEM);
            event.accept(CROWD_SIGN_ITEM);
            event.accept(COUNTER_SIGN_ITEM);
            event.accept(FLOOR_SIGN_ITEM);
            for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                event.accept(decorItem);
            }
            for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                event.accept(bathItem.get());
            }
            for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                event.accept(kitchenItem.get());
            }
            for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                event.accept(restaurantItem.get());
            }
            for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                event.accept(arcadeItem.get());
            }
            for (DeferredItem<? extends Item> propItem : PROP_ITEMS) {
                event.accept(propItem.get());
            }
            for (DeferredItem<? extends Item> giftItem : GIFT_ITEMS) {
                event.accept(giftItem.get());
            }
            for (DeferredItem<? extends Item> safetyItem : SAFETY_ITEMS) {
                event.accept(safetyItem.get());
            }
            for (DeferredItem<? extends Item> guestItem : GUEST_ITEMS) {
                event.accept(guestItem.get());
            }
            for (DeferredItem<? extends Item> staffItem : STAFF_ITEMS) {
                event.accept(staffItem.get());
            }
            for (DeferredItem<? extends Item> maintItem : MAINT_ITEMS) {
                event.accept(maintItem.get());
            }
            for (DeferredItem<? extends Item> resortItem : RESORT_ITEMS) {
                event.accept(resortItem.get());
            }
            event.accept(STATION_TRACK_ITEM);
            event.accept(LAUNCH_TRACK_ITEM);
            event.accept(BRAKE_TRACK_ITEM);
            event.accept(LIFT_TRACK_ITEM);
            event.accept(STATION_ZONE_ITEM);
            event.accept(LAUNCH_ZONE_ITEM);
            event.accept(BRAKE_ZONE_ITEM);
            event.accept(LIFT_ZONE_ITEM);
            event.accept(EFFECT_ITEM);
            event.accept(EFFECTS_PANEL_ITEM);
            event.accept(CAMERA_ITEM);
            event.accept(CONNECTOR_ITEM);
            event.accept(PHOTO_SCREEN_ITEM);
            event.accept(SPAWNER_ITEM);
            event.accept(QUEUE_MARKER_ITEM);
            event.accept(STATION_MARKER_ITEM);
            event.accept(EXIT_MARKER_ITEM);
        }
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(TrackElementSelectPacket.TYPE, TrackElementSelectPacket.CODEC, TrackElementSelectPacket::handle);
        registrar.playToServer(AnimationConfigPacket.TYPE, AnimationConfigPacket.CODEC, AnimationConfigPacket::handle);
        registrar.playToServer(AnimatronicConfigPacket.TYPE, AnimatronicConfigPacket.CODEC, AnimatronicConfigPacket::handle);
        registrar.playToServer(BrakeConfigPacket.TYPE, BrakeConfigPacket.CODEC, BrakeConfigPacket::handle);
        registrar.playToServer(ButtonPacket.TYPE, ButtonPacket.CODEC, ButtonPacket::handle);
        registrar.playToServer(AnnouncePlayPacket.TYPE, AnnouncePlayPacket.CODEC, AnnouncePlayPacket::handle);
        registrar.playToServer(AnnounceConfigPacket.TYPE, AnnounceConfigPacket.CODEC, AnnounceConfigPacket::handle);
        registrar.playToServer(ClipUploadPacket.TYPE, ClipUploadPacket.CODEC, ClipUploadPacket::handle);
        registrar.playToServer(ClipRequestPacket.TYPE, ClipRequestPacket.CODEC, ClipRequestPacket::handle);
        registrar.playToClient(ClipDataPacket.TYPE, ClipDataPacket.CODEC, ClipDataPacket::handle);
        registrar.playToClient(ClipPlayPacket.TYPE, ClipPlayPacket.CODEC, ClipPlayPacket::handle);
        registrar.playToServer(ConfigPacket.TYPE, ConfigPacket.CODEC, ConfigPacket::handle);
        registrar.playToServer(AnnouncerConfigPacket.TYPE, AnnouncerConfigPacket.CODEC, AnnouncerConfigPacket::handle);
        registrar.playToServer(GateConfigPacket.TYPE, GateConfigPacket.CODEC, GateConfigPacket::handle);
        registrar.playToServer(ChainRampPacket.TYPE, ChainRampPacket.CODEC, ChainRampPacket::handle);
        registrar.playToServer(SeatTimerPacket.TYPE, SeatTimerPacket.CODEC, SeatTimerPacket::handle);
        registrar.playToServer(SeatSpeedPacket.TYPE, SeatSpeedPacket.CODEC, SeatSpeedPacket::handle);
        registrar.playToServer(SectionConfigPacket.TYPE, SectionConfigPacket.CODEC, SectionConfigPacket::handle);
        registrar.playToServer(ZoneConfigPacket.TYPE, ZoneConfigPacket.CODEC, ZoneConfigPacket::handle);
        registrar.playToServer(EffectConfigPacket.TYPE, EffectConfigPacket.CODEC, EffectConfigPacket::handle);
        registrar.playToClient(PhotoRequestPacket.TYPE, PhotoRequestPacket.CODEC, PhotoRequestPacket::handle);
        registrar.playToServer(PhotoUploadPacket.TYPE, PhotoUploadPacket.CODEC, PhotoUploadPacket::handle);
        registrar.playToServer(PhotoFetchPacket.TYPE, PhotoFetchPacket.CODEC, PhotoFetchPacket::handle);
        registrar.playToClient(PhotoDataPacket.TYPE, PhotoDataPacket.CODEC, PhotoDataPacket::handle);
        registrar.playToClient(SwivelStatePacket.TYPE, SwivelStatePacket.CODEC, SwivelStatePacket::handle);
        registrar.playToClient(TeacupStatePacket.TYPE, TeacupStatePacket.CODEC, TeacupStatePacket::handle);
        registrar.playToClient(FerrisStatePacket.TYPE, FerrisStatePacket.CODEC, FerrisStatePacket::handle);
        registrar.playToClient(SwingStatePacket.TYPE, SwingStatePacket.CODEC, SwingStatePacket::handle);
        registrar.playToClient(DropTowerStatePacket.TYPE, DropTowerStatePacket.CODEC, DropTowerStatePacket::handle);
        registrar.playToServer(RideLinkPacket.TYPE, RideLinkPacket.CODEC, RideLinkPacket::handle);
        registrar.playToServer(DropTowerConfigPacket.TYPE, DropTowerConfigPacket.CODEC, DropTowerConfigPacket::handle);
        registrar.playToServer(DropTowerControlPacket.TYPE, DropTowerControlPacket.CODEC, DropTowerControlPacket::handle);
        registrar.playToServer(MarkerConfigPacket.TYPE, MarkerConfigPacket.CODEC, MarkerConfigPacket::handle);
        registrar.playToServer(GuestSpawnerConfigPacket.TYPE, GuestSpawnerConfigPacket.CODEC, GuestSpawnerConfigPacket::handle);
        registrar.playToServer(SupportConfigPacket.TYPE, SupportConfigPacket.CODEC, SupportConfigPacket::handle);
        registrar.playToServer(SignConfigPacket.TYPE, SignConfigPacket.CODEC, SignConfigPacket::handle);
        registrar.playToServer(KitchenConfigPacket.TYPE, KitchenConfigPacket.CODEC, KitchenConfigPacket::handle);
        registrar.playToServer(RestaurantActionPacket.TYPE, RestaurantActionPacket.CODEC, RestaurantActionPacket::handle);
        registrar.playToServer(MenuBoardPacket.TYPE, MenuBoardPacket.CODEC, MenuBoardPacket::handle);
        registrar.playToServer(ArcadeActionPacket.TYPE, ArcadeActionPacket.CODEC, ArcadeActionPacket::handle);
        registrar.playToServer(ParkActionPacket.TYPE, ParkActionPacket.CODEC, ParkActionPacket::handle);
        registrar.playToServer(CoasterPlacePacket.TYPE, CoasterPlacePacket.CODEC, CoasterPlacePacket::handle);
        registrar.playToServer(PropActionPacket.TYPE, PropActionPacket.CODEC, PropActionPacket::handle);
        registrar.playToServer(ServiceActionPacket.TYPE, ServiceActionPacket.CODEC, ServiceActionPacket::handle);
        registrar.playToServer(ServiceTextPacket.TYPE, ServiceTextPacket.CODEC, ServiceTextPacket::handle);
    }
}
