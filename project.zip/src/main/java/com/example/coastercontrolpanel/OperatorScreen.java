package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * Mouse mode for the operator panel. The world keeps running, and WASD / jump / sneak / sprint
 * still move you, so you can click the panel while walking around.
 */
public class OperatorScreen extends Screen {
    private final BlockPos pos;
    private int heldRow = -1;

    public OperatorScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.title"));
        this.pos = pos;
    }

    @Nullable
    private PanelBlockEntity panel() {
        if (minecraft == null || minecraft.level == null) {
            return null;
        }
        return minecraft.level.getBlockEntity(pos) instanceof PanelBlockEntity p ? p : null;
    }

    private Button repairButton;
    private Button resetButton;
    private int queryTimer;

    @Override
    protected void init() {
        // Break Down Your Coaster: shown only while the coaster named like this panel has a breakdown
        repairButton = Button.builder(Component.translatable("gui.coastercontrolpanel.breakdown.start_repair"),
                b -> PacketDistributor.sendToServer(new BreakdownPanelPacket(pos, 1))).bounds(width / 2 - 108, 46, 104, 16).build();
        resetButton = Button.builder(Component.translatable("gui.coastercontrolpanel.breakdown.reset"),
                b -> PacketDistributor.sendToServer(new BreakdownPanelPacket(pos, 2))).bounds(width / 2 + 4, 46, 104, 16).build();
        repairButton.visible = false;
        resetButton.visible = false;
        addRenderableWidget(repairButton);
        addRenderableWidget(resetButton);
        PacketDistributor.sendToServer(new BreakdownPanelPacket(pos, 0));
    }

    private static BreakdownStatePacket breakdown() {
        BreakdownStatePacket s = BreakdownStatePacket.latest;
        return s != null && s.active() && System.currentTimeMillis() - BreakdownStatePacket.latestAt < 3000 ? s : null;
    }

    private static Component bd(String key, Object... args) {
        return Component.translatable("gui.coastercontrolpanel.breakdown." + key, args);
    }

    private void drawBreakdown(GuiGraphics g) {
        BreakdownStatePacket s = breakdown();
        repairButton.visible = s != null && !s.repairing() && !s.ready();
        resetButton.visible = s != null && s.ready();
        if (s == null) {
            return;
        }
        int x0 = width / 2 - 112;
        g.fill(x0 - 1, 5, x0 + 225, 67, 0xFF8A2A2A);
        g.fill(x0, 6, x0 + 224, 66, 0xE01B1D24);
        g.drawString(font, bd("alert", s.coaster()), x0 + 6, 9, 0xFF6060, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.breakdown.type." + BreakdownController.typeKey(s.kind()))
                .append(" - ").append(Component.translatable("gui.coastercontrolpanel.breakdown.sev." + BreakdownController.sevKey(s.sev())))
                .append(" - ").append(Component.translatable("gui.coastercontrolpanel.breakdown.element." + BreakdownSettings.ELEMENT_KEYS[Math.max(0, Math.min(6, s.element()))])),
                x0 + 6, 20, 0xE0E4F0, false);
        Component status;
        if (s.ready()) {
            status = bd("status_ready");
        } else if (s.repairing()) {
            status = bd("status_repairing", s.repairLeft());
        } else if (s.sev() == BreakdownSettings.S_MAJOR) {
            status = bd("status_major", s.repairTotal());
        } else if (s.autoAvail()) {
            status = bd("status_auto", s.autoLeft(), s.repairTotal());
        } else {
            status = bd("status_manual", s.repairTotal());
        }
        g.drawString(font, status, x0 + 6, 32, 0xFFD060, false);
    }

    private boolean dragging = false;
    private double dragDx;
    private double dragDy;

    private int panelX() {
        return PanelLayout.x;
    }

    private int panelY() {
        return PanelLayout.top(height, panel());
    }

    private int rowAt(double mx, double my) {
        double lx = (mx - panelX()) / PanelLayout.scale;
        double ly = (my - panelY()) / PanelLayout.scale;
        return PanelRenderer.hit(panel(), 0, 0, lx, ly);
    }

    private boolean overPanel(double mx, double my) {
        PanelBlockEntity p = panel();
        return p != null && mx >= panelX() && mx < panelX() + PanelLayout.width()
                && my >= panelY() && my < panelY() + PanelLayout.height(p);
    }

    /** The top strip of the panel, beside the lever: grab it to move the panel. */
    private boolean overTitle(double mx, double my) {
        PanelBlockEntity p = panel();
        if (!overPanel(mx, my)) {
            return false;
        }
        double lx = (mx - panelX()) / PanelLayout.scale;
        double ly = (my - panelY()) / PanelLayout.scale;
        return ly < 28 && (p == null || !p.hasExtras() || lx > 30);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur: the player must keep seeing the ride. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void tick() {
        if (panel() == null) {
            onClose();
            return;
        }
        if (queryTimer++ % 10 == 0) {
            PacketDistributor.sendToServer(new BreakdownPanelPacket(pos, 0));
        }
        // Keep walking: screens normally stop the movement keys from working.
        if (minecraft != null) {
            Options o = minecraft.options;
            long window = minecraft.getWindow().getWindow();
            KeyMapping[] moves = {o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keyShift, o.keySprint};
            for (KeyMapping k : moves) {
                if (k.getKey().getType() == InputConstants.Type.KEYSYM) {
                    k.setDown(InputConstants.isKeyDown(window, k.getKey().getValue()));
                }
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        PanelBlockEntity p = panel();
        if (p == null) {
            return;
        }
        PanelLayout.clamp(width, height, p);
        g.pose().pushPose();
        g.pose().translate(panelX(), panelY(), 0);
        g.pose().scale(PanelLayout.scale, PanelLayout.scale, 1.0F);
        PanelRenderer.draw(g, font, p, 0, 0, heldRow, Component.translatable("gui.coastercontrolpanel.operator_hint"));
        g.pose().popPose();
        Component move = Component.translatable("gui.coastercontrolpanel.operator_move");
        g.drawString(font, move, Math.max(2, panelX()), Math.max(2, panelY() - 10), 0xC8C8D8, true);
        drawBreakdown(g);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 1 && overTitle(mouseX, mouseY)) {
            PanelLayout.reset();
            return true;
        }
        if (button == 0 && overTitle(mouseX, mouseY)) {
            dragging = true;
            dragDx = mouseX - panelX();
            dragDy = mouseY - panelY();
            return true;
        }
        if (button == 0) {
            int row = rowAt(mouseX, mouseY);
            if (row >= 0) {
                heldRow = row;
                PacketDistributor.sendToServer(new ButtonPacket(pos, row, true));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging) {
            PanelLayout.x = (int) Math.round(mouseX - dragDx);
            PanelLayout.y = (int) Math.round(mouseY - dragDy);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (overPanel(mouseX, mouseY)) {
            int top = panelY();
            PanelLayout.scale = Math.max(PanelLayout.MIN_SCALE,
                    Math.min(PanelLayout.MAX_SCALE, PanelLayout.scale + (scrollY > 0 ? 0.1F : -0.1F)));
            PanelLayout.y = top;
            PanelLayout.save();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging && button == 0) {
            dragging = false;
            PanelLayout.save();
            return true;
        }
        if (button == 0 && heldRow >= 0) {
            PacketDistributor.sendToServer(new ButtonPacket(pos, heldRow, false));
            heldRow = -1;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClientKeys.MOUSE.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        if (heldRow >= 0) {
            PacketDistributor.sendToServer(new ButtonPacket(pos, heldRow, false));
            heldRow = -1;
        }
        KeyMapping.setAll();
        super.removed();
    }
}
