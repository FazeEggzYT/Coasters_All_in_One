package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the Ride Start Block's screen. action 0 = save settings, 1 = dispatch, 2 = stop. */
public record FlatRideControlPacket(BlockPos pos, int action, int loadSecs, int runSecs, int speedPct) implements CustomPacketPayload {
    public static final Type<FlatRideControlPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "flat_ride_control"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FlatRideControlPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.loadSecs);
                buf.writeVarInt(p.runSecs);
                buf.writeVarInt(p.speedPct);
            },
            buf -> new FlatRideControlPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(FlatRideControlPacket p, IPayloadContext context) {
        var player = context.player();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 100.0) {
            return;
        }
        if (player.level().getBlockEntity(p.pos) instanceof FlatRideBlockEntity be) {
            be.control(player, p.action, p.loadSecs, p.runSecs, p.speedPct);
        }
    }
}
