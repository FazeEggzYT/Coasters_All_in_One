package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: a button on one of the prop screens (see ParkProps.act). */
public record PropActionPacket(BlockPos pos, int action, int a) implements CustomPacketPayload {
    public static final Type<PropActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "prop_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PropActionPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.a + 1000);
            },
            buf -> new PropActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt() - 1000));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(PropActionPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 64.0 || !level.isLoaded(p.pos)) {
            return;
        }
        ParkProps.act(player, level, p.pos, p.action, p.a);
    }
}
