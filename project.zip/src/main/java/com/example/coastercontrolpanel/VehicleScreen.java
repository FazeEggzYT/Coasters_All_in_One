package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.DyeColor;
import net.neoforged.neoforge.network.PacketDistributor;

/** The vehicle picker: choose a vehicle body for the Coaster Cart you clicked, and its colour. */
public class VehicleScreen extends Screen {
    private static final int W = 380;
    private static final int H = 236;
    private final BlockPos pos;
    private int selected = 0;
    private int colour = 0;
    private int left;
    private int top;

    public VehicleScreen(BlockPos pos) {
        super(Component.translatable("item.coastercontrolpanel.coaster_vehicle_kit"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        for (int i = 0; i < CoasterVehicles.IDS.length; i++) {
            final int n = i;
            addRenderableWidget(Button.builder(Component.literal(CoasterVehicles.NAMES[i]), b -> selected = n)
                    .bounds(left + 8, top + 22 + i * 13, 146, 12).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.vehicle_place"), b -> {
            PacketDistributor.sendToServer(new VehiclePlacePacket(pos, selected, colour));
            onClose();
        }).bounds(left + 162, top + H - 22, 210, 16).build());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sx = left + 162;
        int sy = top + 150;
        for (int i = 0; i < CoasterBuilder.COLOURS.length; i++) {
            int x = sx + i * 23;
            if (mx >= x && mx < x + 20 && my >= sy && my < sy + 14) {
                colour = i;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private DyeColor dye() {
        return colour > 0 ? CoasterBuilder.COLOURS[colour] : DyeColor.byName(CoasterVehicles.DYES[selected], DyeColor.RED);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xEE1B1F27);
        g.fill(left, top, left + W, top + 16, 0xFF2E6FB0);
        g.drawString(font, title, left + 6, top + 4, 0xFFFFFFFF, false);
        int bx = left + 162;
        g.fill(bx, top + 22, bx + 210, top + 146, 0xFF10141A);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.vehicle_side"), bx + 3, top + 24, 0xFF6C7A8C, false);
        side(g, bx, top + 22, 210, 124);
        for (int i = 0; i < CoasterBuilder.COLOURS.length; i++) {
            int x = bx + i * 23;
            DyeColor d = CoasterBuilder.COLOURS[i];
            int c = d == null ? 0xFF8C96A3 : 0xFF000000 | AnchorTrack.dyeRgb(d);
            g.fill(x - 1, top + 149, x + 21, top + 165, i == colour ? 0xFFFFFFFF : 0xFF4A5666);
            g.fill(x, top + 150, x + 20, top + 164, c);
            if (d == null) {
                g.drawString(font, "-", x + 8, top + 153, 0xFF10141A, false);
            }
        }
        g.drawString(font, CoasterVehicles.BLURBS[selected], bx, top + 172, 0xFFD6DEE8, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.vehicle_note"), bx, top + 186, 0xFF6C7A8C, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.vehicle_note2"), bx, top + 198, 0xFF6C7A8C, false);
    }

    /** The vehicle from the side, one square per block, in the block's map colour. The cart is the grey square. */
    private void side(GuiGraphics g, int x0, int y0, int w, int h) {
        int minZ = 99;
        int maxZ = -99;
        int minY = 99;
        int maxY = -99;
        for (String cell : CoasterVehicles.CELLS[selected]) {
            String[] f = cell.split(",", 4);
            int z = Integer.parseInt(f[2]);
            int y = Integer.parseInt(f[1]);
            minZ = Math.min(minZ, z);
            maxZ = Math.max(maxZ, z);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        minZ = Math.min(minZ, 0);
        maxZ = Math.max(maxZ, 0);
        minY = Math.min(minY, 0);
        maxY = Math.max(maxY, 0);
        int cell = Math.min(24, Math.min((w - 20) / (maxZ - minZ + 1), (h - 30) / (maxY - minY + 1)));
        int ox = x0 + (w - (maxZ - minZ + 1) * cell) / 2;
        int oy = y0 + 18 + (h - 24 - (maxY - minY + 1) * cell) / 2;
        // back to front: later columns (larger x) first so the nearest block shows
        java.util.Map<Long, Integer> shown = new java.util.HashMap<>();
        java.util.Map<Long, Integer> depth = new java.util.HashMap<>();
        for (String c : CoasterVehicles.CELLS[selected]) {
            String[] f = c.split(",", 4);
            int x = Integer.parseInt(f[0]);
            int y = Integer.parseInt(f[1]);
            int z = Integer.parseInt(f[2]);
            long key = ((long) y << 32) | (z & 0xFFFFFFFFL);
            if (!depth.containsKey(key) || x < depth.get(key)) {
                depth.put(key, x);
                shown.put(key, colourOf(f[3].replace("{c}", dye().getName())));
            }
        }
        for (java.util.Map.Entry<Long, Integer> e : shown.entrySet()) {
            int y = (int) (e.getKey() >> 32);
            int z = (int) (long) e.getKey();
            int px = ox + (z - minZ) * cell;
            int py = oy + (maxY - y) * cell;
            g.fill(px, py, px + cell - 1, py + cell - 1, e.getValue());
        }
        int px = ox + (0 - minZ) * cell;
        int py = oy + (maxY - 0) * cell;
        g.fill(px, py, px + cell - 1, py + cell - 1, 0xFF7B8591);
        g.drawString(font, ">", ox + (maxZ - minZ + 1) * cell + 2, oy, 0xFFFFC83C, false);
    }

    private static int colourOf(String blockState) {
        String id = blockState.contains("[") ? blockState.substring(0, blockState.indexOf('[')) : blockState;
        try {
            ResourceLocation rl = ResourceLocation.parse(id);
            if (id.startsWith("create:")) {
                String n = id.substring(7).replace("_seat", "");
                DyeColor d = DyeColor.byName(n, null);
                return d == null ? 0xFFCCCCCC : 0xFF000000 | (AnchorTrack.dyeRgb(d) & 0xFFFFFF);
            }
            if (BuiltInRegistries.BLOCK.containsKey(rl)) {
                return 0xFF000000 | BuiltInRegistries.BLOCK.get(rl).defaultMapColor().col;
            }
        } catch (RuntimeException e) {
            // fall through
        }
        return 0xFFCCCCCC;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
