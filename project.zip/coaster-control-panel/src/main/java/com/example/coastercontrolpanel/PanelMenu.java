package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Setup menu. The 16 top slots are "ghost" slots: they only remember which item you
 * clicked with, they never take the item. Row r: slot r*2 = Input, slot r*2+1 = Output.
 */
public class PanelMenu extends AbstractContainerMenu {
    public static final int GHOST_SLOTS = PanelBlockEntity.CH * 2;
    public static final int ROW_Y = 52;
    public static final int ROW_STEP = 17;
    public static final int IN_X = 196;
    public static final int OUT_X = 222;

    public static final int MASTER_IN_X = 257;
    public static final int MASTER_OUT_X = 283;
    public static final int MASTER_Y = 32;

    private final BlockPos pos;
    /** Client side only: which page of the setup screen is showing (0 = rows, 1 = round buttons). */
    public int page = 0;
    /** Client side only: false for the Effects Panel, which has no master switch or round buttons. */
    public boolean extras = true;

    /** Client side: built from the data the server sent. */
    public PanelMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, new SimpleContainer(GHOST_SLOTS), buf.readBlockPos());
    }

    /** Server side. */
    public PanelMenu(int id, Inventory playerInv, SimpleContainer container, BlockPos pos) {
        super(CoasterControlPanel.PANEL_MENU.get(), id);
        this.pos = pos;

        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            int y = ROW_Y + ROW_STEP * (r % PanelBlockEntity.RECT);
            addSlot(new GhostSlot(this, container, r * 2, IN_X, y, r));
            addSlot(new GhostSlot(this, container, r * 2 + 1, OUT_X, y, r));
        }
        addSlot(new GhostSlot(this, container, PanelBlockEntity.MASTER * 2, MASTER_IN_X, MASTER_Y,
                PanelBlockEntity.MASTER));
        addSlot(new GhostSlot(this, container, PanelBlockEntity.MASTER * 2 + 1, MASTER_OUT_X, MASTER_Y,
                PanelBlockEntity.MASTER));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInv, col + row * 9 + 9, 257 + col * 18, 108 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInv, col, 257 + col * 18, 168));
        }
    }

    public BlockPos getPos() {
        return pos;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < GHOST_SLOTS) {
            Slot slot = slots.get(slotId);
            ItemStack carried = getCarried();
            if (carried.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.set(carried.copyWithCount(1));
            }
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }

    boolean channelVisible(int channel) {
        if (channel == PanelBlockEntity.MASTER) {
            return extras;
        }
        if (channel < PanelBlockEntity.RECT) {
            return page == 0;
        }
        return extras && page == 1;
    }

    private static class GhostSlot extends Slot {
        private final PanelMenu menu;
        private final int channel;

        GhostSlot(PanelMenu menu, Container container, int index, int x, int y, int channel) {
            super(container, index, x, y);
            this.menu = menu;
            this.channel = channel;
        }

        @Override
        public boolean isActive() {
            return menu.channelVisible(channel);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }

        @Override
        public boolean mayPickup(Player player) {
            return false;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
