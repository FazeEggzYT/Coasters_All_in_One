package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Ghost slots for the Redstone Link items of a zone controller (as many as its type has), plus your inventory. */
public class ZoneMenu extends AbstractContainerMenu {
    private final BlockPos pos;
    private final ZoneType type;

    public ZoneMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, new SimpleContainer(ZoneType.MAX_SLOTS), buf.readBlockPos(),
                ZoneType.values()[Math.floorMod(buf.readVarInt(), ZoneType.values().length)]);
    }

    public ZoneMenu(int id, Inventory playerInv, SimpleContainer container, BlockPos pos, ZoneType type) {
        super(CoasterControlPanel.ZONE_MENU.get(), id);
        this.pos = pos;
        this.type = type;
        for (int i = 0; i < type.slots(); i++) {
            addSlot(new GhostSlot(container, i, 160, 18 + i * 19));
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInv, col + row * 9 + 9, 199 + col * 18, 104 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInv, col, 199 + col * 18, 162));
        }
    }

    public BlockPos getPos() {
        return pos;
    }

    public ZoneType zoneType() {
        return type;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < type.slots()) {
            ItemStack carried = getCarried();
            slots.get(slotId).set(carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1));
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }

    private static class GhostSlot extends Slot {
        GhostSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }

        @Override
        public boolean mayPickup(Player player) {
            return false;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
