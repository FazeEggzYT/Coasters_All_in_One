package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client to server for the arcade screens. Actions: 0 start a game (a = sub-game), 1 finish (a = score, b = extra),
 * 2 claw drop (a = slot, b = closeness), 10 token exchange (a = nuggets, 0 = up to 64), 11 token rate (a = change),
 * 20 prize buy (a = row), 21 prize price (a = row, b = change), 22 prize remove (a = row).
 */
public record ArcadeActionPacket(BlockPos pos, int action, int a, int b) implements CustomPacketPayload {
    public static final Type<ArcadeActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "arcade_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ArcadeActionPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.a + 1000);
                buf.writeVarInt(p.b + 1000);
            },
            buf -> new ArcadeActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt() - 1000, buf.readVarInt() - 1000));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ArcadeActionPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        Level level = player.level();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 144.0 || !level.isLoaded(p.pos)) {
            return;
        }
        switch (p.action) {
            case 0, 1, 2 -> {
                if (level.getBlockEntity(p.pos) instanceof ArcadeBlocks.ArcadeBlockEntity be) {
                    if (p.action == 0) {
                        be.start(player, p.a);
                    } else if (p.action == 1) {
                        be.finish(player, p.a, p.b);
                    } else {
                        be.claw(player, p.a, p.b);
                    }
                }
            }
            case 10, 11 -> {
                if (level.getBlockEntity(p.pos) instanceof ArcadeBlocks.TokenBlockEntity be) {
                    if (p.action == 10) {
                        be.exchange(player, p.a);
                    } else {
                        be.changeRate(p.a);
                    }
                }
            }
            case 20, 21, 22 -> {
                if (level.getBlockEntity(p.pos) instanceof ArcadeBlocks.PrizeBlockEntity be) {
                    if (p.action == 20) {
                        be.buy(player, p.a);
                    } else if (p.action == 21) {
                        be.changePrice(p.a, p.b);
                    } else {
                        be.clearOffer(p.a);
                    }
                }
            }
            default -> {
            }
        }
    }
}
