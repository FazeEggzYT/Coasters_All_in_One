package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.DriveTyre;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Drive Tyre: marks the span of HotbarScopeMixin's chain checks so a held Drive Tyre is accepted as a Chain there. Optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.SimulatedCoastersClient", remap = false)
public class HotbarScopeMixin {
    @Inject(method = {"tickClearHotbarSelectionWhenHotbarChanges"}, at = @At("HEAD"), remap = false, require = 0)
    private static void ccp$enter(CallbackInfo ci) {
        DriveTyre.enter();
    }

    @Inject(method = {"tickClearHotbarSelectionWhenHotbarChanges"}, at = @At("RETURN"), remap = false, require = 0)
    private static void ccp$exit(CallbackInfo ci) {
        DriveTyre.exit();
    }
}
