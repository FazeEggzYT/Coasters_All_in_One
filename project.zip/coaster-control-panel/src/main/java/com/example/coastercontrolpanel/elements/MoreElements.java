package com.example.coastercontrolpanel.elements;

import java.util.List;

/** The second batch of elements. Same rules as {@link TrackElement}: start upright and straight, end level and upright. */
final class MoreElements {
    private MoreElements() {
    }

    private static double sm(double t) {
        return TrackElements.smooth(t);
    }

    private static double pl(double u, double ramp) {
        return TrackElements.plateau(u, ramp);
    }

    private static double sq(double v) {
        return v * v;
    }

    /** 0 at both ends with zero slope, rising to 1 over the element. */
    private static double drift(double u) {
        return u - Math.sin(2.0 * Math.PI * u) / (2.0 * Math.PI);
    }

    private static Pose roll(double u, Params p, double r, double len, double turns) {
        double phi = 2.0 * Math.PI * turns * u;
        double env = sq(Math.sin(Math.PI * u));
        return new Pose(p.side() * r * env * Math.sin(phi), r * env * (1.0 - Math.cos(phi)), len * u, p.side() * phi);
    }

    private static Pose flatTurn(double u, Params p, double r, double sweep, double bankDeg, double y) {
        double th = sweep * u;
        double bank = Math.toRadians(bankDeg) * pl(u, 0.25);
        return new Pose(p.side() * r * (1.0 - Math.cos(th)), y, r * Math.sin(th), -p.side() * bank);
    }

    static final List<TrackElement> LIST = List.of(
            // ================================================================ inversions
            new TrackElement("inline_twist", "inversions", true, false, (u, p) -> roll(u, p, 0.9 + 0.4 * p.size(), 18.0 + 5.0 * p.size(), 2.0)),
            new TrackElement("double_corkscrew", "inversions", true, false, (u, p) -> roll(u, p, 1.5 + 0.8 * p.size(), 18.0 + 6.0 * p.size(), 2.0)),
            new TrackElement("heartline_roll", "inversions", true, false, (u, p) -> roll(u, p, 0.5 + 0.2 * p.size(), 10.0 + 3.0 * p.size(), 1.0)),
            new TrackElement("sea_serpent", "inversions", true, false, (u, p) -> {
                double r = 2.0 + 0.8 * p.size();
                return new Pose(p.side() * 1.5 * r * Math.sin(2.0 * Math.PI * u) * sq(Math.sin(Math.PI * u)), 0.0,
                        (16.0 + 5.0 * p.size()) * u, p.side() * Math.PI * (1.0 - Math.cos(2.0 * Math.PI * u)));
            }),
            new TrackElement("tilted_loop", "inversions", true, false, (u, p) -> {
                double r = 3.0 + 3.0 * p.size();
                double th = 2.0 * Math.PI * u;
                double dy = r * (1.0 - Math.cos(th));
                double a = p.side() * Math.toRadians(35.0);
                return new Pose(-Math.sin(a) * dy + p.side() * (2.0 + p.size()) * drift(u), Math.cos(a) * dy, r * Math.sin(th), 0.0);
            }),
            new TrackElement("teardrop_loop", "inversions", true, false, (u, p) -> {
                double r = 3.0 + 3.0 * p.size();
                double th = 2.0 * Math.PI * u;
                double dy = r * (1.0 - Math.cos(th)) * (1.0 + 0.25 * sq(Math.sin(th / 2.0)));
                double k = 1.0 - 0.35 * (1.0 - Math.cos(th)) / 2.0;
                return new Pose(p.side() * (2.0 + p.size()) * drift(u), dy, r * Math.sin(th) * k, 0.0);
            }),
            new TrackElement("tall_loop", "inversions", true, false, (u, p) -> {
                double r = 3.0 + 2.5 * p.size();
                double th = 2.0 * Math.PI * u;
                return new Pose(p.side() * (2.0 + p.size()) * drift(u), 1.35 * r * (1.0 - Math.cos(th)), 0.85 * r * Math.sin(th), 0.0);
            }),
            new TrackElement("aileron_roll", "inversions", true, false, (u, p) ->
                    new Pose(0.0, 0.0, (16.0 + 6.0 * p.size()) * u, p.side() * 2.0 * Math.PI * sm(u))),
            new TrackElement("wide_loop", "inversions", true, false, (u, p) -> {
                double r = 3.0 + 3.0 * p.size();
                double th = 2.0 * Math.PI * u;
                return new Pose(p.side() * (6.0 + 3.0 * p.size()) * drift(u), r * (1.0 - Math.cos(th)), r * Math.sin(th), 0.0);
            }),

            // ================================================================ hills
            new TrackElement("bunny_hops", "hills", false, true, (u, p) ->
                    new Pose(0.0, (1.2 + 0.5 * p.size() + 0.4 * p.rise()) * sq(Math.sin(3.0 * Math.PI * u)), (18.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("stair_climb", "hills", false, true, (u, p) -> {
                double a = 1.5 + 0.5 * p.size() + 0.5 * p.rise();
                double y = u < 0.5 ? a * sm(2.0 * u) : a + a * sm(2.0 * u - 1.0);
                return new Pose(0.0, y, (16.0 + 4.0 * p.size()) * u, 0.0);
            }),
            new TrackElement("twin_peaks", "hills", false, true, (u, p) ->
                    new Pose(0.0, (3.0 + p.size() + p.rise()) * sq(Math.sin(2.0 * Math.PI * u)) * (1.0 - 0.45 * u), (16.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("top_hat", "hills", false, true, (u, p) -> {
                double h = 8.0 + 3.0 * p.size() + 2.0 * p.rise();
                return new Pose(0.0, h * pl(u, 0.35), (h * 1.7 + 4.0) * u, 0.0);
            }),
            new TrackElement("speed_hill", "hills", false, true, (u, p) ->
                    new Pose(0.0, (1.4 + 0.5 * p.size() + 0.3 * p.rise()) * sq(Math.sin(Math.PI * u)), (20.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("dive_hill", "hills", false, true, (u, p) -> {
                double h = 3.0 + p.size() + p.rise();
                double d = 2.0 + p.rise();
                return new Pose(0.0, h * sq(Math.sin(Math.PI * u)) - d * sm(u), (14.0 + 5.0 * p.size()) * u, 0.0);
            }),
            new TrackElement("valley", "hills", false, true, (u, p) ->
                    new Pose(0.0, -(2.5 + p.size() + p.rise()) * sq(Math.sin(Math.PI * u)), (14.0 + 5.0 * p.size()) * u, 0.0)),
            new TrackElement("tabletop", "hills", false, true, (u, p) ->
                    new Pose(0.0, (3.0 + p.size() + p.rise()) * pl(u, 0.28), (18.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("ramp_up", "hills", false, true, (u, p) -> {
                double h = 6.0 + 3.0 * p.size() + 2.0 * p.rise();
                return new Pose(0.0, h * sm(u), h * 1.1 * u, 0.0);
            }),
            new TrackElement("gentle_climb", "hills", false, true, (u, p) ->
                    new Pose(0.0, (3.0 + p.size() + p.rise()) * sm(u), (18.0 + 8.0 * p.size()) * u, 0.0)),
            new TrackElement("gentle_drop", "hills", false, true, (u, p) ->
                    new Pose(0.0, -(3.0 + p.size() + p.rise()) * sm(u), (18.0 + 8.0 * p.size()) * u, 0.0)),

            // ================================================================ turns
            new TrackElement("flat_turn", "turns", true, false, (u, p) -> flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 0.0, 0.0)),
            new TrackElement("flat_u_turn", "turns", true, false, (u, p) -> flatTurn(u, p, 3.0 + 2.0 * p.size(), Math.PI, 0.0, 0.0)),
            new TrackElement("banked_u_turn", "turns", true, false, (u, p) -> flatTurn(u, p, 3.0 + 2.0 * p.size(), Math.PI, 35.0, 0.0)),
            new TrackElement("hairpin", "turns", true, false, (u, p) -> flatTurn(u, p, 2.0 + 1.2 * p.size(), Math.PI, 55.0, 0.0)),
            new TrackElement("wide_sweep", "turns", true, false, (u, p) -> flatTurn(u, p, 8.0 + 4.0 * p.size(), 0.5 * Math.PI, 30.0, 0.0)),
            new TrackElement("wide_u_turn", "turns", true, false, (u, p) -> flatTurn(u, p, 8.0 + 3.0 * p.size(), Math.PI, 30.0, 0.0)),
            new TrackElement("carousel", "turns", true, false, (u, p) -> flatTurn(u, p, 4.0 + 2.0 * p.size(), 1.5 * Math.PI, 40.0, 0.0)),
            new TrackElement("helix_up", "turns", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 1.5 * p.size(), 2.0 * Math.PI, 40.0, (3.0 + p.rise()) * sm(u))),
            new TrackElement("double_helix", "turns", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 1.5 * p.size(), 4.0 * Math.PI, 40.0, -(6.0 + 2.0 * p.rise()) * sm(u))),
            new TrackElement("wide_s_bend", "turns", true, false, (u, p) -> {
                double bank = Math.toRadians(30.0) * Math.sin(2.0 * Math.PI * u) * pl(u, 0.2);
                return new Pose(p.side() * (6.0 + 3.0 * p.size()) * sm(u), 0.0, (20.0 + 6.0 * p.size()) * u, -p.side() * bank);
            }),
            new TrackElement("chicane", "turns", true, false, (u, p) -> {
                double bank = Math.toRadians(25.0) * Math.sin(2.0 * Math.PI * u) * pl(u, 0.2);
                return new Pose(p.side() * (2.0 + p.size()) * sm(u), 0.0, (8.0 + 2.0 * p.size()) * u, -p.side() * bank);
            }),
            new TrackElement("lane_change", "turns", true, false, (u, p) ->
                    new Pose(p.side() * (4.0 + 3.0 * p.size()) * sm(u), 0.0, (14.0 + 4.0 * p.size()) * u, 0.0)),
            new TrackElement("dive_turn", "turns", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 30.0, -(3.0 + p.rise()) * sm(u))),
            new TrackElement("climbing_turn", "turns", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 30.0, (3.0 + p.rise()) * sm(u))),
            new TrackElement("overbanked_quarter", "turns", true, false, (u, p) ->
                    flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 100.0, 0.0)),
            new TrackElement("spiral_dive", "turns", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 1.5 * p.size(), 1.5 * Math.PI, 35.0, -(4.0 + 2.0 * p.rise()) * sm(u))),

            // ================================================================ drops
            new TrackElement("first_drop", "drops", false, true, (u, p) -> {
                double d = 12.0 + 6.0 * p.size() + 3.0 * p.rise();
                return new Pose(0.0, -d * sm(u), (d * 0.5 + 4.0) * u, 0.0);
            }),
            new TrackElement("rolling_drop", "drops", true, true, (u, p) -> {
                double d = 6.0 + 3.0 * p.size() + p.rise();
                return new Pose(0.0, -d * sm(u), d * 1.3 * u, p.side() * 2.0 * Math.PI * sm(u));
            }),
            new TrackElement("double_drop", "drops", false, true, (u, p) -> {
                double d = 4.0 + 2.0 * p.size() + p.rise();
                double y = u < 0.5 ? -d * sm(2.0 * u) : -d - d * sm(2.0 * u - 1.0);
                return new Pose(0.0, y, (14.0 + 5.0 * p.size()) * u, 0.0);
            }),
            new TrackElement("stepped_drop", "drops", false, true, (u, p) -> {
                double d = 3.0 + p.size() + p.rise();
                int seg = Math.min(2, (int) Math.floor(u * 3.0));
                return new Pose(0.0, -d * (seg + sm(u * 3.0 - seg)), (18.0 + 6.0 * p.size()) * u, 0.0);
            }),
            new TrackElement("plunge", "drops", false, true, (u, p) -> {
                double d = 10.0 + 5.0 * p.size() + 2.0 * p.rise();
                return new Pose(0.0, -d * sm(u), (d * 0.28 + 3.0) * u, 0.0);
            }),
            new TrackElement("dive_camelback", "drops", false, true, (u, p) ->
                    new Pose(0.0, (3.0 + p.size()) * sq(Math.sin(2.0 * Math.PI * u)) - (4.0 + 2.0 * p.size() + p.rise()) * sm(u),
                            (18.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("plunge_helix", "drops", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 1.5 * p.size(), 2.0 * Math.PI, 40.0, -(8.0 + 2.0 * p.size() + 2.0 * p.rise()) * sm(u))),
            new TrackElement("slide_drop", "drops", true, true, (u, p) -> {
                double d = 5.0 + 2.0 * p.size() + p.rise();
                return new Pose(p.side() * (3.0 + 2.0 * p.size()) * sm(u), -d * sm(u), (d * 1.2 + 4.0) * u, 0.0);
            }),

            // ================================================================ specials
            new TrackElement("straight", "specials", false, false, (u, p) -> new Pose(0.0, 0.0, (6.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("slalom", "specials", true, false, (u, p) ->
                    new Pose(p.side() * (2.0 + p.size()) * 2.0 * Math.sin(2.0 * Math.PI * u) * sq(Math.sin(Math.PI * u)), 0.0, (14.0 + 5.0 * p.size()) * u, 0.0)),
            new TrackElement("double_slalom", "specials", true, false, (u, p) ->
                    new Pose(p.side() * (2.0 + p.size()) * 2.0 * Math.sin(4.0 * Math.PI * u) * sq(Math.sin(Math.PI * u)), 0.0, (20.0 + 6.0 * p.size()) * u, 0.0)),
            new TrackElement("wiggle", "specials", true, false, (u, p) ->
                    new Pose(p.side() * (1.0 + 0.6 * p.size()) * 2.0 * Math.sin(3.0 * Math.PI * u) * sq(Math.sin(Math.PI * u)), 0.0, (12.0 + 4.0 * p.size()) * u, 0.0)),
            new TrackElement("rocker", "specials", true, false, (u, p) ->
                    new Pose(0.0, 0.0, (14.0 + 4.0 * p.size()) * u, p.side() * Math.toRadians(30.0) * Math.sin(2.0 * Math.PI * u) * pl(u, 0.25))),
            new TrackElement("dip_turn", "specials", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 30.0, -(2.0 + p.rise()) * sq(Math.sin(Math.PI * u)))),
            new TrackElement("hill_turn", "specials", true, true, (u, p) ->
                    flatTurn(u, p, 3.0 + 2.0 * p.size(), 0.5 * Math.PI, 30.0, (2.0 + p.size() + p.rise()) * sq(Math.sin(Math.PI * u)))),
            new TrackElement("banked_hill_turn", "specials", true, true, (u, p) ->
                    flatTurn(u, p, 4.0 + 2.0 * p.size(), Math.PI, 35.0, (2.0 + p.size() + p.rise()) * sq(Math.sin(Math.PI * u)))),
            new TrackElement("dip_tunnel", "specials", false, true, (u, p) ->
                    new Pose(0.0, -(3.0 + p.size() + p.rise()) * pl(u, 0.25), (18.0 + 5.0 * p.size()) * u, 0.0))
    );
}
