package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/** A ride block entity that has a settings screen and Start / Pause / End controls (Drop Tower, Swing Ride). */
public interface RideEngine {
    int ACTION_START = 0;
    int ACTION_PAUSE = 1;
    int ACTION_END = 2;
    /** Emergency stop: brakes the ride at once, wherever it is. */
    int ACTION_HALT = 3;

    boolean idle();

    void applyConfig(CompoundTag tag);

    void control(int action);

    void refreshRedstone();
}
