package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Makes one effect while its signal is on (Redstone Link, and optionally plain redstone).
 * All settings live in the int array {@link #s}; the indices are the S_ constants.
 */
public class EffectBlockEntity extends BlockEntity {
    public static final int S_EFFECT = 0;
    public static final int S_AMOUNT = 1;
    public static final int S_SPREAD = 2;
    public static final int S_SPEED = 3;
    public static final int S_RATE = 4;
    public static final int S_SIZE = 5;
    public static final int S_OFFSET = 6;
    public static final int S_RUN = 7;
    public static final int S_DELAY = 8;
    public static final int S_COLOR = 9;
    public static final int S_FADE = 10;
    public static final int S_SOUND = 11;
    public static final int S_REDSTONE = 12;
    public static final int S_SHAPE = 13;
    public static final int S_TRAIL = 14;
    public static final int S_TWINKLE = 15;
    public static final int S_FLIGHT = 16;
    public static final int COUNT = 17;

    public static final int[] MIN = {0, 1, 0, 10, 1, 25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1};
    public static final int[] MAX = {EffectType.values().length - 1, 20, 100, 300, 20, 300, 40, 60, 10, 16, 16, 1, 1, 4, 1, 1, 3};
    public static final int[] DEF = {0, 2, 15, 100, 2, 100, 2, 0, 0, 16, 16, 1, 0, 1, 1, 0, 2};
    private static final String[] KEYS = {"Effect", "Amount", "Spread", "Speed", "Rate", "Size", "Offset", "Run",
            "Delay", "Color", "Fade", "Sound", "Redstone", "Shape", "Trail", "Twinkle", "Flight"};

    private final int[] s = DEF.clone();
    private final SimpleContainer frequency = new SimpleContainer(1);
    private final Link link = new Link();
    private boolean registered = false;
    private boolean loading = false;
    private int received = 0;

    private boolean wasActive = false;
    private int elapsed = -1;
    private int testTicks = 0;

    public EffectBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.EFFECT_BE.get(), pos, state);
        s[S_AMOUNT] = EffectType.byIndex(0).defAmount;
        s[S_RATE] = EffectType.byIndex(0).defRate;
        frequency.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLink();
                    registerLink();
                }
            }
        });
    }

    public SimpleContainer getFrequency() {
        return frequency;
    }

    public int get(int index) {
        return s[index];
    }

    @Nullable
    public static EffectBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof EffectBlockEntity e ? e : null;
    }

    // ---------------------------------------------------------------- link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLink();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLink();
    }

    @Override
    public void setRemoved() {
        unregisterLink();
        super.setRemoved();
    }

    private void registerLink() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        ItemStack stack = frequency.getItem(0);
        link.alive = !stack.isEmpty();
        link.key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        received = 0;
        if (link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, link);
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, link);
        }
    }

    private void unregisterLink() {
        if (!registered) {
            return;
        }
        registered = false;
        if (level != null && link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, link);
        }
        link.alive = false;
        received = 0;
    }

    // ---------------------------------------------------------------- settings

    public void applyConfig(int[] values) {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int i = 0; i < COUNT && i < values.length; i++) {
            s[i] = Math.max(MIN[i], Math.min(MAX[i], values[i]));
        }
        setChanged();
        BlockState state = getBlockState();
        level.sendBlockUpdated(worldPosition, state, state, 3);
    }

    /** Run the effect for three seconds, whatever the signal says. */
    public void test() {
        testTicks = 60;
    }

    // ---------------------------------------------------------------- behaviour

    public void serverTick() {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        boolean signal = received > 0 || (s[S_REDSTONE] == 1 && server.hasNeighborSignal(worldPosition));
        boolean active = signal || testTicks > 0;
        if (testTicks > 0) {
            testTicks--;
        }
        if (!active) {
            wasActive = false;
            elapsed = -1;
            return;
        }
        if (!wasActive) {
            elapsed = 0;
        }
        wasActive = true;
        elapsed++;
        int start = s[S_DELAY] * 20;
        if (elapsed <= start) {
            return;
        }
        if (s[S_RUN] > 0 && elapsed > start + s[S_RUN] * 20 && testTicks <= 0) {
            return;
        }
        EffectType type = EffectType.byIndex(s[S_EFFECT]);
        int interval = type.isFirework() ? s[S_RATE] * 10 : s[S_RATE];
        if ((elapsed - start) % Math.max(1, interval) != 0) {
            return;
        }
        emit(server, type);
    }

    private void emit(ServerLevel server, EffectType type) {
        Direction facing = getBlockState().getValue(EffectBlock.FACING);
        double dist = 0.55 + s[S_OFFSET] / 10.0;
        double ox = worldPosition.getX() + 0.5 + facing.getStepX() * dist;
        double oy = worldPosition.getY() + 0.5 + facing.getStepY() * dist;
        double oz = worldPosition.getZ() + 0.5 + facing.getStepZ() * dist;
        RandomSource rand = server.random;
        double spread = s[S_SPREAD] / 100.0;
        double speed = type.baseSpeed * s[S_SPEED] / 100.0;

        if (type.isFirework()) {
            launchRockets(server, type, ox, oy, oz, facing, rand, spread, speed);
            return;
        }
        int color = rgb(s[S_COLOR]);
        int fade = rgb(s[S_FADE]);
        float size = s[S_SIZE] / 100.0F;
        double side = 0.12 + spread * 0.4;
        for (int i = 0; i < s[S_AMOUNT]; i++) {
            ParticleOptions options = type.options(color, fade, size);
            if (options == null) {
                continue;
            }
            double vx = facing.getStepX() * speed + (rand.nextDouble() - 0.5) * 2 * speed * spread;
            double vy = facing.getStepY() * speed + (rand.nextDouble() - 0.5) * 2 * speed * spread;
            double vz = facing.getStepZ() * speed + (rand.nextDouble() - 0.5) * 2 * speed * spread;
            double px = ox + (rand.nextDouble() - 0.5) * side * (1 - Math.abs(facing.getStepX()));
            double py = oy + (rand.nextDouble() - 0.5) * side * (1 - Math.abs(facing.getStepY()));
            double pz = oz + (rand.nextDouble() - 0.5) * side * (1 - Math.abs(facing.getStepZ()));
            // count 0 means the three numbers are the particle's velocity
            server.sendParticles(options, px, py, pz, 0, vx, vy, vz, 1.0);
        }
        if (s[S_SOUND] == 1 && type.sound != null && elapsed % 8 == 0) {
            server.playSound(null, worldPosition, type.sound, SoundSource.BLOCKS, 0.5F, 1.0F);
        }
    }

    private void launchRockets(ServerLevel server, EffectType type, double ox, double oy, double oz,
                               Direction facing, RandomSource rand, double spread, double speed) {
        int count = type == EffectType.ROCKET || type == EffectType.CANNON ? 1 : s[S_AMOUNT];
        for (int i = 0; i < count; i++) {
            ItemStack stack = new ItemStack(Items.FIREWORK_ROCKET);
            stack.set(DataComponents.FIREWORKS, new Fireworks(
                    type == EffectType.CANNON ? 1 : s[S_FLIGHT], List.of(explosion(rand))));
            FireworkRocketEntity rocket = new FireworkRocketEntity(server, stack, ox, oy, oz, true);
            double vx = facing.getStepX() + (rand.nextDouble() - 0.5) * 2 * spread * 0.5;
            double vy = facing.getStepY() + (rand.nextDouble() - 0.5) * 2 * spread * 0.5;
            double vz = facing.getStepZ() + (rand.nextDouble() - 0.5) * 2 * spread * 0.5;
            rocket.shoot(vx, vy, vz, (float) speed, 1.0F);
            server.addFreshEntity(rocket);
        }
    }

    private FireworkExplosion explosion(RandomSource rand) {
        FireworkExplosion.Shape[] shapes = FireworkExplosion.Shape.values();
        FireworkExplosion.Shape shape = shapes[Math.min(s[S_SHAPE], shapes.length - 1)];
        int c = s[S_COLOR] >= 16 ? DyeColor.byId(rand.nextInt(16)).getFireworkColor() : rgb(s[S_COLOR]);
        int f = s[S_FADE] >= 16 ? DyeColor.byId(rand.nextInt(16)).getFireworkColor() : rgb(s[S_FADE]);
        return new FireworkExplosion(shape, new IntArrayList(new int[]{c}), new IntArrayList(new int[]{f}),
                s[S_TRAIL] == 1, s[S_TWINKLE] == 1);
    }

    /** Colour setting 0..15 are the dyes; 16 is random each time. */
    private static int rgb(int setting) {
        if (setting >= 16) {
            return DyeColor.byId((int) (Math.random() * 16)).getFireworkColor();
        }
        return DyeColor.byId(setting).getFireworkColor();
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        list.set(0, frequency.getItem(0));
        ContainerHelper.saveAllItems(tag, list, registries);
        for (int i = 0; i < COUNT; i++) {
            tag.putInt(KEYS[i], s[i]);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        frequency.setItem(0, list.get(0));
        for (int i = 0; i < COUNT; i++) {
            if (tag.contains(KEYS[i])) {
                s[i] = Math.max(MIN[i], Math.min(MAX[i], tag.getInt(KEYS[i])));
            }
        }
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- the Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        @Override
        public int getTransmittedStrength() {
            return 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            received = power;
        }

        @Override
        public boolean isListening() {
            return true;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
