package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterTools;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Track Unrestrictor: the anchor facing / bend rules ("facing opposite directions", "impossible bend"...). Optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlock", remap = false)
public class AnchorShapeLimitMixin {
    @Inject(method = "haveOppositeFacing", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$opposite(BlockState a, BlockState b, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "haveSameFacingCollinearAlongFacing", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$collinear(BlockState a, BlockState b, BlockPos pa, BlockPos pb, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "connectionHasImpossibleBend", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$bend(BlockState a, BlockState b, BlockPos pa, BlockPos pb, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "connectionReversesOnSameFacingCoplanarPlane", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$reverse(Level level, BlockPos pa, BlockPos pb, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }
}
