package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: all the settings of a zone controller. */
public record ZoneConfigPacket(BlockPos pos, int clear, int s1, int s2, boolean redstone,
                               boolean show, boolean clearTrack) implements CustomPacketPayload {
    public static final Type<ZoneConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "zone_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ZoneConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.clear);
                buf.writeVarInt(p.s1);
                buf.writeVarInt(p.s2);
                buf.writeBoolean(p.redstone);
                buf.writeBoolean(p.show);
                buf.writeBoolean(p.clearTrack);
            },
            buf -> new ZoneConfigPacket(buf.readBlockPos(), buf.readVarInt(),
                    buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ZoneConfigPacket p, IPayloadContext context) {
        ZoneBlockEntity zone = ZoneBlockEntity.lookup(context.player(), p.pos);
        if (zone == null) {
            return;
        }
        zone.applyConfig(p.clear, p.s1, p.s2, p.redstone);
        if (p.clearTrack) {
            zone.clearTrack();
        }
        if (p.show) {
            zone.showArea();
        }
    }
}
