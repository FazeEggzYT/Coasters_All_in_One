package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/** The screens of the Restaurant and Cafe pack. */
public final class RestaurantScreens {
    private RestaurantScreens() {
    }

    abstract static class Base extends Screen {
        protected final BlockPos pos;
        protected final int w;
        protected final int h;
        protected int left;
        protected int top;

        protected Base(Component title, BlockPos pos, int w, int h) {
            super(title);
            this.pos = pos;
            this.w = w;
            this.h = h;
        }

        @Override
        protected void init() {
            left = (width - w) / 2;
            top = (height - h) / 2;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                    .bounds(left + w - 52, top + h - 22, 44, 16).build());
            build();
        }

        protected abstract void build();

        protected void act(int action, int a, int b) {
            PacketDistributor.sendToServer(new RestaurantActionPacket(pos, action, a, b));
        }

        @Override
        public boolean isPauseScreen() {
            return false;
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            renderTransparentBackground(g);
            g.fill(left, top, left + w, top + h, 0xFF3A3E4D);
            g.fill(left + 1, top + 1, left + w - 1, top + h - 1, 0xFF1B1D24);
            g.drawString(font, title, left + 8, top + 7, 0xFFFFFF, false);
        }

        protected BlockState state() {
            return minecraft != null && minecraft.level != null ? minecraft.level.getBlockState(pos) : null;
        }
    }

    // ------------------------------------------------------------------ options (table, chair, booth, parasol)

    public static class OptionsScreen extends Base {
        private RestaurantConfigurable.Option[] options = new RestaurantConfigurable.Option[0];

        public OptionsScreen(BlockPos pos) {
            super(Component.translatable("gui.coastercontrolpanel.options_title"), pos, 230, 130);
        }

        @Override
        protected void build() {
            BlockState s = state();
            if (s != null && s.getBlock() instanceof RestaurantConfigurable c) {
                options = c.options();
            }
            for (int i = 0; i < options.length; i++) {
                final int idx = i;
                int y = top + 24 + i * 22;
                addRenderableWidget(Button.builder(Component.literal("<"), b -> step(idx, -1)).bounds(left + 108, y, 18, 16).build());
                addRenderableWidget(Button.builder(Component.literal(">"), b -> step(idx, 1)).bounds(left + 204, y, 18, 16).build());
            }
        }

        private void step(int idx, int dir) {
            BlockState s = state();
            if (s == null) {
                return;
            }
            RestaurantConfigurable.Option o = options[idx];
            int n = o.max() + 1;
            int v = Math.floorMod(RestaurantConfigurable.get(s, o) + dir, n);
            act(100, idx, v);
        }

        private Component valueText(BlockState s, RestaurantConfigurable.Option o) {
            int v = RestaurantConfigurable.get(s, o);
            if (o.key().equals("color")) {
                String n = DyeColor.byId(v).getName().replace('_', ' ');
                return Component.literal(Character.toUpperCase(n.charAt(0)) + n.substring(1));
            }
            if (o.max() == 1) {
                return Component.translatable(v == 1 ? "gui.coastercontrolpanel.on" : "gui.coastercontrolpanel.off");
            }
            return Component.translatable("gui.coastercontrolpanel.opt." + o.key() + "." + v);
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            BlockState s = state();
            if (s == null) {
                return;
            }
            for (int i = 0; i < options.length; i++) {
                int y = top + 28 + i * 22;
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.opt." + options[i].key()), left + 8, y, 0xE0E4F0, false);
                g.drawCenteredString(font, valueText(s, options[i]), left + 165, y, 0xFFFFFF);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.options_help"), left + 8, top + h - 18, 0x9AA0B4, false);
        }
    }

    // ------------------------------------------------------------------ kiosk

    public static class KioskScreen extends Base {
        private boolean setup;
        private Button[] main = new Button[RestaurantBlocks.KioskBlockEntity.SLOTS];

        public KioskScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.order_kiosk"), pos, 270, 212);
        }

        private RestaurantBlocks.KioskBlockEntity kiosk() {
            return minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof RestaurantBlocks.KioskBlockEntity k ? k : null;
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable(setup ? "gui.coastercontrolpanel.kiosk_done" : "gui.coastercontrolpanel.kiosk_setup"),
                    b -> {
                        setup = !setup;
                        rebuildWidgets();
                    }).bounds(left + 8, top + h - 22, 70, 16).build());
            for (int i = 0; i < RestaurantBlocks.KioskBlockEntity.SLOTS; i++) {
                final int row = i;
                int y = top + 24 + i * 24;
                if (!setup) {
                    main[i] = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_order"),
                            b -> act(0, row, 0)).bounds(left + w - 62, y, 54, 18).build());
                } else {
                    addRenderableWidget(Button.builder(Component.literal("-"), b -> act(1, row, -1)).bounds(left + w - 92, y, 18, 18).build());
                    addRenderableWidget(Button.builder(Component.literal("+"), b -> act(1, row, 1)).bounds(left + w - 72, y, 18, 18).build());
                    addRenderableWidget(Button.builder(Component.literal("x"), b -> act(2, row, 0)).bounds(left + w - 28, y, 20, 18).build());
                }
            }
        }

        @Override
        public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            RestaurantBlocks.KioskBlockEntity k = kiosk();
            if (!setup) {
                for (int i = 0; i < main.length; i++) {
                    if (main[i] != null) {
                        main[i].active = k != null && !k.offers[i].isEmpty();
                    }
                }
            }
            super.render(g, mouseX, mouseY, partialTick);
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            RestaurantBlocks.KioskBlockEntity k = kiosk();
            if (k == null) {
                return;
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.kiosk_next", k.nextNumber), left + w - 100, top + 7, 0xE8A93A, false);
            for (int i = 0; i < RestaurantBlocks.KioskBlockEntity.SLOTS; i++) {
                int y = top + 24 + i * 24;
                g.fill(left + 6, y - 2, left + w - 6, y + 20, 0xFF23262F);
                ItemStack st = k.offers[i];
                if (st.isEmpty()) {
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.kiosk_empty"), left + 14, y + 5, 0x6A6F80, false);
                    continue;
                }
                g.renderFakeItem(st, left + 10, y);
                g.drawString(font, font.plainSubstrByWidth(st.getHoverName().getString(), 110), left + 32, y + 5, 0xFFFFFF, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.kiosk_price", k.prices[i]), left + 146, y + 5, 0xE8A93A, false);
            }
            g.drawString(font, Component.translatable(setup ? "gui.coastercontrolpanel.kiosk_help_setup" : "gui.coastercontrolpanel.kiosk_help"),
                    left + 84, top + h - 18, 0x9AA0B4, false);
        }
    }

    // ------------------------------------------------------------------ register

    public static class RegisterScreen extends Base {
        public RegisterScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.cash_register"), pos, 250, 212);
        }

        private RestaurantBlocks.KioskBlockEntity kiosk() {
            return minecraft != null && minecraft.level != null ? RestaurantBlocks.findKiosk(minecraft.level, pos) : null;
        }

        private List<RestaurantBlocks.Order> pending() {
            RestaurantBlocks.KioskBlockEntity k = kiosk();
            return k == null ? List.of() : k.orders.stream().filter(o -> !o.ready()).toList();
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.register_all"), b -> act(11, 0, 0))
                    .bounds(left + 8, top + h - 22, 70, 16).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.register_clear"), b -> act(12, 0, 0))
                    .bounds(left + 82, top + h - 22, 70, 16).build());
            for (int i = 0; i < 7; i++) {
                final int row = i;
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.register_ready"), b -> {
                    List<RestaurantBlocks.Order> p = pending();
                    if (row < p.size()) {
                        act(10, p.get(row).number(), 0);
                    }
                }).bounds(left + w - 62, top + 34 + i * 22, 54, 18).build());
            }
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            RestaurantBlocks.KioskBlockEntity k = kiosk();
            if (k == null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.register_nokiosk"), left + 8, top + 30, 0xE07070, false);
                return;
            }
            List<RestaurantBlocks.Order> p = pending();
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.register_count", p.size(), k.readyNumbers().size()),
                    left + 8, top + 22, 0x9AA0B4, false);
            for (int i = 0; i < 7; i++) {
                int y = top + 32 + i * 22;
                g.fill(left + 6, y, left + w - 6, y + 20, 0xFF23262F);
                if (i < p.size()) {
                    RestaurantBlocks.Order o = p.get(i);
                    g.drawString(font, "#" + o.number(), left + 12, y + 6, 0xE8A93A, false);
                    g.renderFakeItem(o.item(), left + 48, y + 2);
                    g.drawString(font, font.plainSubstrByWidth(o.item().getHoverName().getString(), 110), left + 70, y + 6, 0xFFFFFF, false);
                }
            }
            if (p.size() > 7) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.register_more", p.size() - 7), left + 160, top + 22, 0x9AA0B4, false);
            }
        }
    }

    // ------------------------------------------------------------------ pickup display

    public static class PickupScreen extends Base {
        public PickupScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.pickup_display"), pos, 230, 130);
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.pickup_collect"), b -> act(20, 0, 0))
                    .bounds(left + 8, top + 90, 130, 20).build());
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            if (minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof RestaurantBlocks.PickupBlockEntity b) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.pickup_preparing", b.preparing), left + 8, top + 26, 0x9AA0B4, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.pickup_ready"), left + 8, top + 42, 0x6FE08A, false);
                StringBuilder sb = new StringBuilder();
                for (int n : b.ready) {
                    sb.append('#').append(n).append("  ");
                }
                g.drawString(font, sb.length() == 0 ? "-" : font.plainSubstrByWidth(sb.toString(), 210), left + 8, top + 56, 0xFFFFFF, false);
            }
        }
    }

    // ------------------------------------------------------------------ condiment stand

    public static class CondimentScreen extends Base {
        public CondimentScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.condiment_stand"), pos, 230, 130);
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.sauce_ketchup"), b -> act(30, 0, 0))
                    .bounds(left + 8, top + 56, 100, 18).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.sauce_mustard"), b -> act(30, 1, 0))
                    .bounds(left + 122, top + 56, 100, 18).build());
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            int ketchup = 0;
            int mustard = 0;
            if (minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof RestaurantBlocks.CondimentBlockEntity c) {
                ketchup = c.ketchup;
                mustard = c.mustard;
            }
            bar(g, left + 8, top + 30, ketchup, 0xFFC03030);
            bar(g, left + 122, top + 30, mustard, 0xFFE0C020);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.sauce_help"), left + 8, top + 84, 0x9AA0B4, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.sauce_help2"), left + 8, top + 96, 0x9AA0B4, false);
        }

        private void bar(GuiGraphics g, int x, int y, int value, int colour) {
            g.fill(x, y, x + 100, y + 14, 0xFF3A3E4D);
            g.fill(x + 1, y + 1, x + 99, y + 13, 0xFF0D0E12);
            g.fill(x + 1, y + 1, x + 1 + value * 98 / 100, y + 13, colour);
            g.drawCenteredString(font, value + "%", x + 50, y + 3, 0xFFFFFF);
        }
    }

    // ------------------------------------------------------------------ menu board

    public static class MenuBoardScreen extends Base {
        private EditBox title;
        private final EditBox[] lines = new EditBox[RestaurantBlocks.MenuBoardBlockEntity.LINES];
        private boolean auto;
        private Button autoButton;

        public MenuBoardScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.menu_board"), pos, 250, 232);
        }

        @Override
        protected void build() {
            RestaurantBlocks.MenuBoardBlockEntity b = minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof RestaurantBlocks.MenuBoardBlockEntity m ? m : null;
            if (b != null) {
                auto = b.auto;
            }
            title = new EditBox(font, left + 8, top + 22, w - 16, 16, Component.empty());
            title.setMaxLength(24);
            title.setValue(b == null ? "" : b.title);
            addRenderableWidget(title);
            for (int i = 0; i < lines.length; i++) {
                lines[i] = new EditBox(font, left + 8, top + 44 + i * 20, w - 16, 16, Component.empty());
                lines[i].setMaxLength(28);
                lines[i].setValue(b == null ? "" : b.lines[i]);
                addRenderableWidget(lines[i]);
            }
            autoButton = Button.builder(autoText(), x -> {
                auto = !auto;
                x.setMessage(autoText());
            }).bounds(left + 8, top + h - 22, 150, 16).build();
            addRenderableWidget(autoButton);
        }

        private Component autoText() {
            return Component.translatable(auto ? "gui.coastercontrolpanel.board_auto_on" : "gui.coastercontrolpanel.board_auto_off");
        }

        @Override
        public void removed() {
            String[] text = new String[lines.length];
            for (int i = 0; i < lines.length; i++) {
                text[i] = lines[i] == null ? "" : lines[i].getValue();
            }
            PacketDistributor.sendToServer(new MenuBoardPacket(pos, title == null ? "" : title.getValue(), text, auto));
            super.removed();
        }
    }
}
