package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.animatronics.Anims;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/**
 * Timeline editor. One row per linked animatronic. Click empty space on a row to add a clip, click a clip to select it,
 * drag it to move it, drag its right edge to resize it. The buttons below change the selected clip's animation.
 */
public class AnimationControllerScreen extends Screen {
    private int w = 380;
    private int h = 214;
    private static final int LEFT = 84;
    private static final int ROW = 17;
    private static final int TOP = 58;
    private int right = 372;

    private final BlockPos pos;
    private int total = 400;
    private boolean loop = true;
    private final List<AnimationControllerBlockEntity.Clip> clips = new ArrayList<>();
    private int selected = -1;
    private int dragMode; // 0 none, 1 move, 2 resize
    private int dragOffset;
    private boolean playing;
    private EditBox valueBox;
    private Button easeButton;
    private Button dupButton;
    private int shownSel = -2;

    public AnimationControllerScreen(BlockPos pos) {
        super(Component.translatable("block.coastercontrolpanel.animation_controller"));
        this.pos = pos;
        AnimationControllerBlockEntity be = be();
        if (be != null) {
            total = be.totalLength();
            loop = be.loop();
            clips.addAll(be.clips());
            playing = be.playing();
        }
    }

    private AnimationControllerBlockEntity be() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.getBlockEntity(pos) instanceof AnimationControllerBlockEntity b ? b : null;
    }

    private boolean bearing(int track) {
        AnimationControllerBlockEntity be = be();
        Minecraft mc = Minecraft.getInstance();
        return be != null && track >= 0 && track < be.linked().size() && mc.level != null
                && mc.level.getBlockEntity(be.linked().get(track)) instanceof TimelineTarget;
    }

    private boolean selectedBearing() {
        return selected >= 0 && selected < clips.size() && bearing(clips.get(selected).track());
    }

    private int tracks() {
        AnimationControllerBlockEntity be = be();
        return be == null ? 0 : be.linked().size();
    }

    private int snap() {
        return total <= 200 ? 1 : total <= 600 ? 5 : total <= 1800 ? 10 : 20;
    }

    private void send(int command) {
        PacketDistributor.sendToServer(new AnimationConfigPacket(pos, total, loop, command, List.copyOf(clips)));
    }

    @Override
    protected void init() {
        clearWidgets();
        // fit the panel to the window so it still works at big GUI scales
        w = Math.min(380, width - 8);
        right = w - 8;
        h = Math.min(height - 8, TOP + Math.max(3, tracks()) * (ROW + 2) + 76);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        AnimationControllerBlockEntity be = be();
        addRenderableWidget(Button.builder(Component.translatable(playing ? "gui.coastercontrolpanel.timeline_stop" : "gui.coastercontrolpanel.timeline_play"), b -> {
            send(playing ? 2 : 1);
            playing = !playing;
            init();
        }).bounds(x + 8, y + 20, 50, 16).build());
        addRenderableWidget(Button.builder(Component.translatable(loop ? "gui.coastercontrolpanel.timeline_loop_on" : "gui.coastercontrolpanel.timeline_loop_off"), b -> {
            loop = !loop;
            send(0);
            init();
        }).bounds(x + 62, y + 20, 62, 16).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            total = Math.max(AnimationControllerBlockEntity.MIN_LENGTH, total - step());
            fit();
            send(0);
            init();
        }).bounds(x + 130, y + 20, 16, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            total = Math.min(AnimationControllerBlockEntity.MAX_LENGTH, total + step());
            send(0);
        }).bounds(x + 150, y + 20, 16, 16).build());
        // selected clip controls
        addRenderableWidget(Button.builder(Component.literal("<"), b -> cycle(-1)).bounds(x + 8, y + h - 40, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> cycle(1)).bounds(x + 126, y + h - 40, 18, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.timeline_delete"), b -> {
            if (selected >= 0 && selected < clips.size()) {
                clips.remove(selected);
                selected = -1;
                send(0);
            }
        }).bounds(x + 150, y + h - 40, 50, 16).build());
        valueBox = new EditBox(font, x + 204, y + h - 40, 50, 16, Component.empty());
        valueBox.setFilter(str -> str.matches("-?[0-9]{0,4}([.][0-9]{0,2})?"));
        valueBox.setResponder(str -> {
            if (selectedBearing()) {
                try {
                    float v = Math.max(-3600.0F, Math.min(3600.0F, Float.parseFloat(str)));
                    AnimationControllerBlockEntity.Clip c = clips.get(selected);
                    if (c.value() != v) {
                        clips.set(selected, c.withValue(v));
                        send(0);
                    }
                } catch (NumberFormatException ignored) {
                    // half-typed
                }
            }
        });
        addRenderableWidget(valueBox);
        easeButton = Button.builder(Component.empty(), b -> {
            if (selectedBearing()) {
                AnimationControllerBlockEntity.Clip c = clips.get(selected);
                clips.set(selected, c.withEase((c.ease() + 1) % TimelineMath.EASES));
                send(0);
            }
        }).bounds(x + 258, y + h - 40, 60, 16).build();
        addRenderableWidget(easeButton);
        dupButton = Button.builder(Component.translatable("gui.coastercontrolpanel.timeline_duplicate"), b -> {
            if (selected >= 0 && selected < clips.size() && clips.size() < AnimationControllerBlockEntity.MAX_CLIPS) {
                AnimationControllerBlockEntity.Clip c = clips.get(selected);
                int start = Math.min(total - 1, c.start() + c.length());
                clips.add(c.at(start, Math.min(c.length(), total - start)));
                selected = clips.size() - 1;
                shownSel = -2;
                send(0);
            }
        }).bounds(x + 322, y + h - 40, 50, 16).build();
        addRenderableWidget(dupButton);
        shownSel = -2;
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_cancel"), b -> onClose())
                .bounds(x + w - 58, y + h - 24, 50, 16).build());
    }

    private int step() {
        return total <= 400 ? 20 : total <= 1200 ? 100 : 300;
    }

    private void fit() {
        for (int i = 0; i < clips.size(); i++) {
            AnimationControllerBlockEntity.Clip c = clips.get(i);
            int start = Math.min(c.start(), total - 1);
            clips.set(i, c.at(start, Math.min(c.length(), total - start)));
        }
    }

    private void cycle(int d) {
        if (selected >= 0 && selected < clips.size()) {
            AnimationControllerBlockEntity.Clip c = clips.get(selected);
            boolean bear = bearing(c.track());
            int n = bear ? TimelineMath.KINDS : Anims.ids().size();
            AnimationControllerBlockEntity.Clip next = c.withAnim(Math.floorMod(c.anim() + d, n));
            if (bear && (next.anim() == TimelineMath.RETURN || next.anim() == TimelineMath.HOLD || next.anim() == TimelineMath.WAIT)) {
                next = next.withValue(0.0F);
            } else if (bear && next.anim() == TimelineMath.SPIN && Math.abs(next.value()) < 1.0F) {
                next = next.withValue(90.0F);
            }
            clips.set(selected, next);
            shownSel = -2;
            send(0);
        }
    }

    private int tickAt(double mx) {
        double f = (mx - (width - w) / 2.0 - LEFT) / (right - LEFT);
        int t = (int) Math.round(f * total / snap()) * snap();
        return Math.max(0, Math.min(total, t));
    }

    private int px(int tick) {
        return (width - w) / 2 + LEFT + (int) ((long) tick * (right - LEFT) / total);
    }

    private int rowTop(int track) {
        return (height - h) / 2 + TOP + track * (ROW + 2);
    }

    private int hit(double mx, double my) {
        for (int i = clips.size() - 1; i >= 0; i--) {
            AnimationControllerBlockEntity.Clip c = clips.get(i);
            int top = rowTop(c.track());
            if (my >= top && my < top + ROW && mx >= px(c.start()) && mx <= px(c.start() + c.length())) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) {
            return true;
        }
        int x0 = (width - w) / 2 + LEFT;
        if (mx < x0 || mx > x0 + (right - LEFT)) {
            return false;
        }
        int i = hit(mx, my);
        if (i >= 0) {
            selected = i;
            AnimationControllerBlockEntity.Clip c = clips.get(i);
            int end = px(c.start() + c.length());
            if (mx >= end - 4) {
                dragMode = 2;
            } else {
                dragMode = 1;
                dragOffset = tickAt(mx) - c.start();
            }
            return true;
        }
        for (int track = 0; track < tracks(); track++) {
            int top = rowTop(track);
            if (my >= top && my < top + ROW) {
                if (clips.size() >= AnimationControllerBlockEntity.MAX_CLIPS) {
                    return true;
                }
                int start = Math.min(tickAt(mx), total - snap());
                int len = Math.max(snap(), Math.min(40, total - start));
                clips.add(bearing(track) ? new AnimationControllerBlockEntity.Clip(track, TimelineMath.MOVE_TO, start, Math.max(len, 40 > total - start ? len : 40), 90.0F, TimelineMath.EASE_BOTH)
                        : new AnimationControllerBlockEntity.Clip(track, 0, start, len));
                selected = clips.size() - 1;
                send(0);
                return true;
            }
        }
        selected = -1;
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragMode != 0 && selected >= 0 && selected < clips.size()) {
            AnimationControllerBlockEntity.Clip c = clips.get(selected);
            if (dragMode == 1) {
                int start = Math.max(0, Math.min(total - c.length(), tickAt(mx) - dragOffset));
                clips.set(selected, c.at(start, c.length()));
            } else {
                int len = Math.max(snap(), Math.min(total - c.start(), tickAt(mx) - c.start()));
                clips.set(selected, c.at(c.start(), len));
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragMode != 0) {
            dragMode = 0;
            send(0);
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private static String bearingLabel(AnimationControllerBlockEntity.Clip c) {
        String name = Component.translatable("gui.coastercontrolpanel.timeline.kind." + c.anim()).getString();
        return switch (c.anim()) {
            case TimelineMath.MOVE_TO, TimelineMath.RETURN, TimelineMath.ROTATE_BY -> name + " " + fmt(c.value()) + "°";
            case TimelineMath.SPIN -> name + " " + fmt(c.value()) + "°/s";
            default -> name;
        };
    }

    private static String fmt(float v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(java.util.Locale.ROOT, "%.1f", v);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        g.fill(x, y, x + w, y + h, 0xF0202830);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xF0384450);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        g.drawString(font, title, x + 8, y + 7, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.timeline_length", String.format("%.1f", total / 20.0)), x + 172, y + 24, 0xFFFFFF, false);
        AnimationControllerBlockEntity be = be();
        int n = tracks();
        List<String> ids = Anims.ids();
        boolean bearSel = selectedBearing();
        valueBox.visible = bearSel;
        valueBox.active = bearSel;
        easeButton.visible = bearSel;
        easeButton.active = bearSel;
        dupButton.visible = selected >= 0 && selected < clips.size();
        if (n == 0) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.timeline_empty"), x + 8, y + TOP + 4, 0xE0B0B0, false);
        }
        for (int t = 0; t < n; t++) {
            int top = rowTop(t);
            g.fill(x + LEFT, top, x + right, top + ROW, 0xFF161C24);
            BlockPos p = be.linked().get(t);
            Component name = Component.literal((t + 1) + " ");
            if (Minecraft.getInstance().level != null && Minecraft.getInstance().level.getBlockEntity(p) instanceof AnimatronicBlockEntity a) {
                name = Component.literal((t + 1) + " ").append(AnimatronicTexts.type(a));
            } else if (Minecraft.getInstance().level != null && Minecraft.getInstance().level.getBlockEntity(p) instanceof TimelineTarget tt) {
                name = Component.literal((t + 1) + " ").append(tt.timelineLabel());
            }
            g.drawString(font, font.plainSubstrByWidth(name.getString(), LEFT - 12), x + 8, top + 5, 0xC8D0D8, false);
        }
        // grid every second
        for (int tick = 0; tick <= total; tick += 20) {
            int gx = px(tick);
            g.fill(gx, y + TOP - 4, gx + 1, y + TOP - 1, 0xFF8890A0);
            if (total <= 600 && tick % 100 == 0) {
                g.drawString(font, (tick / 20) + "s", gx - 4, y + TOP - 14, 0x9AA2B0, false);
            }
        }
        for (int i = 0; i < clips.size(); i++) {
            AnimationControllerBlockEntity.Clip c = clips.get(i);
            if (c.track() >= n) {
                continue;
            }
            int top = rowTop(c.track());
            int x0 = px(c.start());
            int x1 = Math.max(x0 + 3, px(c.start() + c.length()));
            boolean bear = bearing(c.track());
            int color = java.awt.Color.HSBtoRGB(bear ? 0.55F + c.anim() * 0.07F : (c.anim() * 0.137F) % 1.0F, 0.55F, 0.85F) | 0xFF000000;
            g.fill(x0, top + 1, x1, top + ROW - 1, color);
            if (i == selected) {
                g.renderOutline(x0 - 1, top, x1 - x0 + 2, ROW, 0xFFFFFFFF);
            }
            String label = bear ? bearingLabel(c) : Component.translatable("animatronic.anim." + ids.get(c.anim() % ids.size())).getString();
            g.drawString(font, font.plainSubstrByWidth(label, x1 - x0 - 4), x0 + 2, top + 5, 0x101418, false);
        }
        // playhead
        if (be != null && be.playing() && Minecraft.getInstance().level != null) {
            long t = Minecraft.getInstance().level.getGameTime() - be.startTime();
            int tick = (int) (t % total);
            if (t < total || be.loop()) {
                int gx = px(tick);
                g.fill(gx, y + TOP - 2, gx + 1, y + TOP + Math.max(1, n) * (ROW + 2), 0xFFFF5050);
            }
        }
        // selected clip line
        if (selected >= 0 && selected < clips.size()) {
            AnimationControllerBlockEntity.Clip c = clips.get(selected);
            Component name = bearing(c.track()) ? Component.translatable("gui.coastercontrolpanel.timeline.kind." + c.anim())
                    : Component.translatable("animatronic.anim." + ids.get(c.anim() % ids.size()));
            g.drawCenteredString(font, name, x + 77, y + h - 36, 0xFFFFFF);
            if (shownSel != selected) {
                shownSel = selected;
                valueBox.setValue(String.format(java.util.Locale.ROOT, c.value() == Math.rint(c.value()) ? "%.0f" : "%.2f", c.value()));
            }
            easeButton.setMessage(Component.translatable("gui.coastercontrolpanel.timeline.ease." + c.ease()));
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.timeline_clip",
                    String.format("%.2f", c.start() / 20.0), String.format("%.2f", c.length() / 20.0)), x + 8, y + h - 20, 0xB8C0C8, false);
        } else {
            g.drawWordWrap(font, Component.translatable("gui.coastercontrolpanel.timeline_hint"), x + 8, y + h - 66, w - 16, 0x909AA4);
        }
    }
}
