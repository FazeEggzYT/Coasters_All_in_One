package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The blocks of the Time Machine. The Swing Ride engine runs them: the boom (Pivot Head, Boom pieces and a Pod Hub on
 * each end) lies flat at rest and lifts up from there, while the pods turn on their own.
 */
public final class TimeMachineBlocks {
    private TimeMachineBlocks() {
    }

    public static class BaseBlock extends SwingBlocks.BaseBlock {
        public BaseBlock(Properties properties) {
            super(properties);
        }
    }

    public static class PivotBlock extends SwingBlocks.PivotBlock {
        public PivotBlock(Properties properties) {
            super(properties);
        }
    }

    public static class ArmBlock extends SwingBlocks.ArmBlock {
        public ArmBlock(Properties properties) {
            super(properties);
        }
    }

    public static class HubBlock extends SwingBlocks.HubBlock {
        public HubBlock(Properties properties) {
            super(properties);
        }
    }

    /** A solid pod panel: floor, wall or back. Sticks to other pod blocks and to touching seats. */
    public static class PodBlock extends SwingBlocks.GondolaFrameBlock {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 16, 16);

        public PodBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return false;
        }
    }
}
