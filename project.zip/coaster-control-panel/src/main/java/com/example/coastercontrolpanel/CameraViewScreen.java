package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;

/** Live view through a camera block. Esc or a right-click on the screen to leave. */
public class CameraViewScreen extends Screen {
    private final BlockPos pos;
    private final Direction facing;

    public CameraViewScreen(BlockPos pos, Direction facing) {
        super(Component.translatable("gui.coastercontrolpanel.camera_view"));
        this.pos = pos;
        this.facing = facing;
    }

    @Override
    protected void init() {
        PhotoClient.startView(pos, facing.toYRot());
    }

    @Override
    public void removed() {
        PhotoClient.stopView();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur: the whole point is a clear picture. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.level == null || !(minecraft.level.getBlockEntity(pos) instanceof CameraBlockEntity)) {
            onClose();
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int w = width;
        int h = height;
        int m = 14;
        int len = 22;
        int c = 0xFFFFFFFF;
        // viewfinder corners
        g.fill(m, m, m + len, m + 2, c);
        g.fill(m, m, m + 2, m + len, c);
        g.fill(w - m - len, m, w - m, m + 2, c);
        g.fill(w - m - 2, m, w - m, m + len, c);
        g.fill(m, h - m - 2, m + len, h - m, c);
        g.fill(m, h - m - len, m + 2, h - m, c);
        g.fill(w - m - len, h - m - 2, w - m, h - m, c);
        g.fill(w - m - 2, h - m - len, w - m, h - m, c);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (blink) {
            g.fill(m + 8, m + 8, m + 16, m + 16, 0xFFE03030);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.camera_live"), m + 22, m + 8, 0xFFFFFF, true);
        g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.camera_hint"), w / 2, h - m - 12,
                0xCCCCCC);
    }
}
