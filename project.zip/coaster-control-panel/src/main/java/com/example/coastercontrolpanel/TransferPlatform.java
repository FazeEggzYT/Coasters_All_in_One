package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import org.joml.Quaterniond;
import org.joml.Vector3d;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Transfer track: a platform that is a real Sable structure (a "sub-level") carrying real Coasters Simulated track.
 * Everything from Sable and Coasters Simulated is reached by reflection, so a mismatch can never stop the game from
 * loading; each failure is logged with what was being attempted.
 *
 * What happens:
 *  - assemble(): the blocks connected to the top of the Transfer Table are turned into one structure.
 *  - physicsStep(): every physics step the structure is steered (by velocity) to its place on the rail.
 *  - dock()/undock(): at a stop the recorded track joins between the platform's end anchors and the fixed anchors are
 *    added; when the platform leaves they are removed again. Carts can therefore only cross while it is docked.
 */
public final class TransferPlatform {
    /** Tables that own a platform, looked at by the physics hook. */
    static final Set<TransferTableBlockEntity> ACTIVE = ConcurrentHashMap.newKeySet();

    private static boolean hooked;
    private static Method evSystem;
    private static Method evStep;
    private static Method sysLevel;
    private static Method sysPipeline;
    private static Method pipeVelocityReset;
    private static Method pipeAddVelocity;
    private static Method pipeWake;
    private static Method pipeTeleport;
    private static Method subPose;
    private static Method subRemoved;
    private static Method poseOrientation;
    private static Method posePosition;
    private static Method containerGet;
    private static Method containerSub;
    private static Method containerInBounds;
    private static Method uniqueId;
    private static int errors;

    private TransferPlatform() {
    }

    public record Assembled(UUID id, Vec3 base, Quaterniond orientation, String error) {
    }

    private static Method find(Class<?> c, String name, int params, Class<?>... first) throws Exception {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == params) {
                Class<?>[] p = m.getParameterTypes();
                boolean ok = true;
                for (int i = 0; i < first.length && ok; i++) {
                    ok = p[i] == first[i];
                }
                if (ok) {
                    m.setAccessible(true);
                    return m;
                }
            }
        }
        throw new IllegalStateException("missing " + c.getName() + "." + name + "/" + params);
    }

    private static void fail(String what, Throwable e) {
        if (errors++ < 6) {
            CoasterControlPanel.LOGGER.error("Transfer platform: {} failed", what, e);
        }
    }

    // ---------------------------------------------------------------- the physics hook

    /** Called once from the mod constructor. If Sable's event is not there, platforms simply never move. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void registerHook() {
        if (hooked) {
            return;
        }
        try {
            Class<?> evt = Class.forName("dev.ryanhcode.sable.neoforge.event.ForgeSablePrePhysicsTickEvent");
            evSystem = evt.getMethod("getPhysicsSystem");
            evStep = evt.getMethod("getTimeStep");
            Consumer c = e -> onPrePhysics(e);
            NeoForge.EVENT_BUS.addListener(EventPriority.NORMAL, false, (Class) evt, c);
            hooked = true;
            CoasterControlPanel.LOGGER.info("Transfer platform: hooked into Sable's physics step.");
        } catch (Throwable e) {
            CoasterControlPanel.LOGGER.warn("Transfer platform: Sable's physics event was not found; carrying platforms are off.", e);
        }
    }

    private static void onPrePhysics(Object event) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        try {
            Object system = evSystem.invoke(event);
            double dt = (Double) evStep.invoke(event);
            if (sysLevel == null) {
                Class<?> sc = Class.forName("dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem");
                sysLevel = find(sc, "getLevel", 0);
                sysPipeline = find(sc, "getPipeline", 0);
            }
            Object level = sysLevel.invoke(system);
            Object pipeline = sysPipeline.invoke(system);
            for (TransferTableBlockEntity be : ACTIVE) {
                if (be.getLevel() == level && !be.isRemoved()) {
                    try {
                        be.physicsStep(pipeline, dt);
                    } catch (Throwable t) {
                        fail("steering the platform", t);
                    }
                }
            }
        } catch (Throwable t) {
            fail("physics hook", t);
        }
    }

    // ---------------------------------------------------------------- looking a platform up

    private static void resolveContainer() throws Exception {
        if (containerGet != null) {
            return;
        }
        Class<?> cc = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
        containerGet = find(cc, "getContainer", 1, ServerLevel.class);
        containerSub = find(cc, "getSubLevel", 1, UUID.class);
        containerInBounds = find(cc, "inBounds", 1, BlockPos.class);
        Class<?> sl = Class.forName("dev.ryanhcode.sable.sublevel.SubLevel");
        subPose = find(sl, "logicalPose", 0);
        subRemoved = find(sl, "isRemoved", 0);
        uniqueId = find(sl, "getUniqueId", 0);
        Class<?> pose = Class.forName("dev.ryanhcode.sable.companion.math.Pose3d");
        posePosition = find(pose, "position", 0);
        poseOrientation = find(pose, "orientation", 0);
    }

    /** The structure with this id, or null. */
    public static Object subLevel(ServerLevel level, UUID id) {
        try {
            resolveContainer();
            Object container = containerGet.invoke(null, level);
            Object sub = containerSub.invoke(container, id);
            if (sub == null || (Boolean) subRemoved.invoke(sub)) {
                return null;
            }
            return sub;
        } catch (Throwable t) {
            fail("looking up the platform", t);
            return null;
        }
    }

    public static Vector3d position(Object sub) throws Exception {
        Object pose = subPose.invoke(sub);
        return new Vector3d((Vector3d) posePosition.invoke(pose));
    }

    public static Quaterniond orientation(Object sub) throws Exception {
        Object pose = subPose.invoke(sub);
        return new Quaterniond((Quaterniond) poseOrientation.invoke(pose));
    }

    /** True if this block position is inside a moving structure's own space (not the normal world). */
    public static boolean inStructureSpace(ServerLevel level, BlockPos pos) {
        try {
            resolveContainer();
            Object container = containerGet.invoke(null, level);
            return (Boolean) containerInBounds.invoke(container, pos);
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- assembling

    /** Turns the blocks connected to the top of the table into one structure. */
    public static Assembled assemble(ServerLevel level, BlockPos table, Direction facing) {
        try {
            resolveContainer();
            Class<?> helper = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper");
            Class<?> frontier = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper$FrontierPredicate");
            BlockPos start = table.above();
            if (level.getBlockState(start).isAir()) {
                return new Assembled(null, null, null, "Build the platform on top of the table first (the block above it must be solid).");
            }
            final int ty = table.getY();
            InvocationHandler handler = (proxy, m, a) -> {
                if (m.getName().equals("isValidConnection")) {
                    BlockPos to = (BlockPos) a[2];
                    BlockState toState = (BlockState) a[3];
                    return !toState.isAir() && !to.equals(table) && to.getY() > ty && to.getY() <= ty + 9
                            && Math.abs(to.getX() - table.getX()) <= 7 && Math.abs(to.getZ() - table.getZ()) <= 7;
                }
                return switch (m.getName()) {
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == a[0];
                    case "toString" -> "TransferFrontier";
                    default -> null;
                };
            };
            Object predicate = Proxy.newProxyInstance(frontier.getClassLoader(), new Class<?>[]{frontier}, handler);
            Method gather = find(helper, "gatherConnectedBlocks", 4, BlockPos.class, ServerLevel.class);
            Object result = gather.invoke(null, start, level, 600, predicate);
            Class<?> rc = result.getClass();
            Object state = rc.getMethod("assemblyState").invoke(result);
            if (!"SUCCESS".equals(String.valueOf(state))) {
                return new Assembled(null, null, null, "Could not assemble: " + state + " (limit 600 blocks).");
            }
            @SuppressWarnings("unchecked")
            Iterable<BlockPos> blocks = (Iterable<BlockPos>) rc.getMethod("blocks").invoke(result);
            Object box = rc.getMethod("boundingBox").invoke(result);
            Method assemble = find(helper, "assembleBlocks", 4, ServerLevel.class, BlockPos.class);
            Object sub = assemble.invoke(null, level, start, blocks, box);
            if (sub == null) {
                return new Assembled(null, null, null, "Sable refused to assemble the platform.");
            }
            Vector3d pos = position(sub);
            UUID id = (UUID) uniqueId.invoke(sub);
            CoasterControlPanel.LOGGER.info("Transfer platform: assembled {} at {} for table {}.", id, pos, table);
            return new Assembled(id, new Vec3(pos.x, pos.y, pos.z), orientation(sub), null);
        } catch (Throwable t) {
            fail("assembling the platform", t);
            return new Assembled(null, null, null, "Assembling failed, see the log (Transfer platform).");
        }
    }

    // ---------------------------------------------------------------- steering

    /** Moves the structure to {@code target} for this physics step, by velocity, and keeps it level. */
    public static void steer(Object pipeline, Object sub, Vec3 target, Quaterniond wantRot, double dt) throws Exception {
        if (pipeWake == null) {
            Class<?> pc = Class.forName("dev.ryanhcode.sable.api.physics.PhysicsPipeline");
            pipeVelocityReset = find(pc, "resetVelocity", 1);
            pipeAddVelocity = find(pc, "addLinearAndAngularVelocity", 3);
            pipeWake = find(pc, "wakeUp", 1);
            pipeTeleport = find(pc, "teleport", 3);
        }
        Vector3d pos = position(sub);
        Vector3d v = new Vector3d(target.x - pos.x, target.y - pos.y, target.z - pos.z).div(dt);
        double len = v.length();
        if (len > 8.0) {
            v.mul(8.0 / len);
        }
        Quaterniond rot = orientation(sub);
        if (Math.abs(rot.dot(wantRot)) < 0.99995) {
            pipeTeleport.invoke(pipeline, sub, new Vector3d(pos), new Quaterniond(wantRot));
        }
        pipeVelocityReset.invoke(pipeline, sub);
        pipeAddVelocity.invoke(pipeline, sub, v, new Vector3d());
        pipeWake.invoke(pipeline, sub);
    }

    // ---------------------------------------------------------------- is a block on a platform?

    private static Method plotContainsChunk;

    /** True if {@code pos} lies inside the structure of a platform that belongs to a Transfer Table in this level. */
    public static boolean isOnPlatform(net.minecraft.world.level.Level level, BlockPos pos) {
        if (ACTIVE.isEmpty() || !(level instanceof ServerLevel sl)) {
            return false;
        }
        try {
            net.minecraft.world.level.ChunkPos cp = new net.minecraft.world.level.ChunkPos(pos);
            for (TransferTableBlockEntity t : ACTIVE) {
                UUID id = t.platformId();
                if (id == null || t.getLevel() != level) {
                    continue;
                }
                Object sub = subLevel(sl, id);
                if (sub == null) {
                    continue;
                }
                if (subPlot == null) {
                    subPlot = sub.getClass().getMethod("getPlot");
                    Class<?> plotClass = Class.forName("dev.ryanhcode.sable.sublevel.plot.LevelPlot");
                    plotChunks = plotClass.getMethod("getLoadedChunks");
                    holderChunk = Class.forName("dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder").getMethod("getChunk");
                }
                if (plotContainsChunk == null) {
                    plotContainsChunk = Class.forName("dev.ryanhcode.sable.sublevel.plot.LevelPlot")
                            .getMethod("contains", net.minecraft.world.level.ChunkPos.class);
                }
                if ((Boolean) plotContainsChunk.invoke(subPlot.invoke(sub), cp)) {
                    return true;
                }
            }
        } catch (Throwable t) {
            fail("checking whether a block is on the platform", t);
        }
        return false;
    }

    // ---------------------------------------------------------------- taking the platform apart again

    /**
     * Turns the platform back into normal blocks in the world, where it stands now (rounded to whole blocks).
     * Refuses if the platform is turned, or if any block would land on something that is not air.
     * @return null on success, otherwise the reason it was not done
     */
    public static String disassemble(ServerLevel level, UUID id) {
        try {
            Object sub = subLevel(level, id);
            if (sub == null) {
                return "The platform no longer exists.";
            }
            if (subPlot == null) {
                subPlot = sub.getClass().getMethod("getPlot");
                Class<?> plotClass = Class.forName("dev.ryanhcode.sable.sublevel.plot.LevelPlot");
                plotChunks = plotClass.getMethod("getLoadedChunks");
                holderChunk = Class.forName("dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder").getMethod("getChunk");
            }
            Quaterniond rot = orientation(sub);
            if (Math.abs(rot.w) < 0.99999 && Math.abs(rot.y) < 0.99999) {
                return "The platform is turned; it can only be taken apart when it is level and square.";
            }
            Object plot = subPlot.invoke(sub);
            List<BlockPos> blocks = new ArrayList<>();
            for (Object holder : (Iterable<?>) plotChunks.invoke(plot)) {
                LevelChunk chunk = (LevelChunk) holderChunk.invoke(holder);
                if (chunk == null) {
                    continue;
                }
                int minY = chunk.getMinBuildHeight();
                int maxY = chunk.getMaxBuildHeight();
                BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
                for (int x = chunk.getPos().getMinBlockX(); x <= chunk.getPos().getMaxBlockX(); x++) {
                    for (int z = chunk.getPos().getMinBlockZ(); z <= chunk.getPos().getMaxBlockZ(); z++) {
                        for (int y = minY; y < maxY; y++) {
                            m.set(x, y, z);
                            if (!chunk.getBlockState(m).isAir()) {
                                blocks.add(m.immutable());
                            }
                        }
                    }
                }
            }
            if (blocks.isEmpty()) {
                return "The platform has no blocks.";
            }
            BlockPos ref = blocks.get(0);
            Method transformPosition = null;
            Object pose = subPose.invoke(sub);
            for (Method pm : pose.getClass().getMethods()) {
                if (pm.getName().equals("transformPosition") && pm.getParameterCount() == 1
                        && pm.getParameterTypes()[0] == Vector3d.class) {
                    transformPosition = pm;
                }
            }
            if (transformPosition == null) {
                return "Could not work out where the platform is.";
            }
            Vector3d w = (Vector3d) transformPosition.invoke(pose, new Vector3d(ref.getX() + 0.5, ref.getY() + 0.5, ref.getZ() + 0.5));
            BlockPos target = BlockPos.containing(w.x, w.y, w.z);
            int dx = target.getX() - ref.getX();
            int dy = target.getY() - ref.getY();
            int dz = target.getZ() - ref.getZ();
            for (BlockPos b : blocks) {
                BlockPos to = b.offset(dx, dy, dz);
                if (inStructureSpace(level, to) || !level.getBlockState(to).isAir()) {
                    return "No room: the blocks would land on " + to.toShortString() + ", which is not empty.";
                }
            }
            Class<?> helper = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper");
            Class<?> tc = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper$AssemblyTransform");
            Object transform = tc.getConstructor(BlockPos.class, BlockPos.class, int.class,
                    net.minecraft.world.level.block.Rotation.class, ServerLevel.class)
                    .newInstance(ref, target, 0, net.minecraft.world.level.block.Rotation.NONE, level);
            Method move = find(helper, "moveBlocks", 3, ServerLevel.class);
            move.invoke(null, level, transform, blocks);
            CoasterControlPanel.LOGGER.info("Transfer platform: put {} block(s) of platform {} back into the world (shifted by {}, {}, {}).",
                    blocks.size(), id, dx, dy, dz);
            return null;
        } catch (Throwable t) {
            fail("taking the platform apart", t);
            return "Taking it apart failed, see the log (Transfer platform).";
        }
    }

    // ---------------------------------------------------------------- what is on the platform

    private static Method subPlot;
    private static Method plotChunks;
    private static Method holderChunk;

    /** The start anchors of every Brake Run built on the platform. */
    public static List<BlockEntity> brakeAnchors(ServerLevel level, UUID id) {
        List<BlockEntity> out = new ArrayList<>();
        try {
            Object sub = subLevel(level, id);
            if (sub == null) {
                return out;
            }
            if (subPlot == null) {
                subPlot = sub.getClass().getMethod("getPlot");
                Class<?> plotClass = Class.forName("dev.ryanhcode.sable.sublevel.plot.LevelPlot");
                plotChunks = plotClass.getMethod("getLoadedChunks");
                holderChunk = Class.forName("dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder").getMethod("getChunk");
            }
            Object plot = subPlot.invoke(sub);
            for (Object holder : (Iterable<?>) plotChunks.invoke(plot)) {
                LevelChunk chunk = (LevelChunk) holderChunk.invoke(holder);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof DriveTyre.Holder h && h.ccp$brake() != null) {
                        out.add(be);
                    }
                }
            }
        } catch (Throwable t) {
            fail("looking for the brake on the platform", t);
        }
        return out;
    }

    // ---------------------------------------------------------------- track joins at the stops

    private static final String ANCHOR = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity";

    public static boolean isAnchor(BlockEntity be) {
        return be != null && be.getClass().getName().equals(ANCHOR);
    }

    @SuppressWarnings("unchecked")
    public static Map<BlockPos, Object> peers(BlockEntity anchor) throws Exception {
        return (Map<BlockPos, Object>) anchor.getClass().getMethod("getAnchorPeerCurvesView").invoke(anchor);
    }

    public static void putPeer(ServerLevel level, BlockEntity anchor, BlockPos peer, Object bezier) throws Exception {
        Method m = null;
        for (Method c : anchor.getClass().getMethods()) {
            if (c.getName().equals("putAnchorPeerCurve") && c.getParameterCount() == 3) {
                m = c;
            }
        }
        m.invoke(anchor, level, peer, bezier);
    }

    public static void removePeer(ServerLevel level, BlockEntity anchor, BlockPos peer) throws Exception {
        for (Method c : anchor.getClass().getMethods()) {
            if (c.getName().equals("removeAnchorPeerCurve") && c.getParameterCount() == 2) {
                c.invoke(anchor, level, peer);
                return;
            }
        }
    }

    /** Fixed anchors near the table that are joined to a track anchor inside a moving structure. */
    public static List<BlockEntity> fixedAnchorsNear(ServerLevel level, BlockPos center) {
        List<BlockEntity> out = new ArrayList<>();
        int cx = center.getX() >> 4;
        int cz = center.getZ() >> 4;
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (isAnchor(be)) {
                        out.add(be);
                    }
                }
            }
        }
        return out;
    }

    public static Object newBezier(net.minecraft.nbt.CompoundTag tag) throws Exception {
        Class<?> bc = Class.forName("com.simibubi.create.content.trains.track.BezierConnection");
        return bc.getConstructor(net.minecraft.nbt.CompoundTag.class, BlockPos.class).newInstance(tag, BlockPos.ZERO);
    }

    public static net.minecraft.nbt.CompoundTag bezierTag(Object bezier) throws Exception {
        return (net.minecraft.nbt.CompoundTag) bezier.getClass().getMethod("write", BlockPos.class).invoke(bezier, BlockPos.ZERO);
    }
}
