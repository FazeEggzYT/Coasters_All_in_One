package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the settings chosen in the Animatronic screen (opened with a Create Wrench). */
public record AnimatronicConfigPacket(BlockPos pos, int character, int animation, boolean redstone, int speed)
        implements CustomPacketPayload {
    public static final Type<AnimatronicConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "animatronic_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AnimatronicConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.character);
                buf.writeVarInt(p.animation);
                buf.writeBoolean(p.redstone);
                buf.writeVarInt(p.speed);
            },
            buf -> new AnimatronicConfigPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(AnimatronicConfigPacket p, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 2304.0
                || !(player.getMainHandItem().getItem() instanceof WrenchItem)) {
            return;
        }
        if (player.level().getBlockEntity(p.pos) instanceof AnimatronicBlockEntity be) {
            be.setAll(p.character, p.animation, p.redstone, p.speed);
        }
    }
}
