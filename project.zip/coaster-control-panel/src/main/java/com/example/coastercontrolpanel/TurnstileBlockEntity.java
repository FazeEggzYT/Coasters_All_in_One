package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Holds nothing that is saved. The client keeps the spin of the arms here so they turn smoothly. */
public class TurnstileBlockEntity extends BlockEntity {
    public float angle = 0.0F;
    public float speed = 0.0F;
    public float lastTime = -1.0F;

    public TurnstileBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.TURNSTILE_BE.get(), pos, state);
    }
}
