package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemDisplayContext;

/** Items on the Photo Frame Wall and the text of the Staff Rota Board. */
public final class ServiceRenderers {
    private ServiceRenderers() {
    }

    private static final int FULL_BRIGHT = 15728880;

    public static class PhotoWall implements BlockEntityRenderer<GuestBlocks.PhotoWallBlockEntity> {
        private final ItemRenderer items;

        public PhotoWall(BlockEntityRendererProvider.Context context) {
            this.items = context.getItemRenderer();
        }

        @Override
        public void render(GuestBlocks.PhotoWallBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            Direction facing = be.getBlockState().getValue(DecorBlocks.FACING);
            for (int i = 0; i < 4; i++) {
                if (be.shown[i].isEmpty()) {
                    continue;
                }
                float x = (i % 2 == 0 ? -1 : 1) * 0.23F;
                float y = (i / 2 == 0 ? 1 : -1) * 0.23F;
                pose.pushPose();
                pose.translate(0.5, 0.5, 0.5);
                pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
                pose.translate(x, y, -0.22);
                pose.scale(0.42F, 0.42F, 0.42F);
                items.renderStatic(be.shown[i], ItemDisplayContext.FIXED, light, overlay, pose, buffers, be.getLevel(), (int) be.getBlockPos().asLong() + i);
                pose.popPose();
            }
        }
    }

    public static class RotaBoard implements BlockEntityRenderer<GuestBlocks.TextBlockEntity> {
        private final Font font;

        public RotaBoard(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        private void line(String s, int colour, float x, float y, float baseScale, float maxWidth, PoseStack pose, MultiBufferSource buffers) {
            if (s.isEmpty()) {
                return;
            }
            Component text = Component.literal(s);
            int w = Math.max(1, font.width(text));
            float scale = Math.min(baseScale, maxWidth / w);
            pose.pushPose();
            pose.translate(x, -y + 4.0F * scale, 0.0);
            pose.scale(scale, -scale, scale);
            font.drawInBatch(text, -w / 2.0F, 0.0F, colour, false, pose.last().pose(), buffers, Font.DisplayMode.NORMAL, 0, FULL_BRIGHT);
            pose.popPose();
        }

        @Override
        public void render(GuestBlocks.TextBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            if (be.getBlockState().getBlock() instanceof ResortBlocks.ResortSignBlock) {
                Direction f = be.getBlockState().getValue(DecorBlocks.FACING);
                pose.pushPose();
                pose.translate(0.5, 0.5, 0.5);
                pose.mulPose(Axis.YP.rotationDegrees(-f.toYRot()));
                pose.translate(0.0, 0.0, -0.3125 + 0.004);
                line(be.lines[0], 0xFFFFE9A8, 0.0F, -0.30F, 0.04F, 0.85F, pose, buffers);
                line(be.lines[1], 0xFFFFFFFF, 0.0F, -0.12F, 0.025F, 0.85F, pose, buffers);
                line(be.lines[2], 0xFF9EE6F0, 0.0F, 0.04F, 0.025F, 0.85F, pose, buffers);
                pose.popPose();
                return;
            }
            if (!(be.getBlockState().getBlock() instanceof StaffBlocks.RotaBoardBlock)) {
                return;
            }
            Direction facing = be.getBlockState().getValue(DecorBlocks.FACING);
            pose.pushPose();
            pose.translate(0.5, 0.5, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
            pose.translate(0.0, 0.0, -0.3125 + 0.004);
            line("STAFF ROTA", 0xFFFFD84A, 0.0F, -0.40F, 0.03F, 0.8F, pose, buffers);
            for (int r = 0; r < 6; r++) {
                line(be.lines[r * 2], 0xFFFFFFFF, -0.22F, -0.25F + r * 0.115F, 0.016F, 0.4F, pose, buffers);
                line(be.lines[r * 2 + 1], 0xFF9EE6A0, 0.22F, -0.25F + r * 0.115F, 0.016F, 0.4F, pose, buffers);
            }
            pose.popPose();
        }
    }
}
