package com.example.coastercontrolpanel;

/**
 * The movement of a Drop Tower carriage, free of any Minecraft types so it can be checked on its own.
 * Height ("rise") is blocks above the resting position, "vel" is blocks per second (up is positive).
 * Nothing here moves anything: {@link #tick} advances the numbers and the block entity applies them.
 */
public final class DropTowerMotion {
    public static final int IDLE = 0;
    public static final int COUNTDOWN = 1;
    public static final int RUNNING = 2;
    public static final int PAUSED = 3;
    public static final int ENDING = 4;

    private static final double LIFT_ACCEL = 3.0;
    private static final double EASE_DECEL = 3.0;
    private static final double ARRIVE = 0.002;

    public int phase = IDLE;
    public int stepIndex;
    public int loop;
    public double stepTime;
    public double rise;
    public double vel;
    public double maxRise = 20.0;
    /** True when a sequence has run to its end and is waiting for End (End Mode: wait). */
    public boolean finished;
    /** True once an ENDING has reached the bottom. */
    public boolean landed;

    public void start(double maxRiseBlocks) {
        phase = RUNNING;
        stepIndex = 0;
        loop = 0;
        stepTime = 0;
        rise = 0;
        vel = 0;
        maxRise = Math.max(0.0, maxRiseBlocks);
        finished = false;
        landed = false;
    }

    public void togglePause() {
        if (phase == RUNNING) {
            phase = PAUSED;
        } else if (phase == PAUSED && !finished) {
            phase = RUNNING;
        }
    }

    public void end() {
        if (phase == RUNNING || phase == PAUSED) {
            phase = ENDING;
            finished = false;
        }
    }

    private void nextStep(DropTowerSettings c) {
        stepIndex++;
        stepTime = 0;
        vel = 0;
        if (stepIndex >= c.steps.size()) {
            loop++;
            stepIndex = 0;
            if (loop >= c.loops) {
                if (c.endMode == 0) {
                    phase = ENDING;
                } else {
                    phase = PAUSED;
                    finished = true;
                }
            }
        }
    }

    /** Advances by dt seconds. */
    public void tick(DropTowerSettings c, double dt) {
        switch (phase) {
            case RUNNING -> runStep(c, dt);
            case PAUSED -> brakeToStop(c, dt);
            case ENDING -> {
                if (vel > 0.0) {
                    brakeToStop(c, dt);
                } else {
                    boolean there = rise <= ARRIVE || glide(c, 0.0, c.returnSpeed, dt);
                    if (there) {
                        rise = 0;
                        vel = 0;
                        landed = true;
                        phase = IDLE;
                    }
                }
            }
            default -> {
            }
        }
        rise = Math.max(0.0, Math.min(maxRise, rise));
    }

    private void brakeToStop(DropTowerSettings c, double dt) {
        double d = c.brake * dt;
        if (Math.abs(vel) <= d) {
            vel = 0;
        } else {
            vel -= Math.signum(vel) * d;
        }
        rise += vel * dt;
    }

    private void runStep(DropTowerSettings c, double dt) {
        if (c.steps.isEmpty()) {
            nextStep(c);
            return;
        }
        DropTowerSettings.Step s = c.steps.get(Math.min(stepIndex, c.steps.size() - 1));
        stepTime += dt;
        double target = Math.min(s.a, maxRise);
        switch (s.type) {
            case DropTowerSettings.LIFT -> {
                if (target - rise <= ARRIVE) {
                    arrive(c, target);
                } else if (lift(target, s.b, dt)) {
                    arrive(c, target);
                }
            }
            case DropTowerSettings.HOLD -> {
                vel = 0;
                if (stepTime >= s.a) {
                    nextStep(c);
                }
            }
            case DropTowerSettings.FALL -> {
                if (rise - target <= ARRIVE) {
                    arrive(c, target);
                } else if (fall(c, target, s.b, dt)) {
                    arrive(c, target);
                }
            }
            default -> {
                if (Math.abs(rise - target) <= ARRIVE) {
                    arrive(c, target);
                } else if (glide(c, target, s.b, dt)) {
                    arrive(c, target);
                }
            }
        }
    }

    private void arrive(DropTowerSettings c, double target) {
        rise = target;
        vel = 0;
        nextStep(c);
    }

    /** @return true when the target height is reached */
    private boolean lift(double target, double vmax, double dt) {
        double dist = target - rise;
        double allowed = Math.sqrt(2.0 * EASE_DECEL * dist);
        double want = Math.min(vmax, Math.max(0.6, allowed));
        if (vel < want) {
            vel = Math.min(want, vel + LIFT_ACCEL * dt);
        } else {
            vel = Math.max(want, vel - 2.0 * EASE_DECEL * dt);
        }
        vel = Math.max(vel, 0.3);
        double step = vel * dt;
        if (step >= dist) {
            return true;
        }
        rise += step;
        return false;
    }

    /** A fall under gravity ("accel"), braked so it comes to rest at the target. @return true when reached */
    private boolean fall(DropTowerSettings c, double target, double accel, double dt) {
        double dist = rise - target;
        double speed = Math.max(0.0, -vel);
        speed = Math.min(c.maxSpeed, speed + accel * dt);
        double stopDist = speed * speed / (2.0 * c.brake);
        if (dist <= stopDist) {
            speed = Math.max(0.8, Math.sqrt(2.0 * c.brake * dist));
        }
        double step = speed * dt;
        if (step >= dist) {
            return true;
        }
        vel = -speed;
        rise -= step;
        return false;
    }

    /** A steady move to the target at about "speed", eased in and out. @return true when reached */
    private boolean glide(DropTowerSettings c, double target, double speed, double dt) {
        double dist = Math.abs(target - rise);
        double dir = Math.signum(target - rise);
        double allowed = Math.sqrt(2.0 * EASE_DECEL * dist);
        double want = Math.min(speed, Math.max(0.5, allowed));
        double cur = Math.abs(vel);
        if (cur < want) {
            cur = Math.min(want, cur + LIFT_ACCEL * dt);
        } else {
            cur = Math.max(want, cur - 2.0 * EASE_DECEL * dt);
        }
        cur = Math.max(cur, 0.3);
        double step = cur * dt;
        if (step >= dist) {
            return true;
        }
        vel = dir * cur;
        rise += dir * step;
        return false;
    }
}
