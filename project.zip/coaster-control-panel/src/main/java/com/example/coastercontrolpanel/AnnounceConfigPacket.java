package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: names, sounds, volumes and pitches typed into the Announcement Panel setup screen. */
public record AnnounceConfigPacket(BlockPos pos, String[] names, int[] sounds, int[] volumes, int[] pitches)
        implements CustomPacketPayload {
    public static final Type<AnnounceConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "announce_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AnnounceConfigPacket> CODEC =
            StreamCodec.of(AnnounceConfigPacket::write, AnnounceConfigPacket::read);

    private static void write(RegistryFriendlyByteBuf buf, AnnounceConfigPacket p) {
        buf.writeBlockPos(p.pos);
        for (int r = 0; r < AnnouncePanelBlockEntity.ROWS; r++) {
            buf.writeUtf(p.names[r], 32);
            buf.writeVarInt(p.sounds[r]);
            buf.writeVarInt(p.volumes[r]);
            buf.writeVarInt(p.pitches[r]);
        }
    }

    private static AnnounceConfigPacket read(RegistryFriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        int n = AnnouncePanelBlockEntity.ROWS;
        String[] names = new String[n];
        int[] sounds = new int[n];
        int[] volumes = new int[n];
        int[] pitches = new int[n];
        for (int r = 0; r < n; r++) {
            names[r] = buf.readUtf(32);
            sounds[r] = buf.readVarInt();
            volumes[r] = buf.readVarInt();
            pitches[r] = buf.readVarInt();
        }
        return new AnnounceConfigPacket(pos, names, sounds, volumes, pitches);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(AnnounceConfigPacket p, IPayloadContext context) {
        AnnouncePanelBlockEntity panel = AnnouncePanelBlockEntity.lookup(context.player(), p.pos);
        if (panel != null) {
            panel.applyConfig(p.names, p.sounds, p.volumes, p.pitches);
        }
    }
}
