package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Locale;
import java.util.function.Consumer;

/** Swivel Bearing: the angles, the controls and the Redstone Links. */
public class SwivelScreen extends Screen {
    private static final int W = 340;
    private static final int H = 262;

    private final BlockPos pos;
    private SwivelSettings s = new SwivelSettings();
    private int tab;
    private int left;
    private int top;
    private boolean loaded;

    public SwivelScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.swivel.title"));
        this.pos = pos;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.swivel." + key);
    }

    private SwivelBlockEntity be() {
        return minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(pos) instanceof SwivelBlockEntity b ? b : null;
    }

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.2f", v);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (!loaded) {
            loaded = true;
            SwivelBlockEntity b = be();
            if (b != null) {
                s = b.cfg.copy();
            }
        }
        rebuild();
    }

    private EditBox edit(int x, int y, int w, double value, double min, double max, Consumer<Float> set) {
        EditBox box = new EditBox(font, left + x, top + y, w, 14, Component.empty());
        box.setValue(num(value));
        box.setFilter(str -> str.matches("-?[0-9]{0,3}([.][0-9]{0,2})?"));
        box.setResponder(str -> {
            try {
                set.accept((float) Math.max(min, Math.min(max, Float.parseFloat(str))));
            } catch (NumberFormatException ignored) {
                // half-typed
            }
        });
        return box;
    }

    private Button button(int x, int y, int w, int h, Component label, Runnable action) {
        Button btn = Button.builder(label, bt -> action.run()).bounds(left + x, top + y, w, h).build();
        addRenderableWidget(btn);
        return btn;
    }

    private void rebuild() {
        clearWidgets();
        String[] tabs = {"tab_settings", "tab_control", "tab_links"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button tb = button(8 + i * 66, 22, 62, 16, t(tabs[i]), () -> {
                tab = idx;
                rebuild();
            });
            tb.active = tab != i;
        }
        button(W - 52, 4, 44, 14, Component.translatable("gui.coastercontrolpanel.ok"), this::onClose);
        if (tab == 0) {
            int x = 208;
            int w = 110;
            addRenderableWidget(edit(x, 52, w, s.rest, -180, 180, v -> s.rest = v));
            addRenderableWidget(edit(x, 72, w, s.active, -180, 180, v -> s.active = v));
            addRenderableWidget(edit(x, 92, w, s.speed, 1, 180, v -> s.speed = v));
            button(x, 112, w, 14, t("mode." + s.mode), () -> {
                s.mode = (s.mode + 1) % SwivelSettings.MODES;
                rebuild();
            });
            button(x, 132, w, 14, t("signal." + (s.analog ? 1 : 0)), () -> {
                s.analog = !s.analog;
                rebuild();
            });
            button(x, 152, w, 14, t("carry." + (s.carryAll ? 1 : 0)), () -> {
                s.carryAll = !s.carryAll;
                rebuild();
            });
            addRenderableWidget(edit(x, 172, w, s.reach, 2, 24, v -> s.reach = Math.round(v)));
        } else if (tab == 1) {
            button(8, 150, 100, 20, t("go_active"), () -> act(RideEngine.ACTION_START));
            button(120, 150, 100, 20, t("go_rest"), () -> act(RideEngine.ACTION_END));
            button(232, 150, 100, 20, t("hold"), () -> act(RideEngine.ACTION_PAUSE));
        } else {
            for (int i = 0; i < RideLinks.COUNT; i++) {
                final int slot = i;
                int y = RideLinks.ROW_Y[i];
                button(190, y, 70, 16, Component.translatable("gui.coastercontrolpanel.ride.link_set"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, false)));
                button(264, y, 50, 16, Component.translatable("gui.coastercontrolpanel.ride.link_clear"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, true)));
            }
        }
    }

    private void act(int action) {
        sendConfig();
        PacketDistributor.sendToServer(new DropTowerControlPacket(pos, action));
    }

    private void sendConfig() {
        s.sanitize();
        PacketDistributor.sendToServer(new DropTowerConfigPacket(pos, s.toTag()));
    }

    @Override
    public void removed() {
        sendConfig();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, title, left + 8, top + 8, 0xFFFFFF, false);
        int text = 0xE0E4F0;
        int dim = 0x7A8098;
        SwivelBlockEntity b = be();
        if (tab == 0) {
            String[] labels = {"rest", "active", "speed", "mode", "signal", "carry", "reach"};
            for (int i = 0; i < labels.length; i++) {
                g.drawString(font, t("set." + labels[i]), left + 12, top + 55 + i * 20, text, false);
            }
            g.drawString(font, t("settings_note"), left + 12, top + 205, dim, false);
            g.drawString(font, t("settings_note_2"), left + 12, top + 217, dim, false);
        } else if (tab == 1) {
            if (b != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.swivel.angle_line",
                        String.format(Locale.ROOT, "%.1f", b.angle), String.format(Locale.ROOT, "%.1f", b.targetAngle())), left + 12, top + 52, 0xFFFFFF, false);
                g.drawString(font, t(b.holding() ? "status.hold" : b.moving ? "status.moving" : "status.still"), left + 12, top + 68, text, false);
            }
            g.drawString(font, t("control_note_1"), left + 12, top + 100, dim, false);
            g.drawString(font, t("control_note_2"), left + 12, top + 112, dim, false);
            g.drawString(font, t("control_note_3"), left + 12, top + 124, dim, false);
        } else {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note"), left + 12, top + 44, dim, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.0"), left + 12, top + 60, 0xFFFFC040, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.1"), left + 12, top + 126, 0xFFFF6050, false);
            for (int i = 0; i < RideLinks.COUNT; i++) {
                int y = top + RideLinks.ROW_Y[i];
                g.drawString(font, t("link." + i), left + 12, y + 4, text, false);
                g.fill(left + 150, y - 1, left + 168, y + 17, 0xFF3A3E4D);
                g.fill(left + 151, y, left + 167, y + 16, 0xFF101218);
                if (b != null && !b.links().stack(i).isEmpty()) {
                    g.renderItem(b.links().stack(i), left + 151, y);
                }
            }
        }
    }
}
