package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** A ride fence: a post with two rails that join other ride fences and the posts of ride gates. */
public class RideFenceBlock extends Block {
    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;

    private static final VoxelShape POST = Block.box(6, 0, 6, 10, 16, 10);
    private static final VoxelShape POST_COLL = Block.box(6, 0, 6, 10, 24, 10);
    private static final VoxelShape[] ARMS = {
            Block.box(7, 0, 0, 9, 16, 6),   // north
            Block.box(10, 0, 7, 16, 16, 9), // east
            Block.box(7, 0, 10, 9, 16, 16), // south
            Block.box(0, 0, 7, 6, 16, 9)    // west
    };
    private static final VoxelShape[] ARMS_COLL = {
            Block.box(7, 0, 0, 9, 24, 6),
            Block.box(10, 0, 7, 16, 24, 9),
            Block.box(7, 0, 10, 9, 24, 16),
            Block.box(0, 0, 7, 6, 24, 9)
    };
    private static final Direction[] SIDES = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    public RideFenceBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false)
                .setValue(SOUTH, false).setValue(WEST, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST);
    }

    private static BooleanProperty prop(Direction d) {
        return switch (d) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case SOUTH -> SOUTH;
            default -> WEST;
        };
    }

    private static boolean canConnect(BlockState neighbor, Direction toward) {
        if (neighbor.getBlock() instanceof RideFenceBlock) {
            return true;
        }
        return neighbor.getBlock() instanceof RideGateBlock && RideGateBlock.opensAlong(neighbor, toward);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = defaultBlockState();
        for (Direction d : SIDES) {
            state = state.setValue(prop(d), canConnect(level.getBlockState(pos.relative(d)), d));
        }
        return state;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction.getAxis().isHorizontal()) {
            return state.setValue(prop(direction), canConnect(neighborState, direction));
        }
        return state;
    }

    private static VoxelShape build(BlockState state, VoxelShape post, VoxelShape[] arms) {
        VoxelShape shape = post;
        for (int i = 0; i < 4; i++) {
            if (state.getValue(prop(SIDES[i]))) {
                shape = Shapes.or(shape, arms[i]);
            }
        }
        return shape;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return build(state, POST, ARMS);
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return build(state, POST_COLL, ARMS_COLL);
    }
}
