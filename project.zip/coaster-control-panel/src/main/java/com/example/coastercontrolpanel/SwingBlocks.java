package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** The blocks of the Swing Ride: Base (the engine), Pivot Head, Swing Arm, Gondola Hub and Gondola Frame. */
public final class SwingBlocks {
    private SwingBlocks() {
    }

    public static final int REACH = 24;

    /** The nearest Pivot Head within reach of a position. */
    @Nullable
    public static BlockPos findPivot(Level level, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(from.offset(-REACH, -REACH, -REACH), from.offset(REACH, REACH, REACH))) {
            if (level.getBlockState(p).getBlock() instanceof PivotBlock) {
                double d = p.distSqr(from);
                if (d < bestD) {
                    bestD = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    /** True for blocks that belong to the gondola: the Hub and the Frames. */
    public static boolean isGondolaPart(BlockState state) {
        return state.getBlock() instanceof HubBlock || state.getBlock() instanceof GondolaFrameBlock;
    }

    /** The engine. Right-click to open the ride settings and controls. */
    public static class BaseBlock extends BaseEntityBlock {
        public static final MapCodec<BaseBlock> CODEC = simpleCodec(BaseBlock::new);
        private static final VoxelShape SHAPE = Shapes.or(Block.box(0, 0, 0, 16, 6, 16), Block.box(1, 6, 1, 15, 14, 15));

        public BaseBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new SwingBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return createTickerHelper(type, CoasterControlPanel.SWING_BE.get(), (l, p, s, be) -> {
                if (l.isClientSide) {
                    be.clientTick();
                } else {
                    be.serverTick();
                }
            });
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRide(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof SwingBlockEntity be) {
                be.baseRemoved();
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof SwingBlockEntity be) {
                be.refreshRedstone();
            }
        }
    }

    /** The pivot the arm hangs from. Place it on top of your own supports; AXIS is the line the arm swings around. */
    public static class PivotBlock extends Block {
        public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;
        private static final VoxelShape SHAPE_X = Shapes.or(Block.box(0, 4, 4, 16, 12, 12), Block.box(5, 0, 5, 11, 4, 11));
        private static final VoxelShape SHAPE_Z = Shapes.or(Block.box(4, 4, 0, 12, 12, 16), Block.box(5, 0, 5, 11, 4, 11));

        public PivotBlock(Properties properties) {
            super(properties);
            registerDefaultState(stateDefinition.any().setValue(AXIS, Direction.Axis.X));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(AXIS);
        }

        @Nullable
        @Override
        public BlockState getStateForPlacement(BlockPlaceContext context) {
            // the arm swings around the line you place it along
            return defaultBlockState().setValue(AXIS, context.getHorizontalDirection().getAxis());
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return state.getValue(AXIS) == Direction.Axis.X ? SHAPE_X : SHAPE_Z;
        }
    }

    /** One piece of the arm. Stack them straight down under the Pivot Head. */
    public static class ArmBlock extends Block {
        private static final VoxelShape SHAPE = Block.box(5, 0, 5, 11, 16, 11);

        public ArmBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** The centre of the gondola: it goes under the last arm piece. The gondola turns around this block. */
    public static class HubBlock extends Block {
        private static final VoxelShape SHAPE = Shapes.or(Block.box(4, 4, 4, 12, 12, 12), Block.box(6, 12, 6, 10, 16, 10));

        public HubBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** Build the gondola around the Hub out of Frames and your own seats. Frames stick to each other and to seats. */
    public static class GondolaFrameBlock extends Block {
        public GondolaFrameBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return DropTowerBlocks.FrameBlock.SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return Shapes.empty();
        }

        @Override
        protected float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
            return 1.0F;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return true;
        }
    }
}
