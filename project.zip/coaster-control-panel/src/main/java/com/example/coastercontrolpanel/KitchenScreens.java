package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** The two small screens of the Kitchen Pack: Order Bell and Extractor Fan. */
public final class KitchenScreens {
    private KitchenScreens() {
    }

    abstract static class Base extends Screen {
        protected static final int W = 200;
        protected final BlockPos pos;
        protected int left;
        protected int top;
        protected int height2;

        protected Base(Component title, BlockPos pos, int height2) {
            super(title);
            this.pos = pos;
            this.height2 = height2;
        }

        @Override
        protected void init() {
            left = (width - W) / 2;
            top = (height - height2) / 2;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                    .bounds(left + W - 52, top + height2 - 22, 44, 16).build());
            build();
        }

        protected abstract void build();

        protected void send(int action) {
            PacketDistributor.sendToServer(new KitchenConfigPacket(pos, action));
        }

        @Override
        public boolean isPauseScreen() {
            return false;
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            renderTransparentBackground(g);
            g.fill(left, top, left + W, top + height2, 0xFF3A3E4D);
            g.fill(left + 1, top + 1, left + W - 1, top + height2 - 1, 0xFF1B1D24);
            g.drawString(font, title, left + 8, top + 7, 0xFFFFFF, false);
        }
    }

    /** Ring the bell, see the order number, reset it. */
    public static class BellScreen extends Base {
        public BellScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.order_bell"), pos, 118);
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.bell_ring"), b -> send(1))
                    .bounds(left + 8, top + 50, 184, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.bell_reset"), b -> send(2))
                    .bounds(left + 8, top + 76, 90, 16).build());
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            int orders = 0;
            if (minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof KitchenExtras.BellBlockEntity b) {
                orders = b.orders();
            }
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.bell_last", orders), left + W / 2, top + 26, 0xE8A93A);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.bell_help"), left + 8, top + 100, 0x9AA0B4, false);
        }
    }

    /** Off, Low or High. */
    public static class FanScreen extends Base {
        public FanScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.extractor_fan"), pos, 118);
        }

        private int speed() {
            if (minecraft != null && minecraft.level != null) {
                var s = minecraft.level.getBlockState(pos);
                if (s.getBlock() instanceof KitchenExtras.FanBlock) {
                    return s.getValue(KitchenExtras.FanBlock.SPEED);
                }
            }
            return 0;
        }

        @Override
        protected void build() {
            for (int i = 0; i < 3; i++) {
                final int speed = i;
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.fan_" + i), b -> send(10 + speed))
                        .bounds(left + 8 + i * 62, top + 50, 58, 20).build());
            }
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.renderBackground(g, mouseX, mouseY, partialTick);
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.fan_now",
                    Component.translatable("gui.coastercontrolpanel.fan_" + speed())), left + W / 2, top + 26, 0xE8A93A);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.fan_help"), left + 8, top + 80, 0x9AA0B4, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.fan_help2"), left + 8, top + 92, 0x9AA0B4, false);
        }
    }
}
