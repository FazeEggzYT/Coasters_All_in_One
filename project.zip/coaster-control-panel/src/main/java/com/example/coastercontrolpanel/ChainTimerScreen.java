package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Locale;

/** Chain Timer: how long the lift takes to reach full speed when turned on, and to stop when turned off. */
public class ChainTimerScreen extends Screen {
    private final BlockPos pos;
    private float up;
    private float down;
    private EditBox upBox;
    private EditBox downBox;

    public ChainTimerScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.chain_timer.title"));
        this.pos = pos;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getBlockEntity(pos) instanceof DriveTyre.Holder h) {
            up = h.ccp$rampUp();
            down = h.ccp$rampDown();
        }
    }

    private static String num(float v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.1f", v);
    }

    private EditBox box(int x, int y, float value) {
        EditBox b = new EditBox(font, x, y, 60, 16, Component.empty());
        b.setValue(num(value));
        b.setFilter(str -> str.matches("[0-9]{0,3}([.][0-9]?)?"));
        addRenderableWidget(b);
        return b;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 - 40;
        upBox = box(cx + 20, y + 22, up);
        downBox = box(cx + 20, y + 46, down);
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.chain_timer.apply"), b -> {
            apply();
            onClose();
        }).bounds(cx - 90, y + 80, 85, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.chain_timer.instant"), b -> {
            upBox.setValue("0");
            downBox.setValue("0");
        }).bounds(cx + 5, y + 80, 85, 18).build());
    }

    private static float parse(EditBox b) {
        try {
            return Math.max(0.0F, Math.min(120.0F, Float.parseFloat(b.getValue())));
        } catch (NumberFormatException e) {
            return 0.0F;
        }
    }

    private void apply() {
        PacketDistributor.sendToServer(new ChainRampPacket(pos, parse(upBox), parse(downBox)));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int cx = width / 2;
        int y = height / 2 - 40;
        g.fill(cx - 110, y - 14, cx + 110, y + 110, 0xFF3A3E4D);
        g.fill(cx - 109, y - 13, cx + 109, y + 109, 0xFF1B1D24);
        g.drawString(font, title, cx - 100, y - 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.chain_timer.up"), cx - 100, y + 26, 0xE0E4F0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.chain_timer.down"), cx - 100, y + 50, 0xE0E4F0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.chain_timer.note"), cx - 100, y + 68, 0x7A8098, false);
    }
}
