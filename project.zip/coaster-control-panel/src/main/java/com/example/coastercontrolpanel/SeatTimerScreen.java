package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Seat Timer: how many seconds before the restraint opens, and before it closes. */
public class SeatTimerScreen extends Screen {
    private static final int W = 200;
    private static final int H = 112;

    private final BlockPos pos;
    private int open;
    private int close;

    public SeatTimerScreen(BlockPos pos, int open, int close) {
        super(Component.translatable("gui.coastercontrolpanel.seat_title"));
        this.pos = pos;
        this.open = open;
        this.close = close;
    }

    private int step() {
        return Screen.hasShiftDown() ? 5 : 1;
    }

    @Override
    protected void init() {
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> open = Math.max(0, open - step()))
                .bounds(x + 110, y + 28, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> open = Math.min(60, open + step()))
                .bounds(x + 174, y + 28, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> close = Math.max(0, close - step()))
                .bounds(x + 110, y + 52, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> close = Math.min(60, close + step()))
                .bounds(x + 174, y + 52, 18, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(x + 8 + (W - 16) / 2 - 30, y + 86, 60, 18).build());
    }

    @Override
    public void onClose() {
        PacketDistributor.sendToServer(new SeatTimerPacket(pos, open, close));
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xFF3A3E4D);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xFF1B1D24);
        g.drawString(font, title, x + 8, y + 8, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.seat_open"), x + 8, y + 32, 0xE0E4F0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.seat_close"), x + 8, y + 56, 0xE0E4F0, false);
        g.drawCenteredString(font, open + " s", x + 151, y + 32, 0xFFFFFF);
        g.drawCenteredString(font, close + " s", x + 151, y + 56, 0xFFFFFF);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.seat_hint"), x + 8, y + 74, 0x7A8098, false);
        super.render(g, mouseX, mouseY, partialTick);
    }
}
