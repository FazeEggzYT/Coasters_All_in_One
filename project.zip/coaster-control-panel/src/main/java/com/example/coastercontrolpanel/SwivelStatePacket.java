package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client, every tick while a Swivel Bearing moves: the client turns the structure to this angle. */
public record SwivelStatePacket(BlockPos pos, float angle) implements CustomPacketPayload {
    public static final Type<SwivelStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "swivel_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SwivelStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.angle);
            },
            buf -> new SwivelStatePacket(buf.readBlockPos(), buf.readFloat()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SwivelStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof SwivelBlockEntity be) {
            be.receiveAngle(p.angle);
        }
    }
}
