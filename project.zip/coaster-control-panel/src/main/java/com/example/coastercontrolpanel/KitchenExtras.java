package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.function.Supplier;

/** The Fridge, Order Bell, Extractor Fan and the drink item of the Kitchen Pack. */
public final class KitchenExtras {
    private KitchenExtras() {
    }

    // ------------------------------------------------------------------ drinks

    /** A bottled drink: drunk with the drinking animation, gives a short effect, and returns the glass bottle. */
    public static class DrinkItem extends Item {
        private final Supplier<Holder<MobEffect>> effect;
        private final int seconds;

        public DrinkItem(Properties p, Supplier<Holder<MobEffect>> effect, int seconds) {
            super(p);
            this.effect = effect;
            this.seconds = seconds;
        }

        @Override
        public UseAnim getUseAnimation(ItemStack stack) {
            return UseAnim.DRINK;
        }

        @Override
        public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
            ItemStack result = super.finishUsingItem(stack, level, entity);
            if (!level.isClientSide && effect != null) {
                entity.addEffect(new MobEffectInstance(effect.get(), seconds * 20, 0));
            }
            if (entity instanceof Player player) {
                if (player.getAbilities().instabuild) {
                    return result;
                }
                ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE);
                if (result.isEmpty()) {
                    return bottle;
                }
                if (!player.getInventory().add(bottle)) {
                    player.drop(bottle, false);
                }
            }
            return result;
        }
    }

    // ------------------------------------------------------------------ fridge

    public static class FridgeBlockEntity extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);

        public FridgeBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.FRIDGE_BE.get(), pos, state);
        }

        protected FridgeBlockEntity(net.minecraft.world.level.block.entity.BlockEntityType<?> type, BlockPos pos, BlockState state) {
            super(type, pos, state);
        }

        @Override
        public int getContainerSize() {
            return 27;
        }

        @Override
        protected Component getDefaultName() {
            return Component.translatable("block.coastercontrolpanel.fridge");
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return ChestMenu.threeRows(id, inv, this);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
        }
    }

    /** A fridge: 27 slots of storage, and a comparator reads how full it is. */
    public static class FridgeBlock extends BaseEntityBlock {
        public static final MapCodec<FridgeBlock> CODEC = simpleCodec(FridgeBlock::new);

        public FridgeBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(DecorBlocks.FACING, Direction.NORTH));
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(DecorBlocks.FACING);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return defaultBlockState().setValue(DecorBlocks.FACING, c.getHorizontalDirection().getOpposite());
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(1, 0, 1, 15, 16, 15);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new FridgeBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof FridgeBlockEntity be) {
                player.openMenu(be);
                level.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 0.3F, 1.6F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected boolean hasAnalogOutputSignal(BlockState state) {
            return true;
        }

        @Override
        protected int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
            return AbstractContainerMenu.getRedstoneSignalFromBlockEntity(level.getBlockEntity(pos));
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof Container c) {
                Containers.dropContents(level, pos, c);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    // ------------------------------------------------------------------ order bell

    public static class BellBlockEntity extends BlockEntity {
        private int orders;

        public BellBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.BELL_BE.get(), pos, state);
        }

        public int orders() {
            return orders;
        }

        public void ring() {
            if (!(level instanceof ServerLevel sl)) {
                return;
            }
            orders++;
            setChanged();
            sl.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            sl.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.4F, 1.3F);
            sl.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 1.0F, 1.0F);
            BlockState st = getBlockState();
            if (st.hasProperty(BellBlock.POWERED)) {
                sl.setBlock(worldPosition, st.setValue(BellBlock.POWERED, true), 3);
                sl.scheduleTick(worldPosition, st.getBlock(), 10);
            }
            for (Player p : sl.players()) {
                if (p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 24 * 24) {
                    p.displayClientMessage(Component.translatable("message.coastercontrolpanel.order_ready", orders), true);
                }
            }
        }

        public void reset() {
            orders = 0;
            setChanged();
            if (level != null) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Orders", orders);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            orders = tag.getInt("Orders");
        }

        @Override
        public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
            return saveWithoutMetadata(registries);
        }

        @Nullable
        @Override
        public Packet<ClientGamePacketListener> getUpdatePacket() {
            return ClientboundBlockEntityDataPacket.create(this);
        }
    }

    /** Order bell: right-click opens its screen. Ringing numbers the order, tells nearby players and gives a redstone pulse. */
    public static class BellBlock extends BaseEntityBlock {
        public static final MapCodec<BellBlock> CODEC = simpleCodec(BellBlock::new);
        public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

        public BellBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(POWERED, false));
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(POWERED);
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(3, 0, 3, 13, 9, 13);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new BellBlockEntity(pos, state);
        }

        @Override
        protected boolean isSignalSource(BlockState state) {
            return true;
        }

        @Override
        protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
            return state.getValue(POWERED) ? 15 : 0;
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(POWERED)) {
                level.setBlock(pos, s.setValue(POWERED, false), 3);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openOrderBell(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ extractor fan

    /** Extractor fan: right-click to set Off, Low or High. Kitchen machines within 5 blocks cook faster and make no smoke. */
    public static class FanBlock extends DecorBlocks.Facing {
        public static final IntegerProperty SPEED = IntegerProperty.create("speed", 0, 2);

        public FanBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(SPEED, 0));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(SPEED);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 1, 1, 12, 15, 15, 16);
        }

        /** The strongest running fan near a position: 0 none, 1 low, 2 high. */
        public static int bonus(Level level, BlockPos pos) {
            int best = 0;
            for (BlockPos p : BlockPos.betweenClosed(pos.offset(-5, -3, -5), pos.offset(5, 3, 5))) {
                BlockState s = level.getBlockState(p);
                if (s.getBlock() instanceof FanBlock) {
                    best = Math.max(best, s.getValue(SPEED));
                }
            }
            return best;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openFan(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
