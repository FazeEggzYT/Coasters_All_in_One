package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;

/**
 * Listens to one Redstone Link frequency (or plain redstone). When the signal turns on or off it waits
 * "delay" seconds, then opens or closes this gate and every gate beside it at the same moment.
 * Gates beside it need no setup, they just follow.
 */
public class RideGateBlockEntity extends BlockEntity {
    private final SimpleContainer frequency = new SimpleContainer(1);
    private int delay = 3; // seconds

    private int received = 0;
    private boolean lastSignal = false;
    private int pending = -1;
    private boolean pendingTarget = false;

    // client animation, 0 = closed, 1 = open
    public float progress;
    public float prevProgress;

    private final Link link = new Link();
    private boolean registered = false;
    private boolean loading = false;

    public RideGateBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.GATE_BE.get(), pos, state);
        progress = prevProgress = state.getValue(RideGateBlock.OPEN) ? 1.0F : 0.0F;
        frequency.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLink();
                    registerLink();
                }
            }
        });
    }

    public SimpleContainer getFrequency() {
        return frequency;
    }

    public int getDelay() {
        return delay;
    }

    @Nullable
    public static RideGateBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof RideGateBlockEntity g ? g : null;
    }

    public void applyConfig(int newDelay) {
        delay = Math.max(0, Math.min(60, newDelay));
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---------------------------------------------------------------- lifecycle and link

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLink();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLink();
    }

    @Override
    public void setRemoved() {
        unregisterLink();
        super.setRemoved();
    }

    private void registerLink() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        ItemStack stack = frequency.getItem(0);
        link.alive = !stack.isEmpty();
        link.key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        if (link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, link);
            received = 0;
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, link);
        }
    }

    private void unregisterLink() {
        if (!registered) {
            return;
        }
        registered = false;
        if (level != null && link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, link);
        }
        link.alive = false;
        received = 0;
    }

    // ---------------------------------------------------------------- opening and closing

    /** Opens or closes this gate and its neighbours right now. */
    public void setGroupOpen(boolean open) {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean changed = false;
        for (BlockPos p : RideGateBlock.group(level, worldPosition, getBlockState())) {
            BlockState s = level.getBlockState(p);
            if (!(s.getBlock() instanceof RideGateBlock)) {
                continue;
            }
            if (s.getValue(RideGateBlock.OPEN) != open) {
                level.setBlock(p, s.setValue(RideGateBlock.OPEN, open), 3);
                changed = true;
            }
            if (level.getBlockEntity(p) instanceof RideGateBlockEntity g) {
                g.pending = -1;
            }
        }
        if (changed) {
            level.playSound(null, worldPosition, open ? SoundEvents.FENCE_GATE_OPEN : SoundEvents.FENCE_GATE_CLOSE,
                    SoundSource.BLOCKS, 1.0F, 0.9F);
        }
    }

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean signal = received > 0 || level.hasNeighborSignal(worldPosition);
        if (signal != lastSignal) {
            lastSignal = signal;
            if (delay <= 0) {
                setGroupOpen(signal);
            } else {
                pending = delay * 20;
                pendingTarget = signal;
            }
        }
        if (pending > 0) {
            pending--;
            if (pending == 0) {
                pending = -1;
                setGroupOpen(pendingTarget);
            }
        }
    }

    public void clientTick() {
        prevProgress = progress;
        float target = getBlockState().getValue(RideGateBlock.OPEN) ? 1.0F : 0.0F;
        if (progress < target) {
            progress = Math.min(target, progress + 0.07F);
        } else if (progress > target) {
            progress = Math.max(target, progress - 0.07F);
        }
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        list.set(0, frequency.getItem(0));
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Delay", delay);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        frequency.setItem(0, list.get(0));
        if (tag.contains("Delay")) {
            delay = tag.getInt("Delay");
        }
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** The leaf swings outside the block, so tell the renderer not to cull it too early. */
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition).inflate(1.0);
    }

    // ---------------------------------------------------------------- Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        @Override
        public int getTransmittedStrength() {
            return 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            received = power;
        }

        @Override
        public boolean isListening() {
            return true;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
