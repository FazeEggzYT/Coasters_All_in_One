package com.example.coastercontrolpanel;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MobBucketItem;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Blocks that join up with their own kind into a bigger one: aquarium tank, petting pen, penguin pool, campfire pit.
 * Plus the bed sized sleeping bag. The model of a tile shows a wall on every side that has no neighbour.
 */
public final class ParkConnect {
    private ParkConnect() {
    }

    public static final BooleanProperty N = BlockStateProperties.NORTH;
    public static final BooleanProperty E = BlockStateProperties.EAST;
    public static final BooleanProperty S = BlockStateProperties.SOUTH;
    public static final BooleanProperty W = BlockStateProperties.WEST;
    public static final BooleanProperty WET = BlockStateProperties.WATERLOGGED;
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public static final int AQUARIUM = 0;
    public static final int PEN = 1;
    public static final int POOL = 2;
    public static final int FIRE = 3;

    /** How high the wall looks (1/16 blocks). */
    private static final double[] WALL = {16, 12, 14, 4};
    /** How high the wall blocks you. The pen is a full block so sheep stay in and you can still jump in. */
    private static final double[] COLL = {16, 16, 14, 4};
    private static final double[] FLOOR = {2, 2, 2, 1};

    static BooleanProperty prop(Direction d) {
        return switch (d) {
            case NORTH -> N;
            case EAST -> E;
            case SOUTH -> S;
            default -> W;
        };
    }

    public static class Tile extends Block implements SimpleWaterloggedBlock {
        private final int kind;
        private final VoxelShape[] shapes = new VoxelShape[16];
        private final VoxelShape[] colls = new VoxelShape[16];

        public Tile(int kind, Properties p) {
            super(p);
            this.kind = kind;
            registerDefaultState(stateDefinition.any().setValue(N, false).setValue(E, false).setValue(S, false).setValue(W, false)
                    .setValue(WET, false).setValue(LIT, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(N, E, S, W, WET, LIT);
        }

        private boolean holdsWater() {
            return kind == AQUARIUM || kind == POOL;
        }

        private static int index(BlockState s) {
            return (s.getValue(N) ? 1 : 0) | (s.getValue(E) ? 2 : 0) | (s.getValue(S) ? 4 : 0) | (s.getValue(W) ? 8 : 0);
        }

        private VoxelShape build(BlockState s, double h) {
            VoxelShape v = Block.box(0, 0, 0, 16, FLOOR[kind], 16);
            double z1 = s.getValue(N) ? 0 : 2;
            double z2 = s.getValue(S) ? 16 : 14;
            if (!s.getValue(N)) {
                v = Shapes.or(v, Block.box(0, 0, 0, 16, h, 2));
            }
            if (!s.getValue(S)) {
                v = Shapes.or(v, Block.box(0, 0, 14, 16, h, 16));
            }
            if (!s.getValue(W)) {
                v = Shapes.or(v, Block.box(0, 0, z1, 2, h, z2));
            }
            if (!s.getValue(E)) {
                v = Shapes.or(v, Block.box(14, 0, z1, 16, h, z2));
            }
            return v.optimize();
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            int i = index(s);
            if (shapes[i] == null) {
                shapes[i] = build(s, WALL[kind]);
            }
            return shapes[i];
        }

        @Override
        protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            int i = index(s);
            if (colls[i] == null) {
                colls[i] = build(s, COLL[kind]);
            }
            return colls[i];
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            BlockState s = defaultBlockState();
            for (Direction d : Direction.Plane.HORIZONTAL) {
                s = s.setValue(prop(d), c.getLevel().getBlockState(c.getClickedPos().relative(d)).is(this));
            }
            FluidState f = c.getLevel().getFluidState(c.getClickedPos());
            return s.setValue(WET, holdsWater() && f.getType() == Fluids.WATER);
        }

        @Override
        protected BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
            if (s.getValue(WET)) {
                l.scheduleTick(p, Fluids.WATER, Fluids.WATER.getTickDelay(l));
            }
            if (d.getAxis().isHorizontal()) {
                return s.setValue(prop(d), n.is(this));
            }
            return s;
        }

        @Override
        protected FluidState getFluidState(BlockState s) {
            return s.getValue(WET) ? Fluids.WATER.getSource(false) : super.getFluidState(s);
        }

        @Override
        public boolean canPlaceLiquid(@Nullable Player player, BlockGetter l, BlockPos p, BlockState s, net.minecraft.world.level.material.Fluid f) {
            return holdsWater() && SimpleWaterloggedBlock.super.canPlaceLiquid(player, l, p, s, f);
        }

        @Override
        public boolean placeLiquid(LevelAccessor l, BlockPos p, BlockState s, FluidState f) {
            return holdsWater() && SimpleWaterloggedBlock.super.placeLiquid(l, p, s, f);
        }

        /** Every tile of the same kind that touches this one, this one included. */
        private Set<BlockPos> group(Level level, BlockPos start) {
            Set<BlockPos> seen = new HashSet<>();
            ArrayDeque<BlockPos> todo = new ArrayDeque<>();
            todo.add(start);
            seen.add(start);
            while (!todo.isEmpty() && seen.size() < 96) {
                BlockPos p = todo.poll();
                for (Direction d : Direction.Plane.HORIZONTAL) {
                    BlockPos q = p.relative(d);
                    if (!seen.contains(q) && level.getBlockState(q).is(this)) {
                        seen.add(q);
                        todo.add(q);
                    }
                }
            }
            return seen;
        }

        private void setLit(Level level, BlockPos pos, boolean lit) {
            for (BlockPos p : group(level, pos)) {
                BlockState s = level.getBlockState(p);
                if (s.is(this)) {
                    level.setBlock(p, s.setValue(LIT, lit), 3);
                }
            }
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (kind == FIRE) {
                boolean lit = s.getValue(LIT);
                if (!lit && (stack.is(Items.FLINT_AND_STEEL) || stack.is(Items.FIRE_CHARGE))) {
                    if (!level.isClientSide) {
                        setLit(level, pos, true);
                        level.playSound(null, pos, SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
                        if (!player.getAbilities().instabuild) {
                            if (stack.is(Items.FIRE_CHARGE)) {
                                stack.shrink(1);
                            } else {
                                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
                            }
                        }
                    }
                    return ItemInteractionResult.sidedSuccess(level.isClientSide);
                }
                if (lit && stack.is(Items.WATER_BUCKET)) {
                    if (!level.isClientSide) {
                        setLit(level, pos, false);
                        level.playSound(null, pos, SoundEvents.GENERIC_EXTINGUISH_FIRE, SoundSource.BLOCKS, 1.0F, 1.0F);
                        player.setItemInHand(hand, BucketItem.getEmptySuccessItem(stack, player));
                    }
                    return ItemInteractionResult.sidedSuccess(level.isClientSide);
                }
                if (lit && !ParkProps.cooked(stack).isEmpty()) {
                    if (player instanceof ServerPlayer sp && level instanceof ServerLevel sl) {
                        ParkProps.cookOnFire(sp, sl, pos);
                    }
                    return ItemInteractionResult.sidedSuccess(level.isClientSide);
                }
            }
            if (holdsWater() && s.getValue(WET) && stack.getItem() instanceof MobBucketItem fish) {
                if (!level.isClientSide) {
                    fish.checkExtraContent(player, level, stack, pos);
                    level.playSound(null, pos, SoundEvents.BUCKET_EMPTY_FISH, SoundSource.BLOCKS, 1.0F, 1.0F);
                    player.setItemInHand(hand, BucketItem.getEmptySuccessItem(stack, player));
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (kind == FIRE) {
                if (level.isClientSide) {
                    return InteractionResult.SUCCESS;
                }
                if (s.getValue(LIT) && player.isShiftKeyDown()) {
                    setLit(level, pos, false);
                    level.playSound(null, pos, SoundEvents.GENERIC_EXTINGUISH_FIRE, SoundSource.BLOCKS, 1.0F, 1.0F);
                } else {
                    ParkProps.say(player, s.getValue(LIT) ? "fire_help_lit" : "fire_help");
                }
                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        }

        @Override
        protected void entityInside(BlockState s, Level level, BlockPos pos, Entity e) {
            if (kind == FIRE && s.getValue(LIT) && e instanceof LivingEntity && !e.fireImmune() && e.getY() < pos.getY() + 0.4) {
                e.hurt(level.damageSources().campfire(), 1.0F);
            }
        }

        @Override
        public void animateTick(BlockState s, Level level, BlockPos pos, RandomSource r) {
            if (kind == FIRE && s.getValue(LIT)) {
                if (r.nextInt(6) == 0) {
                    level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, pos.getX() + 0.5 + (r.nextDouble() - 0.5) * 0.4, pos.getY() + 0.7,
                            pos.getZ() + 0.5 + (r.nextDouble() - 0.5) * 0.4, 0.0, 0.06, 0.0);
                }
                if (r.nextInt(40) == 0) {
                    level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, SoundEvents.CAMPFIRE_CRACKLE, SoundSource.BLOCKS,
                            0.6F, 1.0F, false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ sleeping bag: two blocks on the floor, like a bed

    public static class Bag extends Block {
        public static final DirectionProperty FACING = DecorBlocks.FACING;
        public static final EnumProperty<BedPart> PART = BlockStateProperties.BED_PART;
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 4.5, 16);

        public Bag(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(PART, BedPart.FOOT));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(FACING, PART);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return SHAPE;
        }

        private static Direction towardOther(BlockState s) {
            Direction f = s.getValue(FACING);
            return s.getValue(PART) == BedPart.FOOT ? f : f.getOpposite();
        }

        @Nullable
        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            Direction d = c.getHorizontalDirection();
            BlockPos head = c.getClickedPos().relative(d);
            Level l = c.getLevel();
            return l.getBlockState(head).canBeReplaced(c) && l.getWorldBorder().isWithinBounds(head)
                    ? defaultBlockState().setValue(FACING, d) : null;
        }

        @Override
        public void setPlacedBy(Level level, BlockPos pos, BlockState s, @Nullable LivingEntity by, ItemStack stack) {
            super.setPlacedBy(level, pos, s, by, stack);
            if (!level.isClientSide) {
                BlockPos head = pos.relative(s.getValue(FACING));
                level.setBlock(head, s.setValue(PART, BedPart.HEAD), 3);
                level.blockUpdated(pos, Blocks.AIR);
                s.updateNeighbourShapes(level, pos, 3);
            }
        }

        @Override
        protected BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
            if (d == towardOther(s)) {
                return n.is(this) && n.getValue(PART) != s.getValue(PART) ? s : Blocks.AIR.defaultBlockState();
            }
            return super.updateShape(s, d, n, l, p, np);
        }

        @Override
        public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState s, Player player) {
            if (!level.isClientSide && player.isCreative() && s.getValue(PART) == BedPart.FOOT) {
                BlockPos other = pos.relative(towardOther(s));
                BlockState o = level.getBlockState(other);
                if (o.is(this) && o.getValue(PART) == BedPart.HEAD) {
                    level.setBlock(other, Blocks.AIR.defaultBlockState(), 35);
                    level.levelEvent(player, 2001, other, Block.getId(o));
                }
            }
            return super.playerWillDestroy(level, pos, s, player);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (player.isShiftKeyDown() && player instanceof ServerPlayer sp) {
                BlockPos foot = s.getValue(PART) == BedPart.FOOT ? pos : pos.relative(towardOther(s));
                sp.setRespawnPosition(level.dimension(), foot, 0.0F, false, false);
                ParkProps.say(player, "bag_spawn");
                return InteractionResult.CONSUME;
            }
            return ParkProps.sitAt(level, pos, player, 4.5);
        }
    }
}
