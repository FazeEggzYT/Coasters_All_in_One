package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client: the latest photo of a camera, as PNG bytes. */
public record PhotoDataPacket(BlockPos camera, int version, int index, int total, byte[] png) implements CustomPacketPayload {
    public static final Type<PhotoDataPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "photo_data"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PhotoDataPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.camera);
                buf.writeVarInt(p.version);
                buf.writeVarInt(p.index);
                buf.writeVarInt(p.total);
                buf.writeByteArray(p.png);
            },
            buf -> new PhotoDataPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readByteArray(PhotoStore.CHUNK + 16)));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(PhotoDataPacket p, IPayloadContext context) {
        PhotoClient.receiveChunk(p.camera, p.version, p.index, p.total, p.png);
    }
}
