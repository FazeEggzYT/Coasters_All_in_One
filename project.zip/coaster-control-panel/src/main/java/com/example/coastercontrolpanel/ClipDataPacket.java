package com.example.coastercontrolpanel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client: a piece of an announcement file the client asked for. */
public record ClipDataPacket(String hash, int index, int total, byte[] data) implements CustomPacketPayload {
    public static final Type<ClipDataPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip_data"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ClipDataPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeUtf(p.hash, 32);
                buf.writeVarInt(p.index);
                buf.writeVarInt(p.total);
                buf.writeByteArray(p.data);
            },
            buf -> new ClipDataPacket(buf.readUtf(32), buf.readVarInt(), buf.readVarInt(),
                    buf.readByteArray(ClipStore.CHUNK + 16)));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ClipDataPacket p, IPayloadContext context) {
        ClipClient.receive(p.hash, p.index, p.total, p.data);
    }
}
