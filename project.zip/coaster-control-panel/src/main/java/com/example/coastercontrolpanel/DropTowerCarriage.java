package com.example.coastercontrolpanel;

import com.simibubi.create.AllTags;
import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.content.contraptions.pulley.PulleyContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

/**
 * The part of a Drop Tower that rides: Create's own moving-structure system carries it. Carriage Frames stick to each
 * other and to seats that touch them (never to the tower), everything else is carried with Create's Super Glue.
 */
public final class DropTowerCarriage {
    private DropTowerCarriage() {
    }

    /** A Create translating contraption anchored on a Carriage Frame; nothing above the anchor is treated as a rope. */
    public static class Contraption extends PulleyContraption {
        public Contraption() {
            super(0);
        }

        @Override
        protected boolean isAnchoringBlockAt(BlockPos pos) {
            return false;
        }
    }

    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(SwingCarriage::registerChecks);
        event.enqueueWork(() -> BlockMovementChecks.registerAttachedCheck((state, level, pos, direction) -> {
            if (!(state.getBlock() instanceof DropTowerBlocks.FrameBlock)) {
                return BlockMovementChecks.CheckResult.PASS;
            }
            BlockState other = level.getBlockState(pos.relative(direction));
            if (other.getBlock() instanceof DropTowerBlocks.FrameBlock || AllTags.AllBlockTags.SEATS.matches(other)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            return BlockMovementChecks.CheckResult.PASS;
        }));
    }
}
