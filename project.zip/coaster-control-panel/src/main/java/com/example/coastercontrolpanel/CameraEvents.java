package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Camera item on an anchor: remembers the anchor, the next camera you place uses it.
 * Camera Connector on a camera, then on a Photo Screen: links them.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class CameraEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        Level level = event.getLevel();
        BlockPos pos = event.getPos();
        Player player = event.getEntity();

        if (stack.is(CoasterControlPanel.CAMERA_ITEM.get()) && AnchorTrack.isAnchor(level.getBlockEntity(pos))) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            if (!level.isClientSide) {
                CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
                tag.putLong("Anchor", pos.asLong());
                stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.camera_anchor"), true);
            }
            return;
        }

        if (stack.is(CoasterControlPanel.CONNECTOR_ITEM.get())) {
            boolean camera = level.getBlockEntity(pos) instanceof CameraBlockEntity;
            boolean screen = level.getBlockEntity(pos) instanceof PhotoScreenBlockEntity;
            if (!camera && !screen) {
                return;
            }
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            if (level.isClientSide) {
                return;
            }
            CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
            if (camera) {
                tag.putLong("Camera", pos.asLong());
                stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_camera"), true);
            } else if (!tag.contains("Camera")) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_first"), true);
            } else {
                BlockPos cam = BlockPos.of(tag.getLong("Camera"));
                if (!(level.getBlockEntity(cam) instanceof CameraBlockEntity)) {
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_gone"), true);
                } else if (level.getBlockEntity(pos) instanceof PhotoScreenBlockEntity ps) {
                    ps.link(cam);
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_done"), true);
                }
            }
        }
    }
}
