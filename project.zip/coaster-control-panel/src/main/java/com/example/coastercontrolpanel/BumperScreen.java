package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Bumper Cars console: the ride controls, the ride length and the wireless inputs and outputs. */
public class BumperScreen extends Screen {
    private static final int W = 340;
    private static final int H = 262;

    private final BlockPos pos;
    private int left;
    private int top;
    private int tab = 0;
    private int seconds = 120;
    private int redstone = 0;
    private boolean loaded;
    private Button startButton;
    private Button pauseButton;
    private Button endButton;
    private Button haltButton;

    public BumperScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.bumper.title"));
        this.pos = pos;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.bumper." + key);
    }

    private BumperBlockEntity be() {
        return minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(pos) instanceof BumperBlockEntity b ? b : null;
    }

    private boolean idle() {
        BumperBlockEntity b = be();
        return b == null || b.idle();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (!loaded) {
            loaded = true;
            BumperBlockEntity b = be();
            if (b != null) {
                seconds = b.rideSeconds;
                redstone = b.redstoneMode;
            }
        }
        rebuild();
    }

    private Button button(int x, int y, int w, int h, Component label, Runnable action) {
        Button btn = Button.builder(label, bt -> action.run()).bounds(left + x, top + y, w, h).build();
        addRenderableWidget(btn);
        return btn;
    }

    private void sendConfig() {
        if (idle()) {
            CompoundTag tag = new CompoundTag();
            tag.putInt("RideSeconds", seconds);
            tag.putInt("Redstone", redstone);
            PacketDistributor.sendToServer(new DropTowerConfigPacket(pos, tag));
        }
    }

    private void act(int action) {
        sendConfig();
        PacketDistributor.sendToServer(new DropTowerControlPacket(pos, action));
    }

    private void rebuild() {
        clearWidgets();
        startButton = pauseButton = endButton = haltButton = null;
        String[] tabs = {"tab_control", "tab_settings", "tab_links"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button tb = button(8 + i * 66, 22, 62, 16, t(tabs[i]), () -> {
                tab = idx;
                rebuild();
            });
            tb.active = tab != i;
        }
        button(W - 52, 4, 44, 14, Component.translatable("gui.coastercontrolpanel.ok"), this::onClose);
        boolean editable = idle();
        if (tab == 0) {
            startButton = button(8, 150, 100, 20, t("start"), () -> act(RideEngine.ACTION_START));
            pauseButton = button(120, 150, 100, 20, t("pause"), () -> act(RideEngine.ACTION_PAUSE));
            endButton = button(232, 150, 100, 20, t("end"), () -> act(RideEngine.ACTION_END));
            haltButton = button(8, 176, 324, 20, t("halt"), () -> act(RideEngine.ACTION_HALT));
        } else if (tab == 1) {
            int[] steps = {-60, -10, 10, 60};
            for (int i = 0; i < steps.length; i++) {
                final int d = steps[i];
                Button b = button(190 + i * 36, 56, 32, 14, Component.literal((d > 0 ? "+" : "") + d), () -> {
                    seconds = Math.max(10, Math.min(1800, seconds + d));
                    sendConfig();
                    rebuild();
                });
                b.active = editable;
            }
            Button rs = button(190, 82, 140, 14, t("redstone." + redstone), () -> {
                redstone = 1 - redstone;
                sendConfig();
                rebuild();
            });
            rs.active = editable;
        } else {
            for (int i = 0; i < RideLinks.COUNT; i++) {
                final int slot = i;
                int y = RideLinks.ROW_Y[i];
                button(190, y, 70, 16, Component.translatable("gui.coastercontrolpanel.ride.link_set"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, false)));
                button(264, y, 50, 16, Component.translatable("gui.coastercontrolpanel.ride.link_clear"),
                        () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, true)));
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (tab == 0 && startButton != null) {
            BumperBlockEntity b = be();
            boolean running = b != null && b.running;
            startButton.active = !running || (b != null && b.halted);
            pauseButton.active = running && !b.halted;
            pauseButton.setMessage(b != null && b.paused ? t("resume") : t("pause"));
            endButton.active = running;
            haltButton.active = running && !b.halted;
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, title, left + 8, top + 8, 0xFFFFFF, false);
        int text = 0xE0E4F0;
        int dim = 0x7A8098;
        if (tab == 0) {
            BumperBlockEntity b = be();
            int status = b == null || !b.running ? 0 : b.halted ? 3 : b.paused ? 2 : 1;
            g.drawString(font, t("status." + status), left + 12, top + 52, 0xFFFFFF, false);
            if (b != null && b.running) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.bumper.time_line", b.ticksLeft / 20), left + 12, top + 68, text, false);
            }
            g.drawString(font, t("control_note_1"), left + 12, top + 108, dim, false);
            g.drawString(font, t("control_note_2"), left + 12, top + 120, dim, false);
            g.drawString(font, t("control_note_3"), left + 12, top + 132, dim, false);
            g.drawString(font, t("control_note_4"), left + 12, top + 202, dim, false);
        } else if (tab == 1) {
            g.drawString(font, t("set.length"), left + 12, top + 59, text, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.bumper.seconds", seconds), left + 12, top + 73, dim, false);
            g.drawString(font, t("set.redstone"), left + 12, top + 85, text, false);
            g.drawString(font, t("settings_note"), left + 12, top + 246, dim, false);
        } else {
            BumperBlockEntity b = be();
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note"), left + 12, top + 44, dim, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.0"), left + 12, top + 60, 0xFFFFC040, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.1"), left + 12, top + 126, 0xFFFF6050, false);
            for (int i = 0; i < RideLinks.COUNT; i++) {
                int y = top + RideLinks.ROW_Y[i];
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link." + i), left + 12, y + 4, text, false);
                g.fill(left + 150, y - 1, left + 168, y + 17, 0xFF3A3E4D);
                g.fill(left + 151, y, left + 167, y + 16, 0xFF101218);
                if (b != null && !b.links().stack(i).isEmpty()) {
                    g.renderItem(b.links().stack(i), left + 151, y);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note_2"), left + 12, top + H - 22, dim, false);
        }
    }
}
