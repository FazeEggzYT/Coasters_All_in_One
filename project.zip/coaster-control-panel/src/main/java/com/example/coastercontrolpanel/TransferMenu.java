package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Eight ghost slots for Redstone Link items (left, right, forward, back, stop A to D), plus your inventory. */
public class TransferMenu extends AbstractContainerMenu {
    public static final int N = TransferTableBlockEntity.INPUTS;
    private final BlockPos pos;

    public TransferMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, new SimpleContainer(N), buf.readBlockPos());
    }

    public TransferMenu(int id, Inventory playerInv, SimpleContainer container, BlockPos pos) {
        super(CoasterControlPanel.TRANSFER_MENU.get(), id);
        this.pos = pos;
        for (int i = 0; i < N; i++) {
            addSlot(new GhostSlot(container, i, slotX(i), slotY(i)));
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInv, col + row * 9 + 9, 69 + col * 18, 130 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInv, col, 69 + col * 18, 188));
        }
    }

    public static int slotX(int i) {
        return 172 + (i % 4) * 30;
    }

    public static int slotY(int i) {
        return i < 4 ? 40 : 84;
    }

    public BlockPos getPos() {
        return pos;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < N) {
            ItemStack carried = getCarried();
            slots.get(slotId).set(carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1));
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }

    private static class GhostSlot extends Slot {
        GhostSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }

        @Override
        public boolean mayPickup(Player player) {
            return false;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
