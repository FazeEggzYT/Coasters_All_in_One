package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Screen of a kitchen machine: slots, a progress arrow, and the list of everything it can make. */
public class KitchenScreen extends AbstractContainerScreen<KitchenMenu> {
    private static final int PANEL_W = 136;

    public KitchenScreen(KitchenMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176 + PANEL_W + 4;
        this.imageHeight = 184;
    }

    private KitchenKind kind() {
        if (minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(menu.pos) instanceof KitchenBlockEntity e) {
            return e.kind();
        }
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + 176, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + 175, y0 + imageHeight - 1, 0xFF1B1D24);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
        // progress arrow between the ingredients and the output
        int ax = x0 + 70;
        int ay = y0 + 43;
        g.fill(ax, ay, ax + 44, ay + 8, 0xFF3A3E4D);
        g.fill(ax + 1, ay + 1, ax + 43, ay + 7, 0xFF0D0E12);
        int w = (int) (42 * menu.progress());
        g.fill(ax + 1, ay + 1, ax + 1 + w, ay + 7, 0xFFE8A93A);
        // recipe panel
        int px = x0 + 180;
        g.fill(px, y0, px + PANEL_W, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(px + 1, y0 + 1, px + PANEL_W - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        KitchenKind k = kind();
        if (k != null) {
            int y = y0 + 22;
            for (KitchenKind.Recipe r : k.recipes) {
                int x = px + 6;
                item(g, new ItemStack(r.a().get(), r.ca()), x, y);
                x += 20;
                if (r.b() != null) {
                    g.drawString(font, "+", x - 1, y + 4, 0xFFFFFF, false);
                    item(g, new ItemStack(r.b().get(), r.cb()), x + 8, y);
                    x += 28;
                }
                g.drawString(font, "->", x, y + 4, 0xE8A93A, false);
                item(g, new ItemStack(r.out().get(), r.outCount()), x + 16, y);
                y += 20;
            }
        }
    }

    private void item(GuiGraphics g, ItemStack stack, int x, int y) {
        g.renderFakeItem(stack, x, y);
        g.renderItemDecorations(font, stack, x, y);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.kitchen_in"), 8, 30, 0x9AA0B4, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.kitchen_out"), 120, 28, 0x9AA0B4, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.kitchen_recipes"), 186, 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 8, 90, 0x7A8098, false);
        KitchenKind k = kind();
        if (k != null) {
            int secs = k.cookTicks / 20;
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.kitchen_time", secs), 8, 76, 0x9AA0B4, false);
        }
    }
}
