package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client to server for the Gift Shop and First Aid screens. Actions: 1 shop buy (a = slot, b = amount), 2 shop price
 * (a = slot, b = change), 3 shop remove slot, 4 shop collect takings, 5 price tag slot, 6 window spin change,
 * 7 window take item, 10 first aid treat, 11 first aid cooldown change (seconds), 12 first aid strength change,
 * 13 first aid cure toggle, 14 defibrillator cooldown change, 15 defibrillator test, 16 lost child call,
 * 17 lost child found, 18 phone call (a = reason).
 */
public record ParkActionPacket(BlockPos pos, int action, int a, int b) implements CustomPacketPayload {
    public static final Type<ParkActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "park_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ParkActionPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.a + 1000);
                buf.writeVarInt(p.b + 1000);
            },
            buf -> new ParkActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt() - 1000, buf.readVarInt() - 1000));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ParkActionPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        Level level = player.level();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 64.0 || !level.isLoaded(p.pos)) {
            return;
        }
        var be = level.getBlockEntity(p.pos);
        switch (p.action) {
            case 1, 2, 3, 4 -> {
                if (be instanceof GiftBlocks.ShopBlockEntity shop) {
                    switch (p.action) {
                        case 1 -> shop.buy(player, p.a, p.b);
                        case 2 -> shop.changePrice(p.a, p.b);
                        case 3 -> shop.removeSlot(player, p.a);
                        default -> shop.collect(player);
                    }
                }
            }
            case 5 -> {
                if (be instanceof GiftBlocks.PriceTagBlockEntity tag) {
                    tag.setSlot(p.a);
                }
            }
            case 6, 7 -> {
                if (be instanceof GiftBlocks.WindowBlockEntity w) {
                    if (p.action == 6) {
                        w.spin = Math.max(0, Math.min(5, w.spin + p.a));
                    } else if (!w.shown.isEmpty()) {
                        ArcadeBlocks.give(player, w.shown);
                        w.shown = net.minecraft.world.item.ItemStack.EMPTY;
                    }
                    w.changed();
                }
            }
            case 10, 11, 12, 13 -> {
                if (be instanceof SafetyBlocks.FirstAidBlockEntity aid) {
                    switch (p.action) {
                        case 10 -> aid.treat(player);
                        case 11 -> aid.changeCooldown(p.a);
                        case 12 -> aid.changeStrength(p.a);
                        default -> aid.toggleCure();
                    }
                }
            }
            case 14, 15 -> {
                if (be instanceof SafetyBlocks.DefibBlockEntity d) {
                    if (p.action == 14) {
                        d.changeCooldown(p.a);
                    } else {
                        d.test(player);
                    }
                }
            }
            case 16, 17 -> {
                if (be instanceof SafetyBlocks.ChildPointBlockEntity c) {
                    if (p.action == 16) {
                        c.call(player);
                    } else {
                        c.found(player);
                    }
                }
            }
            case 18 -> {
                if (be instanceof SafetyBlocks.PhoneBlockEntity ph) {
                    ph.call(player, p.a);
                }
            }
            default -> {
            }
        }
    }
}
