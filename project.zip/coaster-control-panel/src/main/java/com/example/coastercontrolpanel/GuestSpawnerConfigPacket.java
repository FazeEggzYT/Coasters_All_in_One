package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: all the settings of a Guest Spawner, and optionally "spawn one guest now". */
public record GuestSpawnerConfigPacket(BlockPos pos, int[] values, boolean spawnOne) implements CustomPacketPayload {
    public static final Type<GuestSpawnerConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "spawner_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, GuestSpawnerConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.values.length);
                for (int v : p.values) {
                    buf.writeVarInt(v);
                }
                buf.writeBoolean(p.spawnOne);
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                int n = Math.min(buf.readVarInt(), 32);
                int[] values = new int[n];
                for (int i = 0; i < n; i++) {
                    values[i] = buf.readVarInt();
                }
                return new GuestSpawnerConfigPacket(pos, values, buf.readBoolean());
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(GuestSpawnerConfigPacket p, IPayloadContext context) {
        GuestSpawnerBlockEntity spawner = GuestSpawnerBlockEntity.lookup(context.player(), p.pos);
        if (spawner == null) {
            return;
        }
        spawner.applyConfig(p.values);
        if (p.spawnOne && spawner.getLevel() instanceof ServerLevel server) {
            spawner.spawn(server);
        }
    }
}
