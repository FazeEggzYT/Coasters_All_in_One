package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** The blocks of the Teacup Ride: Base (engine), Platter Hub, Platter Plate, Cup Hub, Cup Floor and Cup Wall. */
public final class TeacupBlocks {
    private TeacupBlocks() {
    }

    public static final int REACH = 24;

    /** The nearest Platter Hub within reach of a position. */
    @Nullable
    public static BlockPos findHub(Level level, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(from.offset(-REACH, -REACH, -REACH), from.offset(REACH, REACH, REACH))) {
            if (level.getBlockState(p).getBlock() instanceof PlatterHub) {
                double d = p.distSqr(from);
                if (d < bestD) {
                    bestD = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    /** The engine. Right-click to open the ride settings and controls. */
    public static class BaseBlock extends BaseEntityBlock {
        public static final MapCodec<BaseBlock> CODEC = simpleCodec(BaseBlock::new);
        private static final VoxelShape SHAPE = Shapes.or(Block.box(0, 0, 0, 16, 6, 16), Block.box(1, 6, 1, 15, 14, 15));

        public BaseBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new TeacupBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return createTickerHelper(type, CoasterControlPanel.TEACUP_BE.get(), (l, p, s, be) -> {
                if (l.isClientSide) {
                    be.clientTick();
                } else {
                    be.serverTick();
                }
            });
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRide(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof TeacupBlockEntity be) {
                be.baseRemoved();
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof TeacupBlockEntity be) {
                be.refreshRedstone();
            }
        }
    }

    /** A piece of the platter. Platter pieces stick to each other. */
    public abstract static class PlatterPart extends Block {
        protected PlatterPart(Properties properties) {
            super(properties);
        }
    }

    /** The centre of the platter: it turns around this block. */
    public static class PlatterHub extends PlatterPart {
        private static final VoxelShape SHAPE = Shapes.or(Block.box(0, 0, 0, 16, 12, 16), Block.box(5, 12, 5, 11, 16, 11));

        public PlatterHub(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    public static class PlatterPlate extends PlatterPart {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 12, 16);

        public PlatterPlate(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** The middle of a cup floor: the cup turns around this block. */
    public static class CupHub extends SwingBlocks.HubBlock {
        public CupHub(Properties properties) {
            super(properties);
        }
    }

    /** Solid cup blocks (floor and wall) that stick to each other and to touching seats. */
    public static class CupFloor extends SwingBlocks.GondolaFrameBlock {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 8, 16);

        public CupFloor(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return false;
        }
    }

    public static class CupWall extends SwingBlocks.GondolaFrameBlock {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 16, 16);

        public CupWall(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return false;
        }
    }
}
