package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: all the settings of an effect block, and optionally "run a test". */
public record EffectConfigPacket(BlockPos pos, int[] values, boolean test) implements CustomPacketPayload {
    public static final Type<EffectConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "effect_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, EffectConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.values.length);
                for (int v : p.values) {
                    buf.writeVarInt(v);
                }
                buf.writeBoolean(p.test);
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                int n = Math.min(buf.readVarInt(), 64);
                int[] values = new int[n];
                for (int i = 0; i < n; i++) {
                    values[i] = buf.readVarInt();
                }
                return new EffectConfigPacket(pos, values, buf.readBoolean());
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(EffectConfigPacket p, IPayloadContext context) {
        EffectBlockEntity effect = EffectBlockEntity.lookup(context.player(), p.pos);
        if (effect == null) {
            return;
        }
        effect.applyConfig(p.values);
        if (p.test) {
            effect.test();
        }
    }
}
