package com.example.coastercontrolpanel;

/** The four kinds of sign. They share one block class and one setup screen. */
public enum SignKind {
    RIDE("ride_sign"),
    OPEN("open_sign"),
    HEIGHT("height_sign"),
    WAIT("wait_sign");

    public final String id;

    SignKind(String id) {
        this.id = id;
    }
}
