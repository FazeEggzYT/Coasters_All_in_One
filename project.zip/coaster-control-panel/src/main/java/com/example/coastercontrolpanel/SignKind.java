package com.example.coastercontrolpanel;

/** The four kinds of sign. They share one block class and one setup screen. */
public enum SignKind {
    RIDE("ride_sign"),
    OPEN("open_sign"),
    HEIGHT("height_sign"),
    WAIT("wait_sign"),
    ENTRANCE("entrance_sign"),
    EXIT("exit_sign"),
    NOTICE("notice_sign"),
    DIRECTION("direction_sign"),
    CROWD("queue_status_sign"),
    COUNTER("rides_today_sign"),
    FLOOR("floor_sign");

    public final String id;

    SignKind(String id) {
        this.id = id;
    }
}
