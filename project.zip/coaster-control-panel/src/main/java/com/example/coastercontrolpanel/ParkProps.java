package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * The second round of the amenity packs: bathroom, kitchen, restaurant, gift shop, first aid, arcade extras,
 * guest services and staff props. Four block classes cover them all:
 * Plain (no screen), Seat, Store (a chest-style container), TextProp (a sign with lines of text) and Act (a screen).
 * Shapes, light levels and sounds come from the generated ParkData.
 */
public final class ParkProps {
    private ParkProps() {
    }

    /** One integer state shared by every prop: the look of the block (water level, on/off, brightness...). */
    public static final IntegerProperty ST = IntegerProperty.create("st", 0, 3);

    public static int light(String id, BlockState s) {
        int[] l = ParkData.LIGHT.get(id);
        if (l == null) {
            return 0;
        }
        return l[Math.min(s.getValue(ST), l.length - 1)];
    }

    static VoxelShape shape(String id, BlockState s) {
        double[][] all = ParkData.SHAPES.get(id);
        if (all == null) {
            return Block.box(0, 0, 0, 16, 16, 16);
        }
        double[] b = all[Math.min(s.getValue(ST), all.length - 1)];
        return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), b[0], b[1], b[2], b[3], b[4], b[5]);
    }

    static VoxelShape shape0(String id, Direction facing) {
        double[][] all = ParkData.SHAPES.get(id);
        if (all == null) {
            return Block.box(0, 0, 0, 16, 16, 16);
        }
        double[] b = all[0];
        return DecorBlocks.dbox(facing, b[0], b[1], b[2], b[3], b[4], b[5]);
    }

    static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    static void sound(Level level, BlockPos pos, String key, float pitch) {
        SoundEvent e = switch (key) {
            case "splash" -> SoundEvents.GENERIC_SPLASH;
            case "bucket" -> SoundEvents.BUCKET_EMPTY;
            case "lever" -> SoundEvents.LEVER_CLICK;
            case "wool" -> SoundEvents.WOOL_PLACE;
            case "sand" -> SoundEvents.SAND_PLACE;
            case "wood" -> SoundEvents.WOOD_PLACE;
            case "glass" -> SoundEvents.GLASS_PLACE;
            case "chain" -> SoundEvents.CHAIN_PLACE;
            case "anvil" -> SoundEvents.ANVIL_PLACE;
            case "bell" -> SoundEvents.BELL_BLOCK;
            case "button" -> SoundEvents.STONE_BUTTON_CLICK_ON;
            case "pickup" -> SoundEvents.ITEM_PICKUP;
            case "pop" -> SoundEvents.LAVA_POP;
            case "brew" -> SoundEvents.BREWING_STAND_BREW;
            case "axe" -> SoundEvents.AXE_STRIP;
            case "note" -> SoundEvents.NOTE_BLOCK_CHIME.value();
            default -> SoundEvents.UI_BUTTON_CLICK.value();
        };
        level.playSound(null, pos, e, SoundSource.BLOCKS, 0.8F, pitch);
    }

    static void puff(ServerLevel sl, BlockPos pos, String key, int n) {
        ParticleOptions o = switch (key) {
            case "splash" -> ParticleTypes.SPLASH;
            case "cloud" -> ParticleTypes.CLOUD;
            case "smoke" -> ParticleTypes.CAMPFIRE_COSY_SMOKE;
            case "snow" -> ParticleTypes.SNOWFLAKE;
            case "note" -> ParticleTypes.NOTE;
            default -> null;
        };
        if (o != null) {
            sl.sendParticles(o, pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5, n, 0.2, 0.1, 0.2, 0.02);
        }
    }

    static ItemStack named(Item item, String name) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name));
        return s;
    }

    /** Pay gold nuggets (free in creative). */
    static boolean pay(Player p, int nuggets) {
        if (p.getAbilities().instabuild) {
            return true;
        }
        if (ArcadeBlocks.count(p, Items.GOLD_NUGGET) < nuggets) {
            say(p, "prop_poor", nuggets);
            return false;
        }
        ArcadeBlocks.take(p, Items.GOLD_NUGGET, nuggets);
        return true;
    }

    /** Sit the player on an invisible seat entity. */
    static InteractionResult sit(Level level, BlockPos pos, Player player, String id) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player.isPassenger()) {
            return InteractionResult.PASS;
        }
        if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
            say(player, "seat_taken");
            return InteractionResult.CONSUME;
        }
        Double surface = ParkData.SEAT.get(id);
        double y = (surface == null ? 8.0 : surface) / 16.0 - 0.39;
        SeatEntity seat = new SeatEntity(CoasterControlPanel.SEAT.get(), level);
        seat.setPos(pos.getX() + 0.5, pos.getY() + y, pos.getZ() + 0.5);
        level.addFreshEntity(seat);
        player.startRiding(seat);
        return InteractionResult.CONSUME;
    }

    // ------------------------------------------------------------------ plain props

    /** No screen: a click makes a sound and puffs, a few have a special action. */
    public static class Plain extends DecorBlocks.Facing {
        public final String id;

        public Plain(String id, Properties p) {
            super(p);
            this.id = id;
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(ST);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(0, 0, 0, 16, 16, 16);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shape(id, s);
        }

        @Override
        protected void onPlace(BlockState s, Level level, BlockPos pos, BlockState old, boolean moved) {
            if (!level.isClientSide && id.equals("sprinkler_head")) {
                level.scheduleTick(pos, this, 20);
            }
            super.onPlace(s, level, pos, old, moved);
        }

        private void toggle(BlockState s, Level level, BlockPos pos, int on, int delay) {
            int st = s.getValue(ST);
            int n = st == 0 ? on : 0;
            level.setBlock(pos, s.setValue(ST, n), 3);
            sound(level, pos, ParkData.SOUND.getOrDefault(id, "lever"), ParkData.PITCH.getOrDefault(id, 1.0F));
            if (n != 0 && delay > 0) {
                level.scheduleTick(pos, this, delay);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            ServerLevel sl = (ServerLevel) level;
            int st = s.getValue(ST);
            switch (id) {
                case "vanity_mirror" -> toggle(s, level, pos, 3, 3);
                case "shower_curtain_rail" -> toggle(s, level, pos, 1, 0);
                case "steamer" -> toggle(s, level, pos, 1, 10);
                case "heated_towel_rail" -> toggle(s, level, pos, 1, 20);
                case "toaster" -> {
                    if (st == 2) {
                        ArcadeBlocks.give(player, new ItemStack(CoasterControlPanel.TOAST.get()));
                        level.setBlock(pos, s.setValue(ST, 0), 3);
                        sound(level, pos, "pickup", 1.0F);
                    } else if (st == 0) {
                        say(player, "toaster_need_bread");
                    }
                }
                case "eyewash_station" -> {
                    player.removeEffect(MobEffects.BLINDNESS);
                    player.removeEffect(MobEffects.CONFUSION);
                    sound(level, pos, "splash", 1.0F);
                    puff(sl, pos, "splash", 14);
                    say(player, "eyewash");
                }
                case "napkin_dispenser" -> {
                    ItemStack n = new ItemStack(Items.PAPER);
                    n.set(DataComponents.CUSTOM_NAME, Component.translatable("item.coastercontrolpanel.napkin"));
                    ArcadeBlocks.give(player, n);
                    sound(level, pos, "pickup", 1.4F);
                }
                case "mop_bucket" -> mop(s, level, pos, player, st);
                case "sprinkler_head" -> say(player, "sprinkler_auto");
                default -> {
                    sound(level, pos, ParkData.SOUND.getOrDefault(id, "button"), ParkData.PITCH.getOrDefault(id, 1.0F));
                    String particle = ParkData.PARTICLE.get(id);
                    if (particle != null) {
                        puff(sl, pos, particle, id.equals("snow_globe") ? 40 : 8);
                    }
                }
            }
            return InteractionResult.CONSUME;
        }

        private void mop(BlockState s, Level level, BlockPos pos, Player player, int st) {
            if (st == 1) {
                int n = 0;
                for (BlockPos q : BlockPos.betweenClosed(pos.offset(-3, -1, -3), pos.offset(3, 1, 3))) {
                    if (level.getBlockState(q).getBlock() instanceof StaffBlocks.LitterBlock) {
                        level.removeBlock(q, false);
                        n++;
                    }
                }
                if (n == 0) {
                    say(player, "mop_clean");
                } else {
                    level.setBlock(pos, s.setValue(ST, 2), 3);
                    sound(level, pos, "splash", 0.8F);
                    say(player, "mop_cleaned", n);
                }
            } else if (st == 2) {
                level.setBlock(pos, s.setValue(ST, 0), 3);
                sound(level, pos, "splash", 0.6F);
                say(player, "mop_emptied");
            } else {
                say(player, "mop_need_water");
            }
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (id.equals("toaster") && s.getValue(ST) == 0 && stack.is(Items.BREAD)) {
                if (!level.isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    level.scheduleTick(pos, this, 60);
                    sound(level, pos, "lever", 0.8F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (id.equals("mop_bucket") && s.getValue(ST) == 0 && stack.is(Items.WATER_BUCKET)) {
                if (!level.isClientSide) {
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    if (!player.getAbilities().instabuild) {
                        player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                    }
                    sound(level, pos, "bucket", 1.0F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            int st = s.getValue(ST);
            switch (id) {
                case "vanity_mirror" -> {
                    if (st > 0) {
                        int r = random.nextInt(10);
                        level.setBlock(pos, s.setValue(ST, r < 6 ? 3 : r < 8 ? 2 : 1), 3);
                        level.scheduleTick(pos, this, 2 + random.nextInt(6));
                    }
                }
                case "steamer" -> {
                    if (st == 1) {
                        puff(level, pos, "cloud", 4);
                        sound(level, pos, "pop", 1.8F);
                        level.scheduleTick(pos, this, 12);
                    }
                }
                case "heated_towel_rail" -> {
                    if (st == 1) {
                        puff(level, pos, "cloud", 1);
                        level.scheduleTick(pos, this, 40);
                    }
                }
                case "toaster" -> {
                    if (st == 1) {
                        level.setBlock(pos, s.setValue(ST, 2), 3);
                        sound(level, pos, "lever", 1.4F);
                        puff(level, pos, "smoke", 5);
                    }
                }
                case "sprinkler_head" -> sprinkle(s, level, pos);
                default -> {
                }
            }
        }

        private void sprinkle(BlockState s, ServerLevel level, BlockPos pos) {
            boolean fire = false;
            for (BlockPos q : BlockPos.betweenClosed(pos.offset(-4, -4, -4), pos.offset(4, 2, 4))) {
                if (level.getBlockState(q).is(BlockTags.FIRE)) {
                    fire = true;
                    break;
                }
            }
            boolean run = fire || level.hasNeighborSignal(pos);
            if (run) {
                if (s.getValue(ST) != 1) {
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                }
                if (fire) {
                    for (BlockPos q : BlockPos.betweenClosed(pos.offset(-4, -4, -4), pos.offset(4, 2, 4))) {
                        if (level.getBlockState(q).is(BlockTags.FIRE)) {
                            level.removeBlock(q, false);
                            level.playSound(null, q, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.6F, 1.2F);
                        }
                    }
                }
                level.sendParticles(ParticleTypes.FALLING_WATER, pos.getX() + 0.5, pos.getY() - 0.2, pos.getZ() + 0.5, 24, 1.8, 0.3, 1.8, 0.0);
                level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() - 1.5, pos.getZ() + 0.5, 12, 1.5, 0.2, 1.5, 0.0);
                level.scheduleTick(pos, this, 10);
            } else {
                if (s.getValue(ST) != 0) {
                    level.setBlock(pos, s.setValue(ST, 0), 3);
                }
                level.scheduleTick(pos, this, 40);
            }
        }
    }

    // ------------------------------------------------------------------ seats

    public static class Seat extends DecorBlocks.Facing {
        public final String id;

        public Seat(String id, Properties p) {
            super(p);
            this.id = id;
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(ST);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(0, 0, 0, 16, 16, 16);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shape(id, s);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && player.isShiftKeyDown()) {
                return InteractionResult.PASS;
            }
            return sit(level, pos, player, id);
        }
    }

    // ------------------------------------------------------------------ storage

    public static class StoreBE extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);

        public StoreBE(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.STORE_BE.get(), pos, state);
        }

        int rows() {
            return getBlockState().getBlock() instanceof Store s ? s.rows : 3;
        }

        @Override
        public int getContainerSize() {
            return rows() * 9;
        }

        @Override
        protected Component getDefaultName() {
            return getBlockState().getBlock() instanceof Store s
                    ? Component.translatable("block.coastercontrolpanel." + s.id) : Component.literal("Storage");
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return rows() == 1 ? new ChestMenu(MenuType.GENERIC_9x1, id, inv, this, 1) : ChestMenu.threeRows(id, inv, this);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
        }
    }

    public static class Store extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<Store> CODEC = simpleCodec(p -> new Store("", p, 1));
        public final String id;
        public final int rows;

        public Store(String id, Properties p, int rows) {
            super(p);
            this.id = id;
            this.rows = rows;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(ST);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shape(id, s);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new StoreBE(pos, state);
        }

        @Override
        protected void onPlace(BlockState s, Level level, BlockPos pos, BlockState old, boolean moved) {
            if (!level.isClientSide && id.equals("trash_compactor")) {
                level.scheduleTick(pos, this, 200);
            }
            super.onPlace(s, level, pos, old, moved);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof StoreBE be) {
                player.openMenu(be);
                sound(level, pos, ParkData.SOUND.getOrDefault(id, "wood"), 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (id.equals("trash_compactor")) {
                if (level.getBlockEntity(pos) instanceof StoreBE be && !be.isEmpty()) {
                    be.clearContent();
                    be.setChanged();
                    sound(level, pos, "anvil", 0.5F);
                    puff(level, pos, "smoke", 12);
                }
                level.scheduleTick(pos, this, 200);
            }
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof StoreBE c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    // ------------------------------------------------------------------ text props

    public static class TextProp extends RestaurantBlocks.FacingEntityBlock implements GuestBlocks.TextHolder {
        public static final MapCodec<TextProp> CODEC = simpleCodec(p -> new TextProp("", p, 1, false));
        public final String id;
        public final int lines;
        private final boolean seat;

        public TextProp(String id, Properties p, int lines, boolean seat) {
            super(p);
            this.id = id;
            this.lines = lines;
            this.seat = seat;
        }

        @Override
        public int textLines() {
            return lines;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(ST);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shape(id, s);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new GuestBlocks.TextBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (seat && !player.isShiftKeyDown()) {
                return sit(level, pos, player, id);
            }
            if (level.isClientSide) {
                ClientHooks.openPropText(id, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ blocks with a screen

    public static class PropBE extends RestaurantBlocks.Syncing {
        public final int[] v = new int[6];
        public String text = "";
        public long t;

        public PropBE(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PROP_BE.get(), pos, state);
            if (state.getBlock() instanceof Act a) {
                if (a.id.equals("charging_station")) {
                    v[0] = 100;
                } else if (a.id.equals("air_freshener")) {
                    v[0] = 20;
                }
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putIntArray("V", v);
            tag.putString("Text", text);
            tag.putLong("T", t);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            int[] a = tag.getIntArray("V");
            for (int i = 0; i < v.length && i < a.length; i++) {
                v[i] = a[i];
            }
            text = tag.getString("Text");
            t = tag.getLong("T");
        }
    }

    public static class Act extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<Act> CODEC = simpleCodec(p -> new Act("", p));
        public final String id;

        public Act(String id, Properties p) {
            super(p);
            this.id = id;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(ST);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shape(id, s);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PropBE(pos, state);
        }

        @Override
        protected boolean isSignalSource(BlockState state) {
            return id.equals("fire_alarm_pull");
        }

        @Override
        protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
            return id.equals("fire_alarm_pull") && state.getValue(ST) == 1 ? 15 : 0;
        }

        @Override
        protected void onPlace(BlockState s, Level level, BlockPos pos, BlockState old, boolean moved) {
            if (!level.isClientSide) {
                if (id.equals("ice_machine")) {
                    level.scheduleTick(pos, this, 200);
                } else if (id.equals("charging_station")) {
                    level.scheduleTick(pos, this, 60);
                }
            }
            super.onPlace(s, level, pos, old, moved);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openProp(id, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!(level.getBlockEntity(pos) instanceof PropBE be)) {
                return;
            }
            long now = level.getGameTime();
            switch (id) {
                case "bathtub" -> {
                    int lvl = s.getValue(ST);
                    if (be.v[0] == 1) {
                        if (lvl < 3) {
                            level.setBlock(pos, s.setValue(ST, lvl + 1), 3);
                            sound(level, pos, "splash", 1.0F);
                        }
                        if (lvl + 1 >= 3) {
                            be.v[0] = 0;
                            be.changed();
                        }
                    } else if (be.v[0] == 2) {
                        if (lvl > 0) {
                            level.setBlock(pos, s.setValue(ST, lvl - 1), 3);
                            sound(level, pos, "bucket", 0.6F);
                        }
                        if (lvl - 1 <= 0) {
                            be.v[0] = 0;
                            be.changed();
                        }
                    }
                    if (be.v[0] != 0) {
                        level.sendParticles(ParticleTypes.FALLING_WATER, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.8, 6, 0.05, 0.05, 0.05, 0.0);
                        level.scheduleTick(pos, this, 30);
                    }
                }
                case "air_freshener" -> {
                    if (be.v[2] == 1) {
                        ParticleOptions o = switch (be.v[1]) {
                            case 0 -> ParticleTypes.WITCH;
                            case 1 -> ParticleTypes.HAPPY_VILLAGER;
                            case 2 -> ParticleTypes.CHERRY_LEAVES;
                            default -> ParticleTypes.END_ROD;
                        };
                        Direction f = s.getValue(DecorBlocks.FACING);
                        level.sendParticles(o, pos.getX() + 0.5 + f.getStepX() * 0.35, pos.getY() + 0.9, pos.getZ() + 0.5 + f.getStepZ() * 0.35, 18, 0.3, 0.25, 0.3, 0.01);
                        level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.3F, 2.0F);
                        be.v[3]++;
                        be.changed();
                        level.scheduleTick(pos, this, Math.max(5, be.v[0]) * 20);
                    }
                }
                case "hob" -> {
                    if (s.getValue(ST) > 0) {
                        puff(level, pos, "smoke", 1);
                        level.scheduleTick(pos, this, 20);
                    }
                }
                case "rice_cooker" -> {
                    if (be.v[0] == 2) {
                        if (now >= be.t) {
                            be.v[0] = 3;
                            be.changed();
                            level.setBlock(pos, s.setValue(ST, 2), 3);
                            sound(level, pos, "bell", 1.8F);
                        } else {
                            puff(level, pos, "cloud", 2);
                            level.scheduleTick(pos, this, 20);
                        }
                    }
                }
                case "blender" -> level.setBlock(pos, s.setValue(ST, 0), 3);
                case "ice_machine" -> {
                    if (be.v[0] < 16) {
                        be.v[0]++;
                        be.changed();
                    }
                    level.scheduleTick(pos, this, 200);
                }
                case "coffee_machine" -> {
                    if (be.v[0] == 1) {
                        if (now >= be.t) {
                            ItemStack out = be.v[1] == 2 ? new ItemStack(CoasterControlPanel.HOT_CHOCOLATE.get()) : new ItemStack(CoasterControlPanel.COFFEE.get());
                            Direction f = s.getValue(DecorBlocks.FACING);
                            Containers.dropItemStack(level, pos.getX() + 0.5 + f.getStepX() * 0.6, pos.getY() + 0.4, pos.getZ() + 0.5 + f.getStepZ() * 0.6, out);
                            be.v[0] = 0;
                            be.changed();
                            level.setBlock(pos, s.setValue(ST, 0), 3);
                            sound(level, pos, "bell", 1.6F);
                        } else {
                            puff(level, pos, "cloud", 2);
                            level.scheduleTick(pos, this, 20);
                        }
                    }
                }
                case "fire_alarm_pull" -> {
                    if (be.v[0] == 1) {
                        if (now >= be.t) {
                            be.v[0] = 0;
                            be.changed();
                            level.setBlock(pos, s.setValue(ST, 0), 3);
                        } else {
                            level.playSound(null, pos, SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, 3.0F, 1.7F);
                            level.scheduleTick(pos, this, 8);
                        }
                    }
                }
                case "charging_station" -> {
                    if (be.v[0] < 100) {
                        be.v[0]++;
                        be.changed();
                    }
                    level.scheduleTick(pos, this, 60);
                }
                case "jukebox" -> playNote(s, level, pos, be);
                default -> {
                }
            }
        }

        // ---- jukebox tunes: pairs of (semitone, ticks); semitone 12 is middle C and the note block range is 0 to 24
        static final int[][] TUNES = {
                {16, 8, 16, 8, 17, 8, 19, 8, 19, 8, 17, 8, 16, 8, 14, 8, 12, 8, 12, 8, 14, 8, 16, 8, 16, 12, 14, 4, 14, 16,
                        16, 8, 16, 8, 17, 8, 19, 8, 19, 8, 17, 8, 16, 8, 14, 8, 12, 8, 12, 8, 14, 8, 16, 8, 14, 12, 12, 4, 12, 16},
                {12, 8, 12, 8, 19, 8, 19, 8, 21, 8, 21, 8, 19, 16, 17, 8, 17, 8, 16, 8, 16, 8, 14, 8, 14, 8, 12, 16,
                        19, 8, 19, 8, 17, 8, 17, 8, 16, 8, 16, 8, 14, 16, 19, 8, 19, 8, 17, 8, 17, 8, 16, 8, 16, 8, 14, 16,
                        12, 8, 12, 8, 19, 8, 19, 8, 21, 8, 21, 8, 19, 16, 17, 8, 17, 8, 16, 8, 16, 8, 14, 8, 14, 8, 12, 16},
                {9, 8, 12, 16, 14, 8, 16, 12, 17, 4, 16, 8, 14, 16, 11, 8, 7, 12, 9, 4, 11, 8, 12, 16, 9, 8, 9, 12, 8, 4, 9, 8, 11, 16, 8, 8, 4, 24},
                {19, 6, 19, 6, 16, 6, 19, 6, 21, 6, 19, 6, 16, 12, 14, 6, 16, 6, 14, 6, 16, 6, 12, 24,
                        19, 6, 19, 6, 16, 6, 19, 6, 21, 6, 19, 6, 16, 12, 14, 6, 14, 6, 12, 6, 14, 6, 12, 24}
        };

        static SoundEvent instrument(int tune) {
            return switch (tune) {
                case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
                case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
                case 2 -> SoundEvents.NOTE_BLOCK_FLUTE.value();
                default -> SoundEvents.NOTE_BLOCK_BANJO.value();
            };
        }

        private void playNote(BlockState s, ServerLevel level, BlockPos pos, PropBE be) {
            if (be.v[2] != 1) {
                return;
            }
            int[] tune = TUNES[Math.max(0, Math.min(3, be.v[0]))];
            int i = be.v[1] * 2;
            if (i >= tune.length) {
                if (be.v[3] == 1) {
                    be.v[1] = 0;
                    i = 0;
                } else {
                    be.v[2] = 0;
                    be.changed();
                    level.setBlock(pos, s.setValue(ST, 0), 3);
                    return;
                }
            }
            float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (tune[i] - 12) / 12.0)));
            level.playSound(null, pos, instrument(be.v[0]), SoundSource.RECORDS, 3.0F, pitch);
            level.sendParticles(ParticleTypes.NOTE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 1, 0.3, 0.1, 0.3, (tune[i] - 12) / 24.0);
            be.v[1]++;
            be.changed();
            level.scheduleTick(pos, this, Math.max(2, tune[i + 1]));
        }
    }

    // ------------------------------------------------------------------ what the screens ask for

    static ItemStack cooked(ItemStack in) {
        Item i = in.getItem();
        if (i == Items.BEEF) {
            return new ItemStack(Items.COOKED_BEEF);
        } else if (i == Items.PORKCHOP) {
            return new ItemStack(Items.COOKED_PORKCHOP);
        } else if (i == Items.CHICKEN) {
            return new ItemStack(Items.COOKED_CHICKEN);
        } else if (i == Items.MUTTON) {
            return new ItemStack(Items.COOKED_MUTTON);
        } else if (i == Items.RABBIT) {
            return new ItemStack(Items.COOKED_RABBIT);
        } else if (i == Items.COD) {
            return new ItemStack(Items.COOKED_COD);
        } else if (i == Items.SALMON) {
            return new ItemStack(Items.COOKED_SALMON);
        } else if (i == Items.POTATO) {
            return new ItemStack(Items.BAKED_POTATO);
        } else if (i == Items.KELP) {
            return new ItemStack(Items.DRIED_KELP);
        } else if (i == CoasterControlPanel.RAW_PATTY.get()) {
            return new ItemStack(CoasterControlPanel.COOKED_PATTY.get());
        } else if (i == CoasterControlPanel.RAW_SAUSAGE.get()) {
            return new ItemStack(CoasterControlPanel.COOKED_SAUSAGE.get());
        }
        return ItemStack.EMPTY;
    }

    static Item juiceFrom(int n) {
        return switch (n) {
            case 1 -> Items.APPLE;
            case 2 -> Items.CARROT;
            case 3 -> Items.MELON_SLICE;
            case 4 -> Items.SWEET_BERRIES;
            default -> Items.GLOW_BERRIES;
        };
    }

    static Item juiceTo(int n) {
        return switch (n) {
            case 1 -> CoasterControlPanel.APPLE_JUICE.get();
            case 2 -> CoasterControlPanel.CARROT_JUICE.get();
            case 3 -> CoasterControlPanel.MELON_JUICE.get();
            case 4 -> CoasterControlPanel.BERRY_FIZZ.get();
            default -> CoasterControlPanel.GLOW_SMOOTHIE.get();
        };
    }

    static ItemStack chopped(ItemStack in) {
        Item i = in.getItem();
        if (i == Items.POTATO) {
            return new ItemStack(CoasterControlPanel.POTATO_STRIPS.get(), 2);
        } else if (i == CoasterControlPanel.TORTILLA.get()) {
            return new ItemStack(CoasterControlPanel.TORTILLA_CHIPS.get(), 2);
        } else if (i == Items.BEEF) {
            return new ItemStack(CoasterControlPanel.RAW_PATTY.get(), 2);
        } else if (i == Items.PORKCHOP) {
            return new ItemStack(CoasterControlPanel.RAW_SAUSAGE.get(), 2);
        }
        return ItemStack.EMPTY;
    }

    static final String[] BACKDROPS = {"Castle", "Space", "Beach", "Jungle"};
    static final String[] BALLOONS = {"Red", "Yellow", "Blue", "Green"};
    static final String[] DESIGNS = {"Dragon", "Castle", "Star", "Rocket"};
    static final String[] PAINTS = {"Tiger", "Butterfly", "Star", "Clown"};

    /** Server side of every screen button. */
    static void act(ServerPlayer p, ServerLevel level, BlockPos pos, int action, int a) {
        BlockState s = level.getBlockState(pos);
        if (!(s.getBlock() instanceof Act blk) || !(level.getBlockEntity(pos) instanceof PropBE be)) {
            return;
        }
        long now = level.getGameTime();
        boolean creative = p.getAbilities().instabuild;
        switch (blk.id) {
            case "bathtub" -> {
                if (action >= 1 && action <= 3) {
                    be.v[0] = action == 3 ? 0 : action;
                    be.changed();
                    sound(level, pos, action == 2 ? "bucket" : "splash", 1.0F);
                    if (action != 3) {
                        level.scheduleTick(pos, blk, 5);
                    }
                }
            }
            case "air_freshener" -> {
                switch (action) {
                    case 1 -> {
                        be.v[2] = be.v[2] == 1 ? 0 : 1;
                        level.setBlock(pos, s.setValue(ST, be.v[2]), 3);
                        if (be.v[2] == 1) {
                            level.scheduleTick(pos, blk, 5);
                        }
                        sound(level, pos, "lever", 1.4F);
                    }
                    case 2 -> be.v[0] = Math.max(5, Math.min(60, be.v[0] + a));
                    case 3 -> be.v[1] = (be.v[1] + 1) % 4;
                    default -> {
                    }
                }
                be.changed();
            }
            case "hob" -> {
                if (action >= 1 && action <= 4) {
                    be.v[action - 1] = (be.v[action - 1] + 1) % 4;
                } else if (action == 5) {
                    for (int i = 0; i < 4; i++) {
                        be.v[i] = 0;
                    }
                } else if (action == 6) {
                    cook(p, be, level, pos);
                }
                int max = Math.max(Math.max(be.v[0], be.v[1]), Math.max(be.v[2], be.v[3]));
                level.setBlock(pos, s.setValue(ST, max), 3);
                if (max > 0) {
                    level.scheduleTick(pos, blk, 20);
                }
                sound(level, pos, "button", 1.2F);
                be.changed();
            }
            case "rice_cooker" -> {
                if (action == 1 && be.v[0] == 0) {
                    if (creative || ArcadeBlocks.count(p, Items.WHEAT_SEEDS) >= 2) {
                        if (!creative) {
                            ArcadeBlocks.take(p, Items.WHEAT_SEEDS, 2);
                        }
                        be.v[0] = 1;
                        sound(level, pos, "sand", 1.0F);
                    } else {
                        say(p, "rice_need");
                    }
                } else if (action == 2 && be.v[0] == 1) {
                    be.v[0] = 2;
                    be.t = now + 300;
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    level.scheduleTick(pos, blk, 20);
                    sound(level, pos, "lever", 1.0F);
                } else if (action == 3 && be.v[0] == 3) {
                    ArcadeBlocks.give(p, new ItemStack(CoasterControlPanel.COOKED_RICE.get(), 2));
                    be.v[0] = 0;
                    level.setBlock(pos, s.setValue(ST, 0), 3);
                    sound(level, pos, "pickup", 1.0F);
                }
                be.changed();
            }
            case "blender" -> {
                if (action >= 1 && action <= 5) {
                    Item in = juiceFrom(action);
                    if (creative || ArcadeBlocks.count(p, in) >= 2) {
                        if (!creative) {
                            ArcadeBlocks.take(p, in, 2);
                        }
                        ArcadeBlocks.give(p, new ItemStack(juiceTo(action)));
                        level.setBlock(pos, s.setValue(ST, 1), 3);
                        level.scheduleTick(pos, blk, 40);
                        sound(level, pos, "brew", 1.4F);
                    } else {
                        say(p, "blender_need");
                    }
                }
            }
            case "ice_machine" -> {
                int n = action == 1 ? Math.min(1, be.v[0]) : action == 2 ? be.v[0] : 0;
                if (n > 0) {
                    ArcadeBlocks.give(p, new ItemStack(Items.ICE, n));
                    be.v[0] -= n;
                    be.changed();
                    sound(level, pos, "glass", 1.6F);
                } else if (action == 1 || action == 2) {
                    say(p, "ice_empty");
                }
            }
            case "chopping_board" -> {
                ItemStack held = p.getMainHandItem();
                ItemStack out = chopped(held);
                if (out.isEmpty()) {
                    say(p, "chop_none");
                } else {
                    int n = action == 2 ? Math.min(16, held.getCount()) : 1;
                    Item outItem = out.getItem();
                    int per = out.getCount();
                    held.shrink(n);
                    ArcadeBlocks.give(p, new ItemStack(outItem, per * n));
                    sound(level, pos, "axe", 1.6F);
                }
            }
            case "coffee_machine" -> {
                if ((action == 1 || action == 2) && be.v[0] == 0) {
                    be.v[0] = 1;
                    be.v[1] = action;
                    be.t = now + 100;
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    level.scheduleTick(pos, blk, 20);
                    sound(level, pos, "brew", 1.0F);
                    be.changed();
                } else if (be.v[0] == 1) {
                    say(p, "coffee_busy");
                }
            }
            case "photo_booth" -> {
                if (action == 1 && a >= 0 && a < 4 && pay(p, 1)) {
                    ArcadeBlocks.give(p, named(Items.PAPER, "Photo Strip: " + p.getName().getString() + " (" + BACKDROPS[a] + ")"));
                    level.sendParticles(ParticleTypes.FLASH, pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 1, 0.0, 0.0, 0.0, 0.0);
                    sound(level, pos, "note", 1.8F);
                }
            }
            case "balloon_stand" -> {
                if (action == 1 && a >= 0 && a < 4 && pay(p, 1)) {
                    Item dye = switch (a) {
                        case 0 -> Items.RED_DYE;
                        case 1 -> Items.YELLOW_DYE;
                        case 2 -> Items.BLUE_DYE;
                        default -> Items.GREEN_DYE;
                    };
                    ArcadeBlocks.give(p, named(dye, BALLOONS[a] + " Balloon"));
                    level.setBlock(pos, s.setValue(ST, a), 3);
                    sound(level, pos, "pop", 1.6F);
                }
            }
            case "coin_press" -> {
                if (action == 1 && a >= 0 && a < 4) {
                    if (creative || ArcadeBlocks.count(p, Items.COPPER_INGOT) >= 1) {
                        if (!creative) {
                            ArcadeBlocks.take(p, Items.COPPER_INGOT, 1);
                        }
                        ArcadeBlocks.give(p, named(Items.IRON_NUGGET, "Pressed Penny: " + DESIGNS[a]));
                        sound(level, pos, "anvil", 1.8F);
                    } else {
                        say(p, "coin_need");
                    }
                }
            }
            case "face_paint_station" -> {
                if (action == 1 && a >= 0 && a < 4) {
                    p.addEffect(new MobEffectInstance(MobEffects.GLOWING, 600, 0));
                    say(p, "paint_done", PAINTS[a]);
                    sound(level, pos, "wool", 1.2F);
                }
            }
            case "blood_pressure_monitor" -> {
                if (action == 1) {
                    float hp = p.getHealth();
                    boolean run = p.isSprinting();
                    int sys = 105 + (int) ((20.0F - hp) * 2.0F) + (run ? 25 : 0);
                    be.v[0] = sys;
                    be.v[1] = 68 + (sys - 105) / 3;
                    be.v[2] = 66 + (run ? 40 : 0) + (int) ((20.0F - hp) * 2.0F) + level.random.nextInt(5);
                    be.v[3]++;
                    be.text = p.getName().getString();
                    be.changed();
                    sound(level, pos, "button", 1.6F);
                }
            }
            case "fire_alarm_pull" -> {
                if (action == 1 && be.v[0] == 0) {
                    be.v[0] = 1;
                    be.t = now + 400;
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    level.scheduleTick(pos, blk, 5);
                    for (ServerPlayer sp : level.players()) {
                        sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.alarm", p.getName().getString(),
                                pos.getX(), pos.getY(), pos.getZ()), false);
                    }
                    be.changed();
                } else if (action == 2) {
                    if (StaffBlocks.hasBadge(p)) {
                        be.v[0] = 0;
                        level.setBlock(pos, s.setValue(ST, 0), 3);
                        be.changed();
                        sound(level, pos, "lever", 1.0F);
                    } else {
                        say(p, "staff_only");
                    }
                }
            }
            case "charging_station" -> {
                if (action == 1) {
                    if (be.v[0] >= 25) {
                        be.v[0] -= 25;
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 0));
                        be.changed();
                        sound(level, pos, "note", 2.0F);
                    } else {
                        say(p, "charge_low");
                    }
                }
            }
            case "walkie_talkie_charger" -> {
                if (action >= 1 && action <= 4) {
                    if (!StaffBlocks.hasBadge(p)) {
                        say(p, "staff_only");
                    } else if (now < be.t) {
                        say(p, "radio_wait");
                    } else {
                        be.t = now + 60;
                        be.changed();
                        for (ServerPlayer sp : level.players()) {
                            if (StaffBlocks.hasBadge(sp)) {
                                sp.sendSystemMessage(Component.translatable("message.coastercontrolpanel.radio", p.getName().getString(),
                                        Component.translatable("gui.coastercontrolpanel.prop.walkie_" + action)));
                            }
                        }
                        sound(level, pos, "button", 2.0F);
                    }
                }
            }
            case "sign_in_terminal" -> {
                String name = p.getName().getString();
                java.util.List<String> names = new java.util.ArrayList<>();
                for (String n : be.text.split("\n")) {
                    if (!n.isBlank()) {
                        names.add(n);
                    }
                }
                if (action == 1) {
                    if (!StaffBlocks.hasBadge(p)) {
                        say(p, "staff_only");
                    } else if (!names.contains(name) && names.size() < 8) {
                        names.add(name);
                        radio(level, "signed_in", name);
                    }
                } else if (action == 2 && names.remove(name)) {
                    radio(level, "signed_out", name);
                }
                be.text = String.join("\n", names);
                be.changed();
            }
            case "jukebox" -> {
                if (action >= 1 && action <= 4) {
                    be.v[0] = action - 1;
                    be.v[1] = 0;
                    be.v[2] = 1;
                    level.setBlock(pos, s.setValue(ST, 1), 3);
                    level.scheduleTick(pos, blk, 4);
                } else if (action == 5) {
                    be.v[2] = 0;
                    level.setBlock(pos, s.setValue(ST, 0), 3);
                } else if (action == 6) {
                    be.v[3] = be.v[3] == 1 ? 0 : 1;
                }
                be.changed();
            }
            default -> {
            }
        }
    }

    private static void radio(ServerLevel level, String key, String name) {
        for (ServerPlayer sp : level.players()) {
            sp.sendSystemMessage(Component.translatable("message.coastercontrolpanel." + key, name));
        }
    }

    private static void cook(ServerPlayer p, PropBE be, ServerLevel level, BlockPos pos) {
        if (Math.max(Math.max(be.v[0], be.v[1]), Math.max(be.v[2], be.v[3])) == 0) {
            say(p, "hob_cold");
            return;
        }
        ItemStack held = p.getMainHandItem();
        ItemStack out = cooked(held);
        if (out.isEmpty()) {
            say(p, "cook_none");
            return;
        }
        int n = Math.min(8, held.getCount());
        Item outItem = out.getItem();
        held.shrink(n);
        ArcadeBlocks.give(p, new ItemStack(outItem, n));
        sound(level, pos, "pop", 0.7F);
        puff(level, pos, "smoke", 6);
    }
}
