package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Section Controller setup: three signal items, the size of the detection box, and a clear delay. */
public class SectionScreen extends AbstractContainerScreen<SectionMenu> {
    private int clear = 1;
    private boolean linked = false;
    private String startText = "";
    private String endText = "";

    public SectionScreen(SectionMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 372;
        this.imageHeight = 172;
    }

    private static String fmt(net.minecraft.core.BlockPos p) {
        return p.getX() + ", " + p.getY() + ", " + p.getZ();
    }

    private int step() {
        return Screen.hasShiftDown() ? 5 : 1;
    }

    @Override
    protected void init() {
        super.init();
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof SectionControllerBlockEntity s) {
            clear = s.getClearDelay();
            linked = s.hasTrack();
            startText = s.getAnchorA() == null ? "" : fmt(s.getAnchorA());
            endText = s.getAnchorB() == null ? "" : fmt(s.getAnchorB());
        }
        addPair(88, () -> clear = Math.max(0, clear - step()), () -> clear = Math.min(30, clear + step()));
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.section_show"),
                b -> send(true, false)).bounds(leftPos + 8, topPos + 146, 62, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.zone_unlink"),
                b -> { linked = false; send(false, true); }).bounds(leftPos + 72, topPos + 146, 62, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + 146, topPos + 3, 38, 14).build());
    }

    private void addPair(int y, Runnable minus, Runnable plus) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> minus.run())
                .bounds(leftPos + 80, topPos + y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> plus.run())
                .bounds(leftPos + 166, topPos + y, 18, 16).build());
    }

    private void send(boolean show, boolean clearTrack) {
        PacketDistributor.sendToServer(new SectionConfigPacket(menu.getPos(), clear, show, clearTrack));
    }

    @Override
    public void removed() {
        send(false, false);
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 190, y0 + 4, x0 + 191, y0 + imageHeight - 4, 0xFF3A3E4D);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int dim = 0x7A8098;
        int text = 0xE0E4F0;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.section_next"), 8, 24, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.section_occupied"), 8, 44, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.section_stop"), 8, 64, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.section_clear"), 8, 92, text, false);
        g.drawCenteredString(font, clear + " s", 132, 92, 0xFFFFFF);
        if (linked) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_start", startText), 8, 118, 0x7CE08A, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_end", endText), 8, 130, 0xF0A060, false);
        } else {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_not_linked"), 8, 118, 0xE08080, false);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 199, 66, dim, false);
    }
}
