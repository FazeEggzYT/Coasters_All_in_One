package com.example.coastercontrolpanel;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

/** A restaurant block whose look is set in a small options screen (colours, on/off switches). */
public interface RestaurantConfigurable {
    /** One option: a block state property shown as a button row. */
    record Option(String key, Property<?> prop, int max) {
    }

    Option[] options();

    static int get(BlockState s, Option o) {
        if (o.prop() instanceof IntegerProperty ip) {
            return s.getValue(ip);
        }
        if (o.prop() instanceof BooleanProperty bp) {
            return s.getValue(bp) ? 1 : 0;
        }
        return 0;
    }

    static BlockState set(BlockState s, Option o, int v) {
        if (o.prop() instanceof IntegerProperty ip) {
            return s.setValue(ip, Math.max(0, Math.min(o.max(), v)));
        }
        if (o.prop() instanceof BooleanProperty bp) {
            return s.setValue(bp, v != 0);
        }
        return s;
    }
}
