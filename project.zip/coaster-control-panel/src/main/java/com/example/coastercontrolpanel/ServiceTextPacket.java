package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/** Client to server: kind 0 = new text lines for an info desk, brochure stand or rota board, kind 1 = a feedback note. */
public record ServiceTextPacket(BlockPos pos, int kind, List<String> lines) implements CustomPacketPayload {
    public static final Type<ServiceTextPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "service_text"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ServiceTextPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.kind);
                buf.writeVarInt(p.lines.size());
                for (String s : p.lines) {
                    buf.writeUtf(s, 90);
                }
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                int kind = buf.readVarInt();
                int n = Math.min(GuestBlocks.TextBlockEntity.MAX, buf.readVarInt());
                List<String> l = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    l.add(buf.readUtf(90));
                }
                return new ServiceTextPacket(pos, kind, l);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ServiceTextPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        var level = player.level();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 144.0 || !level.isLoaded(p.pos)) {
            return;
        }
        var be = level.getBlockEntity(p.pos);
        if (p.kind == 0 && be instanceof GuestBlocks.TextBlockEntity t) {
            if (t.getBlockState().getBlock() instanceof StaffBlocks.RotaBoardBlock && !StaffBlocks.hasBadge(player)) {
                return;
            }
            t.apply(p.lines);
        } else if (p.kind == 1 && be instanceof GuestBlocks.FeedbackBlockEntity f && !p.lines.isEmpty()) {
            f.add(player, p.lines.get(0));
        }
    }
}
