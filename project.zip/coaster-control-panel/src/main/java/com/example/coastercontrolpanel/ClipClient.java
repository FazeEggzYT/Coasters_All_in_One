package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Client only: keeps the announcement files other players uploaded, and plays them.
 * The files live in a small resource pack folder in the game directory (see ClipPackEvents),
 * so the game's own sound engine can load them.
 */
public final class ClipClient {
    private record Play(double x, double y, double z, float volume, float pitch) {
    }

    private static final Map<String, ByteArrayOutputStream> PARTIAL = new HashMap<>();
    private static final Map<String, List<Play>> PENDING = new HashMap<>();
    private static final Set<String> REQUESTED = new HashSet<>();

    private ClipClient() {
    }

    public static Path packDir() {
        return FMLPaths.GAMEDIR.get().resolve("coastercontrolpanel_clips");
    }

    private static Path soundDir() {
        return packDir().resolve("assets").resolve(CoasterControlPanel.MOD_ID).resolve("sounds").resolve("clip");
    }

    /** Makes the folder (and its pack.mcmeta) if they are missing. */
    public static void prepare() {
        try {
            Files.createDirectories(soundDir());
            Path meta = packDir().resolve("pack.mcmeta");
            if (!Files.exists(meta)) {
                Files.writeString(meta,
                        "{\"pack\":{\"pack_format\":34,\"description\":\"Announcement clips (made by the mod)\"}}",
                        StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            CoasterControlPanel.LOGGER.warn("Could not prepare the announcement clip folder", e);
        }
    }

    private static boolean have(String hash) {
        return ClipStore.validHash(hash) && Files.exists(soundDir().resolve(hash + ".ogg"));
    }

    /** A piece of a file we asked for arrived. */
    public static void receive(String hash, int index, int total, byte[] data) {
        if (!ClipStore.validHash(hash)) {
            return;
        }
        ByteArrayOutputStream buf = PARTIAL.computeIfAbsent(hash, h -> new ByteArrayOutputStream());
        if (index == 0) {
            buf.reset();
        }
        buf.writeBytes(data);
        if (index + 1 < total) {
            return;
        }
        PARTIAL.remove(hash);
        REQUESTED.remove(hash);
        try {
            prepare();
            Files.write(soundDir().resolve(hash + ".ogg"), buf.toByteArray());
        } catch (IOException e) {
            CoasterControlPanel.LOGGER.warn("Could not save an announcement clip", e);
            return;
        }
        List<Play> waiting = PENDING.remove(hash);
        if (waiting != null) {
            for (Play p : waiting) {
                play(hash, p);
            }
        }
    }

    /** The server says: play this clip here. Ask for the file first if we do not have it. */
    public static void playOrFetch(String hash, double x, double y, double z, float volume, float pitch) {
        if (!ClipStore.validHash(hash)) {
            return;
        }
        Play play = new Play(x, y, z, volume, pitch);
        if (have(hash)) {
            play(hash, play);
            return;
        }
        PENDING.computeIfAbsent(hash, h -> new ArrayList<>()).add(play);
        if (REQUESTED.add(hash)) {
            PacketDistributor.sendToServer(new ClipRequestPacket(hash));
        }
    }

    private static void play(String hash, Play p) {
        Minecraft.getInstance().getSoundManager().play(
                new ClipSoundInstance(hash, p.x(), p.y(), p.z(), p.volume(), p.pitch()));
    }
}
