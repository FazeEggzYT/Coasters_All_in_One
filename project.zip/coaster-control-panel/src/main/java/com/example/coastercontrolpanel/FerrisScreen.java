package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Locale;
import java.util.function.Consumer;

/** Ferris Wheel: the sequence, the general settings, the controls and the Redstone Links. */
public class FerrisScreen extends Screen {
    private static final int W = 340;
    private static final int H = 262;
    private static final int ROW = 18;

    private final BlockPos pos;
    private FerrisSettings s = new FerrisSettings();
    private int tab;
    private int left;
    private int top;
    private Button startButton;
    private Button pauseButton;
    private Button endButton;
    private Button haltButton;
    private int presetIndex = 0;
    private boolean loaded;

    public FerrisScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.ferris.title"));
        this.pos = pos;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.ferris." + key);
    }

    private FerrisBlockEntity be() {
        return minecraft != null && minecraft.level != null && minecraft.level.getBlockEntity(pos) instanceof FerrisBlockEntity b ? b : null;
    }

    private boolean idle() {
        FerrisBlockEntity b = be();
        return b == null || b.idle();
    }

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.2f", v);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (!loaded) {
            loaded = true;
            FerrisBlockEntity b = be();
            if (b != null) {
                s = b.cfg.copy();
            }
        }
        rebuild();
    }

    private EditBox edit(int x, int y, int w, double value, double min, double max, Consumer<Float> set) {
        EditBox box = new EditBox(font, left + x, top + y, w, 14, Component.empty());
        box.setValue(num(value));
        box.setFilter(str -> str.matches("[0-9]{0,3}([.][0-9]{0,2})?"));
        box.setResponder(str -> {
            try {
                set.accept((float) Math.max(min, Math.min(max, Float.parseFloat(str))));
            } catch (NumberFormatException ignored) {
                // half-typed
            }
        });
        box.active = idle();
        return box;
    }

    private Button button(int x, int y, int w, int h, Component label, Runnable action) {
        Button btn = Button.builder(label, bt -> action.run()).bounds(left + x, top + y, w, h).build();
        addRenderableWidget(btn);
        return btn;
    }

    private void rebuild() {
        clearWidgets();
        startButton = pauseButton = endButton = haltButton = null;
        String[] tabs = {"tab_sequence", "tab_settings", "tab_control", "tab_links"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            Button tb = button(8 + i * 66, 22, 62, 16, t(tabs[i]), () -> {
                tab = idx;
                rebuild();
            });
            tb.active = tab != i;
        }
        button(W - 52, 4, 44, 14, Component.translatable("gui.coastercontrolpanel.ok"), this::onClose);
        boolean editable = idle();
        if (tab == 0) {
            buildSequence(editable);
        } else if (tab == 1) {
            buildSettings(editable);
        } else if (tab == 2) {
            buildControl();
        } else {
            buildLinks();
        }
    }

    private void buildSequence(boolean editable) {
        for (int i = 0; i < s.steps.size(); i++) {
            final int idx = i;
            FerrisSettings.Step st = s.steps.get(i);
            int y = 54 + i * ROW;
            Button type = button(26, y, 62, 14, t("type." + st.type), () -> {
                st.retype((st.type + 1) % FerrisSettings.TYPES);
                rebuild();
            });
            type.active = editable;
            double maxA = st.type == FerrisSettings.ROTATE ? 6 : st.type == FerrisSettings.STATION ? 120 : 300;
            addRenderableWidget(edit(92, y, 44, st.a, st.type == FerrisSettings.ROTATE ? 0.1 : 0, maxA, v -> st.a = v));
            if (st.type != FerrisSettings.HOLD) {
                addRenderableWidget(edit(140, y, 44, st.b, st.type == FerrisSettings.ROTATE ? 0.25 : 1, st.type == FerrisSettings.ROTATE ? 30 : 24, v -> st.b = v));
            }
            Button up = button(262, y, 16, 14, Component.literal("^"), () -> {
                s.steps.add(idx - 1, s.steps.remove(idx));
                rebuild();
            });
            up.active = editable && i > 0;
            Button down = button(280, y, 16, 14, Component.literal("v"), () -> {
                s.steps.add(idx + 1, s.steps.remove(idx));
                rebuild();
            });
            down.active = editable && i < s.steps.size() - 1;
            Button del = button(298, y, 16, 14, Component.literal("x"), () -> {
                s.steps.remove(idx);
                rebuild();
            });
            del.active = editable;
        }
        Button add = button(8, H - 24, 100, 16, t("add_step"), () -> {
            s.steps.add(new FerrisSettings.Step(FerrisSettings.ROTATE, 1, 1));
            rebuild();
        });
        add.active = editable && s.steps.size() < FerrisSettings.MAX_STEPS;
        Button preset = button(114, H - 24, 218, 16, Component.empty(), () -> {
            presetIndex = (presetIndex + 1) % FerrisSettings.PRESETS;
            s.preset(presetIndex);
            rebuild();
        });
        preset.setMessage(Component.translatable("gui.coastercontrolpanel.ferris.preset_button",
                t("preset." + ((presetIndex + 1) % FerrisSettings.PRESETS))));
        preset.active = editable;
    }

    private void buildSettings(boolean editable) {
        int x = 208;
        int w = 110;
        addRenderableWidget(edit(x, 52, w, s.loops, 1, 20, v -> s.loops = Math.round(v)));
        addRenderableWidget(edit(x, 72, w, s.preDelay, 0, 30, v -> s.preDelay = v));
        addRenderableWidget(edit(x, 92, w, s.accel, 1, 30, v -> s.accel = v));
        addRenderableWidget(edit(x, 112, w, s.creep, 0.1, 3, v -> s.creep = v));
        addRenderableWidget(edit(x, 132, w, s.haltTime, 0.5, 8, v -> s.haltTime = v));
        Button dir = button(x, 152, w, 14, t("direction." + s.direction), () -> {
            s.direction = 1 - s.direction;
            rebuild();
        });
        dir.active = editable;
        Button rs = button(x, 172, w, 14, t("redstone." + s.redstoneMode), () -> {
            s.redstoneMode = 1 - s.redstoneMode;
            rebuild();
        });
        rs.active = editable;
        Button em = button(x, 192, w, 14, t("endmode." + s.endMode), () -> {
            s.endMode = 1 - s.endMode;
            rebuild();
        });
        em.active = editable;
        Button carry = button(x, 212, w, 14, t("carry." + (s.carryAll ? 1 : 0)), () -> {
            s.carryAll = !s.carryAll;
            rebuild();
        });
        carry.active = editable;
    }

    private void buildControl() {
        startButton = button(8, 150, 100, 20, t("start"), () -> act(RideEngine.ACTION_START));
        pauseButton = button(120, 150, 100, 20, t("pause"), () -> act(RideEngine.ACTION_PAUSE));
        endButton = button(232, 150, 100, 20, t("end"), () -> act(RideEngine.ACTION_END));
        haltButton = button(8, 176, 324, 20, t("halt"), () -> act(RideEngine.ACTION_HALT));
    }

    private void buildLinks() {
        for (int i = 0; i < RideLinks.COUNT; i++) {
            final int slot = i;
            int y = RideLinks.ROW_Y[i];
            button(190, y, 70, 16, Component.translatable("gui.coastercontrolpanel.ride.link_set"),
                    () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, false)));
            button(264, y, 50, 16, Component.translatable("gui.coastercontrolpanel.ride.link_clear"),
                    () -> PacketDistributor.sendToServer(new RideLinkPacket(pos, slot, true)));
        }
    }

    private void drawLinks(GuiGraphics g, int text, int dim) {
        FerrisBlockEntity b = be();
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note"), left + 12, top + 44, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.0"), left + 12, top + 60, 0xFFFFC040, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link_head.1"), left + 12, top + 126, 0xFFFF6050, false);
        for (int i = 0; i < RideLinks.COUNT; i++) {
            int y = top + RideLinks.ROW_Y[i];
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.link." + i), left + 12, y + 4, text, false);
            g.fill(left + 150, y - 1, left + 168, y + 17, 0xFF3A3E4D);
            g.fill(left + 151, y, left + 167, y + 16, 0xFF101218);
            if (b != null && !b.links().stack(i).isEmpty()) {
                g.renderItem(b.links().stack(i), left + 151, y);
            }
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.ride.links_note_2"), left + 12, top + H - 22, dim, false);
    }

    private void act(int action) {
        sendConfig();
        PacketDistributor.sendToServer(new DropTowerControlPacket(pos, action));
    }

    private void sendConfig() {
        if (idle()) {
            s.sanitize();
            PacketDistributor.sendToServer(new DropTowerConfigPacket(pos, s.toTag()));
        }
    }

    @Override
    public void removed() {
        sendConfig();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (tab == 2 && startButton != null) {
            FerrisBlockEntity b = be();
            int phase = b == null ? 0 : b.motion.phase;
            startButton.active = phase == FerrisMotion.IDLE;
            pauseButton.active = phase == FerrisMotion.RUNNING || phase == FerrisMotion.PAUSED || phase == FerrisMotion.COUNTDOWN || phase == FerrisMotion.HALTED;
            pauseButton.setMessage(phase == FerrisMotion.PAUSED || phase == FerrisMotion.HALTED ? t("resume") : t("pause"));
            endButton.active = phase != FerrisMotion.IDLE;
            haltButton.active = phase == FerrisMotion.RUNNING || phase == FerrisMotion.PAUSED || phase == FerrisMotion.ENDING;
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, title, left + 8, top + 8, 0xFFFFFF, false);
        int text = 0xE0E4F0;
        int dim = 0x7A8098;
        if (tab == 0) {
            g.drawString(font, t("col_step"), left + 8, top + 41, dim, false);
            g.drawString(font, t("col_type"), left + 28, top + 41, dim, false);
            g.drawString(font, t("col_a"), left + 94, top + 41, dim, false);
            g.drawString(font, t("col_b"), left + 142, top + 41, dim, false);
            for (int i = 0; i < s.steps.size(); i++) {
                int y = top + 57 + i * ROW;
                g.drawString(font, String.valueOf(i + 1), left + 10, y, text, false);
                g.drawString(font, t("unit." + s.steps.get(i).type), left + 188, y, dim, false);
            }
            if (s.steps.isEmpty()) {
                g.drawString(font, t("no_steps"), left + 28, top + 58, dim, false);
            }
        } else if (tab == 1) {
            String[] labels = {"loops", "pre_delay", "accel", "creep", "halt_time", "direction", "redstone", "endmode", "carry"};
            for (int i = 0; i < labels.length; i++) {
                g.drawString(font, t("set." + labels[i]), left + 12, top + 55 + i * 20, text, false);
            }
            g.drawString(font, t("settings_note"), left + 12, top + 240, dim, false);
        } else if (tab == 3) {
            drawLinks(g, text, dim);
        } else {
            FerrisBlockEntity b = be();
            int phase = b == null ? 0 : b.motion.phase;
            g.drawString(font, t("status." + phase), left + 12, top + 52, 0xFFFFFF, false);
            if (b != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.ferris.status_line",
                        b.motion.stepIndex + 1, Math.max(1, b.cfg.steps.size()), b.motion.loop + 1, b.cfg.loops), left + 12, top + 68, text, false);
                g.drawString(font, b.station >= 0
                        ? Component.translatable("gui.coastercontrolpanel.ferris.station_line", b.station + 1)
                        : t("moving_line"), left + 12, top + 82, text, false);
            }
            g.drawString(font, t("control_note_1"), left + 12, top + 108, dim, false);
            g.drawString(font, t("control_note_2"), left + 12, top + 120, dim, false);
            g.drawString(font, t("control_note_3"), left + 12, top + 132, dim, false);
            g.drawString(font, t("control_note_4"), left + 12, top + 204, dim, false);
        }
    }
}
