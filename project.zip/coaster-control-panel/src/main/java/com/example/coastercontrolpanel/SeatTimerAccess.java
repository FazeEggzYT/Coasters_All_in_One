package com.example.coastercontrolpanel;

/**
 * Added to the Coasters Simulated Additions seat block entity by CoasterSeatMixin.
 * Open and close delays are in seconds. 0 means no delay.
 */
public interface SeatTimerAccess {
    int seatTimerOpenDelay();

    int seatTimerCloseDelay();

    void seatTimerSet(int openSeconds, int closeSeconds);

    /** Used when loading from NBT: no setChanged. */
    void seatTimerLoad(int openSeconds, int closeSeconds);
}
