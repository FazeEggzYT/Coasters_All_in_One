package com.example.coastercontrolpanel;

/**
 * Added to the Coasters Simulated Additions seat block entity by CoasterSeatMixin.
 * Open and close delays are in seconds. 0 means no delay.
 */
public interface SeatTimerAccess {
    int seatTimerOpenDelay();

    int seatTimerCloseDelay();

    /** How fast the restraint moves, in percent of normal speed (10 to 100). */
    int seatTimerSpeed();

    void seatTimerSet(int openSeconds, int closeSeconds, int speedPercent);

    /** Used when loading from NBT: no setChanged. */
    void seatTimerLoad(int openSeconds, int closeSeconds, int speedPercent);
}
