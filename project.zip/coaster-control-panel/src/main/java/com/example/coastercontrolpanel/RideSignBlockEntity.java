package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;

/**
 * Holds what a sign shows. Meaning of the fields by kind:
 * RIDE: line1 and line2 are the text.
 * OPEN: mode 0 = follows redstone power, 1 = always open, 2 = always closed. line1 is an optional ride name.
 * HEIGHT: number = height in cm. line1 replaces the title if set.
 * WAIT (the Redstone Level Sign): mode 0 shows the redstone power (0 to 15), mode 1 shows the power times number.
 * Every sign also reads the redstone power around it (see the renderer): power() is 0 to 15.
 */
public class RideSignBlockEntity extends BlockEntity {
    public static final int MAX_TEXT = 24;

    private String line1 = "";
    private String line2 = "";
    private int color = 0;
    private int number = 120;
    private int mode = 0;
    private boolean lit = false;   // OPEN signs: currently open
    private int shown = 0;         // WAIT signs: the value shown
    private int power = 0;         // every sign: redstone power next to it (0 to 15)

    public RideSignBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SIGN_BE.get(), pos, state);
        SignKind kind = kind();
        if (kind == SignKind.RIDE) {
            line1 = "My Ride";
        } else if (kind == SignKind.WAIT) {
            number = 1;
        } else if (kind == SignKind.CROWD) {
            number = 20;
        } else if (kind == SignKind.FLOOR) {
            line1 = "Queue here";
        }
    }

    private boolean prevPowered = false;
    private final LinkSlots links = new LinkSlots(this, 1);

    /** The Create Redstone Link frequency item this sign listens to (right-click the sign with an item to set it). */
    public net.minecraft.world.SimpleContainer frequency() {
        return links.container();
    }

    /** Redstone power from beside the sign or from the Redstone Link frequency, 0 to 15. */
    private int signal() {
        int p = level == null ? 0 : level.getBestNeighborSignal(worldPosition);
        return Math.max(p, links.strength(0));
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            links.register();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    public SignKind kind() {
        return getBlockState().getBlock() instanceof RideSignBlock b ? b.kind : SignKind.RIDE;
    }

    public String line1() { return line1; }
    public String line2() { return line2; }
    public int color() { return color; }
    public int number() { return number; }
    public int mode() { return mode; }
    public boolean lit() { return lit; }
    public int shown() { return shown; }
    public int power() { return power; }

    @Nullable
    public static RideSignBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof RideSignBlockEntity s ? s : null;
    }

    public void applyConfig(String l1, String l2, int color, int frame, int number, int mode) {
        if (level == null || level.isClientSide) {
            return;
        }
        this.line1 = l1.length() > MAX_TEXT ? l1.substring(0, MAX_TEXT) : l1;
        this.line2 = l2.length() > MAX_TEXT ? l2.substring(0, MAX_TEXT) : l2;
        this.color = Math.floorMod(color, 16);
        this.number = Math.max(0, Math.min(999, number));
        this.mode = Math.max(0, Math.min(7, mode));
        BlockState state = getBlockState();
        int f = Math.max(0, Math.min(3, frame));
        if (state.getValue(RideSignBlock.FRAME) != f) {
            level.setBlock(worldPosition, state.setValue(RideSignBlock.FRAME, f), 3);
        }
        recompute();
        sync();
    }

    private void sync() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    /** Works out what an OPEN or WAIT sign should show now. Returns true if it changed. */
    private boolean recompute() {
        if (level == null) {
            return false;
        }
        boolean changed = false;
        SignKind kind = kind();
        int p = signal();
        if (p != power) {
            power = p;
            changed = true;
        }
        if (kind == SignKind.OPEN) {
            boolean now = mode == 1 || (mode == 0 && p > 0);
            if (now != lit) {
                lit = now;
                changed = true;
            }
        } else if (kind == SignKind.CROWD) {
            int guests = level.getEntitiesOfClass(GuestEntity.class, new AABB(worldPosition).inflate(24.0)).size();
            int full = Math.max(3, number);
            int now = power > 0 ? (power <= 5 ? 0 : power <= 10 ? 1 : 2) : (guests * 3 < full ? 0 : guests * 3 < full * 2 ? 1 : 2);
            if (now != shown) {
                shown = now;
                changed = true;
            }
        } else if (kind == SignKind.WAIT) {
            int now = mode == 1 ? power * Math.max(1, number) : power;
            if (now != shown) {
                shown = now;
                changed = true;
            }
        }
        return changed;
    }

    public void serverTick() {
        if (level == null) {
            return;
        }
        if (kind() == SignKind.COUNTER) {
            // counts every rising edge of a redstone signal, so a short pulse is not missed
            boolean powered = level.hasNeighborSignal(worldPosition) || links.strength(0) > 0;
            if (powered && !prevPowered && shown < 9999) {
                shown++;
                sync();
            }
            prevPowered = powered;
            if (mode == 0 && shown != 0 && level.getGameTime() % 20 == 0 && level.getDayTime() % 24000L < 40L) {
                shown = 0;
                sync();
            }
            return;
        }
        if (level.getGameTime() % 4 != 0) {
            return;
        }
        if (recompute()) {
            sync();
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("L1", line1);
        tag.putString("L2", line2);
        tag.putInt("Color", color);
        tag.putInt("Number", number);
        tag.putInt("Mode", mode);
        tag.putBoolean("Lit", lit);
        tag.putInt("Shown", shown);
        tag.putInt("Power", power);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("L1")) {
            line1 = tag.getString("L1");
            line2 = tag.getString("L2");
            color = tag.getInt("Color");
            number = tag.getInt("Number");
            mode = tag.getInt("Mode");
            lit = tag.getBoolean("Lit");
            shown = tag.getInt("Shown");
            power = tag.getInt("Power");
        }
        links.load(tag, registries);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
