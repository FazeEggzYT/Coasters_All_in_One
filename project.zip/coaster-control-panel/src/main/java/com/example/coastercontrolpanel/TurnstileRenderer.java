package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Draws the three spinning arms of a turnstile. They speed up while someone is let through and slow down after. */
public class TurnstileRenderer implements BlockEntityRenderer<TurnstileBlockEntity> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/turnstile_arm.png");

    public TurnstileRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(TurnstileBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        if (be.getLevel() == null) {
            return;
        }
        boolean passing = be.getBlockState().hasProperty(TurnstileBlock.PASSING)
                && be.getBlockState().getValue(TurnstileBlock.PASSING);
        float time = be.getLevel().getGameTime() + partialTick;
        if (be.lastTime < 0) {
            be.lastTime = time;
        }
        float dt = Math.max(0.0F, Math.min(5.0F, time - be.lastTime));
        be.lastTime = time;
        // degrees per tick: fast while passing, easing off afterwards
        be.speed = passing ? Math.min(24.0F, be.speed + 3.0F * dt) : be.speed * (float) Math.pow(0.9, dt);
        be.angle = (be.angle + be.speed * dt) % 360.0F;

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        for (int k = 0; k < 3; k++) {
            pose.pushPose();
            pose.translate(0.5, 0.0, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(be.angle + k * 120.0F));
            // an arm sticking out along +x, at hip height
            box(vc, pose.last(), 0.05F, 0.66F, -0.04F, 0.46F, 0.72F, 0.04F, light);
            box(vc, pose.last(), 0.44F, 0.60F, -0.05F, 0.48F, 0.78F, 0.05F, light);
            pose.popPose();
        }
    }

    private static void box(VertexConsumer vc, PoseStack.Pose p, float x0, float y0, float z0, float x1, float y1,
                            float z1, int light) {
        quad(vc, p, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0, light);
        quad(vc, p, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0, light);
        quad(vc, p, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0, 0, -1, light);
        quad(vc, p, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, 0, 0, 1, light);
        quad(vc, p, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1, 0, 0, light);
        quad(vc, p, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, -1, 0, 0, light);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose p, float ax, float ay, float az, float bx, float by,
                             float bz, float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz, int light) {
        v(vc, p, ax, ay, az, 0, 1, nx, ny, nz, light);
        v(vc, p, bx, by, bz, 1, 1, nx, ny, nz, light);
        v(vc, p, cx, cy, cz, 1, 0, nx, ny, nz, light);
        v(vc, p, dx, dy, dz, 0, 0, nx, ny, nz, light);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, float u, float v,
                          float nx, float ny, float nz, int light) {
        vc.addVertex(p, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, nx, ny, nz);
    }
}
