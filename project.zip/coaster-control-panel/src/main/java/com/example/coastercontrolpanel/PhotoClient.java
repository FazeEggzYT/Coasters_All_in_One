package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Client side of the ride photos: takes the picture when the server asks, keeps the pictures as textures,
 * and gives the live view. The camera view is made by pointing the game's own camera at a small invisible
 * marker standing where the camera block is.
 */
public final class PhotoClient {
    public static final int PHOTO_W = 256;
    public static final int PHOTO_H = 144;
    private static final int WARM_TICKS = 10;

    public static final class Entry {
        public final int version;
        public final ResourceLocation loc;

        Entry(int version, ResourceLocation loc) {
            this.version = version;
            this.loc = loc;
        }
    }

    private static final Map<Long, Entry> CACHE = new HashMap<>();
    private static final Map<Long, Long> REQUESTED = new HashMap<>();

    // taking a picture
    @Nullable
    private static BlockPos pendingCamera;
    private static float pendingYaw;
    private static int warm = -1;
    private static float flash = 0;

    // the camera swap (shared by picture and live view)
    @Nullable
    private static Entity savedCameraEntity;
    private static CameraType savedType = CameraType.FIRST_PERSON;
    private static boolean swapped = false;
    private static boolean viewing = false;

    private PhotoClient() {
    }

    // ---------------------------------------------------------------- photos on screens

    @Nullable
    public static Entry get(BlockPos camera, int version) {
        Entry e = CACHE.get(camera.asLong());
        if (e == null || e.version < version) {
            long now = System.currentTimeMillis();
            Long last = REQUESTED.get(camera.asLong());
            if (last == null || now - last > 5000) {
                REQUESTED.put(camera.asLong(), now);
                PacketDistributor.sendToServer(new PhotoFetchPacket(camera));
            }
        }
        return e;
    }

    public static void receive(BlockPos camera, int version, byte[] png) {
        Minecraft mc = Minecraft.getInstance();
        try {
            NativeImage image = NativeImage.read(new ByteArrayInputStream(png));
            DynamicTexture texture = new DynamicTexture(image);
            ResourceLocation loc = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID,
                    "photo/" + Long.toHexString(camera.asLong()) + "/" + version);
            mc.getTextureManager().register(loc, texture);
            Entry old = CACHE.put(camera.asLong(), new Entry(version, loc));
            if (old != null) {
                mc.getTextureManager().release(old.loc);
            }
        } catch (Exception e) {
            CoasterControlPanel.LOGGER.warn("Could not read a camera photo", e);
        }
    }

    // ---------------------------------------------------------------- the camera swap

    private static void swapCamera(BlockPos camera, float yaw) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || swapped) {
            return;
        }
        Direction facing = Direction.fromYRot(yaw);
        Marker marker = new Marker(EntityType.MARKER, mc.level);
        marker.moveTo(camera.getX() + 0.5 + facing.getStepX() * 0.6, camera.getY() + 0.62,
                camera.getZ() + 0.5 + facing.getStepZ() * 0.6, yaw, 0.0F);
        savedCameraEntity = mc.getCameraEntity();
        savedType = mc.options.getCameraType();
        mc.setCameraEntity(marker);
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        mc.gameRenderer.setRenderHand(false);
        swapped = true;
    }

    private static void restoreCamera() {
        Minecraft mc = Minecraft.getInstance();
        if (!swapped) {
            return;
        }
        swapped = false;
        mc.setCameraEntity(savedCameraEntity != null ? savedCameraEntity : mc.player);
        mc.options.setCameraType(savedType);
        mc.gameRenderer.setRenderHand(true);
        savedCameraEntity = null;
    }

    // ---------------------------------------------------------------- live view

    public static void startView(BlockPos camera, float yaw) {
        if (viewing) {
            return;
        }
        if (swapped) {
            abortCapture();
        }
        viewing = true;
        swapCamera(camera, yaw);
    }

    public static void stopView() {
        if (!viewing) {
            return;
        }
        viewing = false;
        restoreCamera();
    }

    // ---------------------------------------------------------------- taking the picture

    public static void request(BlockPos camera, float yaw) {
        if (viewing || warm >= 0) {
            return;
        }
        pendingCamera = camera;
        pendingYaw = yaw;
    }

    private static void abortCapture() {
        restoreCamera();
        warm = -1;
        pendingCamera = null;
    }

    public static void reset() {
        viewing = false;
        swapped = false;
        savedCameraEntity = null;
        warm = -1;
        pendingCamera = null;
        flash = 0;
        CACHE.clear();
        REQUESTED.clear();
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        if (pendingCamera != null && warm < 0 && !viewing) {
            swapCamera(pendingCamera, pendingYaw);
            warm = WARM_TICKS;
            flash = 1.0F;
        } else if (warm > 0) {
            warm--;
        } else if (warm < 0 && flash > 0) {
            flash = Math.max(0, flash - 0.06F);
        }
    }

    /** Called once per frame after the world is drawn, before the HUD. */
    public static void afterLevel() {
        if (warm != 0 || pendingCamera == null) {
            return;
        }
        BlockPos camera = pendingCamera;
        try {
            capture(camera);
        } catch (Throwable t) {
            CoasterControlPanel.LOGGER.warn("Could not take a ride photo", t);
        } finally {
            abortCapture();
            flash = 0.9F;
        }
    }

    private static void capture(BlockPos camera) throws Exception {
        Minecraft mc = Minecraft.getInstance();
        NativeImage full = Screenshot.takeScreenshot(mc.getMainRenderTarget());
        NativeImage small = new NativeImage(PHOTO_W, PHOTO_H, false);
        try {
            int fw = full.getWidth();
            int fh = full.getHeight();
            int cw = fw;
            int ch = fw * 9 / 16;
            if (ch > fh) {
                ch = fh;
                cw = fh * 16 / 9;
            }
            int ox = (fw - cw) / 2;
            int oy = (fh - ch) / 2;
            for (int y = 0; y < PHOTO_H; y++) {
                int y0 = oy + y * ch / PHOTO_H;
                int y1 = Math.max(y0 + 1, oy + (y + 1) * ch / PHOTO_H);
                for (int x = 0; x < PHOTO_W; x++) {
                    int x0 = ox + x * cw / PHOTO_W;
                    int x1 = Math.max(x0 + 1, ox + (x + 1) * cw / PHOTO_W);
                    int sx = Math.max(1, (x1 - x0) / 3);
                    int sy = Math.max(1, (y1 - y0) / 3);
                    int r = 0, g = 0, b = 0, n = 0;
                    for (int yy = y0; yy < y1; yy += sy) {
                        for (int xx = x0; xx < x1; xx += sx) {
                            int c = full.getPixelRGBA(Math.min(xx, fw - 1), Math.min(yy, fh - 1));
                            r += c & 255;
                            g += (c >> 8) & 255;
                            b += (c >> 16) & 255;
                            n++;
                        }
                    }
                    n = Math.max(1, n);
                    small.setPixelRGBA(x, y, 0xFF000000 | ((b / n) << 16) | ((g / n) << 8) | (r / n));
                }
            }
            byte[] png = small.asByteArray();
            int total = (png.length + PhotoStore.CHUNK - 1) / PhotoStore.CHUNK;
            for (int i = 0; i < total; i++) {
                int from = i * PhotoStore.CHUNK;
                int to = Math.min(png.length, from + PhotoStore.CHUNK);
                byte[] part = new byte[to - from];
                System.arraycopy(png, from, part, 0, part.length);
                PacketDistributor.sendToServer(new PhotoUploadPacket(camera, i, total, part));
            }
        } finally {
            full.close();
            small.close();
        }
    }

    // ---------------------------------------------------------------- the white flash

    public static void renderFlash(GuiGraphics g) {
        if (flash <= 0) {
            return;
        }
        int alpha = Math.max(0, Math.min(255, (int) (flash * 255)));
        g.fill(0, 0, g.guiWidth(), g.guiHeight(), (alpha << 24) | 0xFFFFFF);
    }
}
