package com.example.coastercontrolpanel.elements;

/** A point on an element's centre line, in the element's own frame: x = right, y = up, z = forward. Plain maths, no Minecraft. */
public record Pose(double x, double y, double z, double roll) {
}
