package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client, every tick while a Ferris Wheel runs: the client moves the wheel and the cabins from these numbers. */
public record FerrisStatePacket(BlockPos pos, float angle, int phase, long axle, int axis, int station) implements CustomPacketPayload {
    public static final Type<FerrisStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "ferris_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FerrisStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.angle);
                buf.writeVarInt(p.phase);
                buf.writeLong(p.axle);
                buf.writeVarInt(p.axis);
                buf.writeVarInt(p.station);
            },
            buf -> new FerrisStatePacket(buf.readBlockPos(), buf.readFloat(), buf.readVarInt(), buf.readLong(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(FerrisStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof FerrisBlockEntity be) {
            be.receiveState(p.angle, p.phase, BlockPos.of(p.axle), p.axis, p.station);
        }
    }
}
