package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Right-click a Swivel, Flip or Spin Bearing that is holding a structure with a Create Wrench (not sneaking): the
 * structure goes back to where it started and turns into blocks again. This is the only way a Flip or Spin Bearing
 * lets go. Bearings that hold nothing are left alone, so the wrench works on them as usual.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class SwivelWrenchEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || event.getEntity().isShiftKeyDown()
                || !(event.getItemStack().getItem() instanceof WrenchItem)
                || !(event.getLevel().getBlockEntity(event.getPos()) instanceof SwivelBlockEntity be) || !be.isAssembled()) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!event.getLevel().isClientSide) {
            be.wrenchDisassemble();
        }
    }
}
