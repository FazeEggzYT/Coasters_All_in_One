package com.example.coastercontrolpanel.elements;

import java.util.List;

/** All the elements the Track Element Selector offers. One line each. */
public final class TrackElements {
    private TrackElements() {
    }

    public static final List<String> CATEGORIES = List.of("inversions", "hills", "turns", "drops", "specials");

    /** Smooth ramp: 0 at u=0, 1 at u=1, flat at both ends. */
    static double smooth(double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        return t * t * (3.0 - 2.0 * t);
    }

    /** A bump that is 0 at both ends and 1 across the middle. */
    static double plateau(double u, double ramp) {
        return smooth(u / ramp) * smooth((1.0 - u) / ramp);
    }

    private static double s(Params p) {
        return 0.75 + 0.25 * p.size();
    }

    private static final List<TrackElement> BASE = List.of(
            // ---- inversions
            new TrackElement("vertical_loop", "inversions", true, false, (u, p) -> {
                double r = 4.0 * p.size() + 2.0;
                double th = 2.0 * Math.PI * u;
                double shift = p.side() * (2.0 + p.size()) * (u - Math.sin(2.0 * Math.PI * u) / (2.0 * Math.PI));
                return new Pose(shift, r * (1.0 - Math.cos(th)), r * Math.sin(th), 0.0);
            }),
            new TrackElement("half_loop", "inversions", true, false, (u, p) -> {
                double r = 4.0 * p.size() + 2.0;
                double th = Math.PI * u;
                double roll = p.side() * Math.PI * smooth((u - 0.5) * 2.0);
                return new Pose(0.0, r * (1.0 - Math.cos(th)), r * Math.sin(th), roll);
            }),
            new TrackElement("corkscrew", "inversions", true, false, (u, p) -> {
                double r = 1.5 + 1.0 * p.size();
                double len = 10.0 + 4.0 * p.size();
                double phi = 2.0 * Math.PI * u;
                double env = Math.sin(Math.PI * u);
                env *= env;
                return new Pose(p.side() * r * env * Math.sin(phi), r * env * (1.0 - Math.cos(phi)), len * u, p.side() * phi);
            }),
            new TrackElement("barrel_roll", "inversions", true, false, (u, p) -> {
                double r = 1.0 + 0.5 * p.size();
                double len = 14.0 + 4.0 * p.size();
                double phi = 2.0 * Math.PI * u;
                double env = Math.sin(Math.PI * u);
                env *= env;
                return new Pose(p.side() * r * env * Math.sin(phi), r * env * (1.0 - Math.cos(phi)), len * u, p.side() * phi);
            }),
            new TrackElement("zero_g_roll", "inversions", true, true, (u, p) -> {
                double len = 18.0 + 4.0 * p.size();
                double h = 2.0 + p.rise() + p.size();
                double hill = Math.sin(Math.PI * u);
                hill *= hill;
                return new Pose(0.0, h * hill, len * u, p.side() * 2.0 * Math.PI * smooth(u));
            }),
            // ---- hills
            new TrackElement("camelback_hill", "hills", false, true, (u, p) -> {
                double len = 14.0 + 6.0 * p.size();
                double h = 3.0 + p.size() + p.rise();
                double a = Math.sin(2.0 * Math.PI * u);
                return new Pose(0.0, h * a * a, len * u, 0.0);
            }),
            new TrackElement("airtime_hill", "hills", false, true, (u, p) -> {
                double len = 10.0 + 4.0 * p.size();
                double h = 3.0 + p.size() + p.rise();
                double a = Math.sin(Math.PI * u);
                return new Pose(0.0, h * a * a, len * u, 0.0);
            }),
            new TrackElement("steep_drop", "hills", false, true, (u, p) -> {
                double drop = 6.0 + 4.0 * p.size() + 2.0 * p.rise();
                double len = drop * 0.9;
                return new Pose(0.0, -drop * smooth(u), len * u, 0.0);
            }),
            // ---- turns
            new TrackElement("banked_turn", "turns", true, false, (u, p) -> {
                double r = 3.0 + 2.0 * p.size();
                double th = 0.5 * Math.PI * u;
                double bank = Math.toRadians(35.0) * plateau(u, 0.3);
                return new Pose(p.side() * r * (1.0 - Math.cos(th)), 0.0, r * Math.sin(th), -p.side() * bank);
            }),
            new TrackElement("overbanked_turn", "turns", true, false, (u, p) -> {
                double r = 3.0 + 2.0 * p.size();
                double th = Math.PI * u;
                double bank = Math.toRadians(100.0) * plateau(u, 0.3);
                return new Pose(p.side() * r * (1.0 - Math.cos(th)), 0.0, r * Math.sin(th), -p.side() * bank);
            }),
            new TrackElement("s_bend", "turns", true, false, (u, p) -> {
                double w = 3.0 + 2.0 * p.size();
                double len = 12.0 + 4.0 * p.size();
                double bank = Math.toRadians(30.0) * Math.sin(2.0 * Math.PI * u) * plateau(u, 0.2);
                return new Pose(p.side() * w * smooth(u), 0.0, len * u, -p.side() * bank);
            }),
            new TrackElement("helix", "turns", true, true, (u, p) -> {
                double r = 3.0 + 1.5 * p.size();
                double th = 2.0 * Math.PI * u;
                double bank = Math.toRadians(40.0) * plateau(u, 0.12);
                return new Pose(p.side() * r * (1.0 - Math.cos(th)), -(3.0 + p.rise()) * smooth(u), r * Math.sin(th), -p.side() * bank);
            })
    );

    public static final List<TrackElement> ALL = java.util.stream.Stream.concat(BASE.stream(), MoreElements.LIST.stream()).toList();

    public static TrackElement byId(String id) {
        for (TrackElement e : ALL) {
            if (e.id().equals(id)) {
                return e;
            }
        }
        return null;
    }
}
