package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * An animated ride gate. The two posts are the block model; the swinging gate leaf is drawn by a
 * block entity renderer. Gates standing side by side (same facing) open and close together.
 * The gate swings toward the direction it faces.
 */
public class RideGateBlock extends BaseEntityBlock {
    public static final MapCodec<RideGateBlock> CODEC = simpleCodec(RideGateBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    private static final VoxelShape CLOSED_NS = Block.box(0, 0, 6, 16, 16, 10);
    private static final VoxelShape CLOSED_EW = Block.box(6, 0, 0, 10, 16, 16);
    private static final VoxelShape CLOSED_NS_COLL = Block.box(0, 0, 6, 16, 24, 10);
    private static final VoxelShape CLOSED_EW_COLL = Block.box(6, 0, 0, 10, 24, 16);
    private static final VoxelShape OPEN_NS = Shapes.or(Block.box(0, 0, 6, 2, 16, 10), Block.box(14, 0, 6, 16, 16, 10));
    private static final VoxelShape OPEN_EW = Shapes.or(Block.box(6, 0, 0, 10, 16, 2), Block.box(6, 0, 14, 10, 16, 16));
    private static final VoxelShape OPEN_NS_COLL = Shapes.or(Block.box(0, 0, 6, 2, 24, 10), Block.box(14, 0, 6, 16, 24, 10));
    private static final VoxelShape OPEN_EW_COLL = Shapes.or(Block.box(6, 0, 0, 10, 24, 2), Block.box(6, 0, 14, 10, 24, 16));

    public RideGateBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(OPEN, false));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, OPEN);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    private static boolean alongX(BlockState state) {
        Direction d = state.getValue(FACING);
        return d == Direction.NORTH || d == Direction.SOUTH;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        boolean open = state.getValue(OPEN);
        if (alongX(state)) {
            return open ? OPEN_NS : CLOSED_NS;
        }
        return open ? OPEN_EW : CLOSED_EW;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        boolean open = state.getValue(OPEN);
        if (alongX(state)) {
            return open ? OPEN_NS_COLL : CLOSED_NS_COLL;
        }
        return open ? OPEN_EW_COLL : CLOSED_EW_COLL;
    }

    /** This gate plus every gate beside it with the same facing (up to 16 each way). */
    public static List<BlockPos> group(Level level, BlockPos pos, BlockState state) {
        List<BlockPos> out = new ArrayList<>();
        out.add(pos);
        Direction facing = state.getValue(FACING);
        Direction side = facing.getClockWise();
        for (Direction d : new Direction[]{side, side.getOpposite()}) {
            BlockPos p = pos.relative(d);
            for (int i = 0; i < 16; i++) {
                BlockState s = level.getBlockState(p);
                if (!(s.getBlock() instanceof RideGateBlock) || s.getValue(FACING) != facing) {
                    break;
                }
                out.add(p);
                p = p.relative(d);
            }
        }
        return out;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RideGateBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return createTickerHelper(type, CoasterControlPanel.GATE_BE.get(), (lvl, pos, st, be) -> be.clientTick());
        }
        return createTickerHelper(type, CoasterControlPanel.GATE_BE.get(), (lvl, pos, st, be) -> be.serverTick());
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof WrenchItem) {
            if (level.getBlockEntity(pos) instanceof RideGateBlockEntity gate) {
                if (!level.isClientSide && player instanceof ServerPlayer sp) {
                    sp.openMenu(new SimpleMenuProvider(
                                    (id, inv, p) -> new RideGateMenu(id, inv, gate.getFrequency(), pos),
                                    Component.translatable("gui.coastercontrolpanel.gate_title")),
                            buf -> buf.writeBlockPos(pos));
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    /** Empty hand: open or close this gate (and its neighbours) by hand. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof RideGateBlockEntity gate) {
            gate.setGroupOpen(!state.getValue(OPEN));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
