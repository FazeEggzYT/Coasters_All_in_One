package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

/** The screens of the Gift Shop pack and the shared base of the Gift Shop and First Aid screens. */
public final class GiftScreens {
    private GiftScreens() {
    }

    abstract static class ParkScreen extends Screen {
        protected final BlockPos pos;
        protected final int w;
        protected final int h;
        protected final int accent;
        protected int left;
        protected int top;

        protected ParkScreen(Component title, BlockPos pos, int w, int h, int accent) {
            super(title);
            this.pos = pos;
            this.w = w;
            this.h = h;
            this.accent = accent;
        }

        @Override
        protected void init() {
            left = (width - w) / 2;
            top = (height - h) / 2;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                    .bounds(left + w - 52, top + h - 22, 44, 16).build());
            build();
        }

        protected abstract void build();

        protected void act(int action, int a, int b) {
            PacketDistributor.sendToServer(new ParkActionPacket(pos, action, a, b));
        }

        @Override
        public boolean isPauseScreen() {
            return false;
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            renderTransparentBackground(g);
            g.fill(left - 1, top - 1, left + w + 1, top + h + 1, 0xFF0B0C10);
            g.fill(left, top, left + w, top + h, 0xFF2A2D3A);
            g.fill(left + 1, top + 1, left + w - 1, top + h - 1, 0xFF1B1D26);
            g.fill(left + 1, top + 1, left + w - 1, top + 18, accent);
            g.fill(left + 1, top + 18, left + w - 1, top + 19, 0xFF000000 | (accent & 0x7F7F7F));
            g.drawString(font, title, left + 8, top + 6, 0xFFFFFF, true);
        }

        protected void row(GuiGraphics g, int x, int y, int rw, int rh) {
            g.fill(x, y, x + rw, y + rh, 0xFF2B2F3E);
            g.fill(x + 1, y + 1, x + rw - 1, y + rh - 1, 0xFF22252F);
        }

        protected int nuggets() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player == null ? 0 : ArcadeBlocks.count(mc.player, Items.GOLD_NUGGET);
        }

        protected boolean creative() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player != null && mc.player.getAbilities().instabuild;
        }

        protected <T extends net.minecraft.world.level.block.entity.BlockEntity> T entity(Class<T> type) {
            if (minecraft != null && minecraft.level != null && type.isInstance(minecraft.level.getBlockEntity(pos))) {
                return type.cast(minecraft.level.getBlockEntity(pos));
            }
            return null;
        }
    }

    // ------------------------------------------------------------------ shelf and till

    public static class ShopScreen extends ParkScreen {
        private boolean setup;
        private final Button[] buy1 = new Button[GiftBlocks.ShopBlockEntity.SLOTS];
        private final Button[] buy5 = new Button[GiftBlocks.ShopBlockEntity.SLOTS];
        private final Button[] minus = new Button[GiftBlocks.ShopBlockEntity.SLOTS];
        private final Button[] plus = new Button[GiftBlocks.ShopBlockEntity.SLOTS];
        private final Button[] remove = new Button[GiftBlocks.ShopBlockEntity.SLOTS];
        private Button collect;

        public ShopScreen(BlockPos pos) {
            super(Component.translatable("gui.coastercontrolpanel.shop_title"), pos, 270, 232, 0xFF9A4A2E);
        }

        @Override
        protected void build() {
            for (int i = 0; i < GiftBlocks.ShopBlockEntity.SLOTS; i++) {
                final int row = i;
                int y = top + 40 + i * 24;
                buy1[i] = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.shop_buy_1"), b -> act(1, row, 1))
                        .bounds(left + w - 98, y + 3, 44, 16).build());
                buy5[i] = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.shop_buy_5"), b -> act(1, row, 5))
                        .bounds(left + w - 52, y + 3, 44, 16).build());
                minus[i] = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(2, row, hasShiftDown() ? -5 : -1))
                        .bounds(left + w - 98, y + 3, 20, 16).build());
                plus[i] = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(2, row, hasShiftDown() ? 5 : 1))
                        .bounds(left + w - 76, y + 3, 20, 16).build());
                remove[i] = addRenderableWidget(Button.builder(Component.literal("x"), b -> act(3, row, 0))
                        .bounds(left + w - 52, y + 3, 20, 16).build());
            }
            collect = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.shop_collect"), b -> act(4, 0, 0))
                    .bounds(left + 90, top + h - 22, 84, 16).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup)
                    .bounds(left + 8, top + h - 22, 76, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            GiftBlocks.ShopBlockEntity be = entity(GiftBlocks.ShopBlockEntity.class);
            boolean till = be != null && be.till();
            for (int i = 0; i < buy1.length; i++) {
                boolean has = be != null && !be.stacks[i].isEmpty();
                boolean sold = has && !till && be.stock[i] <= 0;
                buy1[i].visible = has && !setup;
                buy5[i].visible = has && !setup;
                buy1[i].active = !sold;
                buy5[i].active = !sold;
                minus[i].visible = has && setup;
                plus[i].visible = has && setup;
                remove[i].visible = has && setup;
            }
            collect.visible = setup;
            collect.active = be != null && be.takings > 0;
            super.render(g, mx, my, pt);
            g.drawString(font, Component.translatable(till ? "gui.coastercontrolpanel.shop_till" : "gui.coastercontrolpanel.shop_shelf"),
                    left + w - 8 - font.width(Component.translatable(till ? "gui.coastercontrolpanel.shop_till" : "gui.coastercontrolpanel.shop_shelf")),
                    top + 6, 0xFFE9C9, false);
            g.renderItem(new ItemStack(Items.GOLD_NUGGET), left + 8, top + 22);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_have", nuggets()), left + 28, top + 26, 0xFFE070, false);
            if (be != null && setup) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_takings", be.takings),
                        left + w - 8 - font.width(Component.translatable("gui.coastercontrolpanel.shop_takings", be.takings)), top + 26, 0x9EE6A0, false);
            }
            ItemStack hover = ItemStack.EMPTY;
            for (int i = 0; i < GiftBlocks.ShopBlockEntity.SLOTS; i++) {
                int y = top + 40 + i * 24;
                row(g, left + 8, y, w - 16, 22);
                if (be == null || be.stacks[i].isEmpty()) {
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.kiosk_empty"), left + 34, y + 7, 0x5A5F73, false);
                    continue;
                }
                g.fill(left + 11, y + 3, left + 29, y + 21, 0xFF14151B);
                g.renderItem(be.stacks[i], left + 12, y + 4);
                if (mx >= left + 11 && mx < left + 29 && my >= y + 3 && my < y + 21) {
                    hover = be.stacks[i];
                }
                String name = be.stacks[i].getHoverName().getString();
                if (name.length() > 15) {
                    name = name.substring(0, 14) + "…";
                }
                g.drawString(font, name, left + 34, y + 3, 0xFFFFFF, false);
                boolean sold = !till && be.stock[i] <= 0;
                Component stock = till ? Component.translatable("gui.coastercontrolpanel.shop_unlimited")
                        : sold ? Component.translatable("gui.coastercontrolpanel.shop_sold_out")
                        : Component.translatable("gui.coastercontrolpanel.shop_stock", be.stock[i]);
                g.drawString(font, stock, left + 34, y + 12, sold ? 0xFF6060 : 0x8A8FA3, false);
                int priceX = left + w - 104 - (setup ? 0 : 0);
                Component price = Component.translatable("gui.coastercontrolpanel.shop_price", be.prices[i]);
                g.drawString(font, price, left + 142, y + 7, 0xFFE070, false);
            }
            g.drawString(font, Component.translatable(setup ? "gui.coastercontrolpanel.shop_help_setup"
                    : (till ? "gui.coastercontrolpanel.shop_help_till" : "gui.coastercontrolpanel.shop_help")), left + 8, top + h - 36, 0x8A8FA3, false);
            if (!hover.isEmpty()) {
                g.renderTooltip(font, hover, mx, my);
            }
        }
    }

    // ------------------------------------------------------------------ price tag

    public static class TagScreen extends ParkScreen {
        public TagScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.price_tag"), pos, 220, 128, 0xFFC0392B);
        }

        @Override
        protected void build() {
            for (int i = 0; i < 6; i++) {
                final int s = i;
                addRenderableWidget(Button.builder(Component.literal(String.valueOf(i + 1)), b -> act(5, s, 0))
                        .bounds(left + 8 + i * 34, top + 28, 30, 18).build());
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            GiftBlocks.PriceTagBlockEntity be = entity(GiftBlocks.PriceTagBlockEntity.class);
            int sel = be == null ? 0 : be.slot;
            g.fill(left + 8 + sel * 34, top + 47, left + 38 + sel * 34, top + 49, 0xFFFFD84A);
            row(g, left + 8, top + 54, w - 16, 40);
            if (be == null || be.price < 0) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.tag_none"), left + 14, top + 70, 0x8A8FA3, false);
            } else {
                g.drawString(font, be.name, left + 14, top + 60, 0xFFFFFF, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_price", be.price), left + 14, top + 72, 0xFFE070, false);
                if (be.stock >= 0) {
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_stock", be.stock), left + 14, top + 82, 0x8A8FA3, false);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.tag_help"), left + 8, top + h - 20, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ window display

    public static class WindowScreen extends ParkScreen {
        public WindowScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.window_display"), pos, 230, 136, 0xFF2A7FA8);
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.literal("-"), b -> act(6, -1, 0)).bounds(left + 130, top + 54, 20, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"), b -> act(6, 1, 0)).bounds(left + 196, top + 54, 20, 16).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.window_take"), b -> act(7, 0, 0))
                    .bounds(left + 8, top + h - 22, 84, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            GiftBlocks.WindowBlockEntity be = entity(GiftBlocks.WindowBlockEntity.class);
            row(g, left + 8, top + 26, 100, 70);
            if (be != null && !be.shown.isEmpty()) {
                PoseStack pose = g.pose();
                pose.pushPose();
                pose.translate(left + 58, top + 61, 0);
                pose.scale(3.0F, 3.0F, 1.0F);
                g.renderItem(be.shown, -8, -8);
                pose.popPose();
                String n = be.shown.getHoverName().getString();
                g.drawString(font, n.length() > 16 ? n.substring(0, 15) + "…" : n, left + 14, top + 86, 0xFFFFFF, false);
            } else {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.window_empty"), left + 16, top + 58, 0x5A5F73, false);
            }
            int spin = be == null ? 2 : be.spin;
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.window_spin"), left + 118, top + 32, 0xC8C8D8, false);
            g.drawString(font, spin == 0 ? Component.translatable("gui.coastercontrolpanel.window_still") : Component.literal(spin + "x"),
                    left + 160, top + 58, 0xFFE070, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.window_help"), left + 8, top + h - 36, 0x8A8FA3, false);
        }
    }
}
