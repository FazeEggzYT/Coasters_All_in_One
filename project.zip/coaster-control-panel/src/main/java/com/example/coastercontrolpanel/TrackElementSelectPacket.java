package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.elements.Params;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: what the player picked in the Track Element Selector screen. Empty id clears the selection. */
public record TrackElementSelectPacket(String id, int size, int side, int rise, int rotation) implements CustomPacketPayload {
    public static final Type<TrackElementSelectPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "track_element_select"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TrackElementSelectPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeUtf(p.id, 64);
                buf.writeVarInt(p.size);
                buf.writeVarInt(p.side);
                buf.writeVarInt(p.rise);
                buf.writeVarInt(p.rotation);
            },
            buf -> new TrackElementSelectPacket(buf.readUtf(64), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(TrackElementSelectPacket p, IPayloadContext context) {
        ItemStack stack = context.player().getItemInHand(InteractionHand.MAIN_HAND);
        if (!stack.is(CoasterControlPanel.TRACK_ELEMENT_SELECTOR_ITEM.get())) {
            return;
        }
        ElementState.write(stack, p.id, new Params(p.size, p.side, p.rise), p.rotation);
    }
}
