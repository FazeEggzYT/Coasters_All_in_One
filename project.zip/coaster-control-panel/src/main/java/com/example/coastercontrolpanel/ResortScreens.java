package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** Screens of the Park Hotel and Resort pack and the Ride Maintenance pack. */
public final class ResortScreens {
    private ResortScreens() {
    }

    // ------------------------------------------------------------------ reception desk

    public static class ReceptionScreen extends ServiceScreens.SvcScreen {
        private boolean setup;
        private final List<Button> play = new ArrayList<>();
        private final List<Button> adm = new ArrayList<>();

        public ReceptionScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.reception_desk"), pos, 270, 230, 0xFF2A7FA8);
        }

        @Override
        protected void build() {
            play.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.hotel_checkin"), b -> act(50, 0, 0)).bounds(left + 8, top + h - 44, 110, 18).build()));
            play.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.hotel_checkout"), b -> act(51, 0, 0)).bounds(left + 124, top + h - 44, 110, 18).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("-"), b -> act(52, hasShiftDown() ? -5 : -1, 0)).bounds(left + 8, top + h - 44, 20, 18).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("+"), b -> act(52, hasShiftDown() ? 5 : 1, 0)).bounds(left + 32, top + h - 44, 20, 18).build()));
            adm.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.shop_collect"), b -> act(54, 0, 0)).bounds(left + 124, top + h - 44, 110, 18).build()));
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup).bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            ResortBlocks.ReceptionBlockEntity be = entity(ResortBlocks.ReceptionBlockEntity.class);
            for (Button b : play) {
                b.visible = !setup;
            }
            for (Button b : adm) {
                b.visible = setup;
            }
            super.render(g, mx, my, pt);
            List<ResortBlocks.RoomDoorBlockEntity> rooms = minecraft == null || minecraft.level == null ? List.of()
                    : ResortBlocks.rooms(minecraft.level, pos, ResortBlocks.ROOM_RADIUS);
            long free = rooms.stream().filter(r -> r.stay == null).count();
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.hotel_free", free, rooms.size()), left + 8, top + 24, 0xC8C8D8, false);
            if (be != null) {
                Component pr = Component.translatable(setup ? "gui.coastercontrolpanel.hotel_price_set" : "gui.coastercontrolpanel.hotel_price", be.price);
                g.drawString(font, pr, left + w - 8 - font.width(pr), top + 24, 0xFFE070, false);
                if (setup) {
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_takings", be.takings), left + 60, top + h - 40, 0x9EE6A0, false);
                }
            }
            for (int i = 0; i < 8; i++) {
                int y = top + 38 + i * 18;
                row(g, left + 8, y, w - 16, 16);
                if (i >= rooms.size()) {
                    continue;
                }
                ResortBlocks.RoomDoorBlockEntity r = rooms.get(i);
                g.fill(left + 12, y + 4, left + 20, y + 12, r.stay == null ? 0xFF3FD07A : 0xFFE05050);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.hotel_room", r.number), left + 26, y + 4, 0xFFFFFF, false);
                g.drawString(font, r.stay == null ? Component.translatable("gui.coastercontrolpanel.hotel_vacant") : Component.literal(r.guestName),
                        left + 100, y + 4, r.stay == null ? 0x7CFFB0 : 0xFFA0A0, false);
            }
            if (rooms.isEmpty()) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.hotel_none"), left + 14, top + 44, 0x8A8FA3, false);
            }
        }
    }

    // ------------------------------------------------------------------ room door info

    public static class RoomScreen extends ServiceScreens.SvcScreen {
        private Button minus;
        private Button plus;
        private Button reset;

        public RoomScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.hotel_room_door"), pos, 220, 140, 0xFF7A4A9A);
        }

        @Override
        protected void build() {
            minus = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(53, hasShiftDown() ? -10 : -1, 0)).bounds(left + 150, top + 28, 20, 16).build());
            plus = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(53, hasShiftDown() ? 10 : 1, 0)).bounds(left + 174, top + 28, 20, 16).build());
            reset = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.room_reset"), b -> act(55, 0, 0)).bounds(left + 8, top + h - 44, 100, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            boolean staff = badge();
            minus.visible = staff;
            plus.visible = staff;
            reset.visible = staff;
            super.render(g, mx, my, pt);
            ResortBlocks.RoomDoorBlockEntity be = entity(ResortBlocks.RoomDoorBlockEntity.class);
            if (be == null) {
                return;
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.hotel_room", be.number), left + 12, top + 32, 0xFFE070, false);
            row(g, left + 8, top + 52, w - 16, 28);
            g.fill(left + 14, top + 62, left + 24, top + 72, be.stay == null ? 0xFF3FD07A : 0xFFE05050);
            g.drawString(font, be.stay == null ? Component.translatable("gui.coastercontrolpanel.hotel_vacant")
                    : Component.translatable("gui.coastercontrolpanel.room_guest", be.guestName), left + 30, top + 63, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.room_help"), left + 8, top + h - 22, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ workshop bench

    public static class BenchScreen extends ServiceScreens.SvcScreen {
        public BenchScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.workshop_bench"), pos, 240, 160, 0xFF8A6A2E);
        }

        @Override
        protected void build() {
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.bench_one"), b -> act(60, 1, 0)).bounds(left + 8, top + 96, 106, 18).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.bench_all"), b -> act(60, 2, 0)).bounds(left + 120, top + 96, 106, 18).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            ItemStack held = minecraft == null || minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getMainHandItem();
            row(g, left + 8, top + 26, w - 16, 60);
            if (held.isEmpty() || !held.isDamageableItem()) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.bench_hold"), left + 16, top + 50, 0x8A8FA3, false);
            } else {
                g.fill(left + 14, top + 32, left + 50, top + 68, 0xFF14151B);
                g.renderItem(held, left + 23, top + 41);
                g.drawString(font, held.getHoverName(), left + 58, top + 34, 0xFFFFFF, false);
                float frac = 1.0F - (float) held.getDamageValue() / Math.max(1, held.getMaxDamage());
                g.fill(left + 58, top + 50, left + 218, top + 58, 0xFF0B0C10);
                g.fill(left + 59, top + 51, left + 59 + Math.round(158 * frac), top + 57, frac > 0.5F ? 0xFF3FD07A : frac > 0.25F ? 0xFFE0A030 : 0xFFE05050);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.bench_left", held.getMaxDamage() - held.getDamageValue(), held.getMaxDamage()), left + 58, top + 62, 0xC8C8D8, false);
            }
            int iron = minecraft == null || minecraft.player == null ? 0 : ArcadeBlocks.count(minecraft.player, Items.IRON_INGOT);
            g.renderItem(new ItemStack(Items.IRON_INGOT), left + 8, top + 122);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.bench_iron", iron), left + 28, top + 126, 0xFFE070, false);
        }
    }

    // ------------------------------------------------------------------ safety checklist

    public static class ChecklistScreen extends ServiceScreens.SvcScreen {
        private boolean setup;
        private boolean dirty;
        private final EditBox[] boxes = new EditBox[MaintBlocks.CHECKS];
        private final Button[] ticks = new Button[MaintBlocks.CHECKS];

        public ChecklistScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.safety_checklist_board"), pos, 270, 240, 0xFFB0802A);
        }

        @Override
        protected void build() {
            MaintBlocks.ChecklistBlockEntity be = entity(MaintBlocks.ChecklistBlockEntity.class);
            for (int i = 0; i < MaintBlocks.CHECKS; i++) {
                final int idx = i;
                int y = top + 30 + i * 22;
                ticks[i] = addRenderableWidget(Button.builder(Component.literal(" "), b -> act(61, idx, 0)).bounds(left + 10, y, 20, 18).build());
                boxes[i] = new EditBox(font, left + 36, y + 1, w - 48, 16, Component.empty());
                boxes[i].setMaxLength(30);
                boxes[i].setValue(be == null ? "" : be.lines[i]);
                boxes[i].setResponder(s -> dirty = true);
                addRenderableWidget(boxes[i]);
            }
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.check_sign"), b -> act(62, 0, 0)).bounds(left + 8, top + h - 44, 100, 18).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.check_reset"), b -> act(63, 0, 0)).bounds(left + 112, top + h - 44, 80, 18).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup).bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            MaintBlocks.ChecklistBlockEntity be = entity(MaintBlocks.ChecklistBlockEntity.class);
            for (int i = 0; i < MaintBlocks.CHECKS; i++) {
                boxes[i].visible = setup;
                boxes[i].setEditable(badge());
                ticks[i].setMessage(Component.literal(be != null && (be.mask & (1 << i)) != 0 ? "x" : " "));
                ticks[i].active = badge();
            }
            super.render(g, mx, my, pt);
            if (!setup && be != null) {
                for (int i = 0; i < MaintBlocks.CHECKS; i++) {
                    boolean on = (be.mask & (1 << i)) != 0;
                    g.drawString(font, be.lines[i], left + 38, top + 36 + i * 22, on ? 0x7CFFB0 : 0xFFFFFF, false);
                }
            }
            if (be != null) {
                Component st = be.complete() ? Component.translatable("gui.coastercontrolpanel.check_ok", be.signedBy)
                        : Component.translatable("gui.coastercontrolpanel.check_wait");
                g.drawString(font, st, left + 8, top + h - 58, be.complete() ? 0x7CFFB0 : 0xFFC860, false);
            }
            if (!badge()) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.rota_locked"), left + 84, top + h - 18, 0xFF8A8A, false);
            }
        }

        @Override
        public void removed() {
            if (dirty && badge()) {
                List<String> out = new ArrayList<>();
                for (EditBox b : boxes) {
                    out.add(b == null ? "" : b.getValue());
                }
                PacketDistributor.sendToServer(new ServiceTextPacket(pos, 2, out));
            }
            super.removed();
        }
    }
}
