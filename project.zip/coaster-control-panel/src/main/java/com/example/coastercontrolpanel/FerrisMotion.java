package com.example.coastercontrolpanel;

/**
 * The movement of a Ferris Wheel, free of any Minecraft types. The wheel angle only ever grows (degrees); the direction
 * setting is applied when it is shown. Cabin spacing is 360 / cabins, and a Station step always stops with a cabin at the
 * bottom. Ending carries on to the next whole turn so every block can be put back where it was.
 */
public final class FerrisMotion {
    public static final int IDLE = 0;
    public static final int COUNTDOWN = 1;
    public static final int RUNNING = 2;
    public static final int PAUSED = 3;
    public static final int ENDING = 4;
    public static final int HALTED = 5;

    private static final double EPS = 1.0E-4;

    public int phase = IDLE;
    public int stepIndex;
    public int loop;
    public double stepTime;
    /** Degrees turned since the start (not wrapped). */
    public double angle;
    /** Degrees per second. */
    public double vel;
    public double spacing = 30.0;
    public boolean finished;
    public boolean landed;

    private double goal;
    private boolean goalSet;
    private boolean docked;
    private double haltVel;
    private boolean waitAfterEnding;

    public void start(int cabins) {
        phase = RUNNING;
        spacing = 360.0 / Math.max(1, cabins);
        stepIndex = 0;
        loop = 0;
        angle = 0;
        vel = 0;
        finished = false;
        landed = false;
        waitAfterEnding = false;
        beginStep(null);
    }

    /** Index of the cabin at the bottom (0 is the one that started there), or -1 while between stations. */
    public int stationCabin() {
        double k = angle / spacing;
        return Math.abs(k - Math.rint(k)) < 0.02 ? (int) Math.rint(k) : -1;
    }

    private void beginStep(FerrisSettings c) {
        stepTime = 0;
        goalSet = false;
        docked = false;
    }

    public void togglePause() {
        if (phase == RUNNING) {
            phase = PAUSED;
        } else if (phase == PAUSED && !finished) {
            phase = RUNNING;
        } else if (phase == HALTED) {
            phase = RUNNING;
        }
    }

    /** After a world reload a running ride comes back paused; the current step is worked out again when it resumes. */
    public void restoreAfterLoad() {
        if (phase == RUNNING) {
            phase = PAUSED;
        } else if (phase == COUNTDOWN) {
            phase = IDLE;
        }
        goalSet = false;
        docked = false;
    }

    public void halt() {
        if (phase == RUNNING || phase == PAUSED || phase == ENDING) {
            phase = HALTED;
            haltVel = Math.max(vel, 1.0);
            finished = false;
        }
    }

    public void end(FerrisSettings c) {
        if (phase == RUNNING || phase == PAUSED || phase == HALTED) {
            phase = ENDING;
            finished = false;
            waitAfterEnding = false;
            goalSet = false;
        }
    }

    private void nextStep(FerrisSettings c) {
        stepIndex++;
        if (stepIndex >= c.steps.size()) {
            loop++;
            stepIndex = 0;
            if (loop >= c.loops) {
                phase = ENDING;
                goalSet = false;
                waitAfterEnding = c.endMode == 1;
                return;
            }
        }
        beginStep(c);
    }

    private static double nextMultiple(double value, double unit) {
        double k = value / unit;
        double r = Math.rint(k);
        return Math.abs(k - r) < 1.0E-6 ? r * unit : Math.ceil(k) * unit;
    }

    private void chase(double target, double accel, double dt) {
        double d = target - vel;
        double s = accel * dt;
        vel = Math.abs(d) <= s ? target : vel + Math.signum(d) * s;
    }

    /** Moves toward goal and stops exactly on it. Returns true on arrival. */
    private boolean approach(double goalAngle, double cruise, double accel, double dt) {
        double rem = goalAngle - angle;
        if (rem <= EPS) {
            angle = goalAngle;
            vel = 0;
            return true;
        }
        double brake = Math.sqrt(2.0 * accel * rem);
        double target = Math.min(cruise, Math.max(brake, 1.0));
        chase(target, accel, dt);
        double step = vel * dt;
        if (step >= rem || (rem < 0.3 && vel <= 2.0)) {
            angle = goalAngle;
            vel = 0;
            return true;
        }
        angle += step;
        return false;
    }

    public void tick(FerrisSettings c, double dt) {
        double acc = c.accel;
        switch (phase) {
            case RUNNING -> runStep(c, dt, acc);
            case PAUSED -> {
                chase(0, acc, dt);
                angle += vel * dt;
            }
            case HALTED -> {
                vel = Math.max(0.0, vel - haltVel / Math.max(0.3, c.haltTime) * dt);
                angle += vel * dt;
            }
            case ENDING -> {
                if (!goalSet) {
                    goal = waitAfterEnding ? nextMultiple(angle, spacing) : nextMultiple(angle, 360.0);
                    goalSet = true;
                }
                if (approach(goal, Math.max(c.creep * 6.0, 4.0), acc, dt)) {
                    goalSet = false;
                    if (waitAfterEnding) {
                        phase = PAUSED;
                        finished = true;
                        waitAfterEnding = false;
                    } else {
                        angle = Math.rint(angle / 360.0) * 360.0;
                        landed = true;
                        phase = IDLE;
                    }
                }
            }
            default -> {
            }
        }
    }

    private void runStep(FerrisSettings c, double dt, double acc) {
        if (c.steps.isEmpty()) {
            nextStep(c);
            return;
        }
        FerrisSettings.Step s = c.steps.get(Math.min(stepIndex, c.steps.size() - 1));
        switch (s.type) {
            case FerrisSettings.ROTATE -> {
                if (!goalSet) {
                    goal = angle + s.b * 360.0;
                    goalSet = true;
                }
                chase(s.a * 6.0, acc, dt);
                angle += vel * dt;
                if (angle >= goal) {
                    nextStep(c);
                }
            }
            case FerrisSettings.STATION -> {
                if (!goalSet) {
                    double aligned = nextMultiple(angle, spacing);
                    boolean already = Math.abs(aligned - angle) < 1.0E-6;
                    goal = already ? angle + s.b * spacing : aligned + (s.b - 1) * spacing;
                    goalSet = true;
                    docked = false;
                }
                if (!docked) {
                    if (approach(goal, Math.max(c.creep * 6.0, 3.0), acc, dt)) {
                        docked = true;
                        stepTime = 0;
                    }
                } else {
                    stepTime += dt;
                    vel = 0;
                    if (stepTime >= s.a) {
                        nextStep(c);
                    }
                }
            }
            default -> {
                chase(0, acc, dt);
                angle += vel * dt;
                stepTime += dt;
                if (stepTime >= s.a && vel <= 0.0) {
                    nextStep(c);
                }
            }
        }
    }
}
