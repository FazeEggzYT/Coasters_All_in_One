package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;

/** Makes guests, up to a limit, while the park is open. */
public class GuestSpawnerBlockEntity extends BlockEntity {
    public static final int S_CHANNEL = 0;
    public static final int S_RATE = 1;
    public static final int S_MAX = 2;
    public static final int S_SPEED = 3;
    public static final int S_RIDE = 4;
    public static final int S_KIDS = 5;
    public static final int S_OPEN = 6;
    public static final int COUNT = 7;

    public static final int[] MIN = {1, 1, 1, 50, 5, 0, 0};
    public static final int[] MAX = {16, 60, 100, 150, 300, 100, 2};
    public static final int[] DEF = {1, 12, 30, 100, 30, 10, 0};
    private static final String[] KEYS = {"Channel", "Rate", "Max", "Speed", "Ride", "Kids", "Open"};

    private final int[] s = DEF.clone();
    private final SimpleContainer frequency = new SimpleContainer(1);
    private final Link link = new Link();
    private boolean registered = false;
    private boolean loading = false;
    private int received = 0;

    private double credit = 0;
    // what the screen shows
    private int queueMarkers = 0;
    private int stationMarkers = 0;
    private int exitMarkers = 0;
    private int guests = 0;
    private boolean open = false;

    public GuestSpawnerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SPAWNER_BE.get(), pos, state);
        frequency.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLink();
                    registerLink();
                }
            }
        });
    }

    public SimpleContainer getFrequency() {
        return frequency;
    }

    public int get(int index) {
        return s[index];
    }

    public int getQueueMarkers() {
        return queueMarkers;
    }

    public int getStationMarkers() {
        return stationMarkers;
    }

    public int getExitMarkers() {
        return exitMarkers;
    }

    public int getGuests() {
        return guests;
    }

    public boolean isOpen() {
        return open;
    }

    @Nullable
    public static GuestSpawnerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof GuestSpawnerBlockEntity e ? e : null;
    }

    // ---------------------------------------------------------------- link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLink();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLink();
    }

    @Override
    public void setRemoved() {
        unregisterLink();
        super.setRemoved();
    }

    private void registerLink() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        ItemStack stack = frequency.getItem(0);
        link.alive = !stack.isEmpty();
        link.key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        received = 0;
        if (link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, link);
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, link);
        }
    }

    private void unregisterLink() {
        if (!registered) {
            return;
        }
        registered = false;
        if (level != null && link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, link);
        }
        link.alive = false;
        received = 0;
    }

    // ---------------------------------------------------------------- settings

    public void applyConfig(int[] values) {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int i = 0; i < COUNT && i < values.length; i++) {
            s[i] = Math.max(MIN[i], Math.min(MAX[i], values[i]));
        }
        setChanged();
        sync();
    }

    private void sync() {
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    private boolean computeOpen() {
        return switch (s[S_OPEN]) {
            case 1 -> true;
            case 2 -> false;
            default -> frequency.getItem(0).isEmpty() || received > 0;
        };
    }

    // ---------------------------------------------------------------- spawning

    public void serverTick() {
        if (!(level instanceof ServerLevel server) || server.getGameTime() % 20 != 0) {
            return;
        }
        int q = MarkerRegistry.find(server, worldPosition, s[S_CHANNEL], MarkerKind.QUEUE, 96.0).size();
        int st = MarkerRegistry.find(server, worldPosition, s[S_CHANNEL], MarkerKind.STATION, 96.0).size();
        int ex = MarkerRegistry.find(server, worldPosition, s[S_CHANNEL], MarkerKind.EXIT, 96.0).size();
        int count = countGuests(server);
        boolean nowOpen = computeOpen();
        if (q != queueMarkers || st != stationMarkers || ex != exitMarkers || count != guests || nowOpen != open) {
            queueMarkers = q;
            stationMarkers = st;
            exitMarkers = ex;
            guests = count;
            open = nowOpen;
            sync();
        }
        if (!open || guests >= s[S_MAX]) {
            credit = Math.min(credit, 1.0);
            return;
        }
        credit += s[S_RATE] / 60.0;
        if (credit >= 1.0) {
            credit -= 1.0;
            spawn(server);
        }
    }

    private int countGuests(ServerLevel server) {
        AABB box = new AABB(worldPosition).inflate(128.0);
        return server.getEntitiesOfClass(GuestEntity.class, box, g -> worldPosition.equals(g.getHome())).size();
    }

    /** Makes one guest on top of the block. Also used by the Test button. */
    public boolean spawn(ServerLevel server) {
        BlockPos above = worldPosition.above();
        if (!server.getBlockState(above).getCollisionShape(server, above).isEmpty()) {
            return false;
        }
        GuestEntity guest = CoasterControlPanel.GUEST.get().create(server);
        if (guest == null) {
            return false;
        }
        var rand = server.random;
        boolean kid = rand.nextInt(100) < s[S_KIDS];
        double scale = kid ? 0.65 : 0.92 + rand.nextDouble() * 0.12;
        guest.moveTo(above.getX() + 0.5, above.getY(), above.getZ() + 0.5, rand.nextFloat() * 360.0F, 0.0F);
        guest.setup(worldPosition, s[S_CHANNEL], s[S_SPEED] / 100.0, s[S_RIDE],
                rand.nextInt(GuestEntity.SKINS), scale);
        server.addFreshEntity(guest);
        return true;
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        list.set(0, frequency.getItem(0));
        ContainerHelper.saveAllItems(tag, list, registries);
        for (int i = 0; i < COUNT; i++) {
            tag.putInt(KEYS[i], s[i]);
        }
        tag.putInt("Queues", queueMarkers);
        tag.putInt("Stations", stationMarkers);
        tag.putInt("Exits", exitMarkers);
        tag.putInt("Guests", guests);
        tag.putBoolean("IsOpen", open);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        frequency.setItem(0, list.get(0));
        for (int i = 0; i < COUNT; i++) {
            if (tag.contains(KEYS[i])) {
                s[i] = Math.max(MIN[i], Math.min(MAX[i], tag.getInt(KEYS[i])));
            }
        }
        queueMarkers = tag.getInt("Queues");
        stationMarkers = tag.getInt("Stations");
        exitMarkers = tag.getInt("Exits");
        guests = tag.getInt("Guests");
        open = tag.getBoolean("IsOpen");
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- the Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        @Override
        public int getTransmittedStrength() {
            return 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            received = power;
        }

        @Override
        public boolean isListening() {
            return true;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
