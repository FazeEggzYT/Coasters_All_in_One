package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.elements.Params;
import com.example.coastercontrolpanel.elements.TrackElement;
import com.example.coastercontrolpanel.elements.TrackElements;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/** What the Track Element Selector currently has selected. Stored on the item, so it follows the item and syncs by itself. */
public record ElementState(TrackElement element, Params params, int rotation) {
    public static ElementState read(ItemStack stack) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        TrackElement e = TrackElements.byId(tag.getString("Element"));
        if (e == null) {
            return null;
        }
        Params p = new Params(tag.getInt("Size"), tag.getInt("Side"), tag.getInt("Rise")).clamped();
        return new ElementState(e, p, Math.floorMod(tag.getInt("Rot"), 4));
    }

    /** id empty clears the selection. */
    public static void write(ItemStack stack, String id, Params p, int rotation) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        if (id == null || id.isEmpty() || TrackElements.byId(id) == null) {
            tag.remove("Element");
        } else {
            Params c = p.clamped();
            tag.putString("Element", id);
            tag.putInt("Size", c.size());
            tag.putInt("Side", c.side());
            tag.putInt("Rise", c.rise());
            tag.putInt("Rot", Math.floorMod(rotation, 4));
        }
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
}
