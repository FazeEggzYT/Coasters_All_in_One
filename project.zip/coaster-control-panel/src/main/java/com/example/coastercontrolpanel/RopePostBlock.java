package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** A queue post. It joins to neighbouring posts with a rope, like a fence. You can walk through the rope. */
public class RopePostBlock extends Block {
    public static final BooleanProperty NORTH = BooleanProperty.create("north");
    public static final BooleanProperty EAST = BooleanProperty.create("east");
    public static final BooleanProperty SOUTH = BooleanProperty.create("south");
    public static final BooleanProperty WEST = BooleanProperty.create("west");

    private static final VoxelShape POST = Block.box(6, 0, 6, 10, 16, 10);
    private static final VoxelShape ROPE_N = Block.box(7.5, 10, 0, 8.5, 14, 6);
    private static final VoxelShape ROPE_S = Block.box(7.5, 10, 10, 8.5, 14, 16);
    private static final VoxelShape ROPE_W = Block.box(0, 10, 7.5, 6, 14, 8.5);
    private static final VoxelShape ROPE_E = Block.box(10, 10, 7.5, 16, 14, 8.5);

    public RopePostBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false)
                .setValue(SOUTH, false).setValue(WEST, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST);
    }

    private static BooleanProperty prop(Direction d) {
        return switch (d) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case SOUTH -> SOUTH;
            default -> WEST;
        };
    }

    /** Ropes join other posts and the end of a sign board that runs across the rope. */
    private static boolean joins(BlockState other, Direction toward) {
        if (other.getBlock() instanceof RideSignBlock sign) {
            return sign.kind != SignKind.FLOOR && other.getValue(RideSignBlock.FACING).getAxis() != toward.getAxis();
        }
        return other.getBlock() instanceof RopePostBlock;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = defaultBlockState();
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockState other = context.getLevel().getBlockState(context.getClickedPos().relative(d));
            state = state.setValue(prop(d), joins(other, d));
        }
        return state;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighbor, LevelAccessor level,
                                     BlockPos pos, BlockPos neighborPos) {
        if (direction.getAxis().isHorizontal()) {
            return state.setValue(prop(direction), joins(neighbor, direction));
        }
        return state;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = POST;
        if (state.getValue(NORTH)) {
            shape = Shapes.or(shape, ROPE_N);
        }
        if (state.getValue(SOUTH)) {
            shape = Shapes.or(shape, ROPE_S);
        }
        if (state.getValue(WEST)) {
            shape = Shapes.or(shape, ROPE_W);
        }
        if (state.getValue(EAST)) {
            shape = Shapes.or(shape, ROPE_E);
        }
        return shape;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return POST;
    }
}
