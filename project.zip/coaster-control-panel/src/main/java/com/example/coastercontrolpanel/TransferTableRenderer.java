package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Draws the sliding platform of a transfer table, with a short piece of track on top. */
public class TransferTableRenderer implements BlockEntityRenderer<TransferTableBlockEntity> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/transfer_platform.png");

    public TransferTableRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(TransferTableBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        if (be.hasPlatform()) {
            return; // the platform is a real structure now, drawn by Sable
        }
        // glide towards the position the server reported
        be.drawSide = Mth.lerp(0.35F, be.drawSide, be.side());
        be.drawForward = Mth.lerp(0.35F, be.drawForward, be.forward());
        Direction facing = be.facing();
        pose.pushPose();
        Direction right = facing.getClockWise();
        pose.translate(0.5 + right.getStepX() * be.drawSide + facing.getStepX() * be.drawForward, 0.0,
                0.5 + right.getStepZ() * be.drawSide + facing.getStepZ() * be.drawForward);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        PoseStack.Pose p = pose.last();
        // a flat platform, one block wide and long, 3 px high, sitting on top of the block
        float x0 = -0.5F, x1 = 0.5F, z0 = -0.5F, z1 = 0.5F, y0 = 1.0F, y1 = 1.1875F;
        quad(vc, p, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 0, 1, 1, 0, 1, 0, light);
        quad(vc, p, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, 0, 1, 1, 0, -1, 0, light);
        quad(vc, p, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0, 0.9F, 1, 1, 0, 0, -1, light);
        quad(vc, p, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, 0, 0.9F, 1, 1, 0, 0, 1, light);
        quad(vc, p, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 0, 0.9F, 1, 1, 1, 0, 0, light);
        quad(vc, p, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, 0, 0.9F, 1, 1, -1, 0, 0, light);
        pose.popPose();
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose p,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float u0, float v0, float u1, float v1, float nx, float ny, float nz, int light) {
        v(vc, p, ax, ay, az, u0, v1, nx, ny, nz, light);
        v(vc, p, bx, by, bz, u1, v1, nx, ny, nz, light);
        v(vc, p, cx, cy, cz, u1, v0, nx, ny, nz, light);
        v(vc, p, dx, dy, dz, u0, v0, nx, ny, nz, light);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, float u, float v,
                          float nx, float ny, float nz, int light) {
        vc.addVertex(p, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, nx, ny, nz);
    }
}
