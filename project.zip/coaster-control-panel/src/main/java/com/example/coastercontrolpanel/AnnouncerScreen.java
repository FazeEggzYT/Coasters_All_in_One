package com.example.coastercontrolpanel;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Announcer setup: mode, sound, volume, pitch, repeat, delay and the Redstone Link item. */
public class AnnouncerScreen extends AbstractContainerScreen<AnnouncerMenu> {
    private static final String[] MODE_NAMES = {"Trigger (signal)", "Button (click)", "Switch (repeat)"};

    private int mode;
    private int sound;
    private int volume = 100;
    private int pitch = 100;
    private int repeat = 5;
    private int delay = 0;

    private Button modeButton;
    private Button soundButton;

    public AnnouncerScreen(AnnouncerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 372;
        this.imageHeight = 172;
    }

    private AnnouncerBlockEntity announcer() {
        if (minecraft == null || minecraft.level == null) {
            return null;
        }
        return minecraft.level.getBlockEntity(menu.getPos()) instanceof AnnouncerBlockEntity a ? a : null;
    }

    private int step(int normal, int big) {
        return Screen.hasShiftDown() ? big : normal;
    }

    @Override
    protected void init() {
        super.init();
        AnnouncerBlockEntity a = announcer();
        if (a != null) {
            mode = a.getMode();
            sound = a.getSound();
            volume = a.getVolume();
            pitch = a.getPitch();
            repeat = a.getRepeat();
            delay = a.getDelay();
        }

        addRenderableWidget(Button.builder(Component.literal("OK").withStyle(ChatFormatting.GREEN), b -> onClose())
                .bounds(leftPos + 146, topPos + 3, 38, 14).build());

        modeButton = Button.builder(Component.literal(MODE_NAMES[mode]), b -> {
            mode = (mode + 1) % 3;
            b.setMessage(Component.literal(MODE_NAMES[mode]));
        }).bounds(leftPos + 70, topPos + 20, 114, 16).build();
        addRenderableWidget(modeButton);

        soundButton = Button.builder(Component.literal(AnnouncerSounds.NAMES[sound]), b -> {
            sound = (sound + 1) % AnnouncerSounds.count();
            b.setMessage(Component.literal(AnnouncerSounds.NAMES[sound]));
        }).bounds(leftPos + 70, topPos + 40, 76, 16).build();
        addRenderableWidget(soundButton);

        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.test"), b -> send(true))
                .bounds(leftPos + 148, topPos + 40, 36, 16).build());

        addPair(62, () -> volume = Math.max(10, volume - step(10, 50)), () -> volume = Math.min(600, volume + step(10, 50)));
        addPair(84, () -> pitch = Math.max(50, pitch - 10), () -> pitch = Math.min(200, pitch + 10));
        addPair(106, () -> repeat = Math.max(1, repeat - step(1, 5)), () -> repeat = Math.min(300, repeat + step(1, 5)));
        addPair(128, () -> delay = Math.max(0, delay - step(1, 5)), () -> delay = Math.min(60, delay + step(1, 5)));
    }

    private void addPair(int y, Runnable minus, Runnable plus) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> minus.run())
                .bounds(leftPos + 70, topPos + y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> plus.run())
                .bounds(leftPos + 166, topPos + y, 18, 16).build());
    }

    private void send(boolean test) {
        PacketDistributor.sendToServer(new AnnouncerConfigPacket(menu.getPos(), mode, sound, volume, pitch,
                repeat, delay, test));
    }

    @Override
    public void removed() {
        send(false);
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 190, y0 + 4, x0 + 191, y0 + imageHeight - 4, 0xFF3A3E4D);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int dim = 0x7A8098;
        int text = 0xE0E4F0;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        g.drawString(font, "Mode", 8, 24, text, false);
        g.drawString(font, "Sound", 8, 44, text, false);
        g.drawString(font, "Volume", 8, 66, text, false);
        g.drawString(font, "Pitch", 8, 88, text, false);
        g.drawString(font, "Repeat", 8, 110, text, false);
        g.drawString(font, "Delay", 8, 132, text, false);
        g.drawString(font, "Link item", 8, 153, text, false);
        g.drawCenteredString(font, volume + "%", 127, 66, 0xFFFFFF);
        g.drawCenteredString(font, pitch + "%", 127, 88, 0xFFFFFF);
        g.drawCenteredString(font, repeat + " s", 127, 110, mode == AnnouncerBlockEntity.SWITCH ? 0xFFFFFF : dim);
        g.drawCenteredString(font, delay + " s", 127, 132, 0xFFFFFF);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announcer_hint"), 94, 153, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 199, 66, dim, false);
    }
}
