package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Seat Speed: how fast the restraint goes down and up, in percent of normal. */
public class SeatSpeedScreen extends Screen {
    private static final int W = 200;
    private static final int H = 88;

    private final BlockPos pos;
    private int speed;

    public SeatSpeedScreen(BlockPos pos, int speed) {
        super(Component.translatable("gui.coastercontrolpanel.speed_title"));
        this.pos = pos;
        this.speed = Math.max(10, Math.min(100, speed));
    }

    @Override
    protected void init() {
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> speed = Math.max(10, speed - 10))
                .bounds(x + 110, y + 28, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> speed = Math.min(100, speed + 10))
                .bounds(x + 174, y + 28, 18, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(x + 8 + (W - 16) / 2 - 30, y + 62, 60, 18).build());
    }

    @Override
    public void onClose() {
        PacketDistributor.sendToServer(new SeatSpeedPacket(pos, speed));
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xFF3A3E4D);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xFF1B1D24);
        g.drawString(font, title, x + 8, y + 8, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.seat_speed"), x + 8, y + 32, 0xE0E4F0, false);
        g.drawCenteredString(font, speed + "%", x + 151, y + 32, 0xFFFFFF);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.speed_hint"), x + 8, y + 48, 0x7A8098, false);
    }
}
