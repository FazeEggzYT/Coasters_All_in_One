package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * The Ride Maintenance pack: Workshop Bench (repairs tools for iron), Safety Checklist Board (redstone signal when signed off),
 * Test Dummy, Lift Jack, Grease Station, Tool Wall, Inspection Pit. The Parts Shelf is in ResortBlocks.
 */
public final class MaintBlocks {
    private MaintBlocks() {
    }

    public static final BooleanProperty LOCKED = BooleanProperty.create("locked");
    public static final BooleanProperty RAISED = BooleanProperty.create("raised");
    public static final int CHECKS = 6;

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    // ------------------------------------------------------------------ workbench

    public static class WorkshopBenchBlock extends DecorBlocks.Facing {
        public WorkshopBenchBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 0, 0, 2, 16, 15, 14);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openResort(3, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        /** mode 1: one repair step (25 percent for one iron ingot), mode 2: as many as needed. */
        public static void repair(ServerPlayer p, int mode) {
            ItemStack held = p.getMainHandItem();
            if (held.isEmpty() || !held.isDamaged()) {
                say(p, "bench_nothing");
                return;
            }
            int steps = mode == 2 ? 4 : 1;
            int used = 0;
            for (int i = 0; i < steps && held.isDamaged(); i++) {
                if (!p.getAbilities().instabuild) {
                    if (ArcadeBlocks.count(p, Items.IRON_INGOT) < 1) {
                        break;
                    }
                    ArcadeBlocks.take(p, Items.IRON_INGOT, 1);
                }
                held.setDamageValue(Math.max(0, held.getDamageValue() - Math.max(1, held.getMaxDamage() / 4)));
                used++;
            }
            if (used == 0) {
                say(p, "bench_no_iron");
                return;
            }
            p.level().playSound(null, p.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.5F, 1.5F);
            say(p, "bench_done", used);
        }
    }

    // ------------------------------------------------------------------ checklist board

    public static class ChecklistBlockEntity extends RestaurantBlocks.Syncing {
        public final String[] lines = {"Restraints locked", "Gates working", "Brakes tested", "Lights on", "Track clear", "Staff in place"};
        public int mask;
        public String signedBy = "";

        public ChecklistBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.CHECKLIST_BE.get(), pos, state);
        }

        public boolean complete() {
            return mask == (1 << CHECKS) - 1 && !signedBy.isEmpty();
        }

        @Override
        public void changed() {
            super.changed();
            if (level != null) {
                level.updateNeighborsAt(worldPosition, getBlockState().getBlock());
            }
        }

        public void toggle(int i) {
            if (i < 0 || i >= CHECKS) {
                return;
            }
            mask ^= 1 << i;
            signedBy = "";
            changed();
        }

        public void sign(ServerPlayer p) {
            if (mask != (1 << CHECKS) - 1) {
                say(p, "check_incomplete");
                return;
            }
            signedBy = p.getGameProfile().getName();
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 0.9F, 1.5F);
            }
            say(p, "check_signed");
            changed();
        }

        public void reset() {
            mask = 0;
            signedBy = "";
            changed();
        }

        public void setLines(java.util.List<String> in) {
            for (int i = 0; i < CHECKS; i++) {
                lines[i] = i < in.size() ? in.get(i) : "";
            }
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag l = new ListTag();
            for (String s : lines) {
                l.add(StringTag.valueOf(s));
            }
            tag.put("Lines", l);
            tag.putInt("Mask", mask);
            tag.putString("SignedBy", signedBy);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ListTag l = tag.getList("Lines", Tag.TAG_STRING);
            for (int i = 0; i < l.size() && i < CHECKS; i++) {
                lines[i] = l.getString(i);
            }
            mask = tag.getInt("Mask");
            signedBy = tag.getString("SignedBy");
        }
    }

    public static class ChecklistBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<ChecklistBlock> CODEC = simpleCodec(ChecklistBlock::new);

        public ChecklistBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 1, 13, 15, 15, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ChecklistBlockEntity(pos, state);
        }

        @Override
        protected boolean isSignalSource(BlockState state) {
            return true;
        }

        @Override
        protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
            return level.getBlockEntity(pos) instanceof ChecklistBlockEntity c && c.complete() ? 15 : 0;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openResort(4, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ test dummy

    public static class DummyBlock extends DecorBlocks.Facing {
        public DummyBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(LOCKED, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(LOCKED);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(LOCKED, false);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 3, 0, 3, 13, 16, 13);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean now = !s.getValue(LOCKED);
                level.setBlock(pos, s.setValue(LOCKED, now), 3);
                level.playSound(null, pos, now ? SoundEvents.IRON_TRAPDOOR_CLOSE : SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 0.9F, 0.8F);
                say(player, now ? "dummy_locked" : "dummy_released");
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ lift jack, grease station, tool wall, inspection pit

    public static class JackBlock extends DecorBlocks.Facing {
        public JackBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(RAISED, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(RAISED);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(RAISED, false);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 0, 2, 15, s.getValue(RAISED) ? 12 : 6, 14);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 1, 0, 2, 15, 6, 14);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean now = !s.getValue(RAISED);
                level.setBlock(pos, s.setValue(RAISED, now), 3);
                level.playSound(null, pos, SoundEvents.PISTON_EXTEND, SoundSource.BLOCKS, 0.6F, now ? 1.4F : 0.9F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    public static class GreaseBlock extends DecorBlocks.Facing {
        public GreaseBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 3, 0, 3, 13, 14, 13);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                level.playSound(null, pos, SoundEvents.SLIME_BLOCK_STEP, SoundSource.BLOCKS, 1.0F, 0.6F);
                say(player, "grease");
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    public static class ToolWallBlock extends DecorBlocks.Facing {
        public ToolWallBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 0, 0, 13, 16, 16, 16);
        }
    }

    public static class PitBlock extends Block {
        public PitBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Shapes.or(Block.box(0, 0, 0, 16, 1, 16), Block.box(0, 0, 0, 2, 8, 16), Block.box(14, 0, 0, 16, 8, 16),
                    Block.box(2, 0, 0, 14, 8, 2), Block.box(2, 0, 14, 14, 8, 16));
        }
    }
}
