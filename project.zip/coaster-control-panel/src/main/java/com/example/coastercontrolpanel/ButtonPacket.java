package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: a panel button was pressed (down = true) or released (down = false). */
public record ButtonPacket(BlockPos pos, int row, boolean down) implements CustomPacketPayload {
    public static final Type<ButtonPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "button"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ButtonPacket> CODEC =
            StreamCodec.of(ButtonPacket::write, ButtonPacket::read);

    private static void write(RegistryFriendlyByteBuf buf, ButtonPacket p) {
        buf.writeBlockPos(p.pos);
        buf.writeVarInt(p.row);
        buf.writeBoolean(p.down);
    }

    private static ButtonPacket read(RegistryFriendlyByteBuf buf) {
        return new ButtonPacket(buf.readBlockPos(), buf.readVarInt(), buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ButtonPacket packet, IPayloadContext context) {
        PanelBlockEntity panel = PanelBlockEntity.lookup(context.player(), packet.pos);
        if (panel == null) {
            return;
        }
        if (packet.down) {
            panel.buttonDown(packet.row, context.player());
        } else {
            panel.buttonUp(packet.row);
        }
    }
}
