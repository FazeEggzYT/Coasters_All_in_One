package com.example.coastercontrolpanel;

import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Client only: where the operator panel sits on screen and how big it is. Remembered in the config folder. */
public final class PanelLayout {
    public static final float MIN_SCALE = 0.5F;
    public static final float MAX_SCALE = 2.0F;

    /** Left edge of the panel in GUI pixels. */
    public static int x = 8;
    /** Top edge, or -1 for the default (sitting on the bottom of the screen). */
    public static int y = -1;
    public static float scale = 1.0F;

    static {
        load();
    }

    private PanelLayout() {
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("coastercontrolpanel_hud.properties");
    }

    private static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            return;
        }
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            x = Integer.parseInt(p.getProperty("x", "8"));
            y = Integer.parseInt(p.getProperty("y", "-1"));
            scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, Float.parseFloat(p.getProperty("scale", "1.0"))));
        } catch (IOException | RuntimeException e) {
            x = 8;
            y = -1;
            scale = 1.0F;
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(file())) {
            Properties p = new Properties();
            p.setProperty("x", Integer.toString(x));
            p.setProperty("y", Integer.toString(y));
            p.setProperty("scale", Float.toString(scale));
            p.store(out, "Operator panel position and size");
        } catch (IOException e) {
            CoasterControlPanel.LOGGER.warn("Could not save the panel position", e);
        }
    }

    public static void reset() {
        x = 8;
        y = -1;
        scale = 1.0F;
        save();
    }

    public static int width() {
        return Math.round(PanelRenderer.PANEL_W * scale);
    }

    public static int height(PanelBlockEntity p) {
        return Math.round(PanelRenderer.height(p) * scale);
    }

    public static int top(int guiH, PanelBlockEntity p) {
        return y < 0 ? guiH - 8 - height(p) : y;
    }

    /** Keeps the panel on screen. */
    public static void clamp(int guiW, int guiH, PanelBlockEntity p) {
        x = Math.max(0, Math.min(guiW - Math.min(width(), guiW), x));
        if (y >= 0) {
            y = Math.max(0, Math.min(guiH - Math.min(height(p), guiH), y));
        }
    }
}
