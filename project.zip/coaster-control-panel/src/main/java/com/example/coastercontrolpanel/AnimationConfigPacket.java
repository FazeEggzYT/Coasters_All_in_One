package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/** Client to server: the whole timeline from the Animation Controller screen, and what to do with it (0 nothing, 1 play, 2 stop). */
public record AnimationConfigPacket(BlockPos pos, int total, boolean loop, int command, List<AnimationControllerBlockEntity.Clip> clips)
        implements CustomPacketPayload {
    public static final Type<AnimationConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "animation_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AnimationConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.total);
                buf.writeBoolean(p.loop);
                buf.writeVarInt(p.command);
                buf.writeVarInt(p.clips.size());
                for (AnimationControllerBlockEntity.Clip c : p.clips) {
                    buf.writeVarInt(c.track());
                    buf.writeVarInt(c.anim());
                    buf.writeVarInt(c.start());
                    buf.writeVarInt(c.length());
                    buf.writeFloat(c.value());
                    buf.writeVarInt(c.ease());
                }
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                int total = buf.readVarInt();
                boolean loop = buf.readBoolean();
                int command = buf.readVarInt();
                int n = Math.min(buf.readVarInt(), AnimationControllerBlockEntity.MAX_CLIPS);
                List<AnimationControllerBlockEntity.Clip> clips = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    clips.add(new AnimationControllerBlockEntity.Clip(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readFloat(), buf.readVarInt()));
                }
                return new AnimationConfigPacket(pos, total, loop, command, clips);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(AnimationConfigPacket p, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 2304.0
                || !(player.getMainHandItem().getItem() instanceof WrenchItem)) {
            return;
        }
        if (player.level().getBlockEntity(p.pos) instanceof AnimationControllerBlockEntity be) {
            be.setTimeline(p.total, p.loop, p.clips);
            if (p.command == 1) {
                be.play();
            } else if (p.command == 2) {
                be.stop();
            }
        }
    }
}
