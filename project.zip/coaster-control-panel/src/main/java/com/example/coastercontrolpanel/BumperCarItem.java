package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Right-click the floor to put down a bumper car. */
public class BumperCarItem extends Item {
    public BumperCarItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        BlockPos at = context.getClickedPos().relative(context.getClickedFace() == Direction.UP ? Direction.UP : context.getClickedFace());
        BumperCarEntity car = new BumperCarEntity(CoasterControlPanel.BUMPER_CAR.get(), level);
        car.moveTo(at.getX() + 0.5, at.getY() + (context.getClickedFace() == Direction.UP ? 0.0 : 0.0), at.getZ() + 0.5,
                context.getRotation(), 0.0F);
        if (!level.noCollision(car, car.getBoundingBox())) {
            return InteractionResult.FAIL;
        }
        level.addFreshEntity(car);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
