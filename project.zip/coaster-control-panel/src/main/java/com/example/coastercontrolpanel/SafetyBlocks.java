package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * The First Aid and Safety pack: First Aid Station, Defibrillator Cabinet, Lost Child Point, Fire Extinguisher,
 * Emergency Exit Light, Emergency Phone Box and the Wheelchair and Pram Parking bay.
 */
public final class SafetyBlocks {
    private SafetyBlocks() {
    }

    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    public static final IntegerProperty BAY = IntegerProperty.create("bay", 0, 2);
    public static final int DEFIB_RADIUS = 12;

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    private static void broadcast(ServerPlayer from, Component text) {
        if (from.getServer() != null) {
            from.getServer().getPlayerList().broadcastSystemMessage(text, false);
        }
    }

    // ------------------------------------------------------------------ first aid station

    public static class FirstAidBlockEntity extends RestaurantBlocks.Syncing {
        public long readyAt;
        public int cooldownSec = 60;
        public int strength = 1;
        public boolean cure = true;
        public int treated;

        public FirstAidBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.FIRST_AID_BE.get(), pos, state);
        }

        public void treat(ServerPlayer p) {
            if (level == null) {
                return;
            }
            long now = level.getGameTime();
            if (now < readyAt) {
                say(p, "aid_wait", (readyAt - now + 19) / 20);
                return;
            }
            boolean hurt = p.getHealth() < p.getMaxHealth() - 0.01F;
            boolean sick = cure && (p.hasEffect(MobEffects.POISON) || p.hasEffect(MobEffects.WITHER) || p.hasEffect(MobEffects.WEAKNESS));
            if (!hurt && !sick && !p.isOnFire()) {
                say(p, "aid_healthy");
                return;
            }
            int seconds = 10 + strength * 5;
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, seconds * 20, strength));
            if (cure) {
                p.removeEffect(MobEffects.POISON);
                p.removeEffect(MobEffects.WITHER);
                p.removeEffect(MobEffects.WEAKNESS);
            }
            p.clearFire();
            readyAt = now + cooldownSec * 20L;
            treated++;
            level.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.0F, 1.2F);
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.6, p.getZ(), 5, 0.3, 0.3, 0.3, 0.0);
            }
            say(p, "aid_treated");
            changed();
        }

        public void changeCooldown(int d) {
            cooldownSec = Math.max(10, Math.min(300, cooldownSec + d));
            changed();
        }

        public void changeStrength(int d) {
            strength = Math.max(0, Math.min(2, strength + d));
            changed();
        }

        public void toggleCure() {
            cure = !cure;
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putLong("ReadyAt", readyAt);
            tag.putInt("Cooldown", cooldownSec);
            tag.putInt("Strength", strength);
            tag.putBoolean("Cure", cure);
            tag.putInt("Treated", treated);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            readyAt = tag.getLong("ReadyAt");
            cooldownSec = tag.contains("Cooldown") ? Math.max(10, tag.getInt("Cooldown")) : 60;
            strength = Math.max(0, Math.min(2, tag.getInt("Strength")));
            cure = !tag.contains("Cure") || tag.getBoolean("Cure");
            treated = tag.getInt("Treated");
        }
    }

    public static class FirstAidBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<FirstAidBlock> CODEC = simpleCodec(FirstAidBlock::new);

        public FirstAidBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 2, 0, 3, 14, 16, 13);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new FirstAidBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(10, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ defibrillator

    public static class DefibBlockEntity extends RestaurantBlocks.Syncing {
        public long readyAt;
        public int cooldownSec = 120;
        public int revived;

        public DefibBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.DEFIB_BE.get(), pos, state);
        }

        public boolean ready() {
            return level != null && level.getGameTime() >= readyAt;
        }

        public void revive(ServerPlayer p) {
            if (level == null) {
                return;
            }
            readyAt = level.getGameTime() + cooldownSec * 20L;
            revived++;
            p.setHealth(Math.min(p.getMaxHealth(), 8.0F));
            p.clearFire();
            p.setAirSupply(p.getMaxAirSupply());
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 1));
            shock(p.getX(), p.getY() + 1.0, p.getZ());
            broadcast(p, Component.translatable("message.coastercontrolpanel.defib_revived", p.getName()));
            changed();
        }

        public void shock(double x, double y, double z) {
            if (level == null) {
                return;
            }
            level.playSound(null, worldPosition, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.BLOCKS, 0.6F, 2.0F);
            level.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.8F);
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 30, 0.4, 0.6, 0.4, 0.3);
            }
        }

        public void test(ServerPlayer p) {
            if (!ready()) {
                say(p, "defib_charging", (readyAt - level.getGameTime() + 19) / 20);
                return;
            }
            shock(worldPosition.getX() + 0.5, worldPosition.getY() + 0.7, worldPosition.getZ() + 0.5);
            say(p, "defib_test");
        }

        public void changeCooldown(int d) {
            cooldownSec = Math.max(30, Math.min(600, cooldownSec + d));
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putLong("ReadyAt", readyAt);
            tag.putInt("Cooldown", cooldownSec);
            tag.putInt("Revived", revived);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            readyAt = tag.getLong("ReadyAt");
            cooldownSec = tag.contains("Cooldown") ? Math.max(30, tag.getInt("Cooldown")) : 120;
            revived = tag.getInt("Revived");
        }
    }

    /** Called when a player is about to die: a charged defibrillator within range brings them back. */
    public static boolean tryRevive(ServerPlayer p) {
        DefibBlockEntity be = GiftBlocks.nearest(p.level(), p.blockPosition(), DEFIB_RADIUS, DefibBlockEntity.class, DefibBlockEntity::ready);
        if (be == null) {
            return false;
        }
        be.revive(p);
        return true;
    }

    public static class DefibBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<DefibBlock> CODEC = simpleCodec(DefibBlock::new);

        public DefibBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 2, 2, 9, 14, 14, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new DefibBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(11, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ lost child point

    public static class ChildPointBlockEntity extends RestaurantBlocks.Syncing {
        public long until;
        @Nullable
        public UUID guard;

        public ChildPointBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.CHILD_POINT_BE.get(), pos, state);
        }

        public boolean active() {
            return level != null && level.getGameTime() < until;
        }

        public void call(ServerPlayer p) {
            if (!(level instanceof ServerLevel sl)) {
                return;
            }
            if (active()) {
                say(p, "child_already");
                return;
            }
            until = sl.getGameTime() + 20 * 180;
            BlockState st = getBlockState();
            sl.setBlock(worldPosition, st.setValue(LIT, true), 3);
            Direction f = st.getValue(DecorBlocks.FACING);
            BlockPos at = worldPosition.relative(f);
            IronGolem golem = EntityType.IRON_GOLEM.create(sl);
            if (golem != null) {
                golem.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, f.toYRot(), 0.0F);
                golem.setPlayerCreated(true);
                golem.setCustomName(Component.translatable("entity.coastercontrolpanel.park_guard"));
                golem.setPersistenceRequired();
                golem.restrictTo(worldPosition, 6);
                sl.addFreshEntity(golem);
                guard = golem.getUUID();
            }
            sl.playSound(null, worldPosition, SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, 1.5F, 0.8F);
            broadcast(p, Component.translatable("message.coastercontrolpanel.child_alert", p.getName(),
                    worldPosition.getX(), worldPosition.getY(), worldPosition.getZ()));
            changed();
        }

        public void found(@Nullable ServerPlayer p) {
            if (!(level instanceof ServerLevel sl)) {
                return;
            }
            until = 0;
            BlockState st = getBlockState();
            if (st.hasProperty(LIT) && st.getValue(LIT)) {
                sl.setBlock(worldPosition, st.setValue(LIT, false), 3);
            }
            if (guard != null) {
                net.minecraft.world.entity.Entity e = sl.getEntity(guard);
                if (e != null) {
                    e.discard();
                }
                guard = null;
            }
            if (p != null) {
                broadcast(p, Component.translatable("message.coastercontrolpanel.child_found", p.getName()));
            }
            changed();
        }

        public void serverTick() {
            if (level == null || level.getGameTime() % 20 != 7) {
                return;
            }
            BlockState st = getBlockState();
            if (st.hasProperty(LIT) && st.getValue(LIT) && !active()) {
                found(null);
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putLong("Until", until);
            if (guard != null) {
                tag.putUUID("Guard", guard);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            until = tag.getLong("Until");
            guard = tag.hasUUID("Guard") ? tag.getUUID("Guard") : null;
        }
    }

    public static class ChildPointBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<ChildPointBlock> CODEC = simpleCodec(ChildPointBlock::new);

        public ChildPointBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(LIT, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(LIT);
        }

        @Override
        public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(LIT, false);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 5, 0, 5, 11, 16, 11);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ChildPointBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.CHILD_POINT_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(12, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ fire extinguisher

    public static class ExtinguisherBlockEntity extends RestaurantBlocks.Syncing {
        public static final int MAX = 6;
        public int charges = MAX;

        public ExtinguisherBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.EXTINGUISHER_BE.get(), pos, state);
        }

        /** Puts out fire blocks and burning mobs nearby. Returns true if it used a charge. */
        public boolean spray(int radius) {
            if (!(level instanceof ServerLevel sl) || charges <= 0) {
                return false;
            }
            boolean any = false;
            for (BlockPos q : BlockPos.betweenClosed(worldPosition.offset(-radius, -2, -radius), worldPosition.offset(radius, 3, radius))) {
                if (sl.getBlockState(q).getBlock() instanceof BaseFireBlock) {
                    sl.removeBlock(q, false);
                    sl.sendParticles(ParticleTypes.CLOUD, q.getX() + 0.5, q.getY() + 0.4, q.getZ() + 0.5, 6, 0.2, 0.2, 0.2, 0.02);
                    any = true;
                }
            }
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(worldPosition).inflate(radius), LivingEntity::isOnFire)) {
                e.clearFire();
                sl.sendParticles(ParticleTypes.CLOUD, e.getX(), e.getY() + 1.0, e.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
                any = true;
            }
            if (any) {
                charges--;
                sl.playSound(null, worldPosition, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 1.0F, 0.9F);
                sl.playSound(null, worldPosition, SoundEvents.PHANTOM_FLAP, SoundSource.BLOCKS, 0.6F, 0.5F);
                changed();
            }
            return any;
        }

        public void serverTick() {
            if (level != null && level.getGameTime() % 20 == 11 && charges > 0) {
                spray(4);
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Charges", charges);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            charges = tag.contains("Charges") ? Math.max(0, Math.min(MAX, tag.getInt("Charges"))) : MAX;
        }
    }

    public static class ExtinguisherBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<ExtinguisherBlock> CODEC = simpleCodec(ExtinguisherBlock::new);

        public ExtinguisherBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 5, 0, 8, 11, 11, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ExtinguisherBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.EXTINGUISHER_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.WATER_BUCKET)) {
                if (!level.isClientSide && level.getBlockEntity(pos) instanceof ExtinguisherBlockEntity be) {
                    be.charges = ExtinguisherBlockEntity.MAX;
                    be.changed();
                    level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
                    say(player, "ext_refilled", ExtinguisherBlockEntity.MAX);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof ExtinguisherBlockEntity be) {
                if (!be.spray(6)) {
                    say(player, be.charges <= 0 ? "ext_empty" : "ext_ready", be.charges);
                } else {
                    say(player, "ext_used", be.charges);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ exit light

    public static class ExitLightBlock extends DecorBlocks.Facing {
        public ExitLightBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 1, 5, 13, 15, 11, 16);
        }
    }

    // ------------------------------------------------------------------ emergency phone

    public static class PhoneBlockEntity extends RestaurantBlocks.Syncing {
        public long litUntil;
        public long calmAt;

        public PhoneBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PHONE_BE.get(), pos, state);
        }

        public void call(ServerPlayer p, int reason) {
            if (!(level instanceof ServerLevel sl)) {
                return;
            }
            long now = sl.getGameTime();
            if (now < calmAt) {
                say(p, "phone_wait");
                return;
            }
            int r = Math.max(0, Math.min(3, reason));
            calmAt = now + 100;
            litUntil = now + 300;
            BlockState st = getBlockState();
            sl.setBlock(worldPosition, st.setValue(LIT, true), 3);
            sl.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.5F, 0.7F);
            broadcast(p, Component.translatable("message.coastercontrolpanel.phone_alert", p.getName(),
                    Component.translatable("gui.coastercontrolpanel.phone_reason_" + r),
                    worldPosition.getX(), worldPosition.getY(), worldPosition.getZ()));
            say(p, "phone_sent");
            changed();
        }

        public void serverTick() {
            if (level == null || level.getGameTime() % 10 != 5) {
                return;
            }
            BlockState st = getBlockState();
            if (st.hasProperty(LIT) && st.getValue(LIT) && level.getGameTime() >= litUntil) {
                level.setBlock(worldPosition, st.setValue(LIT, false), 3);
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putLong("LitUntil", litUntil);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            litUntil = tag.getLong("LitUntil");
        }
    }

    public static class PhoneBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<PhoneBlock> CODEC = simpleCodec(PhoneBlock::new);

        public PhoneBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(LIT, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(LIT);
        }

        @Override
        public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(LIT, false);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 2, 0, 2, 14, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PhoneBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.PHONE_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(13, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ wheelchair and pram bay

    public static class BayBlock extends DecorBlocks.Facing {
        public BayBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(BAY, 0));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(BAY);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(0, 0, 0, 16, 1, 16);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            int next = (s.getValue(BAY) + 1) % 3;
            level.setBlock(pos, s.setValue(BAY, next), 3);
            level.playSound(null, pos, SoundEvents.CHAIN_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
            say(player, "bay_" + next);
            return InteractionResult.CONSUME;
        }
    }
}
