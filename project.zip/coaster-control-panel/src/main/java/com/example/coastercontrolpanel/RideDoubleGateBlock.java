package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * A ride gate with two small leaves in one block. It is a normal ride gate in every way (same block entity,
 * Redstone Link, delay, wrench menu, swing animation, opening together with gates beside it), but it draws both
 * leaves, meeting in the middle, and never pairs with neighbours as a half of a double.
 */
public class RideDoubleGateBlock extends RideGateBlock {
    public RideDoubleGateBlock(Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return state;
    }
}
