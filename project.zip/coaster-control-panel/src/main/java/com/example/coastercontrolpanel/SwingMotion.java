package com.example.coastercontrolpanel;

/**
 * The movement of a Swing Ride, free of any Minecraft types so it can be checked on its own.
 * The arm swings as theta = amplitude * sin(phase) degrees; the sequence changes the amplitude and the gondola spin.
 * Pausing and ending wind the amplitude down smoothly (the arm comes to rest at the bottom); an emergency halt slows
 * the swinging itself to a stop.
 */
public final class SwingMotion {
    public static final int IDLE = 0;
    public static final int COUNTDOWN = 1;
    public static final int RUNNING = 2;
    public static final int PAUSED = 3;
    public static final int ENDING = 4;
    public static final int HALTED = 5;

    private static final double SPIN_ACCEL = 45.0;   // degrees per second squared
    private static final double SPIN_DECAY = 90.0;
    private static final double SETTLE_SPEED = 60.0;  // degrees per second, when easing the spin angle back to a whole turn

    public int phase = IDLE;
    public int stepIndex;
    public int loop;
    public double stepTime;
    /** Swing phase in radians. */
    public double phi;
    /** Swing amplitude in degrees. */
    public double amp;
    /** 0..1 speed of the swinging (an emergency halt takes it to 0). */
    public double rateFactor = 1.0;
    public double spinRate;
    public double spinTarget;
    /** Gondola spin angle in degrees. */
    public double spin;
    /** True: the arm only lifts up from rest (theta = amp * (1 - cos) / 2) instead of swinging both ways. */
    public boolean lift;
    public boolean finished;
    public boolean landed;
    /** The period of one full swing, seconds; set at the start. */
    public double period = 5.0;

    private double stepStartAmp;
    private double stepStartPhi;
    private double decay;

    public static double autoPeriod(double armLength) {
        return Math.max(3.0, Math.min(9.0, 2.0 * Math.PI * Math.sqrt(Math.max(1.0, armLength) / 9.8)));
    }

    public void start(double periodSeconds) {
        phase = RUNNING;
        stepIndex = 0;
        loop = 0;
        stepTime = 0;
        phi = 0;
        amp = 0;
        rateFactor = 1.0;
        spinRate = 0;
        spinTarget = 0;
        spin = 0;
        finished = false;
        landed = false;
        period = Math.max(1.0, periodSeconds);
        beginStep();
    }

    public double theta() {
        return lift ? amp * (1.0 - Math.cos(phi)) * 0.5 : amp * Math.sin(phi);
    }

    private void beginStep() {
        stepTime = 0;
        stepStartAmp = amp;
        stepStartPhi = phi;
    }

    public void togglePause() {
        if (phase == RUNNING) {
            phase = PAUSED;
            decay = Math.max(15.0, amp) / (2.0 * period);
        } else if (phase == PAUSED && !finished) {
            phase = RUNNING;
            beginStepKeepProgress();
        } else if (phase == HALTED) {
            phase = RUNNING;
            rateFactor = Math.max(rateFactor, 0.05);
            beginStepKeepProgress();
        }
    }

    private void beginStepKeepProgress() {
        stepStartAmp = amp;
        stepStartPhi = phi;
        stepTime = 0;
    }

    /** After a world reload a running ride comes back paused, winding down. */
    public void restoreAfterLoad(SwingSettings c) {
        if (phase == RUNNING) {
            phase = PAUSED;
            decay = Math.max(15.0, amp) / (Math.max(1.0, c.windDown) * period);
        } else if (phase == COUNTDOWN) {
            phase = IDLE;
        }
        if (phase == PAUSED || phase == HALTED || phase == ENDING) {
            decay = Math.max(15.0, amp) / (Math.max(1.0, c.windDown) * period);
        }
    }

    public void halt() {
        if (phase == RUNNING || phase == PAUSED || phase == ENDING) {
            phase = HALTED;
            finished = false;
        }
    }

    public void end(SwingSettings c) {
        if (phase == RUNNING || phase == PAUSED || phase == HALTED) {
            phase = ENDING;
            finished = false;
            rateFactor = Math.max(rateFactor, 0.2);
            decay = Math.max(15.0, amp) / (Math.max(1.0, c.windDown) * period);
        }
    }

    private void nextStep(SwingSettings c) {
        stepIndex++;
        if (stepIndex >= c.steps.size()) {
            loop++;
            stepIndex = 0;
            if (loop >= c.loops) {
                if (c.endMode == 0) {
                    end(c);
                    phase = ENDING;
                } else {
                    phase = PAUSED;
                    finished = true;
                    decay = Math.max(15.0, amp) / (Math.max(1.0, c.windDown) * period);
                }
                return;
            }
        }
        beginStep();
    }

    public void tick(SwingSettings c, double dt) {
        double w0 = 2.0 * Math.PI / period;
        switch (phase) {
            case RUNNING -> {
                phi += w0 * dt;
                runStep(c, dt);
            }
            case PAUSED -> {
                phi += w0 * dt;
                amp = Math.max(0.0, amp - decay * dt);
                spinTarget = 0;
                chaseSpin(dt, SPIN_DECAY);
            }
            case HALTED -> {
                rateFactor = Math.max(0.0, rateFactor - dt / Math.max(0.3, c.haltTime));
                phi += w0 * rateFactor * dt;
                spinTarget = 0;
                chaseSpin(dt, SPIN_DECAY * 2);
            }
            case ENDING -> {
                phi += w0 * Math.max(rateFactor, 0.2) * dt;
                amp = Math.max(0.0, amp - decay * dt);
                spinTarget = 0;
                chaseSpin(dt, SPIN_DECAY);
                if (amp <= 0.0 && Math.abs(spinRate) < 0.5) {
                    double goal = Math.rint(spin / 360.0) * 360.0;
                    double d = goal - spin;
                    double step = SETTLE_SPEED * dt;
                    if (Math.abs(d) <= step) {
                        spin = 0;
                        phi = 0;
                        landed = true;
                        phase = IDLE;
                    } else {
                        spin += Math.signum(d) * step;
                    }
                }
            }
            default -> {
            }
        }
        spin += spinRate * dt;
    }

    private void chaseSpin(double dt, double accel) {
        double d = spinTarget - spinRate;
        double step = accel * dt;
        spinRate = Math.abs(d) <= step ? spinTarget : spinRate + Math.signum(d) * step;
    }

    private void runStep(SwingSettings c, double dt) {
        if (c.steps.isEmpty()) {
            nextStep(c);
            return;
        }
        SwingSettings.Step s = c.steps.get(Math.min(stepIndex, c.steps.size() - 1));
        stepTime += dt;
        switch (s.type) {
            case SwingSettings.SWING -> {
                double target = Math.min(s.a, c.limit);
                double p = Math.min(1.0, (phi - stepStartPhi) / (2.0 * Math.PI * s.b));
                double desired = stepStartAmp + (target - stepStartAmp) * p;
                double limitRate = 150.0 / period;
                double d = desired - amp;
                amp += Math.max(-limitRate * dt, Math.min(limitRate * dt, d));
                chaseSpin(dt, SPIN_ACCEL);
                if (p >= 1.0) {
                    amp = target;
                    nextStep(c);
                }
            }
            case SwingSettings.SPIN -> {
                spinTarget = s.a * 6.0; // turns per minute to degrees per second
                chaseSpin(dt, SPIN_ACCEL);
                if (stepTime >= s.b) {
                    nextStep(c);
                }
            }
            default -> {
                double rate = Math.max(15.0, stepStartAmp) / (2.0 * period);
                amp = Math.max(0.0, amp - rate * dt);
                spinTarget = 0;
                chaseSpin(dt, SPIN_DECAY);
                if (stepTime >= s.a && amp <= 0.0) {
                    nextStep(c);
                }
            }
        }
    }
}
