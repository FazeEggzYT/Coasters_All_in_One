package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** The screens of the Arcade pack. The mini-games run here on the client; the server checks and caps the result. */
public final class ArcadeScreens {
    private ArcadeScreens() {
    }

    public static Screen forGame(ArcadeGame game, BlockPos pos) {
        return switch (game) {
            case CABINET -> new CabinetScreen(pos);
            case CLAW -> new ClawScreen(pos);
            case MOLE -> new MoleScreen(pos);
            case STRENGTH -> new StrengthScreen(pos);
            case HOOPS -> new HoopsScreen(pos);
            case GALLERY -> new GalleryScreen(pos);
            case RINGS -> new RingsScreen(pos);
            case COCONUT -> new CoconutScreen(pos);
        };
    }

    // ------------------------------------------------------------------ shared base

    abstract static class Base extends Screen {
        protected final BlockPos pos;
        protected final int w;
        protected final int h;
        protected int left;
        protected int top;

        protected Base(Component title, BlockPos pos, int w, int h) {
            super(title);
            this.pos = pos;
            this.w = w;
            this.h = h;
        }

        @Override
        protected void init() {
            left = (width - w) / 2;
            top = (height - h) / 2;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                    .bounds(left + w - 52, top + h - 22, 44, 16).build());
            build();
        }

        protected abstract void build();

        protected void act(int action, int a, int b) {
            PacketDistributor.sendToServer(new ArcadeActionPacket(pos, action, a, b));
        }

        @Override
        public boolean isPauseScreen() {
            return false;
        }

        @Override
        public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            renderTransparentBackground(g);
            g.fill(left, top, left + w, top + h, 0xFF3A3E4D);
            g.fill(left + 1, top + 1, left + w - 1, top + h - 1, 0xFF1B1D24);
            g.drawString(font, title, left + 8, top + 7, 0xFFFFFF, false);
        }

        protected int tokens() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player == null ? 0 : ArcadeBlocks.count(mc.player, CoasterControlPanel.ARCADE_TOKEN.get());
        }

        protected boolean creative() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player != null && mc.player.getAbilities().instabuild;
        }
    }

    // ------------------------------------------------------------------ token machine

    public static class TokenScreen extends Base {
        private boolean setup;
        private final List<Button> setupButtons = new ArrayList<>();
        private final List<Button> playButtons = new ArrayList<>();

        public TokenScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.token_machine"), pos, 230, 130);
        }

        private ArcadeBlocks.TokenBlockEntity be() {
            return minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof ArcadeBlocks.TokenBlockEntity t ? t : null;
        }

        @Override
        protected void build() {
            setupButtons.clear();
            playButtons.clear();
            playButtons.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.token_1"), b -> act(10, 1, 0))
                    .bounds(left + 8, top + 62, 66, 16).build()));
            playButtons.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.token_8"), b -> act(10, 8, 0))
                    .bounds(left + 78, top + 62, 66, 16).build()));
            playButtons.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.token_all"), b -> act(10, 0, 0))
                    .bounds(left + 148, top + 62, 74, 16).build()));
            setupButtons.add(addRenderableWidget(Button.builder(Component.literal("-"), b -> act(11, -1, 0))
                    .bounds(left + 8, top + 62, 20, 16).build()));
            setupButtons.add(addRenderableWidget(Button.builder(Component.literal("+"), b -> act(11, 1, 0))
                    .bounds(left + 32, top + 62, 20, 16).build()));
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> {
                setup = !setup;
                refresh();
            }).bounds(left + 8, top + h - 22, 70, 16).build());
            refresh();
        }

        private void refresh() {
            for (Button b : setupButtons) {
                b.visible = setup;
            }
            for (Button b : playButtons) {
                b.visible = !setup;
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            ArcadeBlocks.TokenBlockEntity be = be();
            int rate = be == null ? 2 : be.rate;
            int nuggets = minecraft == null || minecraft.player == null ? 0 : ArcadeBlocks.count(minecraft.player, Items.GOLD_NUGGET);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.token_rate", rate), left + 8, top + 24, 0xFFE070, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.token_have", nuggets, tokens()), left + 8, top + 38, 0xC8C8D8, false);
            g.drawString(font, Component.translatable(setup ? "gui.coastercontrolpanel.token_help_setup" : "gui.coastercontrolpanel.token_help"),
                    left + 8, top + 86, 0x8A8FA3, false);
            g.renderItem(new ItemStack(Items.GOLD_NUGGET), left + w - 26, top + 22);
            g.renderItem(new ItemStack(CoasterControlPanel.ARCADE_TOKEN.get()), left + w - 26, top + 40);
        }
    }

    // ------------------------------------------------------------------ prize counter

    public static class PrizeScreen extends Base {
        private boolean setup;
        private final Button[] buy = new Button[ArcadeBlocks.PrizeBlockEntity.SLOTS];
        private final Button[] minus = new Button[ArcadeBlocks.PrizeBlockEntity.SLOTS];
        private final Button[] plus = new Button[ArcadeBlocks.PrizeBlockEntity.SLOTS];
        private final Button[] remove = new Button[ArcadeBlocks.PrizeBlockEntity.SLOTS];

        public PrizeScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.prize_counter"), pos, 250, 212);
        }

        private ArcadeBlocks.PrizeBlockEntity be() {
            return minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof ArcadeBlocks.PrizeBlockEntity t ? t : null;
        }

        @Override
        protected void build() {
            for (int i = 0; i < ArcadeBlocks.PrizeBlockEntity.SLOTS; i++) {
                final int row = i;
                int y = top + 34 + i * 22;
                buy[i] = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.prize_buy"), b -> act(20, row, 0))
                        .bounds(left + w - 56, y, 48, 16).build());
                minus[i] = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(21, row, -1))
                        .bounds(left + 150, y, 18, 16).build());
                plus[i] = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(21, row, 1))
                        .bounds(left + 190, y, 18, 16).build());
                remove[i] = addRenderableWidget(Button.builder(Component.literal("x"), b -> act(22, row, 0))
                        .bounds(left + 212, y, 18, 16).build());
            }
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup)
                    .bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            ArcadeBlocks.PrizeBlockEntity be = be();
            for (int i = 0; i < buy.length; i++) {
                boolean has = be != null && !be.offers[i].isEmpty();
                buy[i].visible = has && !setup;
                minus[i].visible = has && setup;
                plus[i].visible = has && setup;
                remove[i].visible = has && setup;
            }
            super.render(g, mx, my, pt);
            int tickets = minecraft == null || minecraft.player == null ? 0
                    : ArcadeBlocks.count(minecraft.player, CoasterControlPanel.PRIZE_TICKET.get());
            g.renderItem(new ItemStack(CoasterControlPanel.PRIZE_TICKET.get()), left + 8, top + 17);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.prize_tickets", tickets), left + 28, top + 21, 0xFFE070, false);
            for (int i = 0; i < buy.length; i++) {
                int y = top + 34 + i * 22;
                if (be == null || be.offers[i].isEmpty()) {
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.kiosk_empty"), left + 30, y + 4, 0x5A5F73, false);
                    continue;
                }
                g.renderItem(be.offers[i], left + 8, y);
                String name = be.offers[i].getHoverName().getString();
                if (name.length() > 17) {
                    name = name.substring(0, 16) + "…";
                }
                g.drawString(font, name, left + 30, y + 4, 0xFFFFFF, false);
                int px = setup ? left + 172 : left + 148;
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.prize_price", be.prices[i]), px, y + 4, 0xFFE070, false);
            }
            g.drawString(font, Component.translatable(setup ? "gui.coastercontrolpanel.prize_help_setup" : "gui.coastercontrolpanel.prize_help"),
                    left + 8, top + h - 40, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ the game base

    abstract static class GameScreen extends Base {
        static final int AX = 10;
        static final int AY = 22;
        static final int AW = 200;
        static final int AH = 120;
        protected static final Random RND = new Random();

        protected final ArcadeGame game;
        protected int phase;
        protected int sub;
        protected int ticks;
        protected int waitTicks;
        protected int score;
        protected Component note = Component.empty();
        protected final List<Button> startButtons = new ArrayList<>();

        protected GameScreen(ArcadeGame game, BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel." + game.id), pos, 220, 196);
            this.game = game;
        }

        protected ArcadeBlocks.ArcadeBlockEntity be() {
            return minecraft != null && minecraft.level != null
                    && minecraft.level.getBlockEntity(pos) instanceof ArcadeBlocks.ArcadeBlockEntity t ? t : null;
        }

        /** Names of the start buttons. One button for most machines. */
        protected String[] startNames() {
            return new String[]{"gui.coastercontrolpanel.arcade_play"};
        }

        @Override
        protected void build() {
            startButtons.clear();
            String[] names = startNames();
            int bw = names.length == 1 ? 90 : 48;
            for (int i = 0; i < names.length; i++) {
                final int idx = i;
                startButtons.add(addRenderableWidget(Button.builder(Component.translatable(names[i]), b -> startGame(idx))
                        .bounds(left + 8 + i * (bw + 8), top + h - 22, bw, 16).build()));
            }
        }

        protected void startGame(int s) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            if (!creative() && tokens() < 1) {
                note = Component.translatable("message.coastercontrolpanel.arcade_no_token");
                return;
            }
            ArcadeBlocks.ArcadeBlockEntity be = be();
            if (be != null && be.sessionActive(null) && !be.sessionActive(mc.player)) {
                note = Component.translatable("message.coastercontrolpanel.arcade_busy");
                return;
            }
            sub = s;
            phase = 1;
            waitTicks = 0;
            note = Component.empty();
            act(0, s, 0);
        }

        protected void finish(int s, int extra) {
            phase = 3;
            score = s;
            int tickets = game.tickets(sub, Math.min(game.maxScore(sub), s));
            note = Component.translatable("gui.coastercontrolpanel.arcade_done", s, tickets);
            act(1, s, extra);
        }

        protected abstract void begin();

        protected abstract void gameTick();

        protected abstract void drawGame(GuiGraphics g, int ax, int ay, int mx, int my);

        protected boolean click(int mx, int my) {
            return false;
        }

        protected boolean key(int keyCode) {
            return false;
        }

        protected Component hint() {
            return Component.translatable("gui.coastercontrolpanel.arcade_hint_" + game.id);
        }

        @Override
        public void tick() {
            super.tick();
            Minecraft mc = Minecraft.getInstance();
            if (phase == 1) {
                waitTicks++;
                ArcadeBlocks.ArcadeBlockEntity be = be();
                if (be != null && mc.player != null && be.sessionActive(mc.player)) {
                    phase = 2;
                    ticks = 0;
                    begin();
                } else if (waitTicks > 40) {
                    phase = 0;
                    note = Component.translatable("message.coastercontrolpanel.arcade_no_token");
                }
            } else if (phase == 2) {
                ticks++;
                gameTick();
            }
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (super.mouseClicked(mx, my, button)) {
                return true;
            }
            if (phase == 2 && mx >= left + AX && mx < left + AX + AW && my >= top + AY && my < top + AY + AH) {
                return click((int) mx - left - AX, (int) my - top - AY);
            }
            return false;
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
            if (phase == 2 && key(keyCode)) {
                return true;
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            for (Button b : startButtons) {
                b.visible = phase == 0 || phase == 3;
            }
            super.render(g, mx, my, pt);
            int ax = left + AX;
            int ay = top + AY;
            g.fill(ax - 1, ay - 1, ax + AW + 1, ay + AH + 1, 0xFF50566B);
            g.fill(ax, ay, ax + AW, ay + AH, 0xFF0B0D12);
            g.enableScissor(ax, ay, ax + AW, ay + AH);
            if (phase == 2) {
                drawGame(g, ax, ay, mx - ax, my - ay);
            } else if (phase == 1) {
                g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.arcade_wait"), ax + AW / 2, ay + AH / 2 - 4, 0xFFE070);
            } else {
                drawIdle(g, ax, ay);
            }
            g.disableScissor();
            g.drawString(font, note, left + 8, top + AY + AH + 6, 0xFFE070, false);
            g.drawString(font, hint(), left + 8, top + AY + AH + 18, 0x8A8FA3, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_tokens", tokens()), left + 8, top + h - 40, 0xC8C8D8, false);
        }

        protected void drawIdle(GuiGraphics g, int ax, int ay) {
            ArcadeBlocks.ArcadeBlockEntity be = be();
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.arcade_cost"), ax + AW / 2, ay + 8, 0xFFE070);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_highscores"), ax + 8, ay + 30, 0xFFFFFF, false);
            String[] names = startNames();
            int rows = game == ArcadeGame.CABINET ? 3 : 1;
            for (int i = 0; i < rows; i++) {
                int hs = be == null ? 0 : be.highs[i];
                String who = be == null || be.highNames[i].isEmpty() ? "-" : be.highNames[i];
                Component label = rows == 1 ? Component.empty() : Component.translatable(names[i]);
                g.drawString(font, label, ax + 8, ay + 44 + i * 12, 0xC8C8D8, false);
                g.drawString(font, hs + "  (" + who + ")", ax + 70, ay + 44 + i * 12, 0x7CFFB0, false);
            }
            if (phase == 3) {
                g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + AW / 2, ay + 92, 0x7CFFB0);
            }
        }
    }

    // ------------------------------------------------------------------ cabinet: snake, memory, reaction

    static class CabinetScreen extends GameScreen {
        private static final int CELL = 8;
        private static final int GW = 25;
        private static final int GH = 15;
        private final int[] sx = new int[GW * GH + 2];
        private final int[] sy = new int[GW * GH + 2];
        private int len;
        private int dir;
        private int nextDir;
        private int appleX;
        private int appleY;
        private int eaten;
        private int step;
        private final int[] cards = new int[12];
        private final boolean[] shown = new boolean[12];
        private final boolean[] matched = new boolean[12];
        private int first = -1;
        private int second = -1;
        private int flip;
        private int misses;
        private int pairs;
        private int round;
        private int state;
        private int waitT;
        private int t0;
        private int total;
        private int pause;
        private String msg = "";
        private static final int[] COLS = {0xFFE05050, 0xFF50C878, 0xFF5090E0, 0xFFE0C040, 0xFFB060E0, 0xFF40D0D0};
        private static final int[] DX = {0, 1, 0, -1};
        private static final int[] DY = {-1, 0, 1, 0};

        CabinetScreen(BlockPos pos) {
            super(ArcadeGame.CABINET, pos);
        }

        @Override
        protected String[] startNames() {
            return new String[]{"gui.coastercontrolpanel.cab_snake", "gui.coastercontrolpanel.cab_memory", "gui.coastercontrolpanel.cab_reaction"};
        }

        @Override
        protected Component hint() {
            return Component.translatable("gui.coastercontrolpanel.arcade_hint_cabinet_" + sub);
        }

        private void placeApple() {
            for (int tries = 0; tries < 200; tries++) {
                int x = RND.nextInt(GW);
                int y = RND.nextInt(GH);
                boolean free = true;
                for (int i = 0; i < len; i++) {
                    if (sx[i] == x && sy[i] == y) {
                        free = false;
                        break;
                    }
                }
                if (free) {
                    appleX = x;
                    appleY = y;
                    return;
                }
            }
        }

        @Override
        protected void begin() {
            if (sub == 0) {
                len = 3;
                for (int i = 0; i < len; i++) {
                    sx[i] = 10 - i;
                    sy[i] = 7;
                }
                dir = 1;
                nextDir = 1;
                eaten = 0;
                step = 0;
                placeApple();
            } else if (sub == 1) {
                for (int i = 0; i < 12; i++) {
                    cards[i] = i / 2;
                    shown[i] = false;
                    matched[i] = false;
                }
                for (int i = 11; i > 0; i--) {
                    int j = RND.nextInt(i + 1);
                    int t = cards[i];
                    cards[i] = cards[j];
                    cards[j] = t;
                }
                first = -1;
                second = -1;
                flip = 0;
                misses = 0;
                pairs = 0;
            } else {
                round = 0;
                total = 0;
                state = 0;
                waitT = 20 + RND.nextInt(60);
                msg = "";
            }
        }

        @Override
        protected void gameTick() {
            if (sub == 0) {
                if (ticks > 1200) {
                    finish(eaten, 0);
                    return;
                }
                if (++step >= 3) {
                    step = 0;
                    dir = nextDir;
                    int nx = sx[0] + DX[dir];
                    int ny = sy[0] + DY[dir];
                    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) {
                        finish(eaten, 0);
                        return;
                    }
                    for (int i = 0; i < len - 1; i++) {
                        if (sx[i] == nx && sy[i] == ny) {
                            finish(eaten, 0);
                            return;
                        }
                    }
                    boolean grow = nx == appleX && ny == appleY;
                    if (grow && len < sx.length - 1) {
                        len++;
                    }
                    for (int i = len - 1; i >= 1; i--) {
                        sx[i] = sx[i - 1];
                        sy[i] = sy[i - 1];
                    }
                    sx[0] = nx;
                    sy[0] = ny;
                    if (grow) {
                        eaten++;
                        placeApple();
                    }
                }
            } else if (sub == 1) {
                if (flip > 0 && --flip == 0 && first >= 0 && second >= 0) {
                    if (cards[first] == cards[second]) {
                        matched[first] = true;
                        matched[second] = true;
                        pairs++;
                    } else {
                        shown[first] = false;
                        shown[second] = false;
                        misses++;
                    }
                    first = -1;
                    second = -1;
                    if (pairs == 6) {
                        finish(Math.max(0, 12 - misses), 0);
                        return;
                    }
                }
                if (ticks > 1200) {
                    finish(pairs, 0);
                }
            } else {
                if (state == 0) {
                    if (--waitT <= 0) {
                        state = 1;
                        t0 = ticks;
                    }
                } else if (state == 2 && --pause <= 0) {
                    round++;
                    if (round >= 5) {
                        finish(Math.min(60, total), 0);
                    } else {
                        state = 0;
                        waitT = 20 + RND.nextInt(60);
                    }
                }
            }
        }

        @Override
        protected boolean key(int k) {
            if (sub != 0) {
                return false;
            }
            int d = switch (k) {
                case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W -> 0;
                case GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> 1;
                case GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S -> 2;
                case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> 3;
                default -> -1;
            };
            if (d < 0) {
                return false;
            }
            if (d != (dir + 2) % 4) {
                nextDir = d;
            }
            return true;
        }

        @Override
        protected boolean click(int mx, int my) {
            if (sub == 1) {
                if (flip > 0) {
                    return true;
                }
                for (int i = 0; i < 12; i++) {
                    int cx = 8 + (i % 4) * 48;
                    int cy = 1 + (i / 4) * 42;
                    if (mx >= cx && mx < cx + 40 && my >= cy && my < cy + 34 && !shown[i] && !matched[i]) {
                        shown[i] = true;
                        if (first < 0) {
                            first = i;
                        } else {
                            second = i;
                            flip = 15;
                        }
                        return true;
                    }
                }
            } else if (sub == 2) {
                if (state == 0) {
                    msg = Component.translatable("gui.coastercontrolpanel.cab_early").getString();
                    state = 2;
                    pause = 30;
                } else if (state == 1) {
                    int ms = (ticks - t0) * 50;
                    int rs = Math.max(0, Math.min(12, 12 - ms / 50));
                    total += rs;
                    msg = ms + " ms  (+" + rs + ")";
                    state = 2;
                    pause = 30;
                }
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            int left = (1200 - ticks) / 20;
            g.drawString(font, "" + Math.max(0, left), ax + AW - 18, ay + 3, 0x8A8FA3, false);
            if (sub == 0) {
                for (int i = 0; i < len; i++) {
                    int c = i == 0 ? 0xFFA0FF90 : 0xFF40B040;
                    g.fill(ax + sx[i] * CELL, ay + sy[i] * CELL, ax + sx[i] * CELL + CELL - 1, ay + sy[i] * CELL + CELL - 1, c);
                }
                g.fill(ax + appleX * CELL + 1, ay + appleY * CELL + 1, ax + appleX * CELL + CELL - 1, ay + appleY * CELL + CELL - 1, 0xFFE04040);
                g.drawString(font, "" + eaten, ax + 3, ay + 3, 0xFFFFFF, false);
            } else if (sub == 1) {
                for (int i = 0; i < 12; i++) {
                    int cx = ax + 8 + (i % 4) * 48;
                    int cy = ay + 1 + (i / 4) * 42;
                    boolean up = shown[i] || matched[i];
                    g.fill(cx, cy, cx + 40, cy + 34, up ? COLS[cards[i]] : 0xFF2A3A6A);
                    g.fill(cx + 1, cy + 1, cx + 39, cy + 33, up ? COLS[cards[i]] & 0xFFE0E0E0 : 0xFF34488A);
                    if (up) {
                        g.drawCenteredString(font, "" + (char) ('A' + cards[i]), cx + 20, cy + 13, 0xFFFFFF);
                    } else {
                        g.drawCenteredString(font, "?", cx + 20, cy + 13, 0xFFA0B0E0);
                    }
                }
            } else {
                int c = state == 0 ? 0xFFB02020 : state == 1 ? 0xFF20B040 : 0xFF303848;
                g.fill(ax + 10, ay + 10, ax + AW - 10, ay + AH - 20, c);
                String t = state == 0 ? Component.translatable("gui.coastercontrolpanel.cab_wait").getString()
                        : state == 1 ? Component.translatable("gui.coastercontrolpanel.cab_go").getString() : msg;
                g.drawCenteredString(font, t, ax + AW / 2, ay + AH / 2 - 14, 0xFFFFFF);
                g.drawCenteredString(font, (round + 1) + "/5   " + total, ax + AW / 2, ay + AH - 14, 0xC8C8D8);
            }
        }
    }

    // ------------------------------------------------------------------ claw machine

    static class ClawScreen extends GameScreen {
        private float clawX = 100;
        private int drop = -1;
        private int before;
        private int slotChosen;

        ClawScreen(BlockPos pos) {
            super(ArcadeGame.CLAW, pos);
        }

        private static int slotX(int i) {
            return 20 + i * 40;
        }

        private int stockCount() {
            ArcadeBlocks.ArcadeBlockEntity be = be();
            int n = 0;
            if (be != null) {
                for (ItemStack s : be.stock) {
                    n += s.getCount();
                }
            }
            return n;
        }

        @Override
        protected void begin() {
            clawX = 100;
            drop = -1;
        }

        private void startDrop() {
            if (drop >= 0) {
                return;
            }
            int slot = Math.max(0, Math.min(4, Math.round((clawX - 20) / 40.0F)));
            float dist = Math.abs(clawX - slotX(slot));
            int closeness = (int) Math.max(0, 100 - dist * 100 / 20.0F);
            slotChosen = dist > 18 ? -1 : slot;
            before = stockCount();
            drop = 0;
            act(2, slotChosen, closeness);
        }

        @Override
        protected void gameTick() {
            Minecraft mc = Minecraft.getInstance();
            long w = mc.getWindow().getWindow();
            if (drop < 0) {
                if (InputConstants.isKeyDown(w, GLFW.GLFW_KEY_LEFT) || InputConstants.isKeyDown(w, GLFW.GLFW_KEY_A)) {
                    clawX -= 3;
                }
                if (InputConstants.isKeyDown(w, GLFW.GLFW_KEY_RIGHT) || InputConstants.isKeyDown(w, GLFW.GLFW_KEY_D)) {
                    clawX += 3;
                }
                clawX = Math.max(10, Math.min(190, clawX));
            } else {
                drop++;
                if (drop > 45) {
                    phase = 3;
                    note = Component.translatable(stockCount() < before ? "gui.coastercontrolpanel.claw_got" : "gui.coastercontrolpanel.claw_nothing");
                }
            }
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                startDrop();
                return true;
            }
            return false;
        }

        @Override
        protected boolean click(int mx, int my) {
            if (drop < 0) {
                startDrop();
            }
            return true;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            if (drop < 0) {
                clawX = Math.max(10, Math.min(190, mx));
            }
            drawStock(g, ax, ay);
            int cy = 12;
            if (drop >= 0) {
                cy = drop < 20 ? 12 + drop * 3 : drop < 28 ? 72 : drop < 45 ? 72 - (drop - 28) * 3 : 12;
            }
            int cx = ax + (int) clawX;
            g.fill(cx, ay, cx + 1, ay + cy, 0xFFA0A8C0);
            boolean closed = drop >= 20;
            g.fill(cx - 5, ay + cy, cx + 6, ay + cy + 3, 0xFFC0C8E0);
            g.fill(cx - (closed ? 3 : 7), ay + cy + 3, cx - (closed ? 2 : 6), ay + cy + 12, 0xFFC0C8E0);
            g.fill(cx + (closed ? 3 : 7), ay + cy + 3, cx + (closed ? 4 : 8), ay + cy + 12, 0xFFC0C8E0);
        }

        private void drawStock(GuiGraphics g, int ax, int ay) {
            ArcadeBlocks.ArcadeBlockEntity be = be();
            for (int i = 0; i < 5; i++) {
                int x = ax + slotX(i);
                g.fill(x - 16, ay + AH - 30, x + 16, ay + AH - 2, 0xFF1C2030);
                if (be != null && !be.stock[i].isEmpty()) {
                    g.renderItem(be.stock[i], x - 8, ay + AH - 26);
                    g.drawString(font, "" + be.stock[i].getCount(), x - 3, ay + AH - 11, 0xC8C8D8, false);
                }
            }
        }

        @Override
        protected void drawIdle(GuiGraphics g, int ax, int ay) {
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.arcade_cost"), ax + AW / 2, ay + 8, 0xFFE070);
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.claw_stock_help"), ax + AW / 2, ay + 24, 0x8A8FA3);
            drawStock(g, ax, ay);
        }
    }

    // ------------------------------------------------------------------ whack-a-mole

    static class MoleScreen extends GameScreen {
        private final int[] up = new int[9];
        private final int[] flash = new int[9];
        private int spawn;

        MoleScreen(BlockPos pos) {
            super(ArcadeGame.MOLE, pos);
        }

        @Override
        protected void begin() {
            score = 0;
            spawn = 10;
            for (int i = 0; i < 9; i++) {
                up[i] = 0;
                flash[i] = 0;
            }
        }

        @Override
        protected void gameTick() {
            for (int i = 0; i < 9; i++) {
                if (up[i] > 0) {
                    up[i]--;
                }
                if (flash[i] > 0) {
                    flash[i]--;
                }
            }
            if (--spawn <= 0) {
                spawn = Math.max(6, 16 - ticks / 50);
                int i = RND.nextInt(9);
                if (up[i] == 0) {
                    up[i] = 18 + RND.nextInt(10);
                }
            }
            if (ticks >= 400) {
                finish(score, 0);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            for (int i = 0; i < 9; i++) {
                int x = 10 + (i % 3) * 64;
                int y = 4 + (i / 3) * 38;
                if (up[i] > 0 && mx >= x && mx < x + 52 && my >= y && my < y + 32) {
                    up[i] = 0;
                    flash[i] = 6;
                    score++;
                    return true;
                }
            }
            return true;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            for (int i = 0; i < 9; i++) {
                int x = ax + 10 + (i % 3) * 64;
                int y = ay + 4 + (i / 3) * 38;
                g.fill(x, y + 18, x + 52, y + 32, 0xFF3A2A1A);
                if (up[i] > 0) {
                    g.fill(x + 12, y + 2, x + 40, y + 20, 0xFF8A5A30);
                    g.fill(x + 18, y + 6, x + 22, y + 10, 0xFF000000);
                    g.fill(x + 30, y + 6, x + 34, y + 10, 0xFF000000);
                    g.fill(x + 23, y + 11, x + 29, y + 15, 0xFFE0A0A0);
                }
                if (flash[i] > 0) {
                    g.drawCenteredString(font, "*", x + 26, y + 6, 0xFFFFE070);
                }
                g.fill(x, y + 28, x + 52, y + 32, 0xFF5A3A20);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + 3, ay + AH - 10, 0xFFFFFF, false);
            g.drawString(font, "" + Math.max(0, (400 - ticks) / 20), ax + AW - 16, ay + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ strength tester

    static class StrengthScreen extends GameScreen {
        private float pos01;
        private float vel;
        private int swing;
        private int best;
        private int lastHit;
        private int pause;

        StrengthScreen(BlockPos pos) {
            super(ArcadeGame.STRENGTH, pos);
        }

        @Override
        protected void begin() {
            swing = 0;
            best = 0;
            lastHit = -1;
            pause = 0;
            pos01 = 0;
            vel = 3.0F;
        }

        @Override
        protected void gameTick() {
            if (pause > 0) {
                if (--pause == 0) {
                    if (swing >= 3) {
                        finish(best, 0);
                    } else {
                        pos01 = 0;
                        vel = 3.0F + swing * 1.2F;
                        lastHit = -1;
                    }
                }
                return;
            }
            pos01 += vel;
            if (pos01 >= 100) {
                pos01 = 100;
                vel = -Math.abs(vel);
            } else if (pos01 <= 0) {
                pos01 = 0;
                vel = Math.abs(vel);
            }
        }

        private void hit() {
            if (pause > 0) {
                return;
            }
            lastHit = Math.round(pos01);
            best = Math.max(best, lastHit);
            swing++;
            pause = 30;
        }

        @Override
        protected boolean click(int mx, int my) {
            hit();
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                hit();
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            int bx = ax + 80;
            g.fill(bx, ay + 8, bx + 40, ay + AH - 8, 0xFF20242E);
            for (int i = 0; i < 10; i++) {
                int y = ay + AH - 8 - (i + 1) * (AH - 16) / 10;
                int c = i < 5 ? 0xFF30C050 : i < 8 ? 0xFFE0C040 : 0xFFE05030;
                if (i * 10 + 10 <= best) {
                    g.fill(bx + 4, y + 2, bx + 36, y + (AH - 16) / 10 - 1, c);
                } else {
                    g.fill(bx + 4, y + 2, bx + 36, y + (AH - 16) / 10 - 1, 0xFF2A2F3C);
                }
            }
            int my2 = ay + AH - 8 - (int) (pos01 * (AH - 16) / 100.0F);
            g.fill(bx - 8, my2, bx + 48, my2 + 2, 0xFFFFFFFF);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.str_swing", Math.min(3, swing + 1)), ax + 4, ay + 4, 0xC8C8D8, false);
            if (lastHit >= 0) {
                g.drawString(font, "" + lastHit, ax + 150, ay + AH / 2, lastHit >= 95 ? 0xFFE070 : 0xFFFFFF, false);
                if (lastHit >= 95) {
                    g.drawCenteredString(font, "DING!", bx + 20, ay - 0 + 1, 0xFFE070);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.str_best", best), ax + 4, ay + AH - 12, 0x7CFFB0, false);
        }
    }

    // ------------------------------------------------------------------ basketball hoops

    static class HoopsScreen extends GameScreen {
        private int cooldown;
        private int shotT = -1;
        private int flashT;
        private int flashPts;

        HoopsScreen(BlockPos pos) {
            super(ArcadeGame.HOOPS, pos);
        }

        private float hoopX(int t) {
            return 100 + 70 * (float) Math.sin(t * 0.09);
        }

        @Override
        protected void begin() {
            score = 0;
            cooldown = 0;
            shotT = -1;
            flashT = 0;
        }

        @Override
        protected void gameTick() {
            if (cooldown > 0) {
                cooldown--;
            }
            if (flashT > 0) {
                flashT--;
            }
            if (shotT >= 0 && ++shotT >= 8) {
                shotT = -1;
                float d = Math.abs(hoopX(ticks) - 100);
                int pts = d < 9 ? 2 : d < 20 ? 1 : 0;
                score = Math.min(20, score + pts);
                flashPts = pts;
                flashT = 12;
            }
            if (ticks >= 600) {
                finish(score, 0);
            }
        }

        private void shoot() {
            if (cooldown == 0 && shotT < 0) {
                shotT = 0;
                cooldown = 12;
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            shoot();
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                shoot();
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            int hx = ax + (int) hoopX(ticks);
            g.fill(hx - 14, ay + 26, hx + 14, ay + 30, 0xFFE06030);
            g.fill(hx - 12, ay + 30, hx + 12, ay + 40, 0x80FFFFFF);
            g.fill(hx - 16, ay + 8, hx + 16, ay + 26, 0xFFD0D4E0);
            g.fill(ax + 99, ay + 20, ax + 101, ay + AH - 20, 0x30FFFFFF);
            float p = shotT < 0 ? 0 : shotT / 8.0F;
            int by = ay + AH - 14 - (int) (p * (AH - 14 - 30));
            g.fill(ax + 95, by, ax + 105, by + 10, 0xFFE08030);
            if (flashT > 0) {
                g.drawCenteredString(font, flashPts == 2 ? "SWISH +2" : flashPts == 1 ? "+1" : "MISS", ax + AW / 2, ay + 56, flashPts > 0 ? 0xFF7CFFB0 : 0xFFE05050);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + 3, ay + AH - 10, 0xFFFFFF, false);
            g.drawString(font, "" + Math.max(0, (600 - ticks) / 20), ax + AW - 16, ay + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ shooting gallery

    static class GalleryScreen extends GameScreen {
        private record Target(float[] x, int lane, float vx, boolean gold) {
        }

        private final List<Target> targets = new ArrayList<>();
        private int spawn;
        private int flash;

        GalleryScreen(BlockPos pos) {
            super(ArcadeGame.GALLERY, pos);
        }

        private static int laneY(int lane) {
            return 14 + lane * 34;
        }

        @Override
        protected void begin() {
            score = 0;
            targets.clear();
            spawn = 5;
        }

        @Override
        protected void gameTick() {
            if (flash > 0) {
                flash--;
            }
            if (--spawn <= 0) {
                spawn = 12 + RND.nextInt(8);
                boolean fromLeft = RND.nextBoolean();
                float speed = 1.4F + RND.nextFloat() * 1.8F;
                targets.add(new Target(new float[]{fromLeft ? -18 : AW}, RND.nextInt(3), fromLeft ? speed : -speed, RND.nextInt(10) == 0));
            }
            targets.removeIf(t -> {
                t.x[0] += t.vx;
                return t.x[0] < -24 || t.x[0] > AW + 4;
            });
            if (ticks >= 600) {
                finish(score, 0);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            for (int i = targets.size() - 1; i >= 0; i--) {
                Target t = targets.get(i);
                int y = laneY(t.lane);
                if (mx >= t.x[0] && mx < t.x[0] + 18 && my >= y && my < y + 18) {
                    targets.remove(i);
                    score = Math.min(30, score + (t.gold ? 2 : 1));
                    flash = 4;
                    return true;
                }
            }
            return true;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            for (int lane = 0; lane < 3; lane++) {
                g.fill(ax, ay + laneY(lane) + 18, ax + AW, ay + laneY(lane) + 20, 0xFF30343F);
            }
            for (Target t : targets) {
                int x = ax + (int) t.x[0];
                int y = ay + laneY(t.lane);
                g.fill(x, y, x + 18, y + 18, t.gold ? 0xFFE0C040 : 0xFFE04040);
                g.fill(x + 3, y + 3, x + 15, y + 15, 0xFFF0F0F0);
                g.fill(x + 6, y + 6, x + 12, y + 12, t.gold ? 0xFFE0C040 : 0xFFE04040);
            }
            int cx = ax + Math.max(0, Math.min(AW, mx));
            int cy = ay + Math.max(0, Math.min(AH, my));
            int c = flash > 0 ? 0xFFFFE070 : 0xFFFFFFFF;
            g.fill(cx - 6, cy, cx + 7, cy + 1, c);
            g.fill(cx, cy - 6, cx + 1, cy + 7, c);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + 3, ay + AH - 10, 0xFFFFFF, false);
            g.drawString(font, "" + Math.max(0, (600 - ticks) / 20), ax + AW - 16, ay + AH - 10, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ ring toss

    static class RingsScreen extends GameScreen {
        private static final int[] CENTRE = {25, 55, 82};
        private static final int[] HALF = {14, 9, 5};
        private float power;
        private float vel;
        private int thrown;
        private int pause;
        private int lastPts = -1;

        RingsScreen(BlockPos pos) {
            super(ArcadeGame.RINGS, pos);
        }

        @Override
        protected void begin() {
            score = 0;
            thrown = 0;
            pause = 0;
            power = 0;
            vel = 2.6F;
            lastPts = -1;
        }

        @Override
        protected void gameTick() {
            if (pause > 0) {
                if (--pause == 0) {
                    if (thrown >= 5) {
                        finish(score, 0);
                    } else {
                        lastPts = -1;
                    }
                }
                return;
            }
            power += vel;
            if (power >= 100) {
                power = 100;
                vel = -Math.abs(vel);
            } else if (power <= 0) {
                power = 0;
                vel = Math.abs(vel);
            }
        }

        private void toss() {
            if (pause > 0) {
                return;
            }
            int pts = 0;
            for (int i = 0; i < 3; i++) {
                if (Math.abs(power - CENTRE[i]) <= HALF[i]) {
                    pts = i + 1;
                }
            }
            score += pts;
            lastPts = pts;
            thrown++;
            pause = 25;
        }

        @Override
        protected boolean click(int mx, int my) {
            toss();
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                toss();
                return true;
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            int bx = ax + 10;
            int by = ay + 70;
            int bw = AW - 20;
            g.fill(bx, by, bx + bw, by + 16, 0xFF20242E);
            int[] cols = {0xFF3070C0, 0xFFE0C040, 0xFFE05030};
            for (int i = 0; i < 3; i++) {
                int x0 = bx + (CENTRE[i] - HALF[i]) * bw / 100;
                int x1 = bx + (CENTRE[i] + HALF[i]) * bw / 100;
                g.fill(x0, by, x1, by + 16, cols[i]);
                g.drawCenteredString(font, "" + (i + 1), (x0 + x1) / 2, by - 11, 0xFFFFFF);
            }
            int mxp = bx + (int) (power * bw / 100.0F);
            g.fill(mxp - 1, by - 4, mxp + 2, by + 20, 0xFFFFFFFF);
            for (int i = 0; i < 5; i++) {
                g.fill(ax + 40 + i * 24, ay + 12, ax + 52 + i * 24, ay + 24, i < thrown ? 0xFF303848 : 0xFFE0C040);
            }
            if (lastPts >= 0) {
                g.drawCenteredString(font, lastPts == 0 ? "MISS" : "+" + lastPts, ax + AW / 2, ay + 40, lastPts == 0 ? 0xFFE05050 : 0xFF7CFFB0);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + 3, ay + AH - 10, 0xFFFFFF, false);
        }
    }

    // ------------------------------------------------------------------ coconut shy

    static class CoconutScreen extends GameScreen {
        private int thrown;
        private int mask;
        private int pause;
        private int flash;
        private int lastX;
        private int lastY;

        CoconutScreen(BlockPos pos) {
            super(ArcadeGame.COCONUT, pos);
        }

        private float cx(int t) {
            return 100 + 80 * (float) Math.sin(t * 0.07);
        }

        private float cy(int t) {
            return 40 + 30 * (float) Math.sin(t * 0.11 + 1.0);
        }

        @Override
        protected void begin() {
            score = 0;
            thrown = 0;
            mask = 0;
            pause = 0;
            flash = 0;
        }

        @Override
        protected void gameTick() {
            if (flash > 0) {
                flash--;
            }
            if (pause > 0 && --pause == 0) {
                finish(score, mask);
            }
        }

        @Override
        protected boolean click(int mx, int my) {
            if (pause > 0 || thrown >= 5) {
                return true;
            }
            float x = cx(ticks);
            float y = cy(ticks);
            lastX = (int) x;
            lastY = (int) y;
            flash = 8;
            thrown++;
            for (int i = 0; i < 5; i++) {
                if ((mask & (1 << i)) == 0) {
                    float dx = x - (20 + i * 40);
                    float dy = y - 30;
                    if (dx * dx + dy * dy <= 13 * 13) {
                        mask |= 1 << i;
                        score++;
                        break;
                    }
                }
            }
            if (thrown >= 5) {
                pause = 25;
            }
            return true;
        }

        @Override
        protected boolean key(int k) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                return click(0, 0);
            }
            return false;
        }

        @Override
        protected void drawGame(GuiGraphics g, int ax, int ay, int mx, int my) {
            g.fill(ax + 4, ay + 44, ax + AW - 4, ay + 48, 0xFF6A4A2A);
            for (int i = 0; i < 5; i++) {
                if ((mask & (1 << i)) == 0) {
                    int x = ax + 20 + i * 40;
                    g.fill(x - 9, ay + 21, x + 9, ay + 39, 0xFF5A3A1E);
                    g.fill(x - 6, ay + 24, x + 6, ay + 36, 0xFF7A5230);
                    g.fill(x - 3, ay + 27, x - 1, ay + 29, 0xFF2A1A0A);
                    g.fill(x + 1, ay + 27, x + 3, ay + 29, 0xFF2A1A0A);
                } else {
                    g.fill(ax + 20 + i * 40 - 8, ay + 47, ax + 20 + i * 40 + 8, ay + 52, 0xFF5A3A1E);
                }
            }
            int x = ax + (int) cx(ticks);
            int y = ay + (int) cy(ticks);
            g.fill(x - 7, y, x + 8, y + 1, 0xFFFFFFFF);
            g.fill(x, y - 7, x + 1, y + 8, 0xFFFFFFFF);
            if (flash > 0) {
                g.fill(ax + lastX - 3, ay + lastY - 3, ax + lastX + 4, ay + lastY + 4, 0xFFFFE070);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.coco_left", 5 - thrown), ax + 3, ay + AH - 10, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.arcade_score", score), ax + 120, ay + AH - 10, 0x7CFFB0, false);
        }
    }
}
