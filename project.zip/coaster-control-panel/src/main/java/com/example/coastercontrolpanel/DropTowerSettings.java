package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything a Drop Tower can be told: the sequence of steps and the general settings. Heights are in blocks above
 * where the carriage stands, speeds in blocks per second, "gravity" in blocks per second squared. Every value is
 * clamped here, so nothing arriving from a screen, a packet or a save can break the ride.
 */
public final class DropTowerSettings {
    public static final int LIFT = 0;
    public static final int HOLD = 1;
    public static final int FALL = 2;
    public static final int GLIDE = 3;
    public static final int TYPES = 4;
    public static final int MAX_STEPS = 10;

    public static final int PRESETS = 4;

    /** One step: LIFT (a = height, b = speed), HOLD (a = seconds), FALL (a = height, b = gravity), GLIDE (a = height, b = speed). */
    public static final class Step {
        public int type;
        public float a;
        public float b;

        public Step(int type, float a, float b) {
            this.type = type;
            this.a = a;
            this.b = b;
            clamp();
        }

        public void clamp() {
            type = Math.max(0, Math.min(TYPES - 1, type));
            a = DropTowerSettings.clamp(a, 0.0F, type == HOLD ? 120.0F : 256.0F);
            switch (type) {
                case LIFT, GLIDE -> b = DropTowerSettings.clamp(b, 0.5F, 60.0F);
                case FALL -> b = DropTowerSettings.clamp(b, 1.0F, 40.0F);
                default -> b = 0.0F;
            }
        }

        /** Sensible values when the type of a step is changed. */
        public void retype(int newType) {
            type = newType;
            switch (type) {
                case LIFT -> {
                    a = 20;
                    b = 4;
                }
                case HOLD -> {
                    a = 3;
                    b = 0;
                }
                case FALL -> {
                    a = 0;
                    b = 9.8F;
                }
                default -> {
                    a = 0;
                    b = 2;
                }
            }
        }
    }

    public final List<Step> steps = new ArrayList<>();
    /** How many times the whole sequence is run. */
    public int loops = 1;
    /** Seconds between pressing Start and the ride moving. */
    public float preDelay = 3.0F;
    /** Braking strength at the end of a fall, blocks per second squared. */
    public float brake = 25.0F;
    /** Speed of the final return to the bottom, blocks per second. */
    public float returnSpeed = 2.0F;
    /** Speed limit of a fall, blocks per second. */
    public float maxSpeed = 40.0F;
    /** 0 = a redstone pulse starts the ride, 1 = the ride runs while powered and returns when the power goes. */
    public int redstoneMode = 0;
    /** 0 = go back down by itself at the end, 1 = wait at the end position until End is pressed. */
    public int endMode = 0;

    public DropTowerSettings() {
        preset(0);
    }

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void preset(int index) {
        steps.clear();
        switch (index) {
            case 1 -> { // bouncy
                steps.add(new Step(LIFT, 20, 5));
                steps.add(new Step(HOLD, 2, 0));
                steps.add(new Step(FALL, 6, 9.8F));
                steps.add(new Step(LIFT, 14, 8));
                steps.add(new Step(FALL, 3, 9.8F));
                steps.add(new Step(LIFT, 9, 6));
                steps.add(new Step(FALL, 0, 9.8F));
            }
            case 2 -> { // stepped
                steps.add(new Step(LIFT, 6, 4));
                steps.add(new Step(HOLD, 1.5F, 0));
                steps.add(new Step(LIFT, 12, 4));
                steps.add(new Step(HOLD, 1.5F, 0));
                steps.add(new Step(LIFT, 18, 4));
                steps.add(new Step(HOLD, 2, 0));
                steps.add(new Step(FALL, 0, 9.8F));
            }
            case 3 -> { // gentle
                steps.add(new Step(LIFT, 16, 2));
                steps.add(new Step(HOLD, 4, 0));
                steps.add(new Step(GLIDE, 0, 2));
            }
            default -> { // classic
                steps.add(new Step(LIFT, 20, 4));
                steps.add(new Step(HOLD, 3, 0));
                steps.add(new Step(FALL, 0, 9.8F));
            }
        }
    }

    public void sanitize() {
        loops = Math.max(1, Math.min(20, loops));
        preDelay = clamp(preDelay, 0.0F, 30.0F);
        brake = clamp(brake, 5.0F, 80.0F);
        returnSpeed = clamp(returnSpeed, 0.5F, 10.0F);
        maxSpeed = clamp(maxSpeed, 2.0F, 80.0F);
        redstoneMode = Math.max(0, Math.min(1, redstoneMode));
        endMode = Math.max(0, Math.min(1, endMode));
        while (steps.size() > MAX_STEPS) {
            steps.remove(steps.size() - 1);
        }
        for (Step s : steps) {
            s.clamp();
        }
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Loops", loops);
        t.putFloat("PreDelay", preDelay);
        t.putFloat("Brake", brake);
        t.putFloat("ReturnSpeed", returnSpeed);
        t.putFloat("MaxSpeed", maxSpeed);
        t.putInt("Redstone", redstoneMode);
        t.putInt("EndMode", endMode);
        ListTag list = new ListTag();
        for (Step s : steps) {
            CompoundTag c = new CompoundTag();
            c.putInt("T", s.type);
            c.putFloat("A", s.a);
            c.putFloat("B", s.b);
            list.add(c);
        }
        t.put("Steps", list);
        return t;
    }

    public static DropTowerSettings fromTag(CompoundTag t) {
        DropTowerSettings s = new DropTowerSettings();
        if (t == null || t.isEmpty()) {
            return s;
        }
        s.loops = t.contains("Loops") ? t.getInt("Loops") : 1;
        s.preDelay = t.contains("PreDelay") ? t.getFloat("PreDelay") : 3.0F;
        s.brake = t.contains("Brake") ? t.getFloat("Brake") : 25.0F;
        s.returnSpeed = t.contains("ReturnSpeed") ? t.getFloat("ReturnSpeed") : 2.0F;
        s.maxSpeed = t.contains("MaxSpeed") ? t.getFloat("MaxSpeed") : 40.0F;
        s.redstoneMode = t.getInt("Redstone");
        s.endMode = t.getInt("EndMode");
        if (t.contains("Steps", Tag.TAG_LIST)) {
            s.steps.clear();
            ListTag list = t.getList("Steps", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size() && i < MAX_STEPS; i++) {
                CompoundTag c = list.getCompound(i);
                s.steps.add(new Step(c.getInt("T"), c.getFloat("A"), c.getFloat("B")));
            }
        }
        s.sanitize();
        return s;
    }

    public DropTowerSettings copy() {
        return fromTag(toTag());
    }
}
