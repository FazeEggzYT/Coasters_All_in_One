package com.example.coastercontrolpanel;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * The sections of the "All in one" creative tab. To add a new section later, add one line to SECTIONS
 * and one language entry "gui.coastercontrolpanel.section.<key>".
 *
 * Layout in the tab grid (9 slots per row): a header row of 9 empty slots (the heading is drawn over it),
 * then the section's items, padded to a full row, then the next header row, and so on.
 */
public final class TabSections {
    public record Section(String key, List<Supplier<? extends ItemLike>> items) {
    }

    public static final List<Section> SECTIONS = List.of(
            new Section("control_panel", List.of(CoasterControlPanel.PANEL_ITEM)),
            new Section("coasters", List.of(CoasterControlPanel.COASTER_SMOOTHER_ITEM, CoasterControlPanel.TRACK_UNRESTRICTOR_ITEM, CoasterControlPanel.DRIVE_TYRE_ITEM)),
            new Section("better_coasters", List.of(CoasterControlPanel.BRAKE_RUN_ITEM, CoasterControlPanel.TRAIN_STOPPER_ITEM, CoasterControlPanel.LAUNCH_RUN_ITEM, CoasterControlPanel.BLOCK_RUN_ITEM, CoasterControlPanel.REDSTONE_TRIGGER_ITEM)),
            new Section("drop_tower", List.of(CoasterControlPanel.DROP_TOWER_BASE_ITEM, CoasterControlPanel.DROP_TOWER_SECTION_ITEM, CoasterControlPanel.DROP_TOWER_FRAME_ITEM, CoasterControlPanel.DROP_TOWER_CONTROLLER_ITEM, CoasterControlPanel.PREMADE_DROP_TOWER_ITEM)),
            new Section("swing_ride", List.of(CoasterControlPanel.SWING_BASE_ITEM, CoasterControlPanel.SWING_PIVOT_ITEM, CoasterControlPanel.SWING_ARM_ITEM, CoasterControlPanel.SWING_HUB_ITEM, CoasterControlPanel.SWING_FRAME_ITEM, CoasterControlPanel.SWING_SECTION_ITEM, CoasterControlPanel.SWING_CONTROLLER_ITEM, CoasterControlPanel.PREMADE_SWING_ITEM)),
            new Section("pirate_ship", List.of(CoasterControlPanel.PIRATE_BASE_ITEM, CoasterControlPanel.PIRATE_PIVOT_ITEM, CoasterControlPanel.PIRATE_ARM_ITEM, CoasterControlPanel.PIRATE_HUB_ITEM, CoasterControlPanel.PIRATE_HULL_ITEM, CoasterControlPanel.PIRATE_SECTION_ITEM, CoasterControlPanel.PIRATE_CONTROLLER_ITEM, CoasterControlPanel.PREMADE_PIRATE_ITEM)),
            new Section("teacup_ride", List.of(CoasterControlPanel.TEACUP_BASE_ITEM, CoasterControlPanel.TEACUP_HUB_ITEM, CoasterControlPanel.TEACUP_PLATE_ITEM, CoasterControlPanel.TEACUP_CUP_HUB_ITEM, CoasterControlPanel.TEACUP_FLOOR_ITEM, CoasterControlPanel.TEACUP_WALL_ITEM, CoasterControlPanel.TEACUP_SECTION_ITEM, CoasterControlPanel.TEACUP_CONTROLLER_ITEM, CoasterControlPanel.PREMADE_TEACUP_ITEM)),
            new Section("ferris_wheel", List.of(CoasterControlPanel.FERRIS_BASE_ITEM, CoasterControlPanel.FERRIS_AXLE_ITEM, CoasterControlPanel.FERRIS_SPOKE_ITEM, CoasterControlPanel.FERRIS_RIM_ITEM, CoasterControlPanel.FERRIS_HUB_ITEM, CoasterControlPanel.FERRIS_FRAME_ITEM, CoasterControlPanel.FERRIS_SECTION_ITEM, CoasterControlPanel.FERRIS_CONTROLLER_ITEM, CoasterControlPanel.PREMADE_FERRIS_ITEM)),
            new Section("track_elements", List.of(CoasterControlPanel.TRACK_ELEMENT_SELECTOR_ITEM)),
            new Section("animatronics", List.of(CoasterControlPanel.ANIMATRONIC_ITEM, CoasterControlPanel.ANIMATRONIC_TOOL_ITEM,
                    CoasterControlPanel.ANIMATION_CONTROLLER_ITEM, CoasterControlPanel.ANIMATION_CONNECTOR_ITEM)),
            new Section("announcer", List.of(CoasterControlPanel.ANNOUNCER_ITEM, CoasterControlPanel.ANNOUNCE_PANEL_ITEM)),
            new Section("ride_gate", List.of(CoasterControlPanel.GATE_ITEM, CoasterControlPanel.GATE_SILVER_ITEM, CoasterControlPanel.GATE_RED_ITEM, CoasterControlPanel.GATE_DOUBLE_ITEM, CoasterControlPanel.RIDE_FENCE_ITEM, CoasterControlPanel.RIDE_FENCE_SILVER_ITEM, CoasterControlPanel.RIDE_FENCE_RED_ITEM)),
            new Section("seat_timer", List.of(CoasterControlPanel.SEAT_TIMER_ITEM, CoasterControlPanel.SEAT_SPEED_ITEM)),
            new Section("section_controller", List.of(CoasterControlPanel.SECTION_ITEM, CoasterControlPanel.SECTION_LINKER_ITEM)),
            new Section("track", List.of(CoasterControlPanel.TRACK_PAINTER_ITEM, CoasterControlPanel.STATION_TRACK_ITEM, CoasterControlPanel.LAUNCH_TRACK_ITEM, CoasterControlPanel.BRAKE_TRACK_ITEM, CoasterControlPanel.LIFT_TRACK_ITEM, CoasterControlPanel.STATION_ZONE_ITEM, CoasterControlPanel.LAUNCH_ZONE_ITEM, CoasterControlPanel.BRAKE_ZONE_ITEM, CoasterControlPanel.LIFT_ZONE_ITEM)),
            new Section("special_effects", List.of(CoasterControlPanel.EFFECT_ITEM, CoasterControlPanel.EFFECTS_PANEL_ITEM)),
            new Section("ride_photos", List.of(CoasterControlPanel.CAMERA_ITEM, CoasterControlPanel.CONNECTOR_ITEM, CoasterControlPanel.PHOTO_SCREEN_ITEM)),
            new Section("guests", List.of(CoasterControlPanel.SPAWNER_ITEM, CoasterControlPanel.QUEUE_MARKER_ITEM, CoasterControlPanel.STATION_MARKER_ITEM, CoasterControlPanel.EXIT_MARKER_ITEM)),
            new Section("auto_supports", List.of(CoasterControlPanel.SUPPORT_TOOL_ITEM, CoasterControlPanel.SUPPORT_ERASER_ITEM)),
            new Section("queue_signs", List.of(CoasterControlPanel.RIDE_SIGN_ITEM, CoasterControlPanel.OPEN_SIGN_ITEM, CoasterControlPanel.HEIGHT_SIGN_ITEM, CoasterControlPanel.WAIT_SIGN_ITEM, CoasterControlPanel.ENTRANCE_SIGN_ITEM, CoasterControlPanel.EXIT_SIGN_ITEM, CoasterControlPanel.NOTICE_SIGN_ITEM, CoasterControlPanel.DIRECTION_SIGN_ITEM, CoasterControlPanel.CROWD_SIGN_ITEM, CoasterControlPanel.COUNTER_SIGN_ITEM, CoasterControlPanel.FLOOR_SIGN_ITEM, CoasterControlPanel.ROPE_POST_ITEM, CoasterControlPanel.FLOOR_ARROW_ITEM)),
            new Section("entrance", List.of(CoasterControlPanel.TURNSTILE_ITEM, CoasterControlPanel.TICKET_ITEM)),
            new Section("bathroom_pack", List.of(CoasterControlPanel.CUBICLE_KIT_ITEM, CoasterControlPanel.CUBICLE_ITEM, CoasterControlPanel.CUBICLE_PANEL_ITEM, CoasterControlPanel.TOILET_ITEM, CoasterControlPanel.URINAL_ITEM, CoasterControlPanel.SINK_ITEM, CoasterControlPanel.HAND_DRYER_ITEM, CoasterControlPanel.SOAP_DISPENSER_ITEM, CoasterControlPanel.SOAP_ITEM, CoasterControlPanel.ROLL_HOLDER_ITEM, CoasterControlPanel.SIGN_MEN_ITEM, CoasterControlPanel.SIGN_WOMEN_ITEM, CoasterControlPanel.SIGN_ACCESS_ITEM, CoasterControlPanel.SIGN_BABY_ITEM)),
            new Section("kitchen_pack", List.of(CoasterControlPanel.PREP_ITEM, CoasterControlPanel.GRILL_ITEM, CoasterControlPanel.FRYER_ITEM, CoasterControlPanel.OVEN_ITEM, CoasterControlPanel.SOFT_SERVE_ITEM, CoasterControlPanel.POPCORN_MACHINE_ITEM, CoasterControlPanel.DRINKS_ITEM, CoasterControlPanel.FRIDGE_ITEM, CoasterControlPanel.BELL_ITEM, CoasterControlPanel.FAN_ITEM, CoasterControlPanel.BUN, CoasterControlPanel.RAW_PATTY, CoasterControlPanel.COOKED_PATTY, CoasterControlPanel.RAW_SAUSAGE, CoasterControlPanel.COOKED_SAUSAGE, CoasterControlPanel.DOUGH, CoasterControlPanel.POTATO_STRIPS, CoasterControlPanel.BURGER, CoasterControlPanel.HOT_DOG, CoasterControlPanel.CHIPS, CoasterControlPanel.DOUGHNUT, CoasterControlPanel.PIZZA_SLICE, CoasterControlPanel.ICE_CREAM, CoasterControlPanel.POPCORN_ITEM, CoasterControlPanel.APPLE_JUICE, CoasterControlPanel.BERRY_FIZZ, CoasterControlPanel.MELON_JUICE, CoasterControlPanel.COLA, CoasterControlPanel.CHEESE, CoasterControlPanel.SALAD, CoasterControlPanel.CHEESEBURGER, CoasterControlPanel.CHICKEN_SANDWICH, CoasterControlPanel.HAM_SANDWICH, CoasterControlPanel.TORTILLA, CoasterControlPanel.TACO, CoasterControlPanel.BURRITO, CoasterControlPanel.TORTILLA_CHIPS, CoasterControlPanel.NACHOS, CoasterControlPanel.FRUIT_CUP, CoasterControlPanel.CANDY_FLOSS, CoasterControlPanel.CARAMEL_POPCORN, CoasterControlPanel.CHOCOLATE_POPCORN, CoasterControlPanel.FRIED_CHICKEN, CoasterControlPanel.CHURRO, CoasterControlPanel.FISH_AND_CHIPS, CoasterControlPanel.FISH_FINGERS, CoasterControlPanel.NUGGETS, CoasterControlPanel.CORN_DOG, CoasterControlPanel.CHEESE_PIZZA, CoasterControlPanel.APPLE_PIE, CoasterControlPanel.CHOC_COOKIE, CoasterControlPanel.CAKE_SLICE, CoasterControlPanel.MUFFIN, CoasterControlPanel.LOADED_POTATO, CoasterControlPanel.SAUSAGE_ROLL, CoasterControlPanel.PASTY, CoasterControlPanel.PRETZEL, CoasterControlPanel.CHOC_ICE_CREAM, CoasterControlPanel.ICE_LOLLY, CoasterControlPanel.SUNDAE, CoasterControlPanel.FROZEN_YOGURT, CoasterControlPanel.MILKSHAKE, CoasterControlPanel.HOT_CHOCOLATE, CoasterControlPanel.CARROT_JUICE, CoasterControlPanel.GLOW_SMOOTHIE)),
            new Section("restaurant_cafe", List.of(CoasterControlPanel.DINING_TABLE_ITEM, CoasterControlPanel.DINING_CHAIR_ITEM, CoasterControlPanel.DINING_BOOTH_ITEM, CoasterControlPanel.MENU_BOARD_ITEM, CoasterControlPanel.ORDER_KIOSK_ITEM, CoasterControlPanel.ORDER_DISPLAY_ITEM, CoasterControlPanel.PICKUP_DISPLAY_ITEM, CoasterControlPanel.CASH_REGISTER_ITEM, CoasterControlPanel.CONDIMENT_STAND_ITEM, CoasterControlPanel.PARASOL_ITEM, CoasterControlPanel.TRAY_TROLLEY_ITEM)),
            new Section("arcade", List.of(CoasterControlPanel.TOKEN_MACHINE_ITEM, CoasterControlPanel.ARCADE_TOKEN, CoasterControlPanel.ARCADE_CABINET_ITEM, CoasterControlPanel.CLAW_MACHINE_ITEM, CoasterControlPanel.WHACK_A_MOLE_ITEM, CoasterControlPanel.STRENGTH_TESTER_ITEM, CoasterControlPanel.BASKETBALL_HOOPS_ITEM, CoasterControlPanel.SHOOTING_GALLERY_ITEM, CoasterControlPanel.RING_TOSS_ITEM, CoasterControlPanel.COCONUT_SHY_ITEM, CoasterControlPanel.PRIZE_COUNTER_ITEM, CoasterControlPanel.PRIZE_TICKET)),
            new Section("gift_shop", List.of(CoasterControlPanel.SHOP_SHELF_ITEM, CoasterControlPanel.SOUVENIR_RACK_ITEM, CoasterControlPanel.PLUSH_TOY_ITEM, CoasterControlPanel.SHOP_TILL_ITEM, CoasterControlPanel.PRICE_TAG_ITEM, CoasterControlPanel.WINDOW_DISPLAY_ITEM, CoasterControlPanel.SHOPPING_BASKET_ITEM, CoasterControlPanel.GIFT_BAG)),
            new Section("first_aid", List.of(CoasterControlPanel.FIRST_AID_STATION_ITEM, CoasterControlPanel.DEFIBRILLATOR_CABINET_ITEM, CoasterControlPanel.LOST_CHILD_POINT_ITEM, CoasterControlPanel.FIRE_EXTINGUISHER_ITEM, CoasterControlPanel.EXIT_LIGHT_ITEM, CoasterControlPanel.EMERGENCY_PHONE_ITEM, CoasterControlPanel.PRAM_PARKING_ITEM)),
            new Section("guest_services", List.of(CoasterControlPanel.INFORMATION_DESK_ITEM, CoasterControlPanel.LOCKER_ITEM, CoasterControlPanel.LOCKER_KEY, CoasterControlPanel.ATM_ITEM, CoasterControlPanel.PHOTO_FRAME_WALL_ITEM, CoasterControlPanel.BROCHURE_STAND_ITEM, CoasterControlPanel.STROLLER_HIRE_RACK_ITEM, CoasterControlPanel.FEEDBACK_BOX_ITEM, CoasterControlPanel.STROLLER)),
            new Section("staff_cleaning", List.of(CoasterControlPanel.STAFF_DOOR_ITEM, CoasterControlPanel.STAFF_BADGE, CoasterControlPanel.JANITOR_CART_ITEM, CoasterControlPanel.SWEEPER_BRUSH, CoasterControlPanel.WET_FLOOR_SIGN_ITEM, CoasterControlPanel.LITTER_PICKER, CoasterControlPanel.STAFF_LOCKER_ITEM, CoasterControlPanel.STAFF_ROTA_BOARD_ITEM, CoasterControlPanel.LITTER_ITEM)),
            new Section("ride_maintenance", List.of(CoasterControlPanel.WORKSHOP_BENCH_ITEM, CoasterControlPanel.PARTS_SHELF_ITEM, CoasterControlPanel.INSPECTION_PIT_ITEM, CoasterControlPanel.TOOL_WALL_ITEM, CoasterControlPanel.TEST_DUMMY_ITEM, CoasterControlPanel.SAFETY_CHECKLIST_BOARD_ITEM, CoasterControlPanel.GREASE_STATION_ITEM, CoasterControlPanel.LIFT_JACK_ITEM)),
            new Section("park_hotel", List.of(CoasterControlPanel.RECEPTION_DESK_ITEM, CoasterControlPanel.HOTEL_ROOM_DOOR_ITEM, CoasterControlPanel.ROOM_KEY, CoasterControlPanel.LUGGAGE_TROLLEY_ITEM, CoasterControlPanel.BELLHOP_STAND_ITEM, CoasterControlPanel.POOL_BAR_ITEM, CoasterControlPanel.RESORT_SIGN_ITEM, CoasterControlPanel.HOTEL_BED_ITEM)),
            new Section("park_decor", List.of(CoasterControlPanel.BENCH_ITEM, CoasterControlPanel.DECK_CHAIR_ITEM, CoasterControlPanel.BIN_ITEM, CoasterControlPanel.LAMP_POST_ITEM, CoasterControlPanel.GARDEN_LIGHT_ITEM, CoasterControlPanel.CLOCK_ITEM, CoasterControlPanel.MAP_BOARD_ITEM, CoasterControlPanel.BOOTH_ITEM, CoasterControlPanel.SNACK_ITEM, CoasterControlPanel.CANDY_ITEM, CoasterControlPanel.FOUNTAIN_ITEM, CoasterControlPanel.PLANTER_ITEM, CoasterControlPanel.FLAG_ITEM, CoasterControlPanel.SPEAKER_ITEM, CoasterControlPanel.BOUNCY_ITEM, CoasterControlPanel.MISTER_ITEM))
    );

    /** Row (counted from the top of the tab) where each section's heading sits. Filled by build(). */
    public static final int[] SECTION_ROWS = new int[SECTIONS.size()];

    private TabSections() {
    }

    private static void empties(Consumer<ItemStack> out, int count) {
        for (int i = 0; i < count; i++) {
            out.accept(ItemStack.EMPTY);
        }
    }

    /**
     * @param grid   receives every slot of the tab grid, including the empty header and padding slots
     * @param search receives only the real items, for the search tab
     */
    public static void build(Consumer<ItemStack> grid, Consumer<ItemStack> search) {
        empties(grid, 9); // header row of the first section
        int row = 0;
        for (int s = 0; s < SECTIONS.size(); s++) {
            Section section = SECTIONS.get(s);
            SECTION_ROWS[s] = row;
            int count = 0;
            for (Supplier<? extends ItemLike> supplier : section.items()) {
                ItemStack stack = new ItemStack(supplier.get().asItem());
                grid.accept(stack);
                search.accept(stack);
                count++;
            }
            int itemRows = (count + 8) / 9;
            row += 1 + itemRows;
            if (s < SECTIONS.size() - 1) {
                empties(grid, (9 - count % 9) % 9); // finish the item row
                empties(grid, 9);                   // header row of the next section
            }
        }
    }
}
