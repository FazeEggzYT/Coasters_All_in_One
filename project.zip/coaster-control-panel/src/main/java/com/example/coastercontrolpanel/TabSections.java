package com.example.coastercontrolpanel;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * The sections of the "All in one" creative tab. To add a new section later, add one line to SECTIONS
 * and one language entry "gui.coastercontrolpanel.section.<key>".
 *
 * Layout in the tab grid (9 slots per row): a header row of 9 empty slots (the heading is drawn over it),
 * then the section's items, padded to a full row, then the next header row, and so on.
 */
public final class TabSections {
    public record Section(String key, List<Supplier<? extends ItemLike>> items) {
    }

    public static final List<Section> SECTIONS = List.of(
            new Section("control_panel", List.of(CoasterControlPanel.PANEL_ITEM)),
            new Section("announcer", List.of(CoasterControlPanel.ANNOUNCER_ITEM)),
            new Section("ride_gate", List.of(CoasterControlPanel.GATE_ITEM, CoasterControlPanel.GATE_SILVER_ITEM, CoasterControlPanel.GATE_RED_ITEM)),
            new Section("seat_timer", List.of(CoasterControlPanel.SEAT_TIMER_ITEM))
    );

    /** Row (counted from the top of the tab) where each section's heading sits. Filled by build(). */
    public static final int[] SECTION_ROWS = new int[SECTIONS.size()];

    private TabSections() {
    }

    private static void empties(Consumer<ItemStack> out, int count) {
        for (int i = 0; i < count; i++) {
            out.accept(ItemStack.EMPTY);
        }
    }

    /**
     * @param grid   receives every slot of the tab grid, including the empty header and padding slots
     * @param search receives only the real items, for the search tab
     */
    public static void build(Consumer<ItemStack> grid, Consumer<ItemStack> search) {
        empties(grid, 9); // header row of the first section
        int row = 0;
        for (int s = 0; s < SECTIONS.size(); s++) {
            Section section = SECTIONS.get(s);
            SECTION_ROWS[s] = row;
            int count = 0;
            for (Supplier<? extends ItemLike> supplier : section.items()) {
                ItemStack stack = new ItemStack(supplier.get().asItem());
                grid.accept(stack);
                search.accept(stack);
                count++;
            }
            int itemRows = (count + 8) / 9;
            row += 1 + itemRows;
            if (s < SECTIONS.size() - 1) {
                empties(grid, (9 - count % 9) % 9); // finish the item row
                empties(grid, 9);                   // header row of the next section
            }
        }
    }
}
