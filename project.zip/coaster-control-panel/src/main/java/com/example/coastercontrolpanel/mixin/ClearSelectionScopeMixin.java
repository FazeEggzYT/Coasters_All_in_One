package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.DriveTyre;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Drive Tyre: marks the span of ClearSelectionScopeMixin's chain checks so a held Drive Tyre is accepted as a Chain there. Optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.ClearCoasterTrackHotbarSelectionPayload", remap = false)
public class ClearSelectionScopeMixin {
    @Inject(method = {"lambda$handleOnServer$0"}, at = @At("HEAD"), remap = false, require = 0)
    private static void ccp$enter(CallbackInfo ci) {
        DriveTyre.enter();
    }

    @Inject(method = {"lambda$handleOnServer$0"}, at = @At("RETURN"), remap = false, require = 0)
    private static void ccp$exit(CallbackInfo ci) {
        DriveTyre.exit();
    }
}
