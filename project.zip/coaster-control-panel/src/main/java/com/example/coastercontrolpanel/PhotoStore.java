package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Server side: the latest photo of every camera, kept in the world folder as a small PNG. */
public final class PhotoStore {
    public static final int CHUNK = 30_000;
    public static final int MAX_BYTES = 600_000;

    private PhotoStore() {
    }

    private static Path file(MinecraftServer server, BlockPos camera) throws IOException {
        Path dir = server.getWorldPath(LevelResource.ROOT).resolve("coastercontrolpanel_photos");
        Files.createDirectories(dir);
        return dir.resolve(camera.asLong() + ".png");
    }

    public static boolean looksLikePng(byte[] b) {
        return b.length > 8 && (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G';
    }

    public static boolean save(MinecraftServer server, BlockPos camera, byte[] bytes) {
        try {
            Files.write(file(server, camera), bytes);
            return true;
        } catch (IOException e) {
            CoasterControlPanel.LOGGER.warn("Could not save camera photo", e);
            return false;
        }
    }

    @Nullable
    public static byte[] load(MinecraftServer server, BlockPos camera) {
        try {
            Path f = file(server, camera);
            return Files.exists(f) ? Files.readAllBytes(f) : null;
        } catch (IOException e) {
            return null;
        }
    }
}
