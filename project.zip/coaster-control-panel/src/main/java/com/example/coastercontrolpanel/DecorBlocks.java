package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/** The park decor blocks. Every one of them does something when you use it. */
public final class DecorBlocks {
    private DecorBlocks() {
    }

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty COLOR = IntegerProperty.create("color", 0, 15);

    /** A box drawn for a block facing north, turned to face another way. Coordinates are in 1/16 blocks. */
    static VoxelShape dbox(Direction d, double x1, double y1, double z1, double x2, double y2, double z2) {
        return switch (d) {
            case SOUTH -> Block.box(16 - x2, y1, 16 - z2, 16 - x1, y2, 16 - z1);
            case EAST -> Block.box(16 - z2, y1, x1, 16 - z1, y2, x2);
            case WEST -> Block.box(z1, y1, 16 - x2, z2, y2, 16 - x1);
            default -> Block.box(x1, y1, z1, x2, y2, z2);
        };
    }

    /** Base class: a block that faces the player. */
    public abstract static class Facing extends Block {
        protected Facing(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(FACING);
            extra(b);
        }

        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return shapeFor(s.getValue(FACING));
        }

        protected abstract VoxelShape shapeFor(Direction facing);
    }

    private static void say(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    // ------------------------------------------------------------------ seats

    /** Bench and deck chair: right-click to sit down. */
    public static class SeatBlock extends Facing {
        private final boolean chair;

        public SeatBlock(boolean chair, Properties p) {
            super(p);
            this.chair = chair;
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return chair ? dbox(f, 2, 0, 2, 14, 11, 14) : dbox(f, 0, 0, 3, 16, 10, 13);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (player.isShiftKeyDown() || player.isPassenger()) {
                return InteractionResult.PASS;
            }
            if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
                say(player, "seat_taken");
                return InteractionResult.CONSUME;
            }
            SeatEntity seat = new SeatEntity(CoasterControlPanel.SEAT.get(), level);
            seat.setPos(pos.getX() + 0.5, pos.getY() + (chair ? 0.3 : 0.25), pos.getZ() + 0.5);
            level.addFreshEntity(seat);
            player.startRiding(seat);
            return InteractionResult.CONSUME;
        }
    }

    // ------------------------------------------------------------------ litter bin

    public static final IntegerProperty FILL = IntegerProperty.create("fill", 0, 3);

    /** Throw things away. It fills up; sneak with an empty hand to empty it. */
    public static class BinBlock extends Facing {
        public BinBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(FILL, 0));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(FILL);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(3, 0, 3, 13, 14, 13);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.isEmpty()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (s.getValue(FILL) >= 3) {
                if (!level.isClientSide) {
                    say(player, "bin_full");
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (!level.isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                level.playSound(null, pos, SoundEvents.BUNDLE_INSERT, SoundSource.BLOCKS, 0.8F, 1.0F);
                if (level.random.nextInt(3) == 0) {
                    level.setBlock(pos, s.setValue(FILL, s.getValue(FILL) + 1), 3);
                }
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                if (player.isShiftKeyDown()) {
                    level.setBlock(pos, s.setValue(FILL, 0), 3);
                    level.playSound(null, pos, SoundEvents.BUNDLE_DROP_CONTENTS, SoundSource.BLOCKS, 0.8F, 1.0F);
                    say(player, "bin_emptied");
                } else {
                    say(player, "bin_level", s.getValue(FILL));
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ lights

    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    public static final IntegerProperty MODE = IntegerProperty.create("mode", 0, 2);

    /** Lamp post and garden light. Right-click: automatic (lights at night), always on, always off. */
    public static class LampBlock extends Block {
        private final boolean tall;

        public LampBlock(boolean tall, Properties p) {
            super(p);
            this.tall = tall;
            registerDefaultState(stateDefinition.any().setValue(LIT, false).setValue(MODE, 0));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(LIT, MODE);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return tall ? Block.box(5, 0, 5, 11, 16, 11) : Block.box(4, 0, 4, 12, 9, 12);
        }

        private boolean wanted(BlockState s, Level level) {
            return switch (s.getValue(MODE)) {
                case 1 -> true;
                case 2 -> false;
                default -> !level.isDay();
            };
        }

        @Override
        protected void onPlace(BlockState s, Level level, BlockPos pos, BlockState old, boolean moved) {
            if (!level.isClientSide) {
                level.scheduleTick(pos, this, 5);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            boolean want = wanted(s, level);
            if (want != s.getValue(LIT)) {
                level.setBlock(pos, s.setValue(LIT, want), 3);
            }
            level.scheduleTick(pos, this, 40);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                BlockState n = s.setValue(MODE, (s.getValue(MODE) + 1) % 3);
                n = n.setValue(LIT, wanted(n, level));
                level.setBlock(pos, n, 3);
                level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.6F, 1.2F);
                say(player, "lamp_mode_" + n.getValue(MODE));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ clock and map

    /** Right-click to read the park time. */
    public static class ClockBlock extends Facing {
        public ClockBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 3, 0, 5, 13, 16, 11);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                long t = level.getDayTime() % 24000L;
                long hours = (t / 1000 + 6) % 24;
                long minutes = (t % 1000) * 60 / 1000;
                say(player, "clock_time", String.format("%02d:%02d", hours, minutes));
                level.playSound(null, pos, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 0.6F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    /** Right-click to list the rides (Ride Signs) within 48 blocks, with distance and direction. */
    public static class MapBoardBlock extends Facing {
        public MapBoardBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 0, 0, 6, 16, 16, 10);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            record Found(String name, double dist, String dir) {
            }
            List<Found> found = new ArrayList<>();
            int radius = 48;
            int cx0 = (pos.getX() - radius) >> 4;
            int cx1 = (pos.getX() + radius) >> 4;
            int cz0 = (pos.getZ() - radius) >> 4;
            int cz1 = (pos.getZ() + radius) >> 4;
            for (int cx = cx0; cx <= cx1; cx++) {
                for (int cz = cz0; cz <= cz1; cz++) {
                    LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                    if (chunk == null) {
                        continue;
                    }
                    for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                        if (be instanceof RideSignBlockEntity sign && sign.kind() == SignKind.RIDE
                                && !sign.line1().isEmpty()) {
                            double dx = sign.getBlockPos().getX() - pos.getX();
                            double dz = sign.getBlockPos().getZ() - pos.getZ();
                            double dist = Math.sqrt(dx * dx + dz * dz);
                            if (dist <= radius) {
                                String[] names = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};
                                int idx = Math.floorMod((int) Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0), 8);
                                found.add(new Found(sign.line1(), dist, names[idx]));
                            }
                        }
                    }
                }
            }
            found.sort((a, b) -> Double.compare(a.dist, b.dist));
            if (found.isEmpty()) {
                say(player, "map_none");
            } else {
                player.sendSystemMessage(Component.translatable("message.coastercontrolpanel.map_title"));
                for (int i = 0; i < Math.min(6, found.size()); i++) {
                    Found f = found.get(i);
                    player.sendSystemMessage(Component.literal(" - " + f.name + "  " + Math.round(f.dist) + " blocks " + f.dir));
                }
            }
            return InteractionResult.CONSUME;
        }
    }

    // ------------------------------------------------------------------ booth

    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    /** Ticket booth. Right-click opens and closes the window. It gives a redstone signal while open. */
    public static class BoothBlock extends Facing {
        public BoothBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(OPEN, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(OPEN);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(0, 0, 0, 16, 16, 16);
        }

        @Override
        protected boolean isSignalSource(BlockState s) {
            return true;
        }

        @Override
        protected int getSignal(BlockState s, BlockGetter l, BlockPos p, Direction d) {
            return s.getValue(OPEN) ? 15 : 0;
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (!stack.is(Items.GOLD_NUGGET) || !s.getValue(OPEN)) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                Block.popResource(level, pos.relative(s.getValue(FACING)), new ItemStack(CoasterControlPanel.TICKET_ITEM.get()));
                level.playSound(null, pos, SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.BLOCKS, 0.8F, 1.4F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean open = !s.getValue(OPEN);
                level.setBlock(pos, s.setValue(OPEN, open), 3);
                level.playSound(null, pos, open ? SoundEvents.WOODEN_TRAPDOOR_OPEN : SoundEvents.WOODEN_TRAPDOOR_CLOSE,
                        SoundSource.BLOCKS, 0.8F, 1.0F);
                say(player, open ? "booth_open" : "booth_closed");
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ vending

    /** Pay one gold nugget, get something to eat. Right-click with a nugget. */
    public static class VendingBlock extends Facing {
        private final ItemStack[] stock;

        public VendingBlock(ItemStack[] stock, Properties p) {
            super(p);
            this.stock = stock;
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 1, 0, 2, 15, 16, 14);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (!stack.is(Items.GOLD_NUGGET)) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                ItemStack out = stock[level.random.nextInt(stock.length)].copy();
                Block.popResource(level, pos.relative(s.getValue(FACING)), out);
                level.playSound(null, pos, SoundEvents.DISPENSER_DISPENSE, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                say(player, "vending_hint");
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ fountain

    /** Empty hand: a drink. Glass bottle: fills it with water. */
    public static class FountainBlock extends Facing {
        public FountainBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Block.box(3, 0, 3, 13, 14, 13);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (!stack.is(Items.GLASS_BOTTLE)) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide) {
                ItemStack water = PotionContents.createItemStack(Items.POTION, Potions.WATER);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                if (!player.getInventory().add(water)) {
                    player.drop(water, false);
                }
                level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                if (player.getFoodData().needsFood()) {
                    player.getFoodData().eat(1, 0.1F);
                    level.playSound(null, pos, SoundEvents.GENERIC_DRINK, SoundSource.BLOCKS, 0.8F, 1.0F);
                } else {
                    say(player, "fountain_full");
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ planter and flag

    /** Right-click with a dye to change the colour of the flowers. */
    public static class PlanterBlock extends Block {
        public PlanterBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(COLOR, 14));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(COLOR);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(1, 0, 1, 15, 13, 15);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            return dye(stack, s, level, pos, player, COLOR);
        }
    }

    public static final BooleanProperty HALF = BooleanProperty.create("half");

    /** Right-click with a dye to recolour. Empty hand to raise or lower it to half mast. */
    public static class FlagBlock extends Block {
        public FlagBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(COLOR, 14).setValue(HALF, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(COLOR, HALF);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(6, 0, 6, 10, 16, 10);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            return dye(stack, s, level, pos, player, COLOR);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                level.setBlock(pos, s.setValue(HALF, !s.getValue(HALF)), 3);
                level.playSound(null, pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    private static ItemInteractionResult dye(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                             IntegerProperty prop) {
        if (!(stack.getItem() instanceof DyeItem dye)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, s.setValue(prop, dye.getDyeColor().getId()), 3);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 0.8F, 1.0F);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    // ------------------------------------------------------------------ speaker

    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

    /** Plays a short park tune. Right-click plays it once; with a redstone signal it repeats. */
    public static class SpeakerBlock extends Facing {
        public SpeakerBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(POWERED, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(POWERED);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 3, 0, 3, 13, 16, 13);
        }

        private void play(Level level, BlockPos pos) {
            level.playSound(null, pos, CoasterControlPanel.PARK_JINGLE.get(), SoundSource.RECORDS, 2.0F, 1.0F);
            if (level instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.NOTE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 1, 0.2, 0.1, 0.2, 1.0);
            }
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (level.isClientSide) {
                return;
            }
            boolean powered = level.hasNeighborSignal(pos);
            if (powered != s.getValue(POWERED)) {
                level.setBlock(pos, s.setValue(POWERED, powered), 3);
                if (powered) {
                    level.scheduleTick(pos, this, 1);
                }
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(POWERED)) {
                play(level, pos);
                level.scheduleTick(pos, this, 150);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                play(level, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ bouncy pad

    public static final IntegerProperty BOUNCE = IntegerProperty.create("bounce", 0, 2);

    /** Bounces you, and takes the fall damage away. Right-click to pick soft, medium or high. */
    public static class BouncyPadBlock extends Block {
        public BouncyPadBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(BOUNCE, 1));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(BOUNCE);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(0, 0, 0, 16, 4, 16);
        }

        @Override
        public void fallOn(Level level, BlockState s, BlockPos pos, Entity entity, float distance) {
            entity.causeFallDamage(distance, 0.0F, level.damageSources().fall());
        }

        @Override
        public void updateEntityAfterFallOn(BlockGetter level, Entity entity) {
            if (entity.isSuppressingBounce()) {
                super.updateEntityAfterFallOn(level, entity);
                return;
            }
            Vec3 v = entity.getDeltaMovement();
            if (v.y < 0.0) {
                BlockState s = level.getBlockState(entity.blockPosition().below());
                int b = s.getBlock() instanceof BouncyPadBlock ? s.getValue(BOUNCE) : 1;
                double factor = b == 0 ? 0.6 : b == 1 ? 0.95 : 1.4;
                entity.setDeltaMovement(v.x, Math.max(0.35, -v.y * factor), v.z);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                BlockState n = s.setValue(BOUNCE, (s.getValue(BOUNCE) + 1) % 3);
                level.setBlock(pos, n, 3);
                say(player, "bounce_" + n.getValue(BOUNCE));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ mister

    public static final BooleanProperty ON = BooleanProperty.create("on");

    /** A cooling mist. Right-click or a redstone signal switches it on. */
    public static class MisterBlock extends Block {
        public MisterBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(ON, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(ON);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(5, 0, 5, 11, 16, 11);
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (!level.isClientSide && level.hasNeighborSignal(pos) && !s.getValue(ON)) {
                level.setBlock(pos, s.setValue(ON, true), 3);
                level.scheduleTick(pos, this, 2);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(ON)) {
                return;
            }
            level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.2, 0.1, 0.2, 0.02);
            level.sendParticles(ParticleTypes.FALLING_WATER, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 3, 0.4, 0.1, 0.4, 0.0);
            if (random.nextInt(20) == 0) {
                level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.3F, 1.6F);
            }
            level.scheduleTick(pos, this, 4);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean on = !s.getValue(ON);
                level.setBlock(pos, s.setValue(ON, on), 3);
                if (on) {
                    level.scheduleTick(pos, this, 2);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
