package com.example.coastercontrolpanel;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/** A charged Defibrillator Cabinet within 12 blocks brings a dying player back. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class SafetyEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p) || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        if (SafetyBlocks.tryRevive(p)) {
            event.setCanceled(true);
        }
    }
}
