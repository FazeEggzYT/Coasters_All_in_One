package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The screens of the Guest Services pack and the Staff Rota Board. */
public final class ServiceScreens {
    private ServiceScreens() {
    }

    abstract static class SvcScreen extends GiftScreens.ParkScreen {
        protected SvcScreen(Component title, BlockPos pos, int w, int h, int accent) {
            super(title, pos, w, h, accent);
        }

        @Override
        protected void act(int action, int a, int b) {
            PacketDistributor.sendToServer(new ServiceActionPacket(pos, action, a, b));
        }

        protected boolean badge() {
            return minecraft != null && minecraft.player != null && StaffBlocks.hasBadge(minecraft.player);
        }
    }

    // ------------------------------------------------------------------ info desk and brochure stand

    public static class TextScreen extends SvcScreen {
        private final int count;
        private final int action;
        private final String guideKey;
        private final String helpKey;
        private final EditBox[] boxes;
        private boolean setup;
        private boolean dirty;

        public TextScreen(BlockPos pos, String titleKey, int accent, int count, int action, String guideKey, String helpKey) {
            super(Component.translatable(titleKey), pos, 270, 52 + count * 20 + 34, accent);
            this.count = count;
            this.action = action;
            this.guideKey = guideKey;
            this.helpKey = helpKey;
            this.boxes = new EditBox[count];
        }

        @Override
        protected void build() {
            GuestBlocks.TextBlockEntity be = entity(GuestBlocks.TextBlockEntity.class);
            for (int i = 0; i < count; i++) {
                boxes[i] = new EditBox(font, left + 8, top + 26 + i * 20, w - 16, 16, Component.empty());
                boxes[i].setMaxLength(60);
                boxes[i].setValue(be == null ? "" : be.lines[i]);
                boxes[i].setResponder(s -> dirty = true);
                boxes[i].visible = false;
                addRenderableWidget(boxes[i]);
            }
            if (action >= 0) {
                addRenderableWidget(Button.builder(Component.translatable(guideKey), b -> act(action, 0, 0))
                        .bounds(left + 8, top + h - 22, 110, 16).build());
            }
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup)
                    .bounds(action >= 0 ? left + 122 : left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            GuestBlocks.TextBlockEntity be = entity(GuestBlocks.TextBlockEntity.class);
            for (EditBox b : boxes) {
                b.visible = setup;
            }
            super.render(g, mx, my, pt);
            if (!setup) {
                row(g, left + 8, top + 24, w - 16, count * 20);
                for (int i = 0; i < count && be != null; i++) {
                    String s = be.lines[i];
                    g.drawString(font, s.isEmpty() ? "" : s, left + 14, top + 31 + i * 20, i == 0 && count == 7 ? 0xFFE070 : 0xFFFFFF, false);
                }
            }
            g.drawString(font, Component.translatable(helpKey), left + 8, top + h - 36, 0x8A8FA3, false);
        }

        @Override
        public void removed() {
            if (dirty) {
                List<String> out = new ArrayList<>();
                for (EditBox b : boxes) {
                    out.add(b == null ? "" : b.getValue());
                }
                PacketDistributor.sendToServer(new ServiceTextPacket(pos, 0, out));
            }
            super.removed();
        }
    }

    // ------------------------------------------------------------------ rota board

    public static class RotaScreen extends SvcScreen {
        private final EditBox[] boxes = new EditBox[12];
        private boolean dirty;

        public RotaScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.staff_rota_board"), pos, 280, 200, 0xFF5A4A9A);
        }

        @Override
        protected void build() {
            GuestBlocks.TextBlockEntity be = entity(GuestBlocks.TextBlockEntity.class);
            boolean edit = badge();
            for (int r = 0; r < 6; r++) {
                for (int c = 0; c < 2; c++) {
                    int i = r * 2 + c;
                    boxes[i] = new EditBox(font, left + 8 + c * 134, top + 40 + r * 20, c == 0 ? 120 : 130, 16, Component.empty());
                    boxes[i].setMaxLength(c == 0 ? 14 : 16);
                    boxes[i].setValue(be == null ? "" : be.lines[i]);
                    boxes[i].setEditable(edit);
                    boxes[i].setResponder(s -> dirty = true);
                    addRenderableWidget(boxes[i]);
                }
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.rota_name"), left + 10, top + 26, 0xFFE070, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.rota_shift"), left + 144, top + 26, 0xFFE070, false);
            g.drawString(font, Component.translatable(badge() ? "gui.coastercontrolpanel.rota_help" : "gui.coastercontrolpanel.rota_locked"),
                    left + 8, top + h - 36, 0x8A8FA3, false);
        }

        @Override
        public void removed() {
            if (dirty && badge()) {
                List<String> out = new ArrayList<>();
                for (EditBox b : boxes) {
                    out.add(b == null ? "" : b.getValue());
                }
                PacketDistributor.sendToServer(new ServiceTextPacket(pos, 0, out));
            }
            super.removed();
        }
    }

    // ------------------------------------------------------------------ ATM

    public static class AtmScreen extends SvcScreen {
        public AtmScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.atm"), pos, 270, 190, 0xFF2E8B57);
        }

        @Override
        protected void build() {
            for (int i = 0; i < 4; i++) {
                final int act = 20 + i;
                int y = top + 52 + i * 24;
                addRenderableWidget(Button.builder(Component.literal("x1"), b -> act(act, 1, 0)).bounds(left + w - 98, y, 40, 18).build());
                addRenderableWidget(Button.builder(Component.literal("x8"), b -> act(act, 8, 0)).bounds(left + w - 54, y, 40, 18).build());
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            int tokens = minecraft == null || minecraft.player == null ? 0 : ArcadeBlocks.count(minecraft.player, CoasterControlPanel.ARCADE_TOKEN.get());
            int ingots = minecraft == null || minecraft.player == null ? 0 : ArcadeBlocks.count(minecraft.player, Items.GOLD_INGOT);
            g.fill(left + 8, top + 24, left + w - 8, top + 46, 0xFF0E2A1A);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.atm_have", nuggets(), ingots, tokens), left + 14, top + 31, 0x7CFFB0, false);
            String[] keys = {"atm_1", "atm_2", "atm_3", "atm_4"};
            for (int i = 0; i < 4; i++) {
                int y = top + 52 + i * 24;
                row(g, left + 8, y - 2, w - 108, 22);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel." + keys[i]), left + 14, y + 5, 0xFFFFFF, false);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.atm_help"), left + 8, top + h - 36, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ photo frame wall

    public static class PhotoScreen extends SvcScreen {
        public PhotoScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.photo_frame_wall"), pos, 270, 170, 0xFF8A5A2E);
        }

        @Override
        protected void build() {
            for (int i = 0; i < 4; i++) {
                final int s = i;
                int x = left + 8 + (i % 2) * 130;
                int y = top + 26 + (i / 2) * 56;
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.photo_set"), b -> act(24, s, 0)).bounds(x + 46, y + 8, 76, 16).build());
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.photo_clear"), b -> act(25, s, 0)).bounds(x + 46, y + 28, 76, 16).build());
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            GuestBlocks.PhotoWallBlockEntity be = entity(GuestBlocks.PhotoWallBlockEntity.class);
            for (int i = 0; i < 4; i++) {
                int x = left + 8 + (i % 2) * 130;
                int y = top + 26 + (i / 2) * 56;
                row(g, x, y, 124, 50);
                g.fill(x + 6, y + 5, x + 42, y + 45, 0xFF5A3A1E);
                g.fill(x + 8, y + 7, x + 40, y + 43, 0xFFE8E0D0);
                if (be != null && !be.shown[i].isEmpty()) {
                    g.renderItem(be.shown[i], x + 16, y + 17);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.photo_help"), left + 8, top + h - 36, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ stroller hire rack

    public static class StrollerScreen extends SvcScreen {
        private boolean setup;
        private final List<Button> play = new ArrayList<>();
        private final List<Button> adm = new ArrayList<>();

        public StrollerScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.stroller_hire_rack"), pos, 250, 170, 0xFF3A8AA8);
        }

        @Override
        protected void build() {
            play.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.stroller_hire"), b -> act(30, 0, 0)).bounds(left + 16, top + 80, 100, 20).build()));
            play.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.stroller_return"), b -> act(31, 0, 0)).bounds(left + 124, top + 80, 100, 20).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("-"), b -> act(32, -1, 0)).bounds(left + 150, top + 52, 20, 16).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("+"), b -> act(32, 1, 0)).bounds(left + 174, top + 52, 20, 16).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("-"), b -> act(33, -1, 0)).bounds(left + 150, top + 74, 20, 16).build()));
            adm.add(addRenderableWidget(Button.builder(Component.literal("+"), b -> act(33, 1, 0)).bounds(left + 174, top + 74, 20, 16).build()));
            adm.add(addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.shop_collect"), b -> act(34, 0, 0)).bounds(left + 16, top + 98, 100, 16).build()));
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup).bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            GuestBlocks.StrollerBlockEntity be = entity(GuestBlocks.StrollerBlockEntity.class);
            for (Button b : play) {
                b.visible = !setup;
            }
            for (Button b : adm) {
                b.visible = setup;
            }
            super.render(g, mx, my, pt);
            if (be == null) {
                return;
            }
            row(g, left + 8, top + 24, w - 16, 44);
            for (int i = 0; i < be.capacity; i++) {
                int x = left + 14 + i * 28;
                boolean there = i < be.capacity - be.out;
                g.fill(x, top + 30, x + 22, top + 62, there ? 0xFF3A8AA8 : 0xFF2A2D3A);
                if (there) {
                    g.renderItem(new ItemStack(CoasterControlPanel.STROLLER.get()), x + 3, top + 38);
                }
            }
            if (!setup) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.stroller_price", be.price, be.refund()), left + 16, top + 106, 0xFFE070, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.stroller_avail", be.capacity - be.out, be.capacity), left + 16, top + 120, 0xC8C8D8, false);
            } else {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.stroller_cap", be.capacity), left + 16, top + 56, 0xFFE070, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.stroller_set_price", be.price), left + 16, top + 78, 0xFFE070, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.shop_takings", be.takings), left + 124, top + 102, 0x9EE6A0, false);
            }
        }
    }

    // ------------------------------------------------------------------ feedback box

    public static class FeedbackScreen extends SvcScreen {
        private EditBox box;

        public FeedbackScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.feedback_box"), pos, 290, 220, 0xFF9A6A2E);
        }

        @Override
        protected void build() {
            box = new EditBox(font, left + 8, top + 40, w - 80, 16, Component.empty());
            box.setMaxLength(80);
            addRenderableWidget(box);
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.feedback_send"), b -> {
                if (!box.getValue().isBlank()) {
                    PacketDistributor.sendToServer(new ServiceTextPacket(pos, 1, List.of(box.getValue())));
                    box.setValue("");
                }
            }).bounds(left + w - 66, top + 40, 58, 16).build());
            if (badge()) {
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.feedback_clear"), b -> act(40, 0, 0))
                        .bounds(left + 8, top + h - 22, 90, 16).build());
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.feedback_prompt"), left + 8, top + 26, 0xC8C8D8, false);
            if (badge()) {
                GuestBlocks.FeedbackBlockEntity be = entity(GuestBlocks.FeedbackBlockEntity.class);
                row(g, left + 8, top + 62, w - 16, 118);
                if (be != null) {
                    int n = be.notes.size();
                    for (int i = 0; i < 9 && i < n; i++) {
                        String s = be.notes.get(n - 1 - i);
                        if (s.length() > 46) {
                            s = s.substring(0, 45) + "…";
                        }
                        g.drawString(font, s, left + 12, top + 67 + i * 12, 0xFFFFFF, false);
                    }
                    g.drawString(font, Component.translatable("gui.coastercontrolpanel.feedback_count", n), left + 110, top + h - 18, 0x8A8FA3, false);
                }
            } else {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.feedback_thanks"), left + 8, top + 70, 0x8A8FA3, false);
            }
        }
    }
}
