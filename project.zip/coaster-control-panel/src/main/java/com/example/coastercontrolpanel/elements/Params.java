package com.example.coastercontrolpanel.elements;

/**
 * What the player can adjust. size 1..3 scales the element, side -1 (left) or +1 (right) picks the direction it
 * turns or shifts, rise is the extra height used by elements that have one (0..3).
 */
public record Params(int size, int side, int rise) {
    public static final Params DEFAULT = new Params(2, 1, 1);

    public Params clamped() {
        return new Params(Math.max(1, Math.min(3, size)), side < 0 ? -1 : 1, Math.max(0, Math.min(3, rise)));
    }
}
