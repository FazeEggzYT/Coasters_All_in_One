package com.example.coastercontrolpanel;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.joml.Vector3d;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Finds out whether a Coasters Simulated cart is inside a box.
 * It talks to Sable (the physics mod) and Coasters Simulated by name at runtime, so this mod
 * still builds and loads without them. If anything is missing, no cart is ever found.
 *
 * Carts are "sub levels" in Sable. We ask Sable for all sub levels of the dimension, keep the ones
 * Coasters Simulated says are carts, and test each cart's centre against the box.
 */
public final class CartScanner {
    private static boolean tried = false;
    private static boolean ok = false;
    private static boolean warned = false;
    private static Method getContainer;
    private static Method getAllSubLevels;
    private static Method isCart;
    private static Method cartCenter;

    private CartScanner() {
    }

    private static void init() {
        tried = true;
        try {
            ClassLoader cl = CartScanner.class.getClassLoader();
            Class<?> containerClass = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer", true, cl);
            Method best = null;
            for (Method m : containerClass.getMethods()) {
                if (m.getName().equals("getContainer") && m.getParameterCount() == 1
                        && java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && m.getParameterTypes()[0].isAssignableFrom(ServerLevel.class)) {
                    if (best == null || best.getParameterTypes()[0].isAssignableFrom(m.getParameterTypes()[0])) {
                        best = m;
                    }
                }
            }
            if (best == null) {
                return;
            }
            getContainer = best;
            getAllSubLevels = best.getReturnType().getMethod("getAllSubLevels");
            Class<?> resolve = Class.forName(
                    "dev.silvergold.simulatedcoasters.track.cart.CoasterCartResolve", true, cl);
            for (Method m : resolve.getMethods()) {
                if (m.getParameterCount() == 1 && m.getName().equals("isCartSubLevel")) {
                    isCart = m;
                } else if (m.getParameterCount() == 1 && m.getName().equals("cartCenterWorld")) {
                    cartCenter = m;
                }
            }
            ok = isCart != null && cartCenter != null;
        } catch (Throwable t) {
            ok = false;
        }
    }

    public static boolean isAvailable() {
        if (!tried) {
            init();
        }
        return ok;
    }

    /** True if the centre of any cart is inside the box. Server side only. */
    public static boolean anyCartIn(Level level, AABB box) {
        if (!(level instanceof ServerLevel server) || !isAvailable()) {
            return false;
        }
        try {
            Object container = getContainer.invoke(null, server);
            if (container == null) {
                return false;
            }
            Object all = getAllSubLevels.invoke(container);
            if (!(all instanceof List<?> list)) {
                return false;
            }
            for (Object sub : list) {
                if (!Boolean.TRUE.equals(isCart.invoke(null, sub))) {
                    continue;
                }
                Object c = cartCenter.invoke(null, sub);
                if (c instanceof Vector3d v && box.contains(v.x(), v.y(), v.z())) {
                    return true;
                }
            }
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                CoasterControlPanel.LOGGER.warn("Section Controller could not scan for carts: {}", t.toString());
            }
        }
        return false;
    }
}
