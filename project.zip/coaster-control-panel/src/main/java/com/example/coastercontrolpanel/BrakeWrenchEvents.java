package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Right-click an anchor of a Brake Run with the Create Wrench (not sneaking) to open its settings. Works on both of
 * its anchors. Sneak-right-click is left alone, so the base mod's wrench actions (removing a span) still work, and
 * anchors that are not part of a Brake Run are never touched.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class BrakeWrenchEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || event.getEntity().isShiftKeyDown()
                || !(event.getItemStack().getItem() instanceof WrenchItem)) {
            return;
        }
        BlockPos start = BrakeController.findStart(event.getLevel(), event.getPos());
        if (start == null) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            ClientHooks.openBrakeRun(start);
        }
    }
}
