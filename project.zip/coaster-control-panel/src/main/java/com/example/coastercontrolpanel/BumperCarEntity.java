package com.example.coastercontrolpanel;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A bumper car: a boat that drives on land. W/A/S/D steer it like a boat; it is held still while a nearby Bumper Cars
 * Console is not running, and cars that touch bounce off each other.
 */
public class BumperCarEntity extends Boat {
    private boolean up;
    private boolean locked;
    private int lockCheck;

    public BumperCarEntity(EntityType<? extends Boat> type, Level level) {
        super(type, level);
    }

    @Override
    public Item getDropItem() {
        return CoasterControlPanel.BUMPER_CAR_ITEM.get();
    }

    @Override
    public void setInput(boolean left, boolean right, boolean forward, boolean back) {
        if (locked) {
            super.setInput(false, false, false, false);
            up = false;
        } else {
            super.setInput(left, right, forward, back);
            up = forward;
        }
    }

    @Override
    public void tick() {
        if (lockCheck-- <= 0) {
            lockCheck = 5;
            locked = BumperBlockEntity.lockedAt(level(), this);
        }
        super.tick();
        if (locked) {
            setDeltaMovement(getDeltaMovement().multiply(0.5, 1.0, 0.5));
        } else if (up && onGround() && getControllingPassenger() != null) {
            Vec3 d = getDeltaMovement();
            double speed = Math.sqrt(d.x * d.x + d.z * d.z);
            if (speed < 0.32) {
                double yaw = Math.toRadians(getYRot());
                setDeltaMovement(d.add(-Math.sin(yaw) * 0.035, 0, Math.cos(yaw) * 0.035));
            }
        }
    }

    /** Bump: two cars push each other apart. */
    @Override
    public void push(Entity other) {
        if (other instanceof BumperCarEntity) {
            Vec3 away = position().subtract(other.position());
            double len = Math.sqrt(away.x * away.x + away.z * away.z);
            if (len > 1.0E-3) {
                setDeltaMovement(getDeltaMovement().add(away.x / len * 0.14, 0, away.z / len * 0.14));
            }
        } else {
            super.push(other);
        }
    }
}
