package com.example.coastercontrolpanel;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.Filterable;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.WrittenBookContent;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The Guest Services pack: Information Desk (joins with its neighbours), Locker and Locker Key, ATM, Photo Frame Wall,
 * Brochure Stand, Stroller Hire Rack and Guest Feedback Box. Also holds the text block entity shared with the Staff Rota Board.
 */
public final class GuestBlocks {
    private GuestBlocks() {
    }

    public static final BooleanProperty JOIN_P = BooleanProperty.create("jp");
    public static final BooleanProperty JOIN_N = BooleanProperty.create("jn");
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    /** A written book with the given lines on one page. */
    public static ItemStack book(String title, String author, List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) {
            if (!l.isBlank()) {
                sb.append(l).append('\n');
            }
        }
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        List<Filterable<Component>> pages = List.of(Filterable.passThrough(Component.literal(sb.toString())));
        String t = title.isBlank() ? "Park Guide" : title;
        stack.set(DataComponents.WRITTEN_BOOK_CONTENT,
                new WrittenBookContent(Filterable.passThrough(t.length() > 32 ? t.substring(0, 32) : t), author, 0, pages, true));
        return stack;
    }

    // ------------------------------------------------------------------ text (info desk, brochure stand, rota board)

    public interface TextHolder {
        int textLines();
    }

    public static class TextBlockEntity extends RestaurantBlocks.Syncing {
        public static final int MAX = 12;
        public final String[] lines = new String[MAX];

        public TextBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.TEXT_BE.get(), pos, state);
            for (int i = 0; i < MAX; i++) {
                lines[i] = "";
            }
        }

        public int count() {
            return getBlockState().getBlock() instanceof TextHolder t ? t.textLines() : 6;
        }

        public void apply(List<String> in) {
            for (int i = 0; i < MAX; i++) {
                String s = i < in.size() ? in.get(i) : "";
                lines[i] = i < count() ? s : "";
            }
            changed();
        }

        public List<String> list() {
            List<String> out = new ArrayList<>();
            for (int i = 0; i < count(); i++) {
                out.add(lines[i]);
            }
            return out;
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag l = new ListTag();
            for (String s : lines) {
                l.add(StringTag.valueOf(s));
            }
            tag.put("Lines", l);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ListTag l = tag.getList("Lines", Tag.TAG_STRING);
            for (int i = 0; i < MAX; i++) {
                lines[i] = i < l.size() ? l.getString(i) : "";
            }
        }
    }

    // ------------------------------------------------------------------ information desk

    public static class InfoDeskBlock extends RestaurantBlocks.FacingEntityBlock implements TextHolder {
        public static final MapCodec<InfoDeskBlock> CODEC = simpleCodec(InfoDeskBlock::new);

        public InfoDeskBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(JOIN_P, false).setValue(JOIN_N, false));
        }

        @Override
        public int textLines() {
            return 6;
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(JOIN_P, JOIN_N);
        }

        private static boolean joined(LevelAccessor level, BlockPos pos, Direction facing, Direction side) {
            BlockState o = level.getBlockState(pos.relative(side));
            return o.getBlock() instanceof InfoDeskBlock && o.getValue(DecorBlocks.FACING) == facing;
        }

        private static BlockState connect(BlockState s, LevelAccessor level, BlockPos pos) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return s.setValue(JOIN_P, joined(level, pos, f, f.getClockWise())).setValue(JOIN_N, joined(level, pos, f, f.getCounterClockWise()));
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return connect(super.getStateForPlacement(c), c.getLevel(), c.getClickedPos());
        }

        @Override
        protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                         BlockPos pos, BlockPos neighborPos) {
            return dir.getAxis().isHorizontal() ? connect(state, level, pos) : state;
        }

        /** The first desk of the run: its text is the one the whole run shares. */
        public static BlockPos master(Level level, BlockPos pos) {
            BlockPos cur = pos;
            for (int i = 0; i < 32; i++) {
                BlockState s = level.getBlockState(cur);
                if (!(s.getBlock() instanceof InfoDeskBlock) || !s.getValue(JOIN_N)) {
                    break;
                }
                cur = cur.relative(s.getValue(DecorBlocks.FACING).getCounterClockWise());
            }
            return cur;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 2, 16, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new TextBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(0, master(level, pos));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    public static class BrochureBlock extends RestaurantBlocks.FacingEntityBlock implements TextHolder {
        public static final MapCodec<BrochureBlock> CODEC = simpleCodec(BrochureBlock::new);

        public BrochureBlock(Properties p) {
            super(p);
        }

        @Override
        public int textLines() {
            return 7;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 3, 0, 4, 13, 16, 12);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new TextBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(1, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ locker and key

    public static class LockerBlockEntity extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
        @Nullable
        public UUID lockId;

        public LockerBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.LOCKER_BE.get(), pos, state);
        }

        @Override
        public int getContainerSize() {
            return 27;
        }

        @Override
        protected Component getDefaultName() {
            return getBlockState().getBlock() instanceof LockerBlock b && b.staff
                    ? Component.translatable("block.coastercontrolpanel.staff_locker")
                    : Component.translatable("block.coastercontrolpanel.locker");
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return ChestMenu.threeRows(id, inv, this);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
            if (lockId != null) {
                tag.putUUID("Lock", lockId);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
            lockId = tag.hasUUID("Lock") ? tag.getUUID("Lock") : null;
        }
    }

    public static class LockerBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<LockerBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
                propertiesCodec(), Codec.BOOL.fieldOf("staff").forGetter(b -> b.staff)).apply(i, LockerBlock::new));
        public final boolean staff;

        public LockerBlock(Properties p, boolean staff) {
            super(p);
            this.staff = staff;
            registerDefaultState(defaultBlockState().setValue(OPEN, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(OPEN);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(OPEN, false);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 0, 3, 15, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new LockerBlockEntity(pos, state);
        }

        private void open(Level level, BlockPos pos, BlockState s, LockerBlockEntity be, Player player) {
            player.openMenu(be);
            level.setBlock(pos, s.setValue(OPEN, true), 3);
            level.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 0.5F, 1.4F);
            level.scheduleTick(pos, this, 20);
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(OPEN)) {
                return;
            }
            BlockEntity be = level.getBlockEntity(pos);
            for (Player p : level.players()) {
                if (p.containerMenu instanceof ChestMenu cm && cm.getContainer() == be) {
                    level.scheduleTick(pos, this, 20);
                    return;
                }
            }
            level.setBlock(pos, s.setValue(OPEN, false), 3);
            level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.5F, 1.4F);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (!(level.getBlockEntity(pos) instanceof LockerBlockEntity be)) {
                return InteractionResult.CONSUME;
            }
            if (staff) {
                if (!StaffBlocks.hasBadge(player)) {
                    say(player, "staff_only");
                    return InteractionResult.CONSUME;
                }
                open(level, pos, s, be, player);
                return InteractionResult.CONSUME;
            }
            ItemStack held = player.getMainHandItem();
            if (be.lockId == null) {
                be.lockId = UUID.randomUUID();
                be.setChanged();
                ItemStack key = new ItemStack(CoasterControlPanel.LOCKER_KEY.get());
                CompoundTag tag = new CompoundTag();
                tag.putUUID("Lock", be.lockId);
                key.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
                ArcadeBlocks.give(player, key);
                say(player, "locker_claimed");
                open(level, pos, s, be, player);
            } else if (LockerKeyItem.matches(held, be.lockId)) {
                if (player.isShiftKeyDown()) {
                    be.lockId = null;
                    be.setChanged();
                    say(player, "locker_freed");
                } else {
                    open(level, pos, s, be, player);
                }
            } else {
                level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.4F, 1.8F);
                say(player, "locker_locked");
            }
            return InteractionResult.CONSUME;
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof LockerBlockEntity c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    public static class LockerKeyItem extends Item {
        public LockerKeyItem(Properties p) {
            super(p.stacksTo(1));
        }

        @Nullable
        public static UUID id(ItemStack s) {
            CompoundTag t = s.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
            return t.hasUUID("Lock") ? t.getUUID("Lock") : null;
        }

        public static boolean matches(ItemStack s, UUID lock) {
            return s.getItem() instanceof LockerKeyItem && lock.equals(id(s));
        }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            UUID id = id(stack);
            tip.add(Component.translatable("item.coastercontrolpanel.locker_key.tip", id == null ? "?" : id.toString().substring(0, 4).toUpperCase()));
        }
    }

    // ------------------------------------------------------------------ ATM

    public static class AtmBlock extends DecorBlocks.Facing {
        public AtmBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 1, 0, 3, 15, 16, 14);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(3, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        /** Actions 20..23. times is how many swaps (1 or 8). */
        public static void exchange(ServerPlayer p, int action, int times) {
            times = Math.max(1, Math.min(8, times));
            for (int i = 0; i < times; i++) {
                boolean ok = switch (action) {
                    case 20 -> swap(p, Items.GOLD_NUGGET, 9, new ItemStack(Items.GOLD_INGOT));
                    case 21 -> swap(p, Items.GOLD_INGOT, 1, new ItemStack(Items.GOLD_NUGGET, 9));
                    case 22 -> swap(p, Items.GOLD_NUGGET, 5, new ItemStack(CoasterControlPanel.ARCADE_TOKEN.get(), 10));
                    default -> swap(p, CoasterControlPanel.ARCADE_TOKEN.get(), 10, new ItemStack(Items.GOLD_NUGGET, 3));
                };
                if (!ok) {
                    say(p, "atm_short");
                    return;
                }
            }
            p.level().playSound(null, p.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.7F, 1.4F);
        }

        private static boolean swap(ServerPlayer p, Item give, int amount, ItemStack get) {
            if (!p.getAbilities().instabuild) {
                if (ArcadeBlocks.count(p, give) < amount) {
                    return false;
                }
                ArcadeBlocks.take(p, give, amount);
            }
            ArcadeBlocks.give(p, get);
            return true;
        }
    }

    // ------------------------------------------------------------------ photo frame wall

    public static class PhotoWallBlockEntity extends RestaurantBlocks.Syncing {
        public final ItemStack[] shown = {ItemStack.EMPTY, ItemStack.EMPTY, ItemStack.EMPTY, ItemStack.EMPTY};

        public PhotoWallBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PHOTO_WALL_BE.get(), pos, state);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag l = new ListTag();
            for (ItemStack s : shown) {
                l.add(s.saveOptional(registries));
            }
            tag.put("Shown", l);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ListTag l = tag.getList("Shown", Tag.TAG_COMPOUND);
            for (int i = 0; i < 4; i++) {
                shown[i] = i < l.size() ? ItemStack.parseOptional(registries, l.getCompound(i)) : ItemStack.EMPTY;
            }
        }
    }

    public static class PhotoWallBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<PhotoWallBlock> CODEC = simpleCodec(PhotoWallBlock::new);

        public PhotoWallBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 13, 16, 16, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PhotoWallBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(4, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ stroller hire rack

    public static class StrollerItem extends Item {
        public StrollerItem(Properties p) {
            super(p.stacksTo(1));
        }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            tip.add(Component.translatable("item.coastercontrolpanel.stroller.tip"));
        }
    }

    public static class StrollerBlockEntity extends RestaurantBlocks.Syncing {
        public int capacity = 4;
        public int out;
        public int price = 6;
        public int takings;

        public StrollerBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.STROLLER_BE.get(), pos, state);
        }

        public int refund() {
            return price / 2;
        }

        public void hire(ServerPlayer p) {
            if (capacity - out <= 0) {
                say(p, "stroller_none");
                return;
            }
            if (!p.getAbilities().instabuild) {
                if (ArcadeBlocks.count(p, Items.GOLD_NUGGET) < price) {
                    say(p, "shop_poor", price);
                    return;
                }
                ArcadeBlocks.take(p, Items.GOLD_NUGGET, price);
                takings += price - refund();
            }
            out++;
            ArcadeBlocks.give(p, new ItemStack(CoasterControlPanel.STROLLER.get()));
            say(p, "stroller_hired", refund());
            changed();
        }

        public void giveBack(ServerPlayer p) {
            for (ItemStack s : p.getInventory().items) {
                if (s.is(CoasterControlPanel.STROLLER.get())) {
                    s.shrink(1);
                    out = Math.max(0, out - 1);
                    if (!p.getAbilities().instabuild && refund() > 0) {
                        ArcadeBlocks.give(p, new ItemStack(Items.GOLD_NUGGET, refund()));
                    }
                    say(p, "stroller_returned", refund());
                    changed();
                    return;
                }
            }
            say(p, "stroller_nothing");
        }

        public void collect(ServerPlayer p) {
            int left = takings;
            takings = 0;
            if (left <= 0) {
                say(p, "shop_no_takings");
                return;
            }
            while (left > 0) {
                int t = Math.min(64, left);
                ArcadeBlocks.give(p, new ItemStack(Items.GOLD_NUGGET, t));
                left -= t;
            }
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Capacity", capacity);
            tag.putInt("Out", out);
            tag.putInt("Price", price);
            tag.putInt("Takings", takings);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            capacity = tag.contains("Capacity") ? tag.getInt("Capacity") : 4;
            out = tag.getInt("Out");
            price = tag.contains("Price") ? Math.max(1, tag.getInt("Price")) : 6;
            takings = tag.getInt("Takings");
        }
    }

    public static class StrollerBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<StrollerBlock> CODEC = simpleCodec(StrollerBlock::new);

        public StrollerBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 2, 16, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new StrollerBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(5, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ guest feedback box

    public static class FeedbackBlockEntity extends RestaurantBlocks.Syncing {
        public static final int MAX = 30;
        public final List<String> notes = new ArrayList<>();

        public FeedbackBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.FEEDBACK_BE.get(), pos, state);
        }

        public void add(ServerPlayer p, String text) {
            String t = text.strip();
            if (t.isEmpty()) {
                return;
            }
            notes.add(p.getGameProfile().getName() + ": " + (t.length() > 80 ? t.substring(0, 80) : t));
            while (notes.size() > MAX) {
                notes.remove(0);
            }
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.BLOCKS, 0.8F, 1.2F);
            }
            say(p, "feedback_thanks");
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag l = new ListTag();
            for (String s : notes) {
                l.add(StringTag.valueOf(s));
            }
            tag.put("Notes", l);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            notes.clear();
            ListTag l = tag.getList("Notes", Tag.TAG_STRING);
            for (int i = 0; i < l.size(); i++) {
                notes.add(l.getString(i));
            }
        }
    }

    public static class FeedbackBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<FeedbackBlock> CODEC = simpleCodec(FeedbackBlock::new);

        public FeedbackBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 3, 0, 4, 13, 14, 12);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new FeedbackBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(6, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
