package com.example.coastercontrolpanel;

import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the settings chosen in the Brake Run screen. The server checks everything before applying it. */
public record BrakeConfigPacket(BlockPos start, CompoundTag settings) implements CustomPacketPayload {
    public static final Type<BrakeConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "brake_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BrakeConfigPacket> CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BrakeConfigPacket::start,
            ByteBufCodecs.COMPOUND_TAG, BrakeConfigPacket::settings,
            BrakeConfigPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BrakeConfigPacket p, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(p.start.getX() + 0.5, p.start.getY() + 0.5, p.start.getZ() + 0.5) > 4096.0
                || !(player.getMainHandItem().getItem() instanceof WrenchItem
                || player.getOffhandItem().getItem() instanceof WrenchItem)) {
            return;
        }
        if (!player.level().isLoaded(p.start)) {
            return;
        }
        if (player.level().getBlockEntity(p.start) instanceof DriveTyre.Holder h && h.ccp$brake() != null) {
            h.ccp$setBrake(BrakeSettings.fromTag(p.settings)); // clamps every value
            h.ccp$sync();
        }
    }
}
