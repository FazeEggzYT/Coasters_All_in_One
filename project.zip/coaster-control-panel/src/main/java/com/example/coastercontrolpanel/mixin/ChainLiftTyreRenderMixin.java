package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.DriveTyre;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Drive Tyre: lifts placed with a Drive Tyre are drawn with the tyre texture instead of the chain texture. Client only, optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.client.track.ChainLiftSpanRenderer", remap = false)
public class ChainLiftTyreRenderMixin {
    @ModifyArg(method = "render", remap = false, require = 0, index = 1,
            at = @At(value = "INVOKE", remap = false,
                    target = "Ldev/silvergold/simulatedcoasters/client/track/ChainLiftSpanRenderer;anchorRenderCenter(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;D)Lnet/minecraft/world/phys/Vec3;"))
    private static BlockPos ccp$whichAnchor(BlockPos pos) {
        DriveTyre.rendering(pos);
        return pos;
    }

    @ModifyArg(method = "render", remap = false, require = 0, index = 0,
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/RenderType;entityCutout(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"))
    private static ResourceLocation ccp$texture(ResourceLocation original) {
        return DriveTyre.textureFor(original);
    }
}
