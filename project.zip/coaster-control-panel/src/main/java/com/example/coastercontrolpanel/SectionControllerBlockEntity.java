package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;

/**
 * One block of a block-section system.
 * Slot 0 (input):  "next section occupied". Listens for the Occupied signal of the next controller.
 * Slot 1 (output): "occupied". On while a cart is inside this controller's box.
 * Slot 2 (output): "stop". On while the next section is occupied. Wire it to a brake or gate.
 */
public class SectionControllerBlockEntity extends BlockEntity {
    private static final int SCAN_EVERY = 5;

    private final SimpleContainer frequencies = new SimpleContainer(3);
    private int range = 8;     // blocks each way sideways
    private int height = 4;    // blocks up and down
    private int clearDelay = 1; // seconds the cart must be gone before "occupied" turns off

    private boolean occupied = false;
    private boolean stopOn = false;
    private long lastSeen = -100000L;
    private int received = 0;

    private final Link[] links = new Link[3];
    private boolean registered = false;
    private boolean loading = false;

    public SectionControllerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SECTION_BE.get(), pos, state);
        links[0] = new Link(0);
        links[1] = new Link(1);
        links[2] = new Link(2);
        frequencies.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLinks();
                    registerLinks();
                }
            }
        });
    }

    public SimpleContainer getFrequencies() {
        return frequencies;
    }

    public int getRange() {
        return range;
    }

    public int getHeight() {
        return height;
    }

    public int getClearDelay() {
        return clearDelay;
    }

    @Nullable
    public static SectionControllerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof SectionControllerBlockEntity s ? s : null;
    }

    public AABB box() {
        return new AABB(worldPosition).inflate(range, height, range);
    }

    public void applyConfig(int newRange, int newHeight, int newClear) {
        range = Math.max(1, Math.min(48, newRange));
        height = Math.max(1, Math.min(24, newHeight));
        clearDelay = Math.max(0, Math.min(30, newClear));
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** Draws the edges of the box with particles so you can see what it covers. */
    public void showArea() {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        AABB b = box();
        double[] xs = {b.minX, b.maxX};
        double[] ys = {b.minY, b.maxY};
        double[] zs = {b.minZ, b.maxZ};
        for (double y : ys) {
            for (double z : zs) {
                line(server, b.minX, y, z, b.maxX, y, z);
            }
            for (double x : xs) {
                line(server, x, y, b.minZ, x, y, b.maxZ);
            }
        }
        for (double x : xs) {
            for (double z : zs) {
                line(server, x, b.minY, z, x, b.maxY, z);
            }
        }
    }

    private void line(ServerLevel server, double x1, double y1, double z1, double x2, double y2, double z2) {
        double len = Math.max(Math.abs(x2 - x1), Math.max(Math.abs(y2 - y1), Math.abs(z2 - z1)));
        int n = (int) Math.max(1, Math.min(40, Math.ceil(len / 1.5)));
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            server.sendParticles(ParticleTypes.END_ROD, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t,
                    z1 + (z2 - z1) * t, 1, 0, 0, 0, 0);
        }
    }

    // ---------------------------------------------------------------- lifecycle and links

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLinks();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLinks();
    }

    @Override
    public void setRemoved() {
        unregisterLinks();
        super.setRemoved();
    }

    private void registerLinks() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        for (int i = 0; i < 3; i++) {
            ItemStack stack = frequencies.getItem(i);
            links[i].alive = !stack.isEmpty();
            links[i].key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        }
        for (Link l : links) {
            if (l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, l);
            }
        }
        received = 0;
        for (Link l : links) {
            if (l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, l);
            }
        }
    }

    private void unregisterLinks() {
        if (!registered) {
            return;
        }
        registered = false;
        for (Link l : links) {
            if (level != null && l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, l);
            }
            l.alive = false;
        }
        received = 0;
    }

    private void push(int slot) {
        if (level != null && !level.isClientSide && links[slot].alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, links[slot]);
        }
    }

    // ---------------------------------------------------------------- ticking

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        long now = level.getGameTime();
        if (now % SCAN_EVERY == 0) {
            if (CartScanner.anyCartIn(level, box())) {
                lastSeen = now;
            }
            boolean should = now - lastSeen <= clearDelay * 20L;
            if (should != occupied) {
                occupied = should;
                BlockState state = getBlockState();
                if (state.hasProperty(SectionControllerBlock.OCCUPIED)) {
                    level.setBlock(worldPosition, state.setValue(SectionControllerBlock.OCCUPIED, occupied), 3);
                }
                push(1);
            }
        }
        boolean stop = received > 0;
        if (stop != stopOn) {
            stopOn = stop;
            push(2);
        }
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        for (int i = 0; i < 3; i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Range", range);
        tag.putInt("Height", height);
        tag.putInt("Clear", clearDelay);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < 3; i++) {
            frequencies.setItem(i, list.get(i));
        }
        if (tag.contains("Range")) {
            range = tag.getInt("Range");
            height = tag.getInt("Height");
            clearDelay = tag.getInt("Clear");
        }
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- Redstone Link endpoints

    private class Link implements IRedstoneLinkable {
        private final int slot;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int slot) {
            this.slot = slot;
        }

        @Override
        public int getTransmittedStrength() {
            return switch (slot) {
                case 1 -> occupied ? 15 : 0;
                case 2 -> stopOn ? 15 : 0;
                default -> 0;
            };
        }

        @Override
        public void setReceivedStrength(int power) {
            if (slot == 0) {
                received = power;
            }
        }

        @Override
        public boolean isListening() {
            return slot == 0;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
