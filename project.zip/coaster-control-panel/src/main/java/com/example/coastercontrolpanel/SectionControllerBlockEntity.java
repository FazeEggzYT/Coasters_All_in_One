package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.List;

import javax.annotation.Nullable;

/**
 * One block of a block-section system.
 * Slot 0 (input):  "next section occupied". Listens for the Occupied signal of the next controller.
 * Slot 1 (output): "occupied". On while a cart is inside this controller's box.
 * Slot 2 (output): "stop". On while the next section is occupied. Wire it to a brake or gate.
 */
public class SectionControllerBlockEntity extends BlockEntity implements TrackZone {
    private static final int SCAN_EVERY = 5;

    private final SimpleContainer frequencies = new SimpleContainer(3);
    private static final double RADIUS = 3.5; // blocks from the track line that still count
    private int clearDelay = 1; // seconds the cart must be gone before "occupied" turns off

    // Optional: the section follows the track between two anchors instead of a box.
    @Nullable
    private BlockPos anchorA;
    @Nullable
    private BlockPos anchorB;
    private List<Vec3> path = List.of();
    private long pathBuilt = -100000L;

    private boolean occupied = false;
    private boolean stopOn = false;
    private long lastSeen = -100000L;
    private int received = 0;

    private final Link[] links = new Link[3];
    private boolean registered = false;
    private boolean loading = false;

    public SectionControllerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SECTION_BE.get(), pos, state);
        links[0] = new Link(0);
        links[1] = new Link(1);
        links[2] = new Link(2);
        frequencies.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLinks();
                    registerLinks();
                }
            }
        });
    }

    public SimpleContainer getFrequencies() {
        return frequencies;
    }

    @Nullable
    public BlockPos getAnchorA() {
        return anchorA;
    }

    @Nullable
    public BlockPos getAnchorB() {
        return anchorB;
    }

    public int getClearDelay() {
        return clearDelay;
    }

    @Nullable
    public static SectionControllerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof SectionControllerBlockEntity s ? s : null;
    }

    public boolean hasTrack() {
        return anchorA != null && anchorB != null;
    }

    /** Follow the track between two anchors. A narrow reach works best, so it is set to 3. */
    @Override
    public int setTrack(BlockPos a, BlockPos b) {
        anchorA = a;
        anchorB = b;
        rebuildPath();
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
        return path.size();
    }

    public void clearTrack() {
        anchorA = null;
        anchorB = null;
        path = List.of();
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    private void rebuildPath() {
        pathBuilt = level != null ? level.getGameTime() : 0L;
        path = (level != null && hasTrack()) ? AnchorTrack.sample(level, anchorA, anchorB) : List.of();
    }

    public void applyConfig(int newClear) {
        clearDelay = Math.max(0, Math.min(30, newClear));
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** Draws the track of the section with particles: green at the start, flame at the end. */
    public void showArea() {
        if (!(level instanceof ServerLevel server) || path.isEmpty()) {
            return;
        }
        int step = Math.max(1, path.size() / 150);
        for (int i = 0; i < path.size(); i += step) {
            Vec3 p = path.get(i);
            server.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        Vec3 a = path.get(0);
        Vec3 b = path.get(path.size() - 1);
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, a.x, a.y + 0.5, a.z, 12, 0.3, 0.3, 0.3, 0);
        server.sendParticles(ParticleTypes.FLAME, b.x, b.y + 0.5, b.z, 12, 0.2, 0.3, 0.2, 0.01);
    }

    // ---------------------------------------------------------------- lifecycle and links

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLinks();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLinks();
    }

    @Override
    public void setRemoved() {
        unregisterLinks();
        super.setRemoved();
    }

    private void registerLinks() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        for (int i = 0; i < 3; i++) {
            ItemStack stack = frequencies.getItem(i);
            links[i].alive = !stack.isEmpty();
            links[i].key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        }
        for (Link l : links) {
            if (l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, l);
            }
        }
        received = 0;
        for (Link l : links) {
            if (l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, l);
            }
        }
    }

    private void unregisterLinks() {
        if (!registered) {
            return;
        }
        registered = false;
        for (Link l : links) {
            if (level != null && l.alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, l);
            }
            l.alive = false;
        }
        received = 0;
    }

    private void push(int slot) {
        if (level != null && !level.isClientSide && links[slot].alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, links[slot]);
        }
    }

    // ---------------------------------------------------------------- ticking

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        long now = level.getGameTime();
        if (now % SCAN_EVERY == 0) {
            boolean found = false;
            if (hasTrack()) {
                if (now - pathBuilt >= 100 || (path.isEmpty() && now - pathBuilt >= 20)) {
                    rebuildPath();
                }
                found = CartScanner.anyCartNear(level, path, RADIUS);
            }
            if (found) {
                lastSeen = now;
            }
            boolean should = now - lastSeen <= clearDelay * 20L;
            if (should != occupied) {
                occupied = should;
                BlockState state = getBlockState();
                if (state.hasProperty(SectionControllerBlock.OCCUPIED)) {
                    level.setBlock(worldPosition, state.setValue(SectionControllerBlock.OCCUPIED, occupied), 3);
                }
                push(1);
            }
        }
        boolean stop = received > 0;
        if (stop != stopOn) {
            stopOn = stop;
            push(2);
        }
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        for (int i = 0; i < 3; i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Clear", clearDelay);
        if (anchorA != null) {
            tag.putLong("AnchorA", anchorA.asLong());
        }
        if (anchorB != null) {
            tag.putLong("AnchorB", anchorB.asLong());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < 3; i++) {
            frequencies.setItem(i, list.get(i));
        }
        if (tag.contains("Clear")) {
            clearDelay = tag.getInt("Clear");
        }
        anchorA = tag.contains("AnchorA") ? BlockPos.of(tag.getLong("AnchorA")) : null;
        anchorB = tag.contains("AnchorB") ? BlockPos.of(tag.getLong("AnchorB")) : null;
        pathBuilt = -100000L;
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- Redstone Link endpoints

    private class Link implements IRedstoneLinkable {
        private final int slot;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int slot) {
            this.slot = slot;
        }

        @Override
        public int getTransmittedStrength() {
            return switch (slot) {
                case 1 -> occupied ? 15 : 0;
                case 2 -> stopOn ? 15 : 0;
                default -> 0;
            };
        }

        @Override
        public void setReceivedStrength(int power) {
            if (slot == 0) {
                received = power;
            }
        }

        @Override
        public boolean isListening() {
            return slot == 0;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
