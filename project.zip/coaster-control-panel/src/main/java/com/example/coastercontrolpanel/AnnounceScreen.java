package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * The Announcement Panel on screen. Tap a button to play its announcement for everyone nearby.
 * The world keeps running and WASD still moves you, like the Ride Control Panel.
 */
public class AnnounceScreen extends Screen {
    private static final int PANEL_W = 222;
    private static final int PANEL_H = 220;
    private static final int BTN_W = 100;
    private static final int BTN_H = 32;

    private final BlockPos pos;
    private int flashRow = -1;
    private long flashUntil = 0L;

    public AnnounceScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.announce_title"));
        this.pos = pos;
    }

    @Nullable
    private AnnouncePanelBlockEntity panel() {
        if (minecraft == null || minecraft.level == null) {
            return null;
        }
        return minecraft.level.getBlockEntity(pos) instanceof AnnouncePanelBlockEntity p ? p : null;
    }

    private int panelX() {
        return 8;
    }

    private int panelY() {
        return height - 8 - PANEL_H;
    }

    private int buttonX(int row) {
        return panelX() + 8 + (row % 2) * 106;
    }

    private int buttonY(int row) {
        return panelY() + 30 + (row / 2) * 37;
    }

    private int rowAt(double mx, double my) {
        AnnouncePanelBlockEntity p = panel();
        for (int r = 0; r < AnnouncePanelBlockEntity.ROWS; r++) {
            if (p != null && p.getName(r).isEmpty()) {
                continue;
            }
            int bx = buttonX(r);
            int by = buttonY(r);
            if (mx >= bx && mx < bx + BTN_W && my >= by && my < by + BTN_H) {
                return r;
            }
        }
        return -1;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur: you keep seeing the ride. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void tick() {
        if (panel() == null) {
            onClose();
            return;
        }
        // Keep walking: screens normally stop the movement keys from working.
        if (minecraft != null) {
            Options o = minecraft.options;
            long window = minecraft.getWindow().getWindow();
            KeyMapping[] moves = {o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keyShift, o.keySprint};
            for (KeyMapping k : moves) {
                if (k.getKey().getType() == InputConstants.Type.KEYSYM) {
                    k.setDown(InputConstants.isKeyDown(window, k.getKey().getValue()));
                }
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        AnnouncePanelBlockEntity p = panel();
        if (p == null) {
            return;
        }
        int px = panelX();
        int py = panelY();
        g.fill(px, py, px + PANEL_W, py + PANEL_H, 0xFF3A3E4D);
        g.fill(px + 2, py + 2, px + PANEL_W - 2, py + PANEL_H - 2, 0xFF1B1D24);
        g.drawString(font, title, px + 8, py + 8, 0xFFFFFF, true);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_hint"), px + 8, py + 19, 0x7A8098, false);

        long now = System.currentTimeMillis();
        for (int r = 0; r < AnnouncePanelBlockEntity.ROWS; r++) {
            if (p.getName(r).isEmpty()) {
                continue;
            }
            int bx = buttonX(r);
            int by = buttonY(r);
            boolean flashing = flashRow == r && now < flashUntil;
            boolean hover = mouseX >= bx && mouseX < bx + BTN_W && mouseY >= by && mouseY < by + BTN_H;
            int face = flashing ? 0xFF8C78F0 : hover ? 0xFF6A5CC8 : 0xFF4A3FA0;
            int off = flashing ? 1 : 0;
            g.fill(bx, by, bx + BTN_W, by + BTN_H, 0xFF0D0E12);
            g.fill(bx + 2 + off, by + 2 + off, bx + BTN_W - 2, by + BTN_H - 2, face);
            // a little speaker
            g.fill(bx + 6, by + 11, bx + 10, by + 21, 0xFFE6E6F0);
            g.fill(bx + 10, by + 8, bx + 14, by + 24, 0xFFE6E6F0);
            g.drawString(font, p.getName(r), bx + 20, by + 6, 0xFFFFFF, true);
            g.drawString(font, AnnouncerSounds.NAMES[p.getSound(r)], bx + 20, by + 18, 0xD8D8EE, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int row = rowAt(mouseX, mouseY);
            if (row >= 0) {
                flashRow = row;
                flashUntil = System.currentTimeMillis() + 250;
                PacketDistributor.sendToServer(new AnnouncePlayPacket(pos, row));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void removed() {
        KeyMapping.setAll();
        super.removed();
    }
}
