package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterTools;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Track Unrestrictor: the anchor reports no legs while a placement by a player holding it is running. Optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity", remap = false)
public class AnchorLegCapMixin {
    @Inject(method = "legCount", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ccp$legCount(CallbackInfoReturnable<Integer> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(0);
        }
    }

    @Inject(method = "canAcceptAnchorPeer", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ccp$accept(net.minecraft.core.BlockPos peer, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(true);
        }
    }
}
