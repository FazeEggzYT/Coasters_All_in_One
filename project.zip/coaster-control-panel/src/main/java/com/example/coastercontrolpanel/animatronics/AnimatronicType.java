package com.example.coastercontrolpanel.animatronics;

import static com.example.coastercontrolpanel.animatronics.Rig.*;

import java.util.ArrayList;
import java.util.List;

/**
 * The characters. To add one: add an entry here with its look (boxes added to the skeleton) and the three animations
 * it can play (ids from {@link Anims}). Nothing else needs to change; the tool and the screen pick it up from here.
 */
public enum AnimatronicType {
    GREETER("greeter", new String[]{"wave", "welcome", "nod"}),
    DANCER("dancer", new String[]{"dance", "spin", "disco"}),
    PIRATE("pirate", new String[]{"point", "swordfight", "laugh"}),
    DRUMMER("drummer", new String[]{"drum", "groove", "nod"}),
    GUITARIST("guitarist", new String[]{"strum", "rock", "groove"}),
    GHOUL("ghoul", new String[]{"creep", "reach", "lunge"}),
    WIZARD("wizard", new String[]{"cast", "conjure", "wave"}),
    KNIGHT("knight", new String[]{"salute", "guard", "nod"});

    public final String id;
    public final String[] animations;
    private List<Box> boxes;

    AnimatronicType(String id, String[] animations) {
        this.id = id;
        this.animations = animations;
    }

    public synchronized List<Box> boxes() {
        if (boxes == null) {
            boxes = build();
        }
        return boxes;
    }

    private List<Box> build() {
        List<Box> b;
        switch (this) {
            case GREETER -> {
                b = skeleton(0xF0ECDC);
                b.add(box(HEAD, -3, 32, -3, 3, 38, 3, 0x15151A));
                b.add(box(HEAD, -5, 32, -5, 5, 33, 5, 0x15151A));
                b.add(box(HEAD, -3.1f, 33, -3.1f, 3.1f, 34, 3.1f, 0xB02030));
                b.add(box(TORSO, -4.3f, 12, -2.3f, 4.3f, 24, 2.3f, 0x2A2F55));
                b.add(box(TORSO, -1, 22, -2.6f, 1, 23.5f, -2.3f, 0xE8E8EE));
                b.add(box(TORSO, -2.2f, 21.6f, -2.7f, -0.4f, 23.4f, -2.4f, 0xC02030));
                b.add(box(TORSO, 0.4f, 21.6f, -2.7f, 2.2f, 23.4f, -2.4f, 0xC02030));
            }
            case DANCER -> {
                b = skeleton(0xF4E8EC);
                b.add(box(TORSO, -4.4f, 15, -2.4f, 4.4f, 24, 2.4f, 0xD83A8E));
                b.add(box(TORSO, -6.5f, 8, -4, 6.5f, 15, 4, 0xF06AB0));
                b.add(box(TORSO, -6.6f, 8, -4.1f, 6.6f, 9, 4.1f, 0xFFD24A));
                b.add(box(HEAD, -4.4f, 30, -4.4f, 4.4f, 33, 4.4f, 0x5A2A18));
                b.add(box(HEAD, -4.4f, 24, 3.2f, 4.4f, 33, 4.5f, 0x5A2A18));
                b.add(glow(HEAD, -1, 33, -1, 1, 34.5f, 1, 0xFFE070));
            }
            case PIRATE -> {
                b = skeleton(0xE0D6BC);
                b.add(box(HEAD, -5, 32, -5, 5, 34, 5, 0x181820));
                b.add(box(HEAD, -3.5f, 34, -4, 3.5f, 37, 4, 0x181820));
                b.add(box(HEAD, -1, 35, -4.2f, 1, 36.5f, -4, 0xE8E4D4));
                b.add(box(HEAD, -3.2f, 27.2f, -4.3f, -0.8f, 29.8f, -4.05f, 0x101010));
                b.add(box(TORSO, -4.3f, 12, -2.3f, 4.3f, 24, 2.3f, 0x8A1E24));
                b.add(box(TORSO, -4.4f, 15, -2.4f, 4.4f, 16.5f, 2.4f, 0x4A2E14));
                b.add(box(FORE_R, 5.5f, 9, -1.5f, 6.5f, 10.5f, 1, 0x6A4A20));
                b.add(box(FORE_R, 5.2f, 9.6f, -1.2f, 6.8f, 10.2f, 0.8f, 0xD4A838));
                b.add(box(FORE_R, 5.7f, 9.6f, -17, 6.3f, 10.2f, -1.2f, 0xC9D0D6));
            }
            case DRUMMER -> {
                b = skeleton(0xE8E4D4);
                b.add(box(HEAD, -4.3f, 29.5f, -4.3f, 4.3f, 31.2f, 4.3f, 0x202028));
                b.add(box(TORSO, -4.3f, 12, -2.3f, 4.3f, 24, 2.3f, 0x30303A));
                b.add(box(FORE_L, -6.5f, 9.6f, -3, -5.5f, 10.4f, 1, 0x6A4A20));
                b.add(box(FORE_R, 5.5f, 9.6f, -3, 6.5f, 10.4f, 1, 0x6A4A20));
                b.add(box(STAGE, -5, 12, -11, 5, 17, -4, 0xB02A2A));
                b.add(box(STAGE, -5.2f, 17, -11.2f, 5.2f, 17.8f, -3.8f, 0xF0F0F0));
                b.add(box(STAGE, -7, 2, 4, 7, 16, 9, 0x992222));
                b.add(box(STAGE, -7.2f, 16, 3.8f, 7.2f, 16.8f, 9.2f, 0xF0F0F0));
                b.add(box(STAGE, 9.5f, 0, -5, 10.5f, 20, -4, 0x8A8A92));
                b.add(box(STAGE, 6.5f, 20, -8, 13.5f, 20.6f, -1, 0xE0B83A));
                b.add(box(STAGE, -11.5f, 0, -5, -10.5f, 16, -4, 0x8A8A92));
                b.add(box(STAGE, -14.5f, 16, -8, -7.5f, 16.6f, -1, 0xE0B83A));
            }
            case GUITARIST -> {
                b = skeleton(0xEAE2D0);
                b.add(box(HEAD, -4.3f, 29.2f, -4.3f, 4.3f, 31, 4.3f, 0x1C1C20));
                b.add(box(HEAD, -3.4f, 27.4f, -4.5f, 3.4f, 29.6f, -4.15f, 0x1C1C20));
                b.add(box(TORSO, -4.3f, 12, -2.3f, 4.3f, 24, 2.3f, 0x1E1E24));
                b.add(box(TORSO, -2, 12, -2.4f, 2, 24, -2.3f, 0xC8202A));
                b.add(box(TORSO, -2, 11.5f, -6.5f, 5, 18, -2.5f, 0xB8741E));
                b.add(box(TORSO, -0.5f, 13, -6.7f, 3.5f, 16.5f, -6.5f, 0x2A1A0C));
                b.add(box(TORSO, -13, 15.5f, -5.5f, -2, 17.2f, -4.2f, 0x4A2E14));
                b.add(box(TORSO, -15, 15, -6, -13, 18, -4, 0x2A1A0C));
            }
            case GHOUL -> {
                b = skeleton(0xB8C4B0);
                b.add(box(TORSO, -5.2f, 4, -3.2f, 5.2f, 24, 3.2f, 0x23212B));
                b.add(box(TORSO, -4.6f, 2, -2.8f, 4.6f, 4, 2.8f, 0x1A1820));
                b.add(box(HEAD, -4.9f, 31, -4.9f, 4.9f, 34, 4.9f, 0x23212B));
                b.add(box(HEAD, -4.9f, 24, 3.6f, 4.9f, 31, 4.9f, 0x23212B));
                b.add(box(HEAD, -4.9f, 24, -4.9f, -3.9f, 31, 4.9f, 0x23212B));
                b.add(box(HEAD, 3.9f, 24, -4.9f, 4.9f, 31, 4.9f, 0x23212B));
                b.add(glow(HEAD, -3, 27.6f, -4.3f, -1, 29.4f, -4.05f, 0xFF2A1E));
                b.add(glow(HEAD, 1, 27.6f, -4.3f, 3, 29.4f, -4.05f, 0xFF2A1E));
                b.add(box(ARM_L, -7.4f, 16, -1.4f, -4.6f, 22, 1.4f, 0x23212B));
                b.add(box(ARM_R, 4.6f, 16, -1.4f, 7.4f, 22, 1.4f, 0x23212B));
            }
            case WIZARD -> {
                b = skeleton(0xF0EBDD);
                b.add(box(HEAD, -5, 32, -5, 5, 33, 5, 0x4B2C8A));
                b.add(box(HEAD, -3.6f, 33, -3.6f, 3.6f, 37, 3.6f, 0x4B2C8A));
                b.add(box(HEAD, -2.4f, 37, -2.4f, 2.4f, 41, 2.4f, 0x4B2C8A));
                b.add(box(HEAD, -1.2f, 41, -1.2f, 1.2f, 44, 1.2f, 0x4B2C8A));
                b.add(glow(HEAD, -0.6f, 36, -3.7f, 0.6f, 37.2f, -3.5f, 0xFFE070));
                b.add(box(HEAD, -2.8f, 21, -4.5f, 2.8f, 26.5f, -4.1f, 0xF4F4F4));
                b.add(box(TORSO, -5, 5, -3, 5, 24, 3, 0x5A36A8));
                b.add(box(TORSO, -5.2f, 5, -3.2f, 5.2f, 7, 3.2f, 0xFFD24A));
                b.add(box(FORE_R, 5.4f, -4, -0.6f, 6.6f, 30, 0.6f, 0x6A4A20));
                b.add(glow(FORE_R, 4.6f, 30, -1.4f, 7.4f, 33, 1.4f, 0x58C8FF));
            }
            default -> {
                b = skeleton(0xD8D8DC);
                b.add(box(HEAD, -4.8f, 24, -4.8f, 4.8f, 33.5f, 4.8f, 0x8C929C));
                b.add(box(HEAD, -3.6f, 28, -4.9f, 3.6f, 29.4f, -4.7f, 0x14141A));
                b.add(box(HEAD, -0.8f, 33.5f, -4, 0.8f, 36.5f, 4, 0xB82430));
                b.add(box(TORSO, -5, 12, -3, 5, 24, 3, 0x8C929C));
                b.add(box(TORSO, -1.2f, 13, -3.2f, 1.2f, 23, -3, 0xB82430));
                b.add(box(ARM_L, -7.4f, 19, -1.8f, -4.6f, 23, 1.8f, 0x8C929C));
                b.add(box(ARM_R, 4.6f, 19, -1.8f, 7.4f, 23, 1.8f, 0x8C929C));
                b.add(box(FORE_L, -9.6f, 6, -4.5f, -8.6f, 18, 3.5f, 0x2C4AA0));
                b.add(box(FORE_L, -9.7f, 11, -0.5f, -8.5f, 13, 0.5f, 0xE0B83A));
                b.add(box(FORE_R, 5.7f, 9.5f, -0.3f, 6.3f, 11, 0.3f, 0x6A4A20));
                b.add(box(FORE_R, 4.2f, 11, -0.9f, 7.8f, 12, 0.9f, 0xD4A838));
                b.add(box(FORE_R, 5.5f, 12, -0.4f, 6.5f, 30, 0.4f, 0xC9D0D6));
            }
        }
        return java.util.Collections.unmodifiableList(new ArrayList<>(b));
    }

    public static AnimatronicType byIndex(int i) {
        AnimatronicType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
