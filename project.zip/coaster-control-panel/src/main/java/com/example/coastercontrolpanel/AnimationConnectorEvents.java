package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * The Animation Connector: right-click an animatronic to pick it, then right-click an Animation Controller to link it
 * (right-click the same pair again to unlink). Sneak and right-click in the air to forget the pick.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class AnimationConnectorEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), event.getPos())) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), null)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private static boolean handle(Player player, InteractionHand hand, Level level, BlockPos clicked) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.ANIMATION_CONNECTOR_ITEM.get())) {
            return false;
        }
        if (level.isClientSide) {
            return true;
        }
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        if (clicked == null) {
            if (player.isShiftKeyDown() && tag.contains("Pick")) {
                tag.remove("Pick");
                stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_cleared"), true);
            } else {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_help"), true);
            }
            return true;
        }
        if ((level.getBlockEntity(clicked) instanceof AnimatronicBlockEntity || level.getBlockEntity(clicked) instanceof TimelineTarget)) {
            tag.putLong("Pick", clicked.asLong());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_picked", clicked.getX(), clicked.getY(), clicked.getZ()), true);
        } else if (level.getBlockEntity(clicked) instanceof AnimationControllerBlockEntity be) {
            if (!tag.contains("Pick")) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_pick_first"), true);
                return true;
            }
            BlockPos pick = BlockPos.of(tag.getLong("Pick"));
            if (!(level.getBlockEntity(pick) instanceof AnimatronicBlockEntity) && !(level.getBlockEntity(pick) instanceof TimelineTarget)) {
                tag.remove("Pick");
                stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_gone"), true);
                return true;
            }
            boolean was = be.linked().contains(pick);
            boolean now = be.toggleLink(pick);
            if (!was && !now) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_full", AnimationControllerBlockEntity.MAX_TRACKS), true);
            } else {
                player.displayClientMessage(Component.translatable(now ? "message.coastercontrolpanel.connector_linked"
                        : "message.coastercontrolpanel.connector_unlinked", be.linked().size()), true);
            }
        } else {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.connector_help"), true);
        }
        return true;
    }
}
