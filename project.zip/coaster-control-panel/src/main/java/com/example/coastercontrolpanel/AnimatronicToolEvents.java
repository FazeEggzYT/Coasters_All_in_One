package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * The Animatronic Tool. Right-click an animatronic to change the selected setting (it cycles to the next value).
 * Sneak and right-click anywhere to change which setting is selected: character, animation, mode, speed.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class AnimatronicToolEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), event.getPos())) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), null)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private static int selected(ItemStack stack) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return Math.floorMod(tag.getInt("Setting"), AnimatronicTexts.SETTINGS.length);
    }

    private static void select(ItemStack stack, int setting) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        tag.putInt("Setting", setting);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    private static boolean handle(Player player, InteractionHand hand, Level level, BlockPos clicked) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.ANIMATRONIC_TOOL_ITEM.get())) {
            return false;
        }
        if (level.isClientSide) {
            return true;
        }
        if (player.isShiftKeyDown() || clicked == null) {
            if (player.isShiftKeyDown()) {
                int next = (selected(stack) + 1) % AnimatronicTexts.SETTINGS.length;
                select(stack, next);
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.animatronic_selected",
                        Component.translatable("animatronic.setting." + AnimatronicTexts.SETTINGS[next])), true);
            } else {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.animatronic_aim",
                        Component.translatable("animatronic.setting." + AnimatronicTexts.SETTINGS[selected(stack)])), true);
            }
            return true;
        }
        if (!(level.getBlockEntity(clicked) instanceof AnimatronicBlockEntity be)) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.animatronic_aim",
                    Component.translatable("animatronic.setting." + AnimatronicTexts.SETTINGS[selected(stack)])), true);
            return true;
        }
        String setting = AnimatronicTexts.SETTINGS[selected(stack)];
        switch (setting) {
            case "character" -> be.setAll(be.character() + 1, 0, be.redstoneMode(), be.speed());
            case "animation" -> be.setAll(be.character(), be.animation() + 1, be.redstoneMode(), be.speed());
            case "mode" -> be.setAll(be.character(), be.animation(), !be.redstoneMode(), be.speed());
            default -> be.setAll(be.character(), be.animation(), be.redstoneMode(), be.speed() + 1);
        }
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.animatronic_changed",
                Component.translatable("animatronic.setting." + setting), AnimatronicTexts.value(setting, be)), true);
        return true;
    }
}
