package com.example.coastercontrolpanel;

/**
 * The four zone controllers. Each has up to four link slots (some listen, some send) and two settings.
 * Language keys:
 *   gui.coastercontrolpanel.zone.<key>.title
 *   gui.coastercontrolpanel.zone.<key>.slot.<slotKey>
 *   gui.coastercontrolpanel.zone.<key>.setting.<settingKey>
 */
public enum ZoneType {
    STATION("station", new String[]{"dispatch", "hold", "occupied"}, new boolean[]{true, false, false},
            new Setting("dwell", 0, 120, 10, false), new Setting("auto", 0, 1, 0, true)),
    LAUNCH("launch", new String[]{"start", "countdown", "launch", "occupied"}, new boolean[]{true, false, false, false},
            new Setting("countdown", 0, 60, 5, false), new Setting("launch_time", 1, 30, 3, false)),
    BRAKE("brake", new String[]{"hold", "brake", "occupied"}, new boolean[]{true, false, false},
            new Setting("release", 0, 30, 0, false), new Setting("only_occupied", 0, 1, 0, true)),
    LIFT("lift", new String[]{"enable", "motor", "occupied"}, new boolean[]{true, false, false},
            new Setting("run_on", 0, 60, 3, false), new Setting("needs_enable", 0, 1, 0, true));

    public record Setting(String key, int min, int max, int def, boolean toggle) {
    }

    public static final int MAX_SLOTS = 4;

    public final String key;
    public final String[] slotKeys;
    public final boolean[] isInput;
    public final Setting[] settings;

    ZoneType(String key, String[] slotKeys, boolean[] isInput, Setting s1, Setting s2) {
        this.key = key;
        this.slotKeys = slotKeys;
        this.isInput = isInput;
        this.settings = new Setting[]{s1, s2};
    }

    public int slots() {
        return slotKeys.length;
    }
}
