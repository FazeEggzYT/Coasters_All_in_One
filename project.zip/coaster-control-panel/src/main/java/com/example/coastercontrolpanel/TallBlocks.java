package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.function.Supplier;

/**
 * Real-size machines. A tall machine is its normal block (the bottom, which holds the block entity and all the logic)
 * plus one or two "top" blocks above it. The top blocks only draw their part of the model, share the bottom's shape,
 * pass clicks down to the bottom, copy its visual state (open door, lit, colour...) and disappear with it.
 */
public final class TallBlocks {
    private TallBlocks() {
    }

    public static final IntegerProperty PART = IntegerProperty.create("part", 1, 2);

    /** Optional custom shape for a top block, for machines whose upper part is shaped differently. */
    public interface ShapeFn {
        VoxelShape get(BlockState top, int part);
    }

    public static class Top extends Block {
        private static final ThreadLocal<Property<?>[]> PENDING = new ThreadLocal<>();
        private final Supplier<? extends Block> base;
        private final ShapeFn shape;

        public static Top create(Supplier<? extends Block> base, ShapeFn shape, Properties p, Property<?>... extra) {
            PENDING.set(extra);
            try {
                return new Top(base, shape, p);
            } finally {
                PENDING.remove();
            }
        }

        private Top(Supplier<? extends Block> base, ShapeFn shape, Properties p) {
            super(p);
            this.base = base;
            this.shape = shape;
            registerDefaultState(stateDefinition.any().setValue(DecorBlocks.FACING, Direction.NORTH).setValue(PART, 1));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(DecorBlocks.FACING, PART);
            Property<?>[] extra = PENDING.get();
            if (extra != null && extra.length > 0) {
                b.add(extra);
            }
        }

        private BlockPos basePos(BlockState s, BlockPos pos) {
            return pos.below(s.getValue(PART));
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter level, BlockPos pos, CollisionContext c) {
            if (shape != null) {
                return shape.get(s, s.getValue(PART));
            }
            BlockPos bp = basePos(s, pos);
            BlockState bs = level.getBlockState(bp);
            return bs.is(base.get()) ? bs.getShape(level, bp, c) : Shapes.block();
        }

        @Override
        protected VoxelShape getCollisionShape(BlockState s, BlockGetter level, BlockPos pos, CollisionContext c) {
            if (shape != null) {
                return shape.get(s, s.getValue(PART));
            }
            BlockPos bp = basePos(s, pos);
            BlockState bs = level.getBlockState(bp);
            return bs.is(base.get()) ? bs.getCollisionShape(level, bp, c) : Shapes.block();
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            BlockPos bp = basePos(s, pos);
            BlockState bs = level.getBlockState(bp);
            if (!bs.is(base.get())) {
                return InteractionResult.PASS;
            }
            return bs.useWithoutItem(level, player, hit.withPosition(bp));
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            BlockPos bp = basePos(s, pos);
            BlockState bs = level.getBlockState(bp);
            if (!bs.is(base.get())) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            return bs.useItemOn(stack, level, player, hand, hit.withPosition(bp));
        }

        @Override
        protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                         BlockPos pos, BlockPos neighborPos) {
            if (dir != Direction.DOWN) {
                return state;
            }
            int part = state.getValue(PART);
            boolean ok = part == 1 ? neighbor.is(base.get()) : neighbor.is(this) && neighbor.getValue(PART) == part - 1;
            if (!ok) {
                return Blocks.AIR.defaultBlockState();
            }
            return mirror(state, neighbor);
        }

        @Override
        public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
            if (!level.isClientSide) {
                BlockPos bp = basePos(state, pos);
                if (level.getBlockState(bp).is(base.get())) {
                    level.destroyBlock(bp, !player.isCreative(), player);
                }
            }
            return super.playerWillDestroy(level, pos, state, player);
        }
    }

    /** Copies the visual state (everything except part and facing) from the block below onto a top block. */
    public static BlockState mirror(BlockState top, BlockState src) {
        for (Property<?> p : top.getProperties()) {
            if (p == PART || p == DecorBlocks.FACING) {
                continue;
            }
            top = copy(top, src, p);
        }
        return top;
    }

    private static <T extends Comparable<T>> BlockState copy(BlockState to, BlockState from, Property<T> p) {
        return from.hasProperty(p) ? to.setValue(p, from.getValue(p)) : to;
    }

    /** The item of a tall machine: needs room above, and places the top block(s) with the bottom. */
    public static class Item extends BlockItem {
        private final Supplier<? extends Block> top;
        private final int height;

        public Item(Block block, net.minecraft.world.item.Item.Properties props, Supplier<? extends Block> top, int height) {
            super(block, props);
            this.top = top;
            this.height = height;
        }

        @Override
        protected boolean canPlace(BlockPlaceContext ctx, BlockState state) {
            Level level = ctx.getLevel();
            BlockPos pos = ctx.getClickedPos();
            for (int i = 1; i < height; i++) {
                BlockPos up = pos.above(i);
                if (up.getY() >= level.getMaxBuildHeight() || !level.getBlockState(up).canBeReplaced()) {
                    return false;
                }
            }
            return super.canPlace(ctx, state);
        }

        @Override
        protected boolean placeBlock(BlockPlaceContext ctx, BlockState state) {
            Level level = ctx.getLevel();
            BlockPos pos = ctx.getClickedPos();
            for (int i = 1; i < height; i++) {
                BlockState t = top.get().defaultBlockState();
                if (state.hasProperty(DecorBlocks.FACING)) {
                    t = t.setValue(DecorBlocks.FACING, state.getValue(DecorBlocks.FACING));
                }
                t = mirror(t.setValue(PART, i), state);
                level.setBlock(pos.above(i), t, 27);
            }
            return super.placeBlock(ctx, state);
        }
    }
}
