package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the text on the front of a sign. */
public class RideSignRenderer implements BlockEntityRenderer<RideSignBlockEntity> {
    private static final int FULL_BRIGHT = 15728880;
    private final Font font;

    public RideSignRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
    }

    @Override
    public void render(RideSignBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        BlockState state = be.getBlockState();
        if (!state.hasProperty(RideSignBlock.FACING)) {
            return;
        }
        Direction facing = state.getValue(RideSignBlock.FACING);
        int color = DyeColor.byId(be.color()).getTextColor() | 0xFF000000;
        Component top;
        Component big;
        Component small = null;
        int bigColor = color;
        boolean bright = false;
        switch (be.kind()) {
            case OPEN -> {
                bright = true;
                top = be.line1().isEmpty() ? null : Component.literal(be.line1());
                big = Component.translatable(be.lit() ? "sign.coastercontrolpanel.open" : "sign.coastercontrolpanel.closed");
                bigColor = be.lit() ? 0xFF55FF55 : 0xFFFF5555;
                small = be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
            case HEIGHT -> {
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.must_be") : Component.literal(be.line1());
                big = Component.literal(String.format("%d.%02d m", be.number() / 100, be.number() % 100));
                small = Component.translatable("sign.coastercontrolpanel.this_tall");
            }
            case WAIT -> {
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.wait_time") : Component.literal(be.line1());
                big = Component.translatable("sign.coastercontrolpanel.minutes", be.shown());
            }
            default -> {
                top = null;
                big = Component.literal(be.line1());
                small = be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
        }
        int packed = bright ? FULL_BRIGHT : light;
        pose.pushPose();
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
        // the board is 2/16 thick at the back; the text sits just in front of it
        pose.translate(0.0, 0.0, -0.5 + 2.0 / 16.0 + 0.004);
        float y = top != null ? -0.20F : -0.08F;
        if (top != null) {
            line(top, color, 0.0F, -0.27F, 0.012F, 0.86F, packed, pose, buffers);
        }
        line(big, bigColor, 0.0F, small != null || top != null ? -0.05F : -0.05F, 0.024F, 0.9F, packed, pose, buffers);
        if (small != null) {
            line(small, color, 0.0F, 0.17F, 0.012F, 0.86F, packed, pose, buffers);
        }
        pose.popPose();
    }

    private void line(Component text, int color, float x, float y, float baseScale, float maxWidth, int light,
                      PoseStack pose, MultiBufferSource buffers) {
        int w = Math.max(1, font.width(text));
        float scale = Math.min(baseScale, maxWidth / w);
        pose.pushPose();
        pose.translate(x, y, 0.0);
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -w / 2.0F, 0.0F, color, false, pose.last().pose(), buffers,
                Font.DisplayMode.NORMAL, 0, light);
        pose.popPose();
    }
}
