package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the text on the front of a sign. */
public class RideSignRenderer implements BlockEntityRenderer<RideSignBlockEntity> {
    private static final int FULL_BRIGHT = 15728880;
    private final Font font;

    public RideSignRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
    }

    @Override
    public void render(RideSignBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        BlockState state = be.getBlockState();
        if (!state.hasProperty(RideSignBlock.FACING)) {
            return;
        }
        Direction facing = state.getValue(RideSignBlock.FACING);
        int color = DyeColor.byId(be.color()).getTextColor() | 0xFF000000;
        Component top;
        Component big;
        Component small = null;
        int bigColor = color;
        boolean bright = false;
        switch (be.kind()) {
            case OPEN -> {
                bright = true;
                top = be.line1().isEmpty() ? null : Component.literal(be.line1());
                big = Component.translatable(be.lit() ? "sign.coastercontrolpanel.open" : "sign.coastercontrolpanel.closed");
                bigColor = be.lit() ? 0xFF55FF55 : 0xFFFF5555;
                small = be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
            case HEIGHT -> {
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.must_be") : Component.literal(be.line1());
                int cm = be.power() > 0 ? 85 + 5 * be.power() : be.number();
                big = Component.literal(String.format("%d.%02d m", cm / 100, cm % 100));
                small = Component.translatable("sign.coastercontrolpanel.this_tall");
            }
            case WAIT -> {
                bright = true;
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.signal") : Component.literal(be.line1());
                big = Component.literal(String.valueOf(be.shown()));
                bigColor = be.power() == 0 ? 0xFF8A2A2A : 0xFFFF4A3A;
                small = be.line2().isEmpty() ? (be.mode() == 0 ? Component.translatable("sign.coastercontrolpanel.of_15") : null) : Component.literal(be.line2());
            }
            case ENTRANCE -> {
                top = be.line1().isEmpty() ? null : Component.literal(be.line1());
                big = Component.translatable(be.power() > 0 ? "sign.coastercontrolpanel.no_entry" : "sign.coastercontrolpanel.entrance");
                if (be.power() > 0) {
                    bright = true;
                    bigColor = 0xFFFF5555;
                }
                small = be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
            case EXIT -> {
                top = be.line1().isEmpty() ? null : Component.literal(be.line1());
                big = Component.translatable("sign.coastercontrolpanel.exit");
                if (be.power() > 0) {
                    bright = true;
                    long t = be.getLevel() != null ? be.getLevel().getGameTime() / 8 : 0;
                    bigColor = t % 2 == 0 ? 0xFF55FF55 : 0xFF1F6B1F;
                }
                small = be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
            case NOTICE -> {
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.notice") : Component.literal(be.line1());
                big = Component.translatable("sign.coastercontrolpanel.notice_" + (be.power() > 0 ? (be.power() - 1) % 8 : be.mode()));
            }
            case DIRECTION -> {
                String[] arrows = {"\u2190", "\u2192", "\u2191", "\u2193"};
                top = null;
                big = Component.literal(arrows[be.power() > 0 ? (Math.min(3, be.mode()) ^ 1) : Math.min(3, be.mode())]);
                small = be.line1().isEmpty() ? null : Component.literal(be.line1());
            }
            case CROWD -> {
                bright = true;
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.queue") : Component.literal(be.line1());
                big = Component.translatable("sign.coastercontrolpanel.crowd_" + Math.min(2, be.shown()));
                bigColor = new int[]{0xFF55FF55, 0xFFFFD84A, 0xFFFF5555}[Math.min(2, be.shown())];
            }
            case COUNTER -> {
                top = be.line1().isEmpty() ? Component.translatable("sign.coastercontrolpanel.rides_today") : Component.literal(be.line1());
                big = Component.literal(String.valueOf(be.shown()));
            }
            case FLOOR -> {
                top = null;
                boolean swap = be.power() > 0 && !be.line2().isEmpty();
                big = Component.literal(swap ? be.line2() : be.line1());
                small = null;
            }
            default -> {
                top = null;
                boolean swap = be.power() > 0 && !be.line2().isEmpty();
                big = Component.literal(swap ? be.line2() : be.line1());
                small = swap || be.line2().isEmpty() ? null : Component.literal(be.line2());
            }
        }
        int packed = bright ? FULL_BRIGHT : light;
        pose.pushPose();
        if (be.kind() == SignKind.FLOOR) {
            // lies on the ground: the top of the text points the way the sign faces
            pose.translate(0.5, 1.0 / 16.0 + 0.004, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
            pose.mulPose(Axis.XP.rotationDegrees(-90.0F));
        } else {
            pose.translate(0.5, 0.5, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
            // the board is 2/16 thick at the back; the text sits just in front of it
            pose.translate(0.0, 0.0, -0.5 + 2.0 / 16.0 + 0.004);
        }
        float y = top != null ? -0.20F : -0.08F;
        if (top != null) {
            line(top, color, 0.0F, -0.27F, 0.012F, 0.86F, packed, pose, buffers);
        }
        // small animations: the arrow bobs the way it points, and a FULL queue sign flashes
        float time = (be.getLevel() != null ? be.getLevel().getGameTime() : 0) + partialTick;
        float bx = 0.0F;
        float by = -0.05F;
        if (be.kind() == SignKind.DIRECTION) {
            float bob = (float) Math.sin(time * 0.25F) * 0.04F;
            switch (be.power() > 0 ? (Math.min(3, be.mode()) ^ 1) : Math.min(3, be.mode())) {
                case 0 -> bx = -bob;
                case 1 -> bx = bob;
                case 2 -> by -= bob;
                default -> by += bob;
            }
        }
        if (be.kind() == SignKind.CROWD && be.shown() >= 2 && ((int) (time / 10.0F)) % 2 == 0) {
            bigColor = 0xFF882222;
        }
        line(big, bigColor, bx, by, 0.024F, 0.9F, packed, pose, buffers);
        if (small != null) {
            line(small, color, 0.0F, 0.17F, 0.012F, 0.86F, packed, pose, buffers);
        }
        pose.popPose();
    }

    private void line(Component text, int color, float x, float y, float baseScale, float maxWidth, int light,
                      PoseStack pose, MultiBufferSource buffers) {
        int w = Math.max(1, font.width(text));
        float scale = Math.min(baseScale, maxWidth / w);
        pose.pushPose();
        pose.translate(x, -y + 4.0F * scale, 0.0);
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -w / 2.0F, 0.0F, color, false, pose.last().pose(), buffers,
                Font.DisplayMode.NORMAL, 0, light);
        pose.popPose();
    }
}
