package com.example.coastercontrolpanel;

import net.minecraft.world.item.DyeColor;

import java.util.List;

/** Track colours by purpose. Each is a rail colour and a beam (centre spine) colour. */
public final class TrackPresets {
    public record Preset(String key, DyeColor rail, DyeColor beam) {
    }

    public static final List<Preset> ALL = List.of(
            new Preset("launch", DyeColor.BLUE, DyeColor.LIGHT_BLUE),
            new Preset("lift", DyeColor.YELLOW, DyeColor.GRAY),
            new Preset("brake", DyeColor.RED, DyeColor.ORANGE),
            new Preset("station", DyeColor.LIME, DyeColor.GREEN),
            new Preset("silver", DyeColor.LIGHT_GRAY, DyeColor.WHITE)
    );

    private TrackPresets() {
    }
}
