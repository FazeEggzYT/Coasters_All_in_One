package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** Number (queue markers only) and channel (which ride it belongs to). */
public class MarkerBlockEntity extends BlockEntity {
    private int number = 1;
    private int channel = 1;

    public MarkerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.MARKER_BE.get(), pos, state);
    }

    public MarkerKind kind() {
        return getBlockState().getBlock() instanceof MarkerBlock m ? m.kind : MarkerKind.QUEUE;
    }

    public int getNumber() {
        return number;
    }

    public int getChannel() {
        return channel;
    }

    public void setNumber(int n) {
        number = Math.max(1, Math.min(99, n));
        sync();
    }

    @Nullable
    public static MarkerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof MarkerBlockEntity m ? m : null;
    }

    public void apply(int newNumber, int newChannel) {
        number = Math.max(1, Math.min(99, newNumber));
        channel = Math.max(1, Math.min(16, newChannel));
        sync();
    }

    private void sync() {
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            MarkerRegistry.add(level, worldPosition);
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        if (level != null && !level.isClientSide) {
            MarkerRegistry.remove(level, worldPosition);
        }
    }

    @Override
    public void setRemoved() {
        if (level != null && !level.isClientSide) {
            MarkerRegistry.remove(level, worldPosition);
        }
        super.setRemoved();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Number", number);
        tag.putInt("Channel", channel);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        number = Math.max(1, tag.getInt("Number"));
        channel = Math.max(1, tag.getInt("Channel"));
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
