package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Game-bus client events: the J and K keys. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) {
            return;
        }
        while (ClientKeys.UNPIN.consumeClick()) {
            if (ClientKeys.pinned != null) {
                ClientKeys.pinned = null;
                mc.player.displayClientMessage(Component.translatable("message.coastercontrolpanel.unpinned"), true);
            }
        }
        while (ClientKeys.MOUSE.consumeClick()) {
            if (ClientKeys.pinned != null) {
                mc.setScreen(new OperatorScreen(ClientKeys.pinned));
            } else {
                mc.player.displayClientMessage(Component.translatable("message.coastercontrolpanel.not_pinned"), true);
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientKeys.pinned = null;
    }
}
