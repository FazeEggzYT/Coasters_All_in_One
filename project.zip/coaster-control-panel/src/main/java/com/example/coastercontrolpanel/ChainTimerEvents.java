package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Right-clicking an anchor of a chain lift or Drive Tyre with the Chain Timer opens its timer screen. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class ChainTimerEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND
                || !event.getItemStack().is(CoasterControlPanel.CHAIN_TIMER_ITEM.get())) {
            return;
        }
        BlockPos start = BrakeController.findChainStart(event.getLevel(), event.getPos());
        if (start == null) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            ClientHooks.openChainTimer(start);
        }
    }
}
