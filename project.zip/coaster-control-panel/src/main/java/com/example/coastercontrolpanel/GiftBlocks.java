package com.example.coastercontrolpanel;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.ArrayList;

/**
 * The Gift Shop pack. Shop Shelf and Shop Till sell items for gold nuggets, the Price Tag reads the nearest
 * shelf or till, the Window Display shows one item on a turntable, the Shopping Basket holds items and the
 * Gift Bag is an item that carries nine stacks.
 */
public final class GiftBlocks {
    private GiftBlocks() {
    }

    public static final IntegerProperty KIND = IntegerProperty.create("kind", 0, 5);

    /** The nearest block entity of a type within a radius (client and server), or null. */
    @Nullable
    public static <T extends BlockEntity> T nearest(Level level, BlockPos pos, int radius, Class<T> type) {
        return nearest(level, pos, radius, type, be -> true);
    }

    @Nullable
    public static <T extends BlockEntity> T nearest(Level level, BlockPos pos, int radius, Class<T> type,
                                                    java.util.function.Predicate<T> accept) {
        T best = null;
        double bestDist = Double.MAX_VALUE;
        for (int cx = (pos.getX() - radius) >> 4; cx <= (pos.getX() + radius) >> 4; cx++) {
            for (int cz = (pos.getZ() - radius) >> 4; cz <= (pos.getZ() + radius) >> 4; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (type.isInstance(be) && accept.test(type.cast(be))) {
                        double d = be.getBlockPos().distSqr(pos);
                        if (d <= radius * radius && d < bestDist) {
                            bestDist = d;
                            best = type.cast(be);
                        }
                    }
                }
            }
        }
        return best;
    }

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    // ------------------------------------------------------------------ shelf and till

    public static class ShopBlockEntity extends RestaurantBlocks.Syncing {
        public static final int SLOTS = 6;
        public static final int MAX_STOCK = 9999;
        public final ItemStack[] stacks = new ItemStack[SLOTS];
        public final int[] stock = new int[SLOTS];
        public final int[] prices = new int[SLOTS];
        public int takings;

        public ShopBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.SHOP_BE.get(), pos, state);
            for (int i = 0; i < SLOTS; i++) {
                stacks[i] = ItemStack.EMPTY;
                prices[i] = 3;
            }
        }

        public boolean till() {
            return getBlockState().getBlock() instanceof ShopBlock b && b.till;
        }

        /** 0 added, 1 already on the till, 2 full. */
        public int addStock(ItemStack held, boolean consume) {
            boolean till = till();
            for (int i = 0; i < SLOTS; i++) {
                if (!stacks[i].isEmpty() && ItemStack.isSameItemSameComponents(stacks[i], held)) {
                    if (till) {
                        return 1;
                    }
                    int add = Math.min(held.getCount(), MAX_STOCK - stock[i]);
                    if (add <= 0) {
                        return 2;
                    }
                    stock[i] += add;
                    if (consume) {
                        held.shrink(add);
                    }
                    changed();
                    return 0;
                }
            }
            for (int i = 0; i < SLOTS; i++) {
                if (stacks[i].isEmpty()) {
                    stacks[i] = held.copyWithCount(1);
                    prices[i] = 3;
                    if (till) {
                        stock[i] = 0;
                    } else {
                        stock[i] = Math.min(held.getCount(), MAX_STOCK);
                        if (consume) {
                            held.shrink(stock[i]);
                        }
                    }
                    changed();
                    return 0;
                }
            }
            return 2;
        }

        public void buy(ServerPlayer p, int slot, int qty) {
            if (slot < 0 || slot >= SLOTS || stacks[slot].isEmpty()) {
                return;
            }
            boolean till = till();
            qty = Math.max(1, Math.min(64, qty));
            if (!till) {
                qty = Math.min(qty, stock[slot]);
            }
            if (qty <= 0) {
                say(p, "shop_sold_out");
                return;
            }
            int cost = prices[slot] * qty;
            if (!p.getAbilities().instabuild) {
                if (ArcadeBlocks.count(p, Items.GOLD_NUGGET) < cost) {
                    say(p, "shop_poor", cost);
                    return;
                }
                ArcadeBlocks.take(p, Items.GOLD_NUGGET, cost);
                takings += cost;
            }
            if (!till) {
                stock[slot] -= qty;
            }
            int left = qty;
            while (left > 0) {
                int t = Math.min(left, Math.max(1, stacks[slot].getMaxStackSize()));
                ArcadeBlocks.give(p, stacks[slot].copyWithCount(t));
                left -= t;
            }
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 0.8F, 1.5F);
            }
            say(p, "shop_bought", qty, stacks[slot].getHoverName());
            changed();
        }

        public void changePrice(int slot, int d) {
            if (slot >= 0 && slot < SLOTS && !stacks[slot].isEmpty()) {
                prices[slot] = Math.max(1, Math.min(999, prices[slot] + d));
                changed();
            }
        }

        public void removeSlot(ServerPlayer p, int slot) {
            if (slot < 0 || slot >= SLOTS || stacks[slot].isEmpty()) {
                return;
            }
            int left = stock[slot];
            while (left > 0) {
                int t = Math.min(left, Math.max(1, stacks[slot].getMaxStackSize()));
                ArcadeBlocks.give(p, stacks[slot].copyWithCount(t));
                left -= t;
            }
            stacks[slot] = ItemStack.EMPTY;
            stock[slot] = 0;
            changed();
        }

        public void collect(ServerPlayer p) {
            if (takings <= 0) {
                say(p, "shop_no_takings");
                return;
            }
            int left = takings;
            takings = 0;
            while (left > 0) {
                int t = Math.min(64, left);
                ArcadeBlocks.give(p, new ItemStack(Items.GOLD_NUGGET, t));
                left -= t;
            }
            changed();
        }

        public void dropAll(Level lvl, BlockPos pos) {
            for (int i = 0; i < SLOTS; i++) {
                int left = stock[i];
                while (left > 0 && !stacks[i].isEmpty()) {
                    int t = Math.min(left, Math.max(1, stacks[i].getMaxStackSize()));
                    Containers.dropItemStack(lvl, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, stacks[i].copyWithCount(t));
                    left -= t;
                }
            }
            int left = takings;
            while (left > 0) {
                int t = Math.min(64, left);
                Containers.dropItemStack(lvl, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.GOLD_NUGGET, t));
                left -= t;
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            ListTag list = new ListTag();
            for (int i = 0; i < SLOTS; i++) {
                CompoundTag t = new CompoundTag();
                t.put("Item", stacks[i].saveOptional(registries));
                t.putInt("Stock", stock[i]);
                t.putInt("Price", prices[i]);
                list.add(t);
            }
            tag.put("Slots", list);
            tag.putInt("Takings", takings);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ListTag list = tag.getList("Slots", Tag.TAG_COMPOUND);
            for (int i = 0; i < SLOTS; i++) {
                if (i < list.size()) {
                    CompoundTag t = list.getCompound(i);
                    stacks[i] = ItemStack.parseOptional(registries, t.getCompound("Item"));
                    stock[i] = t.getInt("Stock");
                    prices[i] = Math.max(1, t.getInt("Price"));
                } else {
                    stacks[i] = ItemStack.EMPTY;
                    stock[i] = 0;
                    prices[i] = 3;
                }
            }
            takings = tag.getInt("Takings");
        }
    }

    /** Shop Shelf (till = false, real stock) and Shop Till (till = true, unlimited set stock). */
    public static class ShopBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<ShopBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
                propertiesCodec(), Codec.BOOL.fieldOf("till").forGetter(b -> b.till)).apply(i, ShopBlock::new));
        public final boolean till;

        public ShopBlock(Properties p, boolean till) {
            super(p);
            this.till = till;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return till ? DecorBlocks.dbox(f, 0, 0, 2, 16, 16, 14) : DecorBlocks.dbox(f, 0, 0, 3, 16, 16, 13);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ShopBlockEntity(pos, state);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof ShopBlockEntity be) {
                be.dropAll(level, pos);
            }
            super.onRemove(state, level, pos, newState, moved);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.isEmpty() || !player.isShiftKeyDown()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof ShopBlockEntity be) {
                Component name = stack.getHoverName();
                int r = be.addStock(stack, !player.getAbilities().instabuild);
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.shop_add_" + r, name), true);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(till ? 1 : 0, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ price tag

    public static class PriceTagBlockEntity extends RestaurantBlocks.Syncing {
        public int slot;
        public String name = "";
        public int price = -1;
        public int stock = -1;

        public PriceTagBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PRICE_TAG_BE.get(), pos, state);
        }

        public void serverTick() {
            if (level == null || level.getGameTime() % 20 != 3) {
                return;
            }
            ShopBlockEntity shop = nearest(level, worldPosition, 6, ShopBlockEntity.class);
            String n = "";
            int pr = -1;
            int st = -1;
            if (shop != null) {
                int s = Math.max(0, Math.min(ShopBlockEntity.SLOTS - 1, slot));
                if (!shop.stacks[s].isEmpty()) {
                    n = shop.stacks[s].getHoverName().getString();
                    pr = shop.prices[s];
                    st = shop.till() ? -1 : shop.stock[s];
                }
            }
            if (!n.equals(name) || pr != price || st != stock) {
                name = n;
                price = pr;
                stock = st;
                changed();
            }
        }

        public void setSlot(int s) {
            slot = Math.max(0, Math.min(ShopBlockEntity.SLOTS - 1, s));
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Slot", slot);
            tag.putString("Name", name);
            tag.putInt("Price", price);
            tag.putInt("Stock", stock);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            slot = tag.getInt("Slot");
            name = tag.getString("Name");
            price = tag.contains("Price") ? tag.getInt("Price") : -1;
            stock = tag.contains("Stock") ? tag.getInt("Stock") : -1;
        }
    }

    public static class PriceTagBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<PriceTagBlock> CODEC = simpleCodec(PriceTagBlock::new);

        public PriceTagBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 0, 5, 15, 10, 11);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PriceTagBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.PRICE_TAG_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(2, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ window display

    public static class WindowBlockEntity extends RestaurantBlocks.Syncing {
        public ItemStack shown = ItemStack.EMPTY;
        public int spin = 2;

        public WindowBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.WINDOW_BE.get(), pos, state);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.put("Shown", shown.saveOptional(registries));
            tag.putInt("Spin", spin);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            shown = ItemStack.parseOptional(registries, tag.getCompound("Shown"));
            spin = Math.max(0, Math.min(5, tag.getInt("Spin")));
        }
    }

    public static class WindowBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<WindowBlock> CODEC = simpleCodec(WindowBlock::new);

        public WindowBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(0, 0, 1, 16, 16, 15);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new WindowBlockEntity(pos, state);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof WindowBlockEntity be
                    && !be.shown.isEmpty()) {
                Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, be.shown.copy());
            }
            super.onRemove(state, level, pos, newState, moved);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.isEmpty()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof WindowBlockEntity be) {
                ItemStack old = be.shown;
                be.shown = stack.copyWithCount(1);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                if (!old.isEmpty()) {
                    ArcadeBlocks.give(player, old);
                }
                be.changed();
                level.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openPark(3, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ shopping basket

    public static class BasketBlockEntity extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(9, ItemStack.EMPTY);

        public BasketBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.BASKET_BE.get(), pos, state);
        }

        @Override
        public int getContainerSize() {
            return 9;
        }

        @Override
        protected Component getDefaultName() {
            return Component.translatable("block.coastercontrolpanel.shopping_basket");
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return new ChestMenu(MenuType.GENERIC_9x1, id, inv, this, 1);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(9, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
        }
    }

    public static class BasketBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<BasketBlock> CODEC = simpleCodec(BasketBlock::new);

        public BasketBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(2, 0, 3, 14, 7, 13);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new BasketBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof BasketBlockEntity be) {
                player.openMenu(be);
                level.playSound(null, pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.6F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof BasketBlockEntity c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    // ------------------------------------------------------------------ souvenir rack and plush toy

    public static class RackBlock extends DecorBlocks.Facing {
        public RackBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 2, 0, 2, 14, 16, 14);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            level.playSound(null, pos, SoundEvents.BOOK_PAGE_TURN, SoundSource.BLOCKS, 0.8F, 1.2F);
            say(player, "rack_spin");
            return InteractionResult.CONSUME;
        }
    }

    public static class PlushBlock extends DecorBlocks.Facing {
        public PlushBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(KIND, 0));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(KIND);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 3, 0, 3, 13, 12, 13);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (player.isShiftKeyDown()) {
                int next = (s.getValue(KIND) + 1) % 6;
                level.setBlock(pos, s.setValue(KIND, next), 3);
                say(player, "plush_kind_" + next);
            }
            level.playSound(null, pos, SoundEvents.WOOL_HIT, SoundSource.BLOCKS, 0.9F, 1.6F + level.random.nextFloat() * 0.4F);
            return InteractionResult.CONSUME;
        }
    }

    // ------------------------------------------------------------------ gift bag item

    /** Right-click to open nine slots; the contents stay in the bag. */
    public static class GiftBagItem extends Item {
        public GiftBagItem(Properties p) {
            super(p.stacksTo(1));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack bag = player.getItemInHand(hand);
            if (!level.isClientSide) {
                SimpleContainer box = new SimpleContainer(9);
                NonNullList<ItemStack> list = NonNullList.withSize(9, ItemStack.EMPTY);
                bag.getOrDefault(DataComponents.CONTAINER, ItemContainerContents.EMPTY).copyInto(list);
                for (int i = 0; i < 9; i++) {
                    box.setItem(i, list.get(i));
                }
                player.openMenu(new SimpleMenuProvider((id, inv, p) -> new BagMenu(id, inv, box, bag), bag.getHoverName()));
                level.playSound(null, player.blockPosition(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.7F, 1.4F);
            }
            return InteractionResultHolder.sidedSuccess(bag, level.isClientSide);
        }
    }

    private static class BagMenu extends ChestMenu {
        private final SimpleContainer box;
        private final ItemStack bag;

        BagMenu(int id, Inventory inv, SimpleContainer box, ItemStack bag) {
            super(MenuType.GENERIC_9x1, id, inv, box, 1);
            this.box = box;
            this.bag = bag;
        }

        private boolean isBag(ItemStack s) {
            return s == bag || (s.getItem() instanceof GiftBagItem);
        }

        @Override
        public void clicked(int slotId, int button, ClickType type, Player player) {
            if (slotId >= 0 && slotId < slots.size() && isBag(slots.get(slotId).getItem())) {
                return;
            }
            if (type == ClickType.SWAP && button >= 0 && button < 9 && isBag(player.getInventory().getItem(button))) {
                return;
            }
            if (!getCarried().isEmpty() && isBag(getCarried())) {
                return;
            }
            super.clicked(slotId, button, type, player);
        }

        @Override
        public ItemStack quickMoveStack(Player player, int index) {
            if (index >= 0 && index < slots.size() && isBag(slots.get(index).getItem())) {
                return ItemStack.EMPTY;
            }
            return super.quickMoveStack(player, index);
        }

        @Override
        public void removed(Player player) {
            super.removed(player);
            if (!player.level().isClientSide) {
                java.util.List<ItemStack> out = new ArrayList<>();
                for (int i = 0; i < 9; i++) {
                    out.add(box.getItem(i));
                }
                bag.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(out));
            }
        }
    }
}
