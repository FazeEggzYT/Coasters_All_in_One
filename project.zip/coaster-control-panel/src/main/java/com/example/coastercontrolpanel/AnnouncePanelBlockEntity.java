package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * The Announcement Panel: a console of buttons, each one plays an announcement sound for
 * everyone nearby when tapped. Every row has a name, a sound, a volume and a pitch.
 */
public class AnnouncePanelBlockEntity extends BlockEntity {
    public static final int ROWS = 10;
    public static final int MAX_VOLUME = 400;
    private static final String[] DEFAULT_NAMES = {"Welcome", "Safety", "Please wait", "Doors", "Thank you", "", "", "", "", ""};

    private final String[] names = new String[ROWS];
    private final int[] sounds = new int[ROWS];
    private final int[] volumes = new int[ROWS];   // percent. 100% is about 16 blocks, 400% about 64.
    private final int[] pitches = new int[ROWS];   // percent
    private final long[] lastPlayed = new long[ROWS];
    private final String[] clips = new String[ROWS];   // hash of an uploaded .ogg, or "" for a built-in sound

    public AnnouncePanelBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.ANNOUNCE_PANEL_BE.get(), pos, state);
        for (int r = 0; r < ROWS; r++) {
            names[r] = DEFAULT_NAMES[r];
            sounds[r] = r % AnnouncerSounds.count();
            volumes[r] = 200;
            pitches[r] = 100;
            lastPlayed[r] = -100000L;
            clips[r] = "";
        }
    }

    public String getName(int r) {
        return names[r];
    }

    public int getSound(int r) {
        return sounds[r];
    }

    public String getClip(int r) {
        return clips[r];
    }

    public void setClip(int r, String hash) {
        clips[r] = hash;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    public int getVolume(int r) {
        return volumes[r];
    }

    public int getPitch(int r) {
        return pitches[r];
    }

    @Nullable
    public static AnnouncePanelBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof AnnouncePanelBlockEntity p ? p : null;
    }

    public void applyConfig(String[] newNames, int[] newSounds, int[] newVolumes, int[] newPitches) {
        for (int r = 0; r < ROWS; r++) {
            names[r] = newNames[r].length() > 14 ? newNames[r].substring(0, 14) : newNames[r];
            sounds[r] = Math.max(0, Math.min(AnnouncerSounds.count() - 1, newSounds[r]));
            volumes[r] = Math.max(10, Math.min(MAX_VOLUME, newVolumes[r]));
            pitches[r] = Math.max(50, Math.min(200, newPitches[r]));
        }
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** A button was tapped: play that announcement where the panel stands. */
    public void play(int row) {
        if (level == null || level.isClientSide || row < 0 || row >= ROWS || names[row].isEmpty()) {
            return;
        }
        long now = level.getGameTime();
        if (now - lastPlayed[row] < 10) {
            return;
        }
        lastPlayed[row] = now;
        if (!clips[row].isEmpty()) {
            if (level instanceof ServerLevel server) {
                double radius = 16.0 * Math.max(1.0, volumes[row] / 100.0) + 8.0;
                PacketDistributor.sendToPlayersNear(server, null, worldPosition.getX() + 0.5,
                        worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5, radius,
                        new ClipPlayPacket(clips[row], worldPosition.getX() + 0.5, worldPosition.getY() + 0.5,
                                worldPosition.getZ() + 0.5, volumes[row], pitches[row]));
            }
            return;
        }
        level.playSound(null, worldPosition, AnnouncerSounds.get(sounds[row]), SoundSource.RECORDS,
                volumes[row] / 100.0F, pitches[row] / 100.0F);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        for (int r = 0; r < ROWS; r++) {
            tag.putString("Name" + r, names[r]);
            tag.putInt("Snd" + r, sounds[r]);
            tag.putInt("Vol" + r, volumes[r]);
            tag.putInt("Pit" + r, pitches[r]);
            tag.putString("Clip" + r, clips[r]);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int r = 0; r < ROWS; r++) {
            if (tag.contains("Name" + r)) {
                names[r] = tag.getString("Name" + r);
                sounds[r] = Math.max(0, Math.min(AnnouncerSounds.count() - 1, tag.getInt("Snd" + r)));
                volumes[r] = Math.max(10, Math.min(MAX_VOLUME, tag.getInt("Vol" + r)));
                pitches[r] = Math.max(50, Math.min(200, tag.getInt("Pit" + r)));
                clips[r] = tag.getString("Clip" + r);
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
