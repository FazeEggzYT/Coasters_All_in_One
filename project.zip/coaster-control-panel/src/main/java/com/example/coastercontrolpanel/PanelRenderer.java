package com.example.coastercontrolpanel;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Draws the operator panel. Used by both the on-screen HUD and the mouse-control screen. */
public final class PanelRenderer {
    public static final int PANEL_W = 222;
    public static final int PANEL_H = 220;
    public static final int PANEL_H_FULL = 310;
    public static final int BTN_W = 100;
    public static final int BTN_H = 32;

    private PanelRenderer() {
    }

    public static int height(PanelBlockEntity p) {
        return p != null && p.hasExtras() ? PANEL_H_FULL : PANEL_H;
    }

    /** Round buttons: channels 10..19, five across, two rows. */
    public static int roundX(int px, int channel) {
        return px + 8 + ((channel - PanelBlockEntity.RECT) % 5) * 42;
    }

    public static int roundY(int py, int channel) {
        return py + 216 + ((channel - PanelBlockEntity.RECT) / 5) * 46;
    }

    /** The lever sits in the top-left corner. */
    public static boolean overLever(int px, int py, double mx, double my) {
        return mx >= px + 4 && mx < px + 30 && my >= py + 4 && my < py + 28;
    }

    /** Which channel (0..19, or MASTER) is under the mouse, or -1. */
    public static int hit(PanelBlockEntity p, int px, int py, double mx, double my) {
        if (p == null) {
            return -1;
        }
        if (p.hasExtras() && overLever(px, py, mx, my)) {
            return PanelBlockEntity.MASTER;
        }
        for (int r = 0; r < PanelBlockEntity.RECT; r++) {
            if (p.getName(r).isEmpty()) {
                continue;
            }
            int bx = buttonX(px, r);
            int by = buttonY(py, r);
            if (mx >= bx && mx < bx + BTN_W && my >= by && my < by + BTN_H) {
                return r;
            }
        }
        if (p.hasExtras()) {
            for (int r = PanelBlockEntity.RECT; r < PanelBlockEntity.ROWS; r++) {
                if (p.getName(r).isEmpty()) {
                    continue;
                }
                int bx = roundX(px, r);
                int by = roundY(py, r);
                if (mx >= bx && mx < bx + 40 && my >= by && my < by + 44) {
                    return r;
                }
            }
        }
        return -1;
    }

    private static void disc(GuiGraphics g, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.round(Math.sqrt(radius * radius - dy * dy + 0.5));
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    public static int buttonX(int px, int row) {
        return px + 8 + (row % 2) * 106;
    }

    public static int buttonY(int py, int row) {
        return py + 30 + (row / 2) * 37;
    }

    private static int shade(int argb, float factor) {
        int r = Math.min(255, (int) (((argb >> 16) & 0xFF) * factor));
        int g = Math.min(255, (int) (((argb >> 8) & 0xFF) * factor));
        int b = Math.min(255, (int) ((argb & 0xFF) * factor));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void drawLever(GuiGraphics g, int px, int py, boolean on, boolean held) {
        g.fill(px + 5, py + 5, px + 29, py + 27, 0xFF0D0E12);
        g.fill(px + 15, py + 8, px + 19, py + 24, 0xFF3A3E4D);
        int knob = on ? 0xFF50FF70 : 0xFFD22A2A;
        int ky = on ? py + 8 : py + 17;
        g.fill(px + 12, ky, px + 22, ky + 7, 0xFF0D0E12);
        g.fill(px + 13, ky + 1 + (held ? 1 : 0), px + 21, ky + 6, knob);
    }

    public static void draw(GuiGraphics g, Font font, PanelBlockEntity p, int px, int py, int heldRow, Component hint) {
        int ph = height(p);
        boolean extras = p.hasExtras();
        boolean master = p.isMasterOn();
        g.fill(px, py, px + PANEL_W, py + ph, 0xFF3A3E4D);
        g.fill(px + 2, py + 2, px + PANEL_W - 2, py + ph - 2, 0xFF1B1D24);
        int tx = extras ? px + 34 : px + 8;

        String title = p.getRideName().isEmpty()
                ? Component.translatable("gui.coastercontrolpanel.title").getString()
                : p.getRideName();
        g.drawString(font, title, tx, py + 8, 0xFFFFFF, true);
        g.drawString(font, hint, tx, py + 19, 0x7A8098, false);

        boolean blink = (System.currentTimeMillis() / 250) % 2 == 0;
        for (int r = 0; r < PanelBlockEntity.RECT; r++) {
            if (p.getName(r).isEmpty()) {
                continue;
            }
            int bx = buttonX(px, r);
            int by = buttonY(py, r);
            boolean lit = p.isLampOn(r);
            int base = PanelBlockEntity.COLORS[p.getColor(r)];
            boolean red = p.getColor(r) == 1;
            boolean flashing = lit && (red || p.getMode(r) == PanelBlockEntity.TIMED);
            float factor = lit ? (flashing && !blink ? 0.8F : 1.2F) : 0.5F;
            int face = shade(base, factor);
            int off = heldRow == r ? 1 : 0;

            g.fill(bx, by, bx + BTN_W, by + BTN_H, 0xFF0D0E12);
            g.fill(bx + 2 + off, by + 2 + off, bx + BTN_W - 2, by + BTN_H - 2, face);
            int lamp = lit ? (red ? 0xFFFF4A40 : 0xFF50FF70) : 0xFF1E3A24;
            g.fill(bx + 6, by + 6, bx + 14, by + 14, 0xFF0D0E12);
            g.fill(bx + 7, by + 7, bx + 13, by + 13, lamp);

            g.drawString(font, p.getName(r), bx + 20, by + 6, 0xFFFFFF, true);
            String mode = switch (p.getMode(r)) {
                case PanelBlockEntity.TOGGLE -> Component.translatable("gui.coastercontrolpanel.mode.toggle").getString();
                case PanelBlockEntity.TIMED -> Component.translatable("gui.coastercontrolpanel.mode.timed").getString()
                        + " " + p.getSeconds(r) + "s";
                default -> Component.translatable("gui.coastercontrolpanel.mode.hold").getString();
            };
            g.drawString(font, mode, bx + 20, by + 18, 0xE6E6E6, false);
        }
        if (extras) {
            drawLever(g, px, py, master, heldRow == PanelBlockEntity.MASTER);
            for (int r = PanelBlockEntity.RECT; r < PanelBlockEntity.ROWS; r++) {
                if (p.getName(r).isEmpty()) {
                    continue;
                }
                int bx = roundX(px, r);
                int by = roundY(py, r);
                boolean lit = p.isLampOn(r);
                int base = PanelBlockEntity.COLORS[p.getColor(r)];
                boolean flashing = lit && (p.getColor(r) == 1 || p.getMode(r) == PanelBlockEntity.TIMED);
                float factor = lit ? (flashing && !blink ? 0.8F : 1.25F) : 0.45F;
                int off = heldRow == r ? 1 : 0;
                disc(g, bx + 20, by + 17 + off, 17, 0xFF0D0E12);
                disc(g, bx + 20, by + 17 + off, 14, shade(base, factor));
                if (lit) {
                    disc(g, bx + 20, by + 17 + off, 6, shade(base, 1.7F));
                }
                String label = font.plainSubstrByWidth(p.getName(r), 64);
                g.pose().pushPose();
                g.pose().translate(bx + 20, by + 36, 0);
                g.pose().scale(0.65F, 0.65F, 1.0F);
                g.drawString(font, label, -font.width(label) / 2, 0, 0xFFFFFF, true);
                g.pose().popPose();
            }
        }
        if (extras && !master) {
            g.fill(px + 2, py + 30, px + PANEL_W - 2, py + ph - 2, 0x99000000);
        }
    }
}
