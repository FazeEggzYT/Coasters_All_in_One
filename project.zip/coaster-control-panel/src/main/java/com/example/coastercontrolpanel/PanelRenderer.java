package com.example.coastercontrolpanel;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Draws the operator panel. Used by both the on-screen HUD and the mouse-control screen. */
public final class PanelRenderer {
    public static final int PANEL_W = 222;
    public static final int PANEL_H = 220;
    public static final int BTN_W = 100;
    public static final int BTN_H = 32;

    private PanelRenderer() {
    }

    public static int buttonX(int px, int row) {
        return px + 8 + (row % 2) * 106;
    }

    public static int buttonY(int py, int row) {
        return py + 30 + (row / 2) * 37;
    }

    private static int shade(int argb, float factor) {
        int r = Math.min(255, (int) (((argb >> 16) & 0xFF) * factor));
        int g = Math.min(255, (int) (((argb >> 8) & 0xFF) * factor));
        int b = Math.min(255, (int) ((argb & 0xFF) * factor));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static void draw(GuiGraphics g, Font font, PanelBlockEntity p, int px, int py, int heldRow, Component hint) {
        g.fill(px, py, px + PANEL_W, py + PANEL_H, 0xFF3A3E4D);
        g.fill(px + 2, py + 2, px + PANEL_W - 2, py + PANEL_H - 2, 0xFF1B1D24);

        String title = p.getRideName().isEmpty()
                ? Component.translatable("gui.coastercontrolpanel.title").getString()
                : p.getRideName();
        g.drawString(font, title, px + 8, py + 8, 0xFFFFFF, true);
        g.drawString(font, hint, px + 8, py + 19, 0x7A8098, false);

        boolean blink = (System.currentTimeMillis() / 250) % 2 == 0;
        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            if (p.getName(r).isEmpty()) {
                continue;
            }
            int bx = buttonX(px, r);
            int by = buttonY(py, r);
            boolean lit = p.isLampOn(r);
            int base = PanelBlockEntity.COLORS[p.getColor(r)];
            boolean red = p.getColor(r) == 1;
            boolean flashing = lit && (red || p.getMode(r) == PanelBlockEntity.TIMED);
            float factor = lit ? (flashing && !blink ? 0.8F : 1.2F) : 0.5F;
            int face = shade(base, factor);
            int off = heldRow == r ? 1 : 0;

            g.fill(bx, by, bx + BTN_W, by + BTN_H, 0xFF0D0E12);
            g.fill(bx + 2 + off, by + 2 + off, bx + BTN_W - 2, by + BTN_H - 2, face);
            int lamp = lit ? (red ? 0xFFFF4A40 : 0xFF50FF70) : 0xFF1E3A24;
            g.fill(bx + 6, by + 6, bx + 14, by + 14, 0xFF0D0E12);
            g.fill(bx + 7, by + 7, bx + 13, by + 13, lamp);

            g.drawString(font, p.getName(r), bx + 20, by + 6, 0xFFFFFF, true);
            String mode = switch (p.getMode(r)) {
                case PanelBlockEntity.TOGGLE -> Component.translatable("gui.coastercontrolpanel.mode.toggle").getString();
                case PanelBlockEntity.TIMED -> Component.translatable("gui.coastercontrolpanel.mode.timed").getString()
                        + " " + p.getSeconds(r) + "s";
                default -> Component.translatable("gui.coastercontrolpanel.mode.hold").getString();
            };
            g.drawString(font, mode, bx + 20, by + 18, 0xE6E6E6, false);
        }
    }
}
