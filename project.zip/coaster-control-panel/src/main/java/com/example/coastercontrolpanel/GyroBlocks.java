package com.example.coastercontrolpanel;

/**
 * The blocks of the Gyro Swing. They behave exactly like the Swing Ride blocks (the same engine runs them); the ring is
 * the gondola and turns in the plane of the swing.
 */
public final class GyroBlocks {
    private GyroBlocks() {
    }

    public static class BaseBlock extends SwingBlocks.BaseBlock {
        public BaseBlock(Properties properties) {
            super(properties);
        }
    }

    public static class PivotBlock extends SwingBlocks.PivotBlock {
        public PivotBlock(Properties properties) {
            super(properties);
        }
    }

    public static class ArmBlock extends SwingBlocks.ArmBlock {
        public ArmBlock(Properties properties) {
            super(properties);
        }
    }

    public static class HubBlock extends SwingBlocks.HubBlock {
        public HubBlock(Properties properties) {
            super(properties);
        }
    }

    /** A piece of the ring: a frame that sticks to other ring pieces and to touching seats. */
    public static class RingBlock extends SwingBlocks.GondolaFrameBlock {
        public RingBlock(Properties properties) {
            super(properties);
        }
    }
}
