package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The ordering chain of the Restaurant and Cafe pack:
 * Order Kiosk (guests order and pay in gold nuggets) -> Cash Register (staff mark orders ready)
 * -> Pickup Display (shows ready numbers, guests collect). The Menu Board can copy the kiosk's menu.
 */
public final class RestaurantBlocks {
    private RestaurantBlocks() {
    }

    public static final int RADIUS = 24;

    /** The nearest order kiosk within the radius, or null. Works on both client and server. */
    @Nullable
    public static KioskBlockEntity findKiosk(Level level, BlockPos pos) {
        KioskBlockEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (int cx = (pos.getX() - RADIUS) >> 4; cx <= (pos.getX() + RADIUS) >> 4; cx++) {
            for (int cz = (pos.getZ() - RADIUS) >> 4; cz <= (pos.getZ() + RADIUS) >> 4; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (be instanceof KioskBlockEntity k) {
                        double d = k.getBlockPos().distSqr(pos);
                        if (d <= RADIUS * RADIUS && d < bestDist) {
                            bestDist = d;
                            best = k;
                        }
                    }
                }
            }
        }
        return best;
    }

    abstract static class Syncing extends BlockEntity {
        Syncing(BlockEntityType<?> type, BlockPos pos, BlockState state) {
            super(type, pos, state);
        }

        public void changed() {
            setChanged();
            if (level != null) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            }
        }

        @Override
        public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
            return saveWithoutMetadata(registries);
        }

        @Nullable
        @Override
        public Packet<ClientGamePacketListener> getUpdatePacket() {
            return ClientboundBlockEntityDataPacket.create(this);
        }
    }

    // ------------------------------------------------------------------ order kiosk

    public record Order(int number, ItemStack item, UUID player, boolean ready) {
    }

    public static class KioskBlockEntity extends Syncing {
        public static final int SLOTS = 6;
        public static final int MAX_ORDERS = 40;
        public final ItemStack[] offers = new ItemStack[SLOTS];
        public final int[] prices = new int[SLOTS];
        public final List<Order> orders = new ArrayList<>();
        public int nextNumber = 1;

        public KioskBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.KIOSK_BE.get(), pos, state);
            for (int i = 0; i < SLOTS; i++) {
                offers[i] = ItemStack.EMPTY;
                prices[i] = 2;
            }
        }

        /** 0 added, 1 already on the menu, 2 menu full. */
        public int addOffer(ItemStack held) {
            for (int i = 0; i < SLOTS; i++) {
                if (!offers[i].isEmpty() && ItemStack.isSameItem(offers[i], held)) {
                    return 1;
                }
            }
            for (int i = 0; i < SLOTS; i++) {
                if (offers[i].isEmpty()) {
                    offers[i] = held.copyWithCount(1);
                    prices[i] = 2;
                    changed();
                    return 0;
                }
            }
            return 2;
        }

        public void clearOffer(int i) {
            if (i >= 0 && i < SLOTS) {
                offers[i] = ItemStack.EMPTY;
                changed();
            }
        }

        public void changePrice(int i, int delta) {
            if (i >= 0 && i < SLOTS && !offers[i].isEmpty()) {
                prices[i] = Math.max(0, Math.min(64, prices[i] + delta));
                changed();
            }
        }

        private static int nuggets(Player p) {
            int n = 0;
            for (ItemStack s : p.getInventory().items) {
                if (s.is(Items.GOLD_NUGGET)) {
                    n += s.getCount();
                }
            }
            return n;
        }

        private static void takeNuggets(Player p, int amount) {
            for (ItemStack s : p.getInventory().items) {
                if (amount <= 0) {
                    return;
                }
                if (s.is(Items.GOLD_NUGGET)) {
                    int t = Math.min(amount, s.getCount());
                    s.shrink(t);
                    amount -= t;
                }
            }
        }

        public void placeOrder(ServerPlayer player, int i) {
            if (i < 0 || i >= SLOTS || offers[i].isEmpty()) {
                return;
            }
            if (orders.size() >= MAX_ORDERS) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.kiosk_busy"), true);
                return;
            }
            int price = prices[i];
            if (!player.getAbilities().instabuild) {
                if (nuggets(player) < price) {
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.kiosk_poor", price), true);
                    return;
                }
                takeNuggets(player, price);
            }
            int number = nextNumber++;
            orders.add(new Order(number, offers[i].copy(), player.getUUID(), false));
            changed();
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.kiosk_placed", number, offers[i].getHoverName()), true);
            if (level != null) {
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.BLOCKS, 0.8F, 1.5F);
            }
        }

        public void markReady(int number) {
            for (int i = 0; i < orders.size(); i++) {
                Order o = orders.get(i);
                if (o.number() == number && !o.ready()) {
                    orders.set(i, new Order(o.number(), o.item(), o.player(), true));
                    changed();
                    if (level != null) {
                        level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
                    }
                    return;
                }
            }
        }

        public void markAllReady() {
            for (int i = 0; i < orders.size(); i++) {
                Order o = orders.get(i);
                orders.set(i, new Order(o.number(), o.item(), o.player(), true));
            }
            changed();
        }

        public void clearOrders() {
            orders.clear();
            changed();
        }

        public int preparing() {
            int n = 0;
            for (Order o : orders) {
                if (!o.ready()) {
                    n++;
                }
            }
            return n;
        }

        public List<Integer> readyNumbers() {
            List<Integer> r = new ArrayList<>();
            for (Order o : orders) {
                if (o.ready()) {
                    r.add(o.number());
                }
            }
            return r;
        }

        /** Gives the player all their ready orders. Returns how many were handed over. */
        public int collect(ServerPlayer player) {
            int n = 0;
            for (int i = orders.size() - 1; i >= 0; i--) {
                Order o = orders.get(i);
                if (o.ready() && o.player().equals(player.getUUID())) {
                    ItemStack give = o.item().copy();
                    if (!player.getInventory().add(give)) {
                        player.drop(give, false);
                    }
                    orders.remove(i);
                    n++;
                }
            }
            if (n > 0) {
                changed();
            }
            return n;
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Next", nextNumber);
            ListTag offerList = new ListTag();
            for (int i = 0; i < SLOTS; i++) {
                CompoundTag t = new CompoundTag();
                t.put("Item", offers[i].saveOptional(registries));
                t.putInt("Price", prices[i]);
                offerList.add(t);
            }
            tag.put("Offers", offerList);
            ListTag orderList = new ListTag();
            for (Order o : orders) {
                CompoundTag t = new CompoundTag();
                t.putInt("No", o.number());
                t.put("Item", o.item().saveOptional(registries));
                t.putUUID("Player", o.player());
                t.putBoolean("Ready", o.ready());
                orderList.add(t);
            }
            tag.put("Orders", orderList);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            nextNumber = Math.max(1, tag.getInt("Next"));
            ListTag offerList = tag.getList("Offers", Tag.TAG_COMPOUND);
            for (int i = 0; i < SLOTS; i++) {
                if (i < offerList.size()) {
                    CompoundTag t = offerList.getCompound(i);
                    offers[i] = ItemStack.parseOptional(registries, t.getCompound("Item"));
                    prices[i] = t.getInt("Price");
                }
            }
            orders.clear();
            ListTag orderList = tag.getList("Orders", Tag.TAG_COMPOUND);
            for (int i = 0; i < orderList.size(); i++) {
                CompoundTag t = orderList.getCompound(i);
                orders.add(new Order(t.getInt("No"), ItemStack.parseOptional(registries, t.getCompound("Item")),
                        t.getUUID("Player"), t.getBoolean("Ready")));
            }
        }
    }

    abstract static class FacingEntityBlock extends BaseEntityBlock {
        protected FacingEntityBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(DecorBlocks.FACING, Direction.NORTH));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(DecorBlocks.FACING);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return defaultBlockState().setValue(DecorBlocks.FACING, c.getHorizontalDirection().getOpposite());
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }
    }

    /** Order kiosk. Empty hand: order screen. Holding an item: adds it to the menu. */
    public static class KioskBlock extends FacingEntityBlock {
        public static final MapCodec<KioskBlock> CODEC = simpleCodec(KioskBlock::new);

        public KioskBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(2, 0, 2, 14, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new KioskBlockEntity(pos, state);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.isEmpty()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof KioskBlockEntity k) {
                int r = k.addOffer(stack);
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.kiosk_add_" + r, stack.getHoverName()), true);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(1, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ cash register

    /** Staff terminal. Lists the orders from the nearest kiosk and marks them ready. */
    public static class RegisterBlock extends DecorBlocks.Facing {
        public RegisterBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 1, 0, 2, 15, 13, 14);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(2, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ pickup display

    public static class PickupBlockEntity extends Syncing {
        public List<Integer> ready = new ArrayList<>();
        public int preparing;
        // client only, for the flashing
        public int lastCount = -1;
        public long blinkUntil;

        public PickupBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.PICKUP_BE.get(), pos, state);
        }

        public void serverTick() {
            if (level == null || level.getGameTime() % 20 != 7) {
                return;
            }
            KioskBlockEntity k = findKiosk(level, worldPosition);
            List<Integer> r = k == null ? new ArrayList<>() : k.readyNumbers();
            int prep = k == null ? 0 : k.preparing();
            if (!r.equals(ready) || prep != preparing) {
                ready = r;
                preparing = prep;
                changed();
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putIntArray("Ready", ready.stream().mapToInt(Integer::intValue).toArray());
            tag.putInt("Preparing", preparing);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            ready = new ArrayList<>();
            for (int n : tag.getIntArray("Ready")) {
                ready.add(n);
            }
            preparing = tag.getInt("Preparing");
        }
    }

    /** Wall screen showing the ready order numbers. Right-click: collect your order. */
    public static class PickupBlock extends FacingEntityBlock {
        public static final MapCodec<PickupBlock> CODEC = simpleCodec(PickupBlock::new);

        public PickupBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 3, 14, 16, 13, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new PickupBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.PICKUP_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(3, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ menu board

    public static class MenuBoardBlockEntity extends Syncing {
        public static final int LINES = 6;
        public String title = "";
        public final String[] lines = {"", "", "", "", "", ""};
        public boolean auto;

        public MenuBoardBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.MENU_BOARD_BE.get(), pos, state);
        }

        public void apply(String title, String[] text, boolean auto) {
            this.title = title.length() > 24 ? title.substring(0, 24) : title;
            for (int i = 0; i < LINES; i++) {
                String s = i < text.length ? text[i] : "";
                lines[i] = s.length() > 28 ? s.substring(0, 28) : s;
            }
            this.auto = auto;
            changed();
        }

        public void serverTick() {
            if (!auto || level == null || level.getGameTime() % 40 != 11) {
                return;
            }
            KioskBlockEntity k = findKiosk(level, worldPosition);
            if (k == null) {
                return;
            }
            boolean diff = false;
            for (int i = 0; i < LINES; i++) {
                String s = k.offers[i].isEmpty() ? "" : k.offers[i].getHoverName().getString() + "  " + k.prices[i] + "g";
                if (!s.equals(lines[i])) {
                    lines[i] = s;
                    diff = true;
                }
            }
            if (diff) {
                changed();
            }
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putString("Title", title);
            tag.putBoolean("Auto", auto);
            for (int i = 0; i < LINES; i++) {
                tag.putString("L" + i, lines[i]);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            title = tag.getString("Title");
            auto = tag.getBoolean("Auto");
            for (int i = 0; i < LINES; i++) {
                lines[i] = tag.getString("L" + i);
            }
        }
    }

    /** A chalkboard menu. Write your own lines, or copy the nearest kiosk's menu and prices. */
    public static class MenuBoardBlock extends FacingEntityBlock {
        public static final MapCodec<MenuBoardBlock> CODEC = simpleCodec(MenuBoardBlock::new);

        public MenuBoardBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 14, 16, 16, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new MenuBoardBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.MENU_BOARD_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(5, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ condiment stand

    public static class CondimentBlockEntity extends Syncing {
        public int ketchup = 100;
        public int mustard = 100;

        public CondimentBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.CONDIMENT_BE.get(), pos, state);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Ketchup", ketchup);
            tag.putInt("Mustard", mustard);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            if (tag.contains("Ketchup")) {
                ketchup = tag.getInt("Ketchup");
                mustard = tag.getInt("Mustard");
            }
        }

        /** Squeezes ketchup (0) or mustard (1) onto the food in the player's hand. */
        public void squeeze(ServerPlayer player, int which) {
            ItemStack held = player.getMainHandItem();
            if (held.get(DataComponents.FOOD) == null) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.sauce_food"), true);
                return;
            }
            String key = which == 0 ? "Ketchup" : "Mustard";
            int level = which == 0 ? ketchup : mustard;
            if (level < 10) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.sauce_empty"), true);
                return;
            }
            CompoundTag existing = held.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
            if (existing.getBoolean(key)) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.sauce_has"), true);
                return;
            }
            ItemStack one = held.split(1);
            CustomData.update(DataComponents.CUSTOM_DATA, one, tag -> {
                tag.putBoolean(key, true);
                tag.putInt("Sauce", tag.getInt("Sauce") + 1);
            });
            List<Component> lore = new ArrayList<>(one.getOrDefault(DataComponents.LORE, ItemLore.EMPTY).lines());
            lore.add(Component.translatable("item.coastercontrolpanel.sauce_" + which));
            one.set(DataComponents.LORE, new ItemLore(lore));
            if (which == 0) {
                ketchup -= 10;
            } else {
                mustard -= 10;
            }
            changed();
            if (!player.getInventory().add(one)) {
                player.drop(one, false);
            }
            if (level() != null) {
                level().playSound(null, worldPosition, SoundEvents.SLIME_BLOCK_STEP, SoundSource.BLOCKS, 0.8F, 1.4F);
            }
        }

        private Level level() {
            return this.level;
        }
    }

    /** Ketchup and mustard. Squeeze onto food: each sauce gives +1 hunger when the food is eaten. */
    public static class CondimentBlock extends FacingEntityBlock {
        public static final MapCodec<CondimentBlock> CODEC = simpleCodec(CondimentBlock::new);

        public CondimentBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(3, 0, 4, 13, 8, 12);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new CondimentBlockEntity(pos, state);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            boolean red = stack.is(Items.BEETROOT);
            boolean yellow = stack.is(Items.YELLOW_DYE);
            if (!red && !yellow) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof CondimentBlockEntity c) {
                if (red) {
                    c.ketchup = Math.min(100, c.ketchup + 25);
                } else {
                    c.mustard = Math.min(100, c.mustard + 25);
                }
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                c.changed();
                level.playSound(null, pos, SoundEvents.SLIME_BLOCK_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(4, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ tray trolley

    public static class TrolleyBlockEntity extends KitchenExtras.FridgeBlockEntity {
        public TrolleyBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.TROLLEY_BE.get(), pos, state);
        }

        @Override
        protected Component getDefaultName() {
            return Component.translatable("block.coastercontrolpanel.tray_trolley");
        }

        private static boolean returnable(ItemStack s) {
            return s.is(Items.BOWL) || s.is(Items.GLASS_BOTTLE) || s.is(Items.PAPER) || s.is(Items.STICK);
        }

        public void serverTick() {
            if (!(level instanceof ServerLevel sl) || sl.getGameTime() % 40 != 3) {
                return;
            }
            AABB box = new AABB(worldPosition).inflate(2.5, 1.0, 2.5);
            for (ItemEntity e : sl.getEntitiesOfClass(ItemEntity.class, box)) {
                ItemStack stack = e.getItem();
                if (!returnable(stack)) {
                    continue;
                }
                ItemStack rest = insert(stack.copy());
                if (rest.isEmpty()) {
                    e.discard();
                } else {
                    e.setItem(rest);
                }
            }
        }

        private ItemStack insert(ItemStack stack) {
            for (int i = 0; i < getContainerSize() && !stack.isEmpty(); i++) {
                ItemStack in = getItem(i);
                if (!in.isEmpty() && ItemStack.isSameItemSameComponents(in, stack) && in.getCount() < in.getMaxStackSize()) {
                    int move = Math.min(stack.getCount(), in.getMaxStackSize() - in.getCount());
                    in.grow(move);
                    stack.shrink(move);
                    setChanged();
                }
            }
            for (int i = 0; i < getContainerSize() && !stack.isEmpty(); i++) {
                if (getItem(i).isEmpty()) {
                    setItem(i, stack.copy());
                    stack.setCount(0);
                }
            }
            return stack;
        }
    }

    /** A tray return trolley: 27 slots; it picks up dropped bowls, bottles, paper and sticks within 2.5 blocks. */
    public static class TrolleyBlock extends FacingEntityBlock {
        public static final MapCodec<TrolleyBlock> CODEC = simpleCodec(TrolleyBlock::new);

        public TrolleyBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(1, 0, 2, 15, 14, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new TrolleyBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> t) {
            if (level.isClientSide) {
                return null;
            }
            return createTickerHelper(t, CoasterControlPanel.TROLLEY_BE.get(), (lvl, pos, st, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof TrolleyBlockEntity be) {
                player.openMenu(be);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof Container c) {
                Containers.dropContents(level, pos, c);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }
}
