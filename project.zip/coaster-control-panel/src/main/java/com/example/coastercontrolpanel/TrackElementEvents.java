package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Track Element Selector. Right-click in the air (or on a block with nothing selected) opens the picker.
 * Right-click a block with an element selected to place it; sneak and right-click in the air to clear the selection.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class TrackElementEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), event.getPos(), event)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), null, null)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private static boolean handle(Player player, InteractionHand hand, Level level, BlockPos clicked,
                                  PlayerInteractEvent.RightClickBlock block) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.TRACK_ELEMENT_SELECTOR_ITEM.get())) {
            return false;
        }
        ElementState st = ElementState.read(stack);
        if (clicked == null || st == null) {
            if (level.isClientSide) {
                if (clicked == null && player.isShiftKeyDown() && st != null) {
                    net.neoforged.neoforge.network.PacketDistributor.sendToServer(new TrackElementSelectPacket("", 0, 0, 0, 0));
                    player.displayClientMessage(Component.translatable("message.coastercontrolpanel.element_cleared"), true);
                } else {
                    ClientHooks.openElementSelector();
                }
            } else if (clicked == null && player.isShiftKeyDown() && st != null) {
                ElementState.write(stack, "", null, 0);
            }
            return true;
        }
        if (level.isClientSide || !(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel sl)) {
            return true;
        }
        ElementPlacer.Context c = ElementPlacer.resolve(sl, sp, clicked, block.getHitVec().getDirection(), st);
        Object[] r = ElementPlacer.place(sl, sp, c);
        if (r[0] != null) {
            Component why = r.length > 1 ? Component.translatable((String) r[0], java.util.Arrays.copyOfRange(r, 1, r.length)) : Component.translatable((String) r[0]);
            sp.displayClientMessage(why, true);
        } else {
            sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.element_placed",
                    Component.translatable("element.coastercontrolpanel." + st.element().id()), r[1], r[4]), true);
        }
        return true;
    }
}
