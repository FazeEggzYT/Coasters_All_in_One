package com.example.coastercontrolpanel;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Dark panel with an Input pair and an Output pair of item slots for every row. */
public class PanelScreen extends AbstractContainerScreen<PanelMenu> {
    private static final int[] ROW_COLORS = {
            0xFF3C78DC, 0xFF3C78DC, 0xFFE6BE28, 0xFFD21E1E, 0xFF288C46, 0xFFE67820
    };

    public PanelScreen(PanelMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 240;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("OK").withStyle(ChatFormatting.GREEN), b -> onClose())
                .bounds(leftPos + 138, topPos + 3, 30, 14)
                .build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        // Panel body and border.
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        // Divider between input and output columns.
        g.fill(x0 + 111, y0 + 28, x0 + 112, y0 + 150, 0xFF3A3E4D);
        // Row color strips.
        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            int y = y0 + 29 + 20 * r;
            g.fill(x0 + 4, y, x0 + 6, y + 16, ROW_COLORS[r]);
        }
        // Slot boxes.
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.input"), 72, 19, 0xA0A8C0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.output"), 124, 19, 0xA0A8C0, false);
        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.row." + r),
                    10, 33 + 20 * r, 0xE0E4F0, false);
        }
    }
}
