package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Setup screen: ride name, and for every row a name, a mode (Hold / Toggle / Timed),
 * seconds, a colour, plus an Input slot and an Output slot.
 */
public class PanelScreen extends AbstractContainerScreen<PanelMenu> {
    private static final int ROWS = PanelBlockEntity.ROWS;

    private final String[] names = new String[ROWS];
    private final int[] modes = new int[ROWS];
    private final int[] seconds = new int[ROWS];
    private final int[] colors = new int[ROWS];
    private String rideName = "";

    private final EditBox[] nameBoxes = new EditBox[ROWS];
    private final EditBox[] secBoxes = new EditBox[ROWS];
    private final Button[] modeButtons = new Button[ROWS];
    private final Button[] colorButtons = new Button[ROWS];
    private EditBox rideBox;

    public PanelScreen(PanelMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 424;
        this.imageHeight = 196;
    }

    private PanelBlockEntity panel() {
        if (minecraft == null || minecraft.level == null) {
            return null;
        }
        return minecraft.level.getBlockEntity(menu.getPos()) instanceof PanelBlockEntity p ? p : null;
    }

    @Override
    protected void init() {
        super.init();
        PanelBlockEntity p = panel();
        for (int r = 0; r < ROWS; r++) {
            names[r] = p != null ? p.getName(r) : "";
            modes[r] = p != null ? p.getMode(r) : PanelBlockEntity.HOLD;
            seconds[r] = p != null ? p.getSeconds(r) : 5;
            colors[r] = p != null ? p.getColor(r) : 0;
        }
        rideName = p != null ? p.getRideName() : "";

        rideBox = new EditBox(font, leftPos + 8, topPos + 19, 150, 14, Component.empty());
        rideBox.setMaxLength(24);
        rideBox.setValue(rideName);
        rideBox.setHint(Component.translatable("gui.coastercontrolpanel.ride_hint"));
        addRenderableWidget(rideBox);

        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + 204, topPos + 17, 40, 16)
                .build());

        for (int r = 0; r < ROWS; r++) {
            final int row = r;
            int y = topPos + PanelMenu.ROW_Y + PanelMenu.ROW_STEP * r + 1;

            EditBox nameBox = new EditBox(font, leftPos + 8, y, 82, 14, Component.empty());
            nameBox.setMaxLength(14);
            nameBox.setValue(names[r]);
            nameBox.setHint(Component.translatable("gui.coastercontrolpanel.unused"));
            nameBoxes[r] = nameBox;
            addRenderableWidget(nameBox);

            modeButtons[r] = Button.builder(modeText(r), b -> {
                modes[row] = (modes[row] + 1) % 3;
                refreshRow(row);
            }).bounds(leftPos + 92, y, 42, 14).build();
            addRenderableWidget(modeButtons[r]);

            EditBox secBox = new EditBox(font, leftPos + 136, y, 26, 14, Component.empty());
            secBox.setMaxLength(3);
            secBox.setFilter(s -> s.matches("\\d{0,3}"));
            secBox.setValue(Integer.toString(seconds[r]));
            secBoxes[r] = secBox;
            addRenderableWidget(secBox);

            colorButtons[r] = Button.builder(colorText(r), b -> {
                colors[row] = (colors[row] + 1) % PanelBlockEntity.COLORS.length;
                refreshRow(row);
            }).bounds(leftPos + 164, y, 28, 14).build();
            addRenderableWidget(colorButtons[r]);

            refreshRow(r);
        }
    }

    private Component modeText(int r) {
        return switch (modes[r]) {
            case PanelBlockEntity.TOGGLE -> Component.translatable("gui.coastercontrolpanel.mode.toggle");
            case PanelBlockEntity.TIMED -> Component.translatable("gui.coastercontrolpanel.mode.timed");
            default -> Component.translatable("gui.coastercontrolpanel.mode.hold");
        };
    }

    private Component colorText(int r) {
        int rgb = PanelBlockEntity.COLORS[colors[r]] & 0xFFFFFF;
        return Component.literal(PanelBlockEntity.COLOR_NAMES[colors[r]]).withStyle(s -> s.withColor(rgb));
    }

    private void refreshRow(int r) {
        modeButtons[r].setMessage(modeText(r));
        colorButtons[r].setMessage(colorText(r));
        secBoxes[r].setEditable(modes[r] == PanelBlockEntity.TIMED);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // Escape
            onClose();
            return true;
        }
        // Let a focused text box swallow keys such as "e" instead of closing the screen.
        if (rideBox != null && rideBox.isFocused() && rideBox.canConsumeInput()) {
            return rideBox.keyPressed(keyCode, scanCode, modifiers) || true;
        }
        for (int r = 0; r < ROWS; r++) {
            if (nameBoxes[r] != null && nameBoxes[r].isFocused() && nameBoxes[r].canConsumeInput()) {
                return nameBoxes[r].keyPressed(keyCode, scanCode, modifiers) || true;
            }
            if (secBoxes[r] != null && secBoxes[r].isFocused() && secBoxes[r].canConsumeInput()) {
                return secBoxes[r].keyPressed(keyCode, scanCode, modifiers) || true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        String[] outNames = new String[ROWS];
        int[] outSeconds = new int[ROWS];
        for (int r = 0; r < ROWS; r++) {
            outNames[r] = nameBoxes[r] != null ? nameBoxes[r].getValue() : names[r];
            int s = 5;
            try {
                if (secBoxes[r] != null && !secBoxes[r].getValue().isEmpty()) {
                    s = Integer.parseInt(secBoxes[r].getValue());
                }
            } catch (NumberFormatException ignored) {
                s = 5;
            }
            outSeconds[r] = Math.max(1, s);
        }
        String ride = rideBox != null ? rideBox.getValue() : rideName;
        PacketDistributor.sendToServer(new ConfigPacket(menu.getPos(), outNames, modes.clone(), outSeconds,
                colors.clone(), ride));
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 250, y0 + 4, x0 + 251, y0 + imageHeight - 4, 0xFF3A3E4D);
        for (int r = 0; r < ROWS; r++) {
            int y = y0 + PanelMenu.ROW_Y + PanelMenu.ROW_STEP * r;
            g.fill(x0 + 3, y, x0 + 5, y + 16, PanelBlockEntity.COLORS[colors[r]]);
        }
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        int hy = 41;
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_name"), 10, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_mode"), 94, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_secs"), 138, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_colour"), 166, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_in"), 199, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_out"), 223, hy, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 257, 96, 0x7A8098, false);
    }
}
