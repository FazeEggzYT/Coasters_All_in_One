package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the transfer table settings. */
public record TransferConfigPacket(BlockPos pos, int[] values) implements CustomPacketPayload {
    public static final Type<TransferConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "transfer_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TransferConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.values.length);
                for (int v : p.values) {
                    buf.writeVarInt(v);
                }
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                int n = Math.min(buf.readVarInt(), 16);
                int[] v = new int[n];
                for (int i = 0; i < n; i++) {
                    v[i] = buf.readVarInt();
                }
                return new TransferConfigPacket(pos, v);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(TransferConfigPacket p, IPayloadContext context) {
        TransferTableBlockEntity t = TransferTableBlockEntity.lookup(context.player(), p.pos);
        if (t != null) {
            t.applyConfig(p.values);
        }
    }
}
