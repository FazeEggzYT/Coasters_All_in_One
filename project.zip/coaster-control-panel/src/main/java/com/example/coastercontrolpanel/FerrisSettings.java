package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/** Everything a Ferris Wheel can be told: the sequence of steps and the general settings. All values are clamped here. */
public final class FerrisSettings {
    public static final int ROTATE = 0;
    public static final int STATION = 1;
    public static final int HOLD = 2;
    public static final int TYPES = 3;
    public static final int MAX_STEPS = 10;
    public static final int PRESETS = 4;

    /** ROTATE: a = turns per minute, b = number of turns. STATION: a = seconds of boarding, b = cabins to move on. HOLD: a = seconds. */
    public static final class Step {
        public int type;
        public float a;
        public float b;

        public Step(int type, float a, float b) {
            this.type = type;
            this.a = a;
            this.b = b;
            clamp();
        }

        public void clamp() {
            type = Math.max(0, Math.min(TYPES - 1, type));
            switch (type) {
                case ROTATE -> {
                    a = FerrisSettings.clamp(a, 0.1F, 6.0F);
                    b = FerrisSettings.clamp(b, 0.25F, 30.0F);
                }
                case STATION -> {
                    a = FerrisSettings.clamp(a, 0.0F, 120.0F);
                    b = Math.round(FerrisSettings.clamp(b, 1.0F, 24.0F));
                }
                default -> {
                    a = FerrisSettings.clamp(a, 0.0F, 300.0F);
                    b = 0.0F;
                }
            }
        }

        public void retype(int newType) {
            type = newType;
            switch (type) {
                case ROTATE -> {
                    a = 1.0F;
                    b = 1.0F;
                }
                case STATION -> {
                    a = 8.0F;
                    b = 1.0F;
                }
                default -> {
                    a = 5.0F;
                    b = 0.0F;
                }
            }
        }
    }

    public final List<Step> steps = new ArrayList<>();
    public int loops = 1;
    public float preDelay = 3.0F;
    /** Degrees per second squared used for speeding up and slowing down. */
    public float accel = 6.0F;
    /** Turns per minute while the wheel creeps to the next cabin. */
    public float creep = 0.5F;
    public float haltTime = 2.0F;
    /** 0 = clockwise, 1 = anticlockwise (seen from the positive end of the axle). */
    public int direction = 0;
    public int redstoneMode = 0;
    public int endMode = 0;
    /** True: every block touching the riding part comes with it, whatever it is. False: only frames and seats. */
    public boolean carryAll = true;

    public FerrisSettings() {
        preset(0);
    }

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void preset(int index) {
        steps.clear();
        switch (index) {
            case 1 -> { // boarding loop: every cabin gets a stop
                for (int i = 0; i < 4; i++) {
                    steps.add(new Step(STATION, 10, 1));
                }
                steps.add(new Step(ROTATE, 1, 1));
            }
            case 2 -> { // fast
                steps.add(new Step(ROTATE, 3, 3));
                steps.add(new Step(STATION, 5, 1));
            }
            case 3 -> { // sightseeing: slow turns with a pause at the top is left to the player
                steps.add(new Step(STATION, 12, 1));
                steps.add(new Step(ROTATE, 0.5F, 1));
                steps.add(new Step(HOLD, 10, 0));
                steps.add(new Step(ROTATE, 0.5F, 1));
            }
            default -> { // relaxed
                steps.add(new Step(STATION, 10, 1));
                steps.add(new Step(ROTATE, 1, 2));
                steps.add(new Step(STATION, 6, 1));
            }
        }
    }

    public void sanitize() {
        loops = Math.max(1, Math.min(20, loops));
        preDelay = clamp(preDelay, 0.0F, 30.0F);
        accel = clamp(accel, 1.0F, 30.0F);
        creep = clamp(creep, 0.1F, 3.0F);
        haltTime = clamp(haltTime, 0.5F, 8.0F);
        direction = Math.max(0, Math.min(1, direction));
        redstoneMode = Math.max(0, Math.min(1, redstoneMode));
        endMode = Math.max(0, Math.min(1, endMode));
        while (steps.size() > MAX_STEPS) {
            steps.remove(steps.size() - 1);
        }
        for (Step s : steps) {
            s.clamp();
        }
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Loops", loops);
        t.putFloat("PreDelay", preDelay);
        t.putFloat("Accel", accel);
        t.putFloat("Creep", creep);
        t.putFloat("HaltTime", haltTime);
        t.putInt("Direction", direction);
        t.putInt("Redstone", redstoneMode);
        t.putInt("EndMode", endMode);
        t.putBoolean("CarryAll", carryAll);
        ListTag list = new ListTag();
        for (Step s : steps) {
            CompoundTag c = new CompoundTag();
            c.putInt("T", s.type);
            c.putFloat("A", s.a);
            c.putFloat("B", s.b);
            list.add(c);
        }
        t.put("Steps", list);
        return t;
    }

    public static FerrisSettings fromTag(CompoundTag t) {
        FerrisSettings s = new FerrisSettings();
        if (t == null || t.isEmpty()) {
            return s;
        }
        s.loops = t.contains("Loops") ? t.getInt("Loops") : 1;
        s.preDelay = t.contains("PreDelay") ? t.getFloat("PreDelay") : 3.0F;
        s.accel = t.contains("Accel") ? t.getFloat("Accel") : 6.0F;
        s.creep = t.contains("Creep") ? t.getFloat("Creep") : 0.5F;
        s.haltTime = t.contains("HaltTime") ? t.getFloat("HaltTime") : 2.0F;
        s.direction = t.getInt("Direction");
        s.redstoneMode = t.getInt("Redstone");
        s.endMode = t.getInt("EndMode");
        s.carryAll = !t.contains("CarryAll") || t.getBoolean("CarryAll");
        if (t.contains("Steps", Tag.TAG_LIST)) {
            s.steps.clear();
            ListTag list = t.getList("Steps", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size() && i < MAX_STEPS; i++) {
                CompoundTag c = list.getCompound(i);
                s.steps.add(new Step(c.getInt("T"), c.getFloat("A"), c.getFloat("B")));
            }
        }
        s.sanitize();
        return s;
    }

    public FerrisSettings copy() {
        return fromTag(toTag());
    }
}
