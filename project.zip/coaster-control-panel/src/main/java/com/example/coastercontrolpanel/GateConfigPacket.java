package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the ride gate delay. */
public record GateConfigPacket(BlockPos pos, int delay) implements CustomPacketPayload {
    public static final Type<GateConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "gate_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, GateConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.delay);
            },
            buf -> new GateConfigPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(GateConfigPacket packet, IPayloadContext context) {
        RideGateBlockEntity gate = RideGateBlockEntity.lookup(context.player(), packet.pos);
        if (gate != null) {
            gate.applyConfig(packet.delay);
        }
    }
}
