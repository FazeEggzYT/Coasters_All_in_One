package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.DriveTyre;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Drive Tyre: marks the span of ChainLiftOutlineScopeMixin's chain checks so a held Drive Tyre is accepted as a Chain there. Optional. */
@Mixin(targets = "dev.silvergold.simulatedcoasters.client.track.ChainLiftAnchorOutlineClient", remap = false)
public class ChainLiftOutlineScopeMixin {
    @Inject(method = {"isHoldingChain", "onUseItemKey"}, at = @At("HEAD"), remap = false, require = 0)
    private static void ccp$enter(CallbackInfoReturnable<Boolean> ci) {
        DriveTyre.enter();
    }

    @Inject(method = {"isHoldingChain", "onUseItemKey"}, at = @At("RETURN"), remap = false, require = 0)
    private static void ccp$exit(CallbackInfoReturnable<Boolean> ci) {
        DriveTyre.exit();
    }
}
