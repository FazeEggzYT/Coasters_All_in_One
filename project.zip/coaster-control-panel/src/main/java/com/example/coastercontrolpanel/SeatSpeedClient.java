package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client only: opens the Seat Speed screen for the seat at this position. */
public final class SeatSpeedClient {
    private SeatSpeedClient() {
    }

    public static void open(BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getBlockEntity(pos) instanceof SeatTimerAccess seat) {
            mc.setScreen(new SeatSpeedScreen(pos, seat.seatTimerSpeed()));
        }
    }
}
