package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/** Watches its anchor. When a cart arrives, it flashes and asks a nearby player's game to take the picture. */
public class CameraBlockEntity extends BlockEntity {
    private static final double TRIGGER_RADIUS = 4.0;
    private static final int COOLDOWN = 60;

    @Nullable
    private BlockPos anchor;
    private final List<BlockPos> screens = new ArrayList<>();
    private int version = 0;

    private boolean cartHere = false;
    private int cooldown = 0;
    private int flash = 0;

    public CameraBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.CAMERA_BE.get(), pos, state);
    }

    @Nullable
    public BlockPos getAnchor() {
        return anchor;
    }

    public void setAnchor(@Nullable BlockPos anchor) {
        this.anchor = anchor;
        setChanged();
    }

    public int getVersion() {
        return version;
    }

    @Nullable
    public static CameraBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 128.0 * 128.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof CameraBlockEntity c ? c : null;
    }

    public void addScreen(BlockPos pos) {
        if (!screens.contains(pos)) {
            screens.add(pos);
            setChanged();
        }
    }

    public void removeScreen(BlockPos pos) {
        if (screens.remove(pos)) {
            setChanged();
        }
    }

    public void serverTick() {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        if (cooldown > 0) {
            cooldown--;
        }
        if (flash > 0 && --flash == 0) {
            BlockState state = getBlockState();
            if (state.getValue(CameraBlock.LIT)) {
                server.setBlock(worldPosition, state.setValue(CameraBlock.LIT, false), 3);
            }
        }
        if (anchor == null) {
            return;
        }
        boolean cart = CartScanner.isAvailable()
                && CartScanner.anyCartIn(server, new AABB(anchor).inflate(TRIGGER_RADIUS));
        if (cart && !cartHere && cooldown == 0) {
            takePhoto(server);
        }
        cartHere = cart;
    }

    private void takePhoto(ServerLevel server) {
        cooldown = COOLDOWN;
        flash = 6;
        BlockState state = getBlockState();
        server.setBlock(worldPosition, state.setValue(CameraBlock.LIT, true), 3);
        double x = worldPosition.getX() + 0.5;
        double y = worldPosition.getY() + 0.8;
        double z = worldPosition.getZ() + 0.5;
        server.sendParticles(ParticleTypes.END_ROD, x, y, z, 12, 0.3, 0.3, 0.3, 0.05);
        server.playSound(null, worldPosition, SoundEvents.STONE_BUTTON_CLICK_ON, SoundSource.BLOCKS, 1.0F, 1.6F);
        Player nearest = server.getNearestPlayer(x, y, z, 48.0, false);
        if (nearest instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayer(sp, new PhotoRequestPacket(worldPosition,
                    state.getValue(CameraBlock.FACING).toYRot()));
        }
    }

    /** A new photo arrived from a player's game: tell every linked screen. */
    public void photoReceived() {
        if (level == null || level.isClientSide) {
            return;
        }
        version++;
        setChanged();
        screens.removeIf(p -> !(level.getBlockEntity(p) instanceof PhotoScreenBlockEntity));
        for (BlockPos p : screens) {
            if (level.getBlockEntity(p) instanceof PhotoScreenBlockEntity ps) {
                ps.setVersion(version);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (anchor != null) {
            tag.putLong("Anchor", anchor.asLong());
        }
        tag.putInt("Version", version);
        ListTag list = new ListTag();
        for (BlockPos p : screens) {
            list.add(LongTag.valueOf(p.asLong()));
        }
        tag.put("Screens", list);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        anchor = tag.contains("Anchor") ? BlockPos.of(tag.getLong("Anchor")) : null;
        version = tag.getInt("Version");
        screens.clear();
        for (Tag t : tag.getList("Screens", Tag.TAG_LONG)) {
            if (t instanceof LongTag l) {
                screens.add(BlockPos.of(l.getAsLong()));
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
