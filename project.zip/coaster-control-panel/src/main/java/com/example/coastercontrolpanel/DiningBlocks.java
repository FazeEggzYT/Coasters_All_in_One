package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Dining furniture at real scale (one block is one metre): table top at 0.75 m, seats at 0.45 m.
 * Chair and booth: right-click to sit, sneak and right-click for the options. Table and parasol: right-click for options.
 */
public final class DiningBlocks {
    private DiningBlocks() {
    }

    public static final BooleanProperty CLOTH = BooleanProperty.create("cloth");
    public static final IntegerProperty CENTRE = IntegerProperty.create("centre", 0, 3);
    public static final BooleanProperty RESERVED = BooleanProperty.create("reserved");
    public static final BooleanProperty CUSHION = BooleanProperty.create("cushion");
    public static final BooleanProperty LEDGE = BooleanProperty.create("ledge");
    public static final BooleanProperty PARASOL_OPEN = BooleanProperty.create("open");

    private static VoxelShape dbox(Direction d, double x1, double y1, double z1, double x2, double y2, double z2) {
        return DecorBlocks.dbox(d, x1, y1, z1, x2, y2, z2);
    }

    // ------------------------------------------------------------------ table

    /** A 1 m square table, 0.75 m high. Options: tablecloth, cloth colour, centrepiece, reserved sign. */
    public static class TableBlock extends Block implements RestaurantConfigurable {
        private static final Option[] OPTIONS = {
                new Option("cloth", CLOTH, 1), new Option("color", DecorBlocks.COLOR, 15),
                new Option("centre", CENTRE, 3), new Option("reserved", RESERVED, 1)};

        public TableBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(CLOTH, false).setValue(DecorBlocks.COLOR, 0)
                    .setValue(CENTRE, 0).setValue(RESERVED, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(CLOTH, DecorBlocks.COLOR, CENTRE, RESERVED);
        }

        @Override
        public Option[] options() {
            return OPTIONS;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(0, 0, 0, 16, 12.5, 16);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(0, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ chair and booth

    /** Shared sitting behaviour. */
    public abstract static class SeatBase extends DecorBlocks.Facing implements RestaurantConfigurable {
        private final double sitHeight;

        protected SeatBase(double sitHeight, Properties p) {
            super(p);
            this.sitHeight = sitHeight;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (player.isShiftKeyDown()) {
                if (level.isClientSide) {
                    ClientHooks.openRestaurant(0, pos);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (player.isPassenger()) {
                return InteractionResult.PASS;
            }
            if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.seat_taken"), true);
                return InteractionResult.CONSUME;
            }
            SeatEntity seat = new SeatEntity(CoasterControlPanel.SEAT.get(), level);
            seat.setPos(pos.getX() + 0.5, pos.getY() + sitHeight, pos.getZ() + 0.5);
            level.addFreshEntity(seat);
            player.startRiding(seat);
            return InteractionResult.CONSUME;
        }
    }

    /** A dining chair: seat 0.45 m high, back 0.9 m, optional coloured cushion. */
    public static class ChairBlock extends SeatBase {
        private static final Option[] OPTIONS = {new Option("cushion", CUSHION, 1), new Option("color", DecorBlocks.COLOR, 15)};

        public ChairBlock(Properties p) {
            super(0.15, p);
            registerDefaultState(defaultBlockState().setValue(CUSHION, true).setValue(DecorBlocks.COLOR, 14));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(CUSHION, DecorBlocks.COLOR);
        }

        @Override
        public Option[] options() {
            return OPTIONS;
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(dbox(f, 3, 0, 3, 13, 8, 13), dbox(f, 3, 8, 11, 13, 15, 13));
        }
    }

    /** A dining booth seat: upholstered bench with a high back and a table ledge. Put two facing each other. */
    public static class BoothBlock extends SeatBase {
        private static final Option[] OPTIONS = {new Option("color", DecorBlocks.COLOR, 15), new Option("ledge", LEDGE, 1)};

        public BoothBlock(Properties p) {
            super(0.125, p);
            registerDefaultState(defaultBlockState().setValue(LEDGE, true).setValue(DecorBlocks.COLOR, 14));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(LEDGE, DecorBlocks.COLOR);
        }

        @Override
        public Option[] options() {
            return OPTIONS;
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(dbox(f, 0, 0, 4, 16, 8, 12), dbox(f, 0, 0, 12, 16, 16, 16), dbox(f, 0, 0, 0, 16, 12, 4));
        }
    }

    // ------------------------------------------------------------------ parasol

    /** A café parasol: opens and folds, any of 16 colours. */
    public static class ParasolBlock extends Block implements RestaurantConfigurable {
        private static final Option[] OPTIONS = {new Option("open", PARASOL_OPEN, 1), new Option("color", DecorBlocks.COLOR, 15)};

        public ParasolBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(PARASOL_OPEN, true).setValue(DecorBlocks.COLOR, 14));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(PARASOL_OPEN, DecorBlocks.COLOR);
        }

        @Override
        public Option[] options() {
            return OPTIONS;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return s.getValue(PARASOL_OPEN) ? Shapes.or(Block.box(7, 0, 7, 9, 13, 9), Block.box(1, 13, 1, 15, 16, 15))
                    : Block.box(6, 0, 6, 10, 15, 10);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRestaurant(0, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
