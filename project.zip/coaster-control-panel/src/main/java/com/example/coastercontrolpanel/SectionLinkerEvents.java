package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * The Section Linker: right-click one track anchor, then another, then right-click a Section Controller.
 * The controller then watches the track between those two anchors.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class SectionLinkerEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND
                || !event.getItemStack().is(CoasterControlPanel.SECTION_LINKER_ITEM.get())) {
            return;
        }
        BlockPos pos = event.getPos();
        BlockEntity be = event.getLevel().getBlockEntity(pos);
        boolean anchor = AnchorTrack.isAnchor(be);
        boolean controller = be instanceof SectionControllerBlockEntity;
        if (!anchor && !controller) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            return;
        }
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        boolean hasA = tag.contains("LinkA");
        boolean hasB = tag.contains("LinkB");

        if (anchor) {
            if (!hasA || hasB) {
                tag.putLong("LinkA", pos.asLong());
                tag.remove("LinkB");
                say(player, "message.coastercontrolpanel.linker_a");
            } else if (BlockPos.of(tag.getLong("LinkA")).equals(pos)) {
                say(player, "message.coastercontrolpanel.linker_same");
            } else {
                tag.putLong("LinkB", pos.asLong());
                say(player, "message.coastercontrolpanel.linker_b");
            }
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            return;
        }

        SectionControllerBlockEntity section = (SectionControllerBlockEntity) be;
        if (!hasA || !hasB) {
            say(player, "message.coastercontrolpanel.linker_need_two");
            return;
        }
        int points = section.setTrack(BlockPos.of(tag.getLong("LinkA")), BlockPos.of(tag.getLong("LinkB")));
        if (points == 0) {
            say(player, "message.coastercontrolpanel.linker_not_connected");
        } else {
            player.displayClientMessage(
                    Component.translatable("message.coastercontrolpanel.linker_done", points), true);
        }
    }

    private static void say(Player player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }
}
