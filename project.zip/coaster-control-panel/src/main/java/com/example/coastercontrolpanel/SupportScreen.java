package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.neoforged.neoforge.network.PacketDistributor;

/** Settings screen of the Support Tool. Opens with sneak + right-click in the air. */
public class SupportScreen extends Screen {
    private static final int W = 260;
    private static final int H = 168;

    private int style;
    private int spacing;
    private int thickness;
    private int material;
    private int gap;
    private int left;
    private int top;

    public SupportScreen() {
        super(Component.translatable("gui.coastercontrolpanel.support_title"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (minecraft != null && minecraft.player != null) {
            SupportSettings s = SupportSettings.of(minecraft.player.getItemInHand(InteractionHand.MAIN_HAND));
            style = s.style();
            spacing = s.spacing();
            thickness = s.thickness();
            material = s.material();
            gap = s.gap();
        }
        pair(0, () -> style = wrap(style - 1, 0), () -> style = wrap(style + 1, 0));
        pair(1, () -> spacing = Math.max(SupportSettings.MIN[1], spacing - step()),
                () -> spacing = Math.min(SupportSettings.MAX[1], spacing + step()));
        pair(2, () -> thickness = Math.max(SupportSettings.MIN[2], thickness - 1),
                () -> thickness = Math.min(SupportSettings.MAX[2], thickness + 1));
        pair(3, () -> material = wrap(material - 1, 3), () -> material = wrap(material + 1, 3));
        pair(4, () -> gap = Math.max(SupportSettings.MIN[4], gap - 1),
                () -> gap = Math.min(SupportSettings.MAX[4], gap + 1));
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(left + W - 52, top + H - 24, 44, 16).build());
    }

    private int step() {
        return Screen.hasShiftDown() ? 3 : 1;
    }

    private static int wrap(int v, int i) {
        int n = SupportSettings.MAX[i] - SupportSettings.MIN[i] + 1;
        return ((v - SupportSettings.MIN[i]) % n + n) % n + SupportSettings.MIN[i];
    }

    private void pair(int row, Runnable minus, Runnable plus) {
        int y = top + 24 + row * 22;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> minus.run()).bounds(left + 100, y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> plus.run()).bounds(left + 218, y, 18, 16).build());
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new SupportConfigPacket(style, spacing, thickness, material, gap));
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, title, left + 8, top + 7, 0xFFFFFF, false);
        String[] labels = {"style", "spacing", "thickness", "material", "gap"};
        String[] values = {
                SupportSettings.STYLES[style], spacing + " blocks", thickness + "x" + thickness,
                SupportSettings.MATERIAL_NAMES[material], gap + (gap == 1 ? " block" : " blocks")};
        for (int i = 0; i < labels.length; i++) {
            int y = top + 28 + i * 22;
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.support_" + labels[i]), left + 8, y, 0xE0E4F0, false);
            g.drawCenteredString(font, values[i], left + 168, y, 0xFFFFFF);
        }
        // little swatch of the material
        g.fill(left + 240, top + 24 + 3 * 22, left + 252, top + 24 + 3 * 22 + 16, 0xFF000000);
        g.fill(left + 241, top + 25 + 3 * 22, left + 251, top + 23 + 3 * 22 + 16, SupportSettings.MATERIAL_COLORS[material]);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.support_help"), left + 8, top + H - 40, 0x9AA0B4, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.support_help2"), left + 8, top + H - 28, 0x9AA0B4, false);
    }
}
