package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the Transfer Table's platform buttons. 0 = assemble the platform, 1 = record the track joins at the current stop, 2 = take the platform apart. */
public record TransferCarryPacket(BlockPos pos, int action) implements CustomPacketPayload {
    public static final Type<TransferCarryPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "transfer_carry"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TransferCarryPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
            },
            buf -> new TransferCarryPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(TransferCarryPacket p, IPayloadContext context) {
        TransferTableBlockEntity t = TransferTableBlockEntity.lookup(context.player(), p.pos);
        if (t == null) {
            return;
        }
        String message = p.action == 0 ? t.assemblePlatform() : p.action == 1 ? t.recordDock() : p.action == 2 ? t.disassemblePlatform() : "";
        if (!message.isEmpty()) {
            context.player().displayClientMessage(Component.literal(message), true);
        }
    }
}
