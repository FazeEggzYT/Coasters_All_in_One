package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Redstone Trigger: the anchor block of a Redstone Trigger gives a redstone signal (read by comparators, repeaters,
 * lamps, a Create Redstone Link next to it...). The cart hook only records when a train was seen; this class turns that
 * into a signal on the server thread, once per tick, and tells the neighbouring blocks when it changes.
 */
public final class TriggerSignal {
    private static final String ANCHOR_BLOCK = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlock";

    private static final ClassValue<Boolean> IS_ANCHOR = new ClassValue<>() {
        @Override
        protected Boolean computeValue(Class<?> type) {
            for (Class<?> c = type; c != null; c = c.getSuperclass()) {
                if (c.getName().equals(ANCHOR_BLOCK)) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        }
    };

    private record Key(Object dimension, long pos) {
    }

    private static final Map<Key, Boolean> ACTIVE = new ConcurrentHashMap<>();

    private TriggerSignal() {
    }

    public static boolean isAnchorBlock(Block block) {
        return IS_ANCHOR.get(block.getClass());
    }

    /** Remembers that this Redstone Trigger needs looking at every tick until its signal is off again. */
    public static void watch(Level level, BlockPos pos) {
        ACTIVE.put(new Key(level.dimension(), pos.asLong()), Boolean.TRUE);
    }

    /** The signal this anchor gives right now (0 if it is not a Redstone Trigger). */
    public static int power(BlockGetter level, BlockPos pos) {
        if (!BrakeController.armed) {
            return 0;
        }
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof DriveTyre.Holder h && h.ccp$brake() != null && h.ccp$brake().mode == BrakeSettings.MODE_TRIGGER) {
            return h.ccp$brake().power;
        }
        return 0;
    }

    /** Called every tick from the level tick. */
    public static void tick(ServerLevel level) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        long now = level.getGameTime();
        ACTIVE.keySet().removeIf(k -> {
            if (!k.dimension().equals(level.dimension())) {
                return false;
            }
            BlockPos pos = BlockPos.of(k.pos());
            if (!level.isLoaded(pos)) {
                return true;
            }
            BlockEntity be = level.getBlockEntity(pos);
            if (!(be instanceof DriveTyre.Holder h) || h.ccp$brake() == null || h.ccp$brake().mode != BrakeSettings.MODE_TRIGGER) {
                return true;
            }
            BrakeSettings c = h.ccp$brake();
            int want;
            long hold = (long) Math.ceil(c.trigSeconds * 20.0);
            switch (c.trigMode) {
                case 1 -> want = now < c.trigUntil ? c.trigStrength : 0;
                case 2 -> want = c.trigLatched ? c.trigStrength : 0;
                default -> want = now - c.trigLast <= 3 + hold ? c.trigStrength : 0;
            }
            if (want != c.power) {
                c.power = want;
                level.updateNeighborsAt(pos, level.getBlockState(pos).getBlock());
            }
            return want == 0 && c.power == 0;
        });
    }

    /** A train is on the Redstone Trigger (called for every cart, every physics step). */
    public static void seen(Level level, BlockPos pos, BrakeSettings c, BrakeLogic.State st, double speed, long tick) {
        if (Math.abs(speed) >= 0.08) {
            boolean ok = c.direction == BrakeSettings.DIR_BOTH
                    || (c.direction == BrakeSettings.DIR_FORWARD && speed > 0)
                    || (c.direction == BrakeSettings.DIR_REVERSE && speed < 0);
            if (!ok) {
                return;
            }
        }
        boolean entered = st.phase == BrakeLogic.NEW && tick - c.trigLast > 15; // one per train, not per cart
        c.trigLast = tick;
        if (entered) {
            if (c.trigMode == 1) {
                c.trigUntil = tick + (long) Math.ceil(c.trigSeconds * 20.0);
            } else if (c.trigMode == 2) {
                c.trigLatched = !c.trigLatched;
            }
        }
        watch(level, pos);
    }
}
