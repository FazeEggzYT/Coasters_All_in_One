package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: what a sign should show. */
public record SignConfigPacket(BlockPos pos, String line1, String line2, int color, int frame, int number, int mode)
        implements CustomPacketPayload {
    public static final Type<SignConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "sign_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SignConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeUtf(p.line1, 64);
                buf.writeUtf(p.line2, 64);
                buf.writeVarInt(p.color);
                buf.writeVarInt(p.frame);
                buf.writeVarInt(p.number);
                buf.writeVarInt(p.mode);
            },
            buf -> new SignConfigPacket(buf.readBlockPos(), buf.readUtf(64), buf.readUtf(64), buf.readVarInt(),
                    buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SignConfigPacket p, IPayloadContext context) {
        RideSignBlockEntity sign = RideSignBlockEntity.lookup(context.player(), p.pos);
        if (sign != null) {
            sign.applyConfig(p.line1, p.line2, p.color, p.frame, p.number, p.mode);
        }
    }
}
