package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.animatronics.Anims;
import com.example.coastercontrolpanel.animatronics.Pose;
import com.example.coastercontrolpanel.animatronics.Rig;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;

/** Draws the skeleton figure above the block from the boxes and the animation poses in the animatronics package. */
public class AnimatronicRenderer implements BlockEntityRenderer<AnimatronicBlockEntity> {
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/animatronic_white.png");
    /** 32 pixel figure at 0.9 = 1.8 blocks, the height of the player. */
    private static final float SCALE = 0.9F / 16.0F;

    public AnimatronicRenderer(BlockEntityRendererProvider.Context context) {
    }

    /** The figure is taller than the block, so draw it even when the block itself is off screen. */
    @Override
    public boolean shouldRenderOffScreen(AnimatronicBlockEntity be) {
        return true;
    }

    @Override
    public void render(AnimatronicBlockEntity be, float partialTick, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        float t = be.prevTime + (be.time - be.prevTime) * partialTick;
        float blend = be.prevBlend + (be.blend - be.prevBlend) * partialTick;
        String animId = be.driven() >= 0 ? Anims.ids().get(be.driven() % Anims.ids().size()) : be.type().animations[be.animation()];
        Anims.Anim anim = Anims.ALL.get(animId);
        float[] pose = anim == null ? Pose.rest() : Pose.mix(Pose.rest(), anim.at(t), blend);

        // the block itself is solid so its own light is 0; sample the air where the figure stands
        if (be.getLevel() != null) {
            light = LevelRenderer.getLightColor(be.getLevel(), be.getBlockPos().above());
        }

        Direction facing = be.getBlockState().getValue(AnimatronicBlock.FACING);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));

        ps.pushPose();
        ps.translate(0.5, 1.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
        ps.scale(SCALE, SCALE, SCALE);

        // everything that moves with the figure's bounce and spin
        ps.pushPose();
        ps.translate(0, pose[Pose.ROOT_Y], 0);
        ps.mulPose(Axis.YP.rotationDegrees(pose[Pose.ROOT_YAW]));
        List<Rig.Box> boxes = be.type().boxes();
        for (int part = 0; part < Rig.PARTS; part++) {
            drawPart(ps, vc, boxes, part, pose, light);
        }
        ps.popPose();
        ps.popPose();
    }

    private static void drawPart(PoseStack ps, VertexConsumer vc, List<Rig.Box> boxes, int part, float[] pose, int light) {
        // chain from the top of the hierarchy down to this part
        List<Integer> chain = new ArrayList<>();
        for (int p = part; p >= 0 && p < Rig.PARTS; p = Rig.PARENT[p]) {
            chain.add(0, p);
            if (Rig.PARENT[p] < 0) {
                break;
            }
        }
        ps.pushPose();
        float[] last = {0, 0, 0};
        for (int p : chain) {
            float[] pv = Rig.PIVOT[p];
            ps.translate(pv[0] - last[0], pv[1] - last[1], pv[2] - last[2]);
            last = pv;
            rotate(ps, p, pose);
        }
        float[] pv = Rig.PIVOT[part];
        for (Rig.Box b : boxes) {
            if (b.part() != part) {
                continue;
            }
            int r = (b.rgb() >> 16) & 255;
            int g = (b.rgb() >> 8) & 255;
            int bl = b.rgb() & 255;
            box(vc, ps.last(), b.x0() - pv[0], b.y0() - pv[1], b.z0() - pv[2], b.x1() - pv[0], b.y1() - pv[1], b.z1() - pv[2],
                    r, g, bl, b.glow() ? LightTexture.FULL_BRIGHT : light);
        }
        ps.popPose();
    }

    private static void rotate(PoseStack ps, int part, float[] j) {
        switch (part) {
            case Rig.TORSO -> {
                ps.mulPose(Axis.YP.rotationDegrees(j[Pose.TORSO_YAW]));
                ps.mulPose(Axis.XP.rotationDegrees(j[Pose.TORSO_PITCH]));
                ps.mulPose(Axis.ZP.rotationDegrees(j[Pose.TORSO_ROLL]));
            }
            case Rig.HEAD -> {
                ps.mulPose(Axis.YP.rotationDegrees(j[Pose.HEAD_YAW]));
                ps.mulPose(Axis.XP.rotationDegrees(j[Pose.HEAD_PITCH]));
                ps.mulPose(Axis.ZP.rotationDegrees(j[Pose.HEAD_ROLL]));
            }
            case Rig.ARM_L -> {
                ps.mulPose(Axis.XP.rotationDegrees(j[Pose.AL_PITCH]));
                ps.mulPose(Axis.ZP.rotationDegrees(-j[Pose.AL_ROLL]));
            }
            case Rig.ARM_R -> {
                ps.mulPose(Axis.XP.rotationDegrees(j[Pose.AR_PITCH]));
                ps.mulPose(Axis.ZP.rotationDegrees(j[Pose.AR_ROLL]));
            }
            case Rig.FORE_L -> ps.mulPose(Axis.XP.rotationDegrees(j[Pose.AL_ELBOW]));
            case Rig.FORE_R -> ps.mulPose(Axis.XP.rotationDegrees(j[Pose.AR_ELBOW]));
            case Rig.LEG_L -> ps.mulPose(Axis.XP.rotationDegrees(j[Pose.LL_HIP]));
            case Rig.LEG_R -> ps.mulPose(Axis.XP.rotationDegrees(j[Pose.LR_HIP]));
            case Rig.SHIN_L -> ps.mulPose(Axis.XP.rotationDegrees(-j[Pose.LL_KNEE]));
            case Rig.SHIN_R -> ps.mulPose(Axis.XP.rotationDegrees(-j[Pose.LR_KNEE]));
            default -> {
            }
        }
    }

    private static void box(VertexConsumer vc, PoseStack.Pose p, float x0, float y0, float z0, float x1, float y1, float z1,
                            int r, int g, int b, int light) {
        quad(vc, p, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0, r, g, b, light);
        quad(vc, p, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0, r, g, b, light);
        quad(vc, p, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0, 0, -1, r, g, b, light);
        quad(vc, p, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, 0, 0, 1, r, g, b, light);
        quad(vc, p, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1, 0, 0, r, g, b, light);
        quad(vc, p, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, -1, 0, 0, r, g, b, light);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose p, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, float nx, float ny, float nz,
                             int r, int g, int b, int light) {
        v(vc, p, ax, ay, az, 0, 1, nx, ny, nz, r, g, b, light);
        v(vc, p, bx, by, bz, 1, 1, nx, ny, nz, r, g, b, light);
        v(vc, p, cx, cy, cz, 1, 0, nx, ny, nz, r, g, b, light);
        v(vc, p, dx, dy, dz, 0, 0, nx, ny, nz, r, g, b, light);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, float u, float v, float nx, float ny,
                          float nz, int r, int g, int b, int light) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light).setNormal(p, nx, ny, nz);
    }
}
