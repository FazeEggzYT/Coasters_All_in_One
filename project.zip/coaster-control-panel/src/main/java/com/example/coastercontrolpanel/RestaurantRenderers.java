package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Text on the menu board and the pickup display. */
public final class RestaurantRenderers {
    private RestaurantRenderers() {
    }

    private static final int FULL_BRIGHT = 15728880;

    private static void line(Font font, String s, int color, float x, float y, float baseScale, float maxWidth, int light,
                             PoseStack pose, MultiBufferSource buffers) {
        if (s.isEmpty()) {
            return;
        }
        Component text = Component.literal(s);
        int w = Math.max(1, font.width(text));
        float scale = Math.min(baseScale, maxWidth / w);
        pose.pushPose();
        pose.translate(x, -y + 4.0F * scale, 0.0);
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -w / 2.0F, 0.0F, color, false, pose.last().pose(), buffers, Font.DisplayMode.NORMAL, 0, light);
        pose.popPose();
    }

    private static void front(BlockEntity be, PoseStack pose) {
        Direction facing = be.getBlockState().getValue(DecorBlocks.FACING);
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
        // the board is 2/16 thick at the back; the text sits just in front of it
        pose.translate(0.0, 0.0, -0.5 + 2.0 / 16.0 + 0.004);
    }

    public static class MenuBoard implements BlockEntityRenderer<RestaurantBlocks.MenuBoardBlockEntity> {
        private final Font font;

        public MenuBoard(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        @Override
        public void render(RestaurantBlocks.MenuBoardBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            if (be.getLevel() == null || !RestaurantBlocks.JoinBoard.isMaster(be.getBlockState())) {
                return;
            }
            int[] size = RestaurantBlocks.JoinBoard.size(be.getLevel(), be.getBlockPos());
            float w = size[0];
            float h = size[1];
            float cx = (w - 1.0F) / 2.0F;
            float cy = -(h - 1.0F) / 2.0F;
            pose.pushPose();
            front(be, pose);
            String title = be.title.isEmpty() ? "MENU" : be.title;
            line(font, title, 0xFFFFD84A, cx, cy - 0.40F * h, 0.03F * h, 0.8F * w, light, pose, buffers);
            for (int i = 0; i < RestaurantBlocks.MenuBoardBlockEntity.LINES; i++) {
                line(font, be.lines[i], 0xFFFFFFFF, cx, cy + (-0.26F + i * 0.115F) * h, 0.016F * h, 0.82F * w, light, pose, buffers);
            }
            pose.popPose();
        }
    }

    public static class PickupDisplay implements BlockEntityRenderer<RestaurantBlocks.PickupBlockEntity> {
        private final Font font;

        public PickupDisplay(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        @Override
        public void render(RestaurantBlocks.PickupBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            if (be.getLevel() == null || !RestaurantBlocks.JoinBoard.isMaster(be.getBlockState())) {
                return;
            }
            boolean order = be.getBlockState().getBlock() instanceof RestaurantBlocks.OrderDisplayBlock;
            java.util.List<Integer> numbers = order ? be.preparingList : be.ready;
            long now = be.getLevel().getGameTime();
            if (!order) {
                if (be.ready.size() > be.lastCount && be.lastCount >= 0) {
                    be.blinkUntil = now + 60;
                }
                be.lastCount = be.ready.size();
            }
            boolean blink = !order && now < be.blinkUntil && (now / 5) % 2 == 0;
            int[] size = RestaurantBlocks.JoinBoard.size(be.getLevel(), be.getBlockPos());
            float w = size[0];
            float h = size[1];
            float cx = (w - 1.0F) / 2.0F;
            float cy = -(h - 1.0F) / 2.0F;
            pose.pushPose();
            front(be, pose);
            int headColour = order ? 0xFFFFD84A : 0xFF55FF55;
            line(font, order ? "PREPARING" : "COLLECT", headColour, cx, cy - h / 2.0F + 0.17F, 0.025F * Math.min(h, 2.0F), 0.9F * w, FULL_BRIGHT, pose, buffers);
            int cols = 4 * size[0];
            int rows = Math.max(1, (int) ((h - 0.5F) / 0.2F));
            int cap = cols * rows;
            int start = Math.max(0, numbers.size() - cap);
            float top = cy - h / 2.0F + 0.42F;
            for (int i = start; i < numbers.size(); i++) {
                int k = i - start;
                int col = k % cols;
                int row = k / cols;
                int colour = blink && i == numbers.size() - 1 ? 0xFF55FF55 : 0xFFFFFFFF;
                line(font, "#" + numbers.get(i), colour, cx - (cols - 1) * 0.11F + col * 0.22F, top + row * 0.2F, 0.03F, 0.2F, FULL_BRIGHT, pose, buffers);
            }
            if (numbers.isEmpty()) {
                line(font, "-", 0xFF888888, cx, top + 0.1F, 0.03F, 0.2F, FULL_BRIGHT, pose, buffers);
            }
            pose.popPose();
        }
    }
}
