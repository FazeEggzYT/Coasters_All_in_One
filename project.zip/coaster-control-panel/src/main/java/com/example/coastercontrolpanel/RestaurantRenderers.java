package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Text on the menu board and the pickup display. */
public final class RestaurantRenderers {
    private RestaurantRenderers() {
    }

    private static final int FULL_BRIGHT = 15728880;

    private static void line(Font font, String s, int color, float x, float y, float baseScale, float maxWidth, int light,
                             PoseStack pose, MultiBufferSource buffers) {
        if (s.isEmpty()) {
            return;
        }
        Component text = Component.literal(s);
        int w = Math.max(1, font.width(text));
        float scale = Math.min(baseScale, maxWidth / w);
        pose.pushPose();
        pose.translate(x, y, 0.0);
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -w / 2.0F, 0.0F, color, false, pose.last().pose(), buffers, Font.DisplayMode.NORMAL, 0, light);
        pose.popPose();
    }

    private static void front(BlockEntity be, PoseStack pose) {
        Direction facing = be.getBlockState().getValue(DecorBlocks.FACING);
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
        // the board is 2/16 thick at the back; the text sits just in front of it
        pose.translate(0.0, 0.0, -0.5 + 2.0 / 16.0 + 0.004);
    }

    public static class MenuBoard implements BlockEntityRenderer<RestaurantBlocks.MenuBoardBlockEntity> {
        private final Font font;

        public MenuBoard(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        @Override
        public void render(RestaurantBlocks.MenuBoardBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            pose.pushPose();
            front(be, pose);
            String title = be.title.isEmpty() ? "MENU" : be.title;
            line(font, title, 0xFFFFD84A, 0.0F, -0.40F, 0.03F, 0.8F, light, pose, buffers);
            for (int i = 0; i < RestaurantBlocks.MenuBoardBlockEntity.LINES; i++) {
                line(font, be.lines[i], 0xFFFFFFFF, 0.0F, -0.26F + i * 0.115F, 0.016F, 0.82F, light, pose, buffers);
            }
            pose.popPose();
        }
    }

    public static class PickupDisplay implements BlockEntityRenderer<RestaurantBlocks.PickupBlockEntity> {
        private final Font font;

        public PickupDisplay(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        @Override
        public void render(RestaurantBlocks.PickupBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            long now = be.getLevel() == null ? 0 : be.getLevel().getGameTime();
            if (be.ready.size() > be.lastCount && be.lastCount >= 0) {
                be.blinkUntil = now + 60;
            }
            be.lastCount = be.ready.size();
            boolean blink = now < be.blinkUntil && (now / 5) % 2 == 0;
            pose.pushPose();
            front(be, pose);
            line(font, "READY", 0xFF55FF55, -0.22F, -0.27F, 0.02F, 0.4F, FULL_BRIGHT, pose, buffers);
            line(font, "PREPARING " + be.preparing, 0xFFFFD84A, 0.22F, -0.27F, 0.012F, 0.4F, FULL_BRIGHT, pose, buffers);
            int n = Math.min(8, be.ready.size());
            for (int i = 0; i < n; i++) {
                int col = i % 4;
                int row = i / 4;
                int colour = blink && i == be.ready.size() - 1 ? 0xFF55FF55 : 0xFFFFFFFF;
                line(font, "#" + be.ready.get(i), colour, -0.33F + col * 0.22F, -0.08F + row * 0.2F, 0.03F, 0.2F, FULL_BRIGHT, pose, buffers);
            }
            pose.popPose();
        }
    }
}
