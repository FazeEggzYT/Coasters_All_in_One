package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/** Everything a Teacup Ride can be told: the sequence of steps and the general settings. All values are clamped here. */
public final class TeacupSettings {
    public static final int RUN = 0;
    public static final int REST = 1;
    public static final int TYPES = 2;
    public static final int MAX_STEPS = 10;
    public static final int PRESETS = 4;

    /** RUN: a = platter turns per minute, b = cup turns per minute, c = seconds. REST: c = seconds (everything slows down). */
    public static final class Step {
        public int type;
        public float a;
        public float b;
        public float c;

        public Step(int type, float a, float b, float c) {
            this.type = type;
            this.a = a;
            this.b = b;
            this.c = c;
            clamp();
        }

        public void clamp() {
            type = Math.max(0, Math.min(TYPES - 1, type));
            if (type == RUN) {
                a = TeacupSettings.clamp(a, 0.0F, 10.0F);
                b = TeacupSettings.clamp(b, 0.0F, 30.0F);
                c = TeacupSettings.clamp(c, 1.0F, 300.0F);
            } else {
                a = 0;
                b = 0;
                c = TeacupSettings.clamp(c, 1.0F, 120.0F);
            }
        }

        public void retype(int newType) {
            type = newType;
            if (type == RUN) {
                a = 3;
                b = 10;
                c = 15;
            } else {
                a = 0;
                b = 0;
                c = 5;
            }
        }
    }

    public final List<Step> steps = new ArrayList<>();
    public int loops = 1;
    public float preDelay = 3.0F;
    /** Degrees per second squared used for speeding up and slowing down. */
    public float accel = 8.0F;
    public float haltTime = 2.0F;
    /** 0 = the platter turns one way, 1 = the other. */
    public int platterDir = 0;
    /** 0 = all cups spin the same way, 1 = neighbouring cups spin opposite ways. */
    public int cupMode = 0;
    public int redstoneMode = 0;
    public int endMode = 0;
    public boolean carryAll = true;

    public TeacupSettings() {
        preset(0);
    }

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void preset(int index) {
        steps.clear();
        switch (index) {
            case 1 -> { // gentle
                steps.add(new Step(RUN, 1.5F, 3, 20));
                steps.add(new Step(RUN, 2, 6, 20));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 2 -> { // wild
                steps.add(new Step(RUN, 3, 10, 10));
                steps.add(new Step(RUN, 5, 18, 20));
                steps.add(new Step(RUN, 6, 24, 15));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 3 -> { // cups only: the platter stands still
                steps.add(new Step(RUN, 0, 8, 15));
                steps.add(new Step(RUN, 0, 16, 15));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 4 -> { // carousel: classic ride
                steps.add(new Step(RUN, 2, 0, 30));
                steps.add(new Step(RUN, 3, 0, 40));
                steps.add(new Step(RUN, 2, 0, 20));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 5 -> { // carousel: gentle
                steps.add(new Step(RUN, 1, 0, 40));
                steps.add(new Step(RUN, 1.5F, 0, 40));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 6 -> { // carousel: fast
                steps.add(new Step(RUN, 4, 0, 30));
                steps.add(new Step(RUN, 6, 0, 30));
                steps.add(new Step(REST, 0, 0, 4));
            }
            case 7 -> { // carousel: winding up
                steps.add(new Step(RUN, 1, 0, 10));
                steps.add(new Step(RUN, 2, 0, 15));
                steps.add(new Step(RUN, 3, 0, 20));
                steps.add(new Step(RUN, 2, 0, 10));
                steps.add(new Step(REST, 0, 0, 4));
            }
            default -> { // classic
                steps.add(new Step(RUN, 2, 6, 15));
                steps.add(new Step(RUN, 3, 12, 25));
                steps.add(new Step(RUN, 2, 8, 15));
                steps.add(new Step(REST, 0, 0, 4));
            }
        }
    }

    public void sanitize() {
        loops = Math.max(1, Math.min(20, loops));
        preDelay = clamp(preDelay, 0.0F, 30.0F);
        accel = clamp(accel, 1.0F, 40.0F);
        haltTime = clamp(haltTime, 0.5F, 8.0F);
        platterDir = Math.max(0, Math.min(1, platterDir));
        cupMode = Math.max(0, Math.min(1, cupMode));
        redstoneMode = Math.max(0, Math.min(1, redstoneMode));
        endMode = Math.max(0, Math.min(1, endMode));
        while (steps.size() > MAX_STEPS) {
            steps.remove(steps.size() - 1);
        }
        for (Step s : steps) {
            s.clamp();
        }
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Loops", loops);
        t.putFloat("PreDelay", preDelay);
        t.putFloat("Accel", accel);
        t.putFloat("HaltTime", haltTime);
        t.putInt("PlatterDir", platterDir);
        t.putInt("CupMode", cupMode);
        t.putInt("Redstone", redstoneMode);
        t.putInt("EndMode", endMode);
        t.putBoolean("CarryAll", carryAll);
        ListTag list = new ListTag();
        for (Step s : steps) {
            CompoundTag c = new CompoundTag();
            c.putInt("T", s.type);
            c.putFloat("A", s.a);
            c.putFloat("B", s.b);
            c.putFloat("C", s.c);
            list.add(c);
        }
        t.put("Steps", list);
        return t;
    }

    public static TeacupSettings fromTag(CompoundTag t) {
        TeacupSettings s = new TeacupSettings();
        if (t == null || t.isEmpty()) {
            return s;
        }
        s.loops = t.contains("Loops") ? t.getInt("Loops") : 1;
        s.preDelay = t.contains("PreDelay") ? t.getFloat("PreDelay") : 3.0F;
        s.accel = t.contains("Accel") ? t.getFloat("Accel") : 8.0F;
        s.haltTime = t.contains("HaltTime") ? t.getFloat("HaltTime") : 2.0F;
        s.platterDir = t.getInt("PlatterDir");
        s.cupMode = t.getInt("CupMode");
        s.redstoneMode = t.getInt("Redstone");
        s.endMode = t.getInt("EndMode");
        s.carryAll = !t.contains("CarryAll") || t.getBoolean("CarryAll");
        if (t.contains("Steps", Tag.TAG_LIST)) {
            s.steps.clear();
            ListTag list = t.getList("Steps", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size() && i < MAX_STEPS; i++) {
                CompoundTag c = list.getCompound(i);
                s.steps.add(new Step(c.getInt("T"), c.getFloat("A"), c.getFloat("B"), c.getFloat("C")));
            }
        }
        s.sanitize();
        return s;
    }

    public TeacupSettings copy() {
        return fromTag(toTag());
    }
}
