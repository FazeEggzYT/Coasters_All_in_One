package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;

/** Names shown in the action bar. */
public final class AnimatronicTexts {
    public static final String[] SETTINGS = {"character", "animation", "mode", "speed"};

    private AnimatronicTexts() {
    }

    public static Component type(AnimatronicBlockEntity be) {
        return Component.translatable("animatronic.type." + be.type().id);
    }

    public static Component anim(AnimatronicBlockEntity be) {
        return Component.translatable("animatronic.anim." + be.type().animations[be.animation()]);
    }

    public static Component mode(AnimatronicBlockEntity be) {
        return Component.translatable(be.redstoneMode() ? "animatronic.mode.redstone" : "animatronic.mode.loop");
    }

    public static Component speed(AnimatronicBlockEntity be) {
        return Component.translatable("animatronic.speed." + be.speed());
    }

    public static Component summary(AnimatronicBlockEntity be) {
        return Component.translatable("message.coastercontrolpanel.animatronic_summary", type(be), anim(be), mode(be), speed(be));
    }

    public static Component value(String setting, AnimatronicBlockEntity be) {
        return switch (setting) {
            case "character" -> type(be);
            case "animation" -> anim(be);
            case "mode" -> mode(be);
            default -> speed(be);
        };
    }
}
