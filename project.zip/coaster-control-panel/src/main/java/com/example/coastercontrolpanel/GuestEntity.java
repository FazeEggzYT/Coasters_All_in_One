package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A park guest. Walks along the queue markers of its channel, waits for the ride gate, walks to the
 * station marker and "rides" (invisible) for a while, then appears at the exit marker, strolls and leaves.
 */
public class GuestEntity extends PathfinderMob {
    public static final int SKINS = 24;
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(GuestEntity.class, EntityDataSerializers.INT);

    private static final int QUEUE = 0;
    private static final int TO_STATION = 1;
    private static final int RIDING = 2;
    private static final int EXITING = 3;

    @Nullable
    private BlockPos home;
    private int channel = 1;
    private int stage = QUEUE;
    private int timer = 0;
    private int index = 0;
    private double speed = 1.0;
    private int rideTicks = 600;

    public GuestEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    public int getSkin() {
        return Math.floorMod(entityData.get(SKIN), SKINS);
    }

    /** Called by the spawner right after creating the guest. */
    public void setup(BlockPos home, int channel, double speed, int rideSeconds, int skin, double scale) {
        this.home = home;
        this.channel = channel;
        this.speed = speed;
        this.rideTicks = rideSeconds * 20;
        entityData.set(SKIN, skin);
        if (getAttribute(Attributes.SCALE) != null) {
            getAttribute(Attributes.SCALE).setBaseValue(scale);
        }
    }

    @Nullable
    public BlockPos getHome() {
        return home;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return stage != RIDING && super.isPushable();
    }

    // ---------------------------------------------------------------- the walk

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel server) || home == null) {
            return;
        }
        if (stage == RIDING) {
            timer--;
            if (timer <= 0) {
                finishRide(server);
            }
            return;
        }
        if (tickCount % 5 != 0) {
            return;
        }
        switch (stage) {
            case QUEUE -> thinkQueue(server);
            case TO_STATION -> thinkStation(server);
            default -> thinkExit(server);
        }
    }

    private void walkTo(Vec3 target) {
        getNavigation().moveTo(target.x, target.y, target.z, speed);
    }

    private static Vec3 centre(BlockPos p) {
        return new Vec3(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
    }

    private boolean isNear(BlockPos p, double dist) {
        double dx = getX() - (p.getX() + 0.5);
        double dz = getZ() - (p.getZ() + 0.5);
        return dx * dx + dz * dz < dist * dist && Math.abs(getY() - p.getY()) < 2.5;
    }

    private void thinkQueue(ServerLevel server) {
        List<MarkerBlockEntity> queue = MarkerRegistry.find(server, home, channel, MarkerKind.QUEUE, 96.0);
        if (queue.isEmpty()) {
            stage = TO_STATION;
            return;
        }
        index = Math.max(0, Math.min(index, queue.size() - 1));
        BlockPos target = queue.get(index).getBlockPos();
        walkTo(centre(target));
        if (!isNear(target, 1.4)) {
            return;
        }
        if (index == queue.size() - 1) {
            if (gateClosedNear(server, target)) {
                getNavigation().stop();
                return;
            }
            stage = TO_STATION;
            return;
        }
        BlockPos next = queue.get(index + 1).getBlockPos();
        if (occupied(server, next)) {
            getNavigation().stop();
            return;
        }
        index++;
    }

    /** Is another guest standing on this marker? */
    private boolean occupied(ServerLevel server, BlockPos marker) {
        AABB box = new AABB(marker).inflate(0.7, 1.5, 0.7);
        for (GuestEntity other : server.getEntitiesOfClass(GuestEntity.class, box)) {
            if (other != this && other.stage != RIDING) {
                return true;
            }
        }
        return false;
    }

    /** A Ride Gate close to the front of the queue holds the guest back until it is open. */
    private boolean gateClosedNear(ServerLevel server, BlockPos front) {
        boolean anyGate = false;
        for (BlockPos p : BlockPos.betweenClosed(front.offset(-5, -1, -5), front.offset(5, 2, 5))) {
            BlockState state = server.getBlockState(p);
            if (state.getBlock() instanceof RideGateBlock) {
                anyGate = true;
                if (state.getValue(RideGateBlock.OPEN)) {
                    return false;
                }
            }
        }
        return anyGate;
    }

    private void thinkStation(ServerLevel server) {
        List<MarkerBlockEntity> stations = MarkerRegistry.find(server, home, channel, MarkerKind.STATION, 96.0);
        if (stations.isEmpty()) {
            beginRide(server);
            return;
        }
        BlockPos target = stations.get(0).getBlockPos();
        walkTo(centre(target));
        if (isNear(target, 1.3)) {
            beginRide(server);
        }
    }

    private void beginRide(ServerLevel server) {
        getNavigation().stop();
        stage = RIDING;
        timer = rideTicks;
        setInvisible(true);
        setSilent(true);
        setNoGravity(true);
        noPhysics = true;
        setDeltaMovement(Vec3.ZERO);
    }

    private void finishRide(ServerLevel server) {
        List<MarkerBlockEntity> exits = MarkerRegistry.find(server, home, channel, MarkerKind.EXIT, 96.0);
        noPhysics = false;
        setNoGravity(false);
        setInvisible(false);
        setSilent(false);
        if (!exits.isEmpty()) {
            BlockPos exit = exits.get(0).getBlockPos();
            teleportTo(exit.getX() + 0.5, exit.getY(), exit.getZ() + 0.5);
        }
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1.0, getZ(), 6, 0.3, 0.5, 0.3, 0.0);
        stage = EXITING;
        timer = 240;
    }

    private void thinkExit(ServerLevel server) {
        timer -= 5;
        if (timer <= 0) {
            server.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.8, getZ(), 6, 0.2, 0.4, 0.2, 0.02);
            discard();
            return;
        }
        if (tickCount % 40 == 0) {
            List<MarkerBlockEntity> exits = MarkerRegistry.find(server, home, channel, MarkerKind.EXIT, 96.0);
            Vec3 base = exits.isEmpty() ? position() : centre(exits.get(0).getBlockPos());
            walkTo(base.add((random.nextDouble() - 0.5) * 10, 0, (random.nextDouble() - 0.5) * 10));
        }
    }

    // ---------------------------------------------------------------- saving

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (home != null) {
            tag.putLong("Home", home.asLong());
        }
        tag.putInt("Channel", channel);
        tag.putInt("Stage", stage);
        tag.putInt("Timer", timer);
        tag.putInt("Index", index);
        tag.putDouble("WalkSpeed", speed);
        tag.putInt("RideTicks", rideTicks);
        tag.putInt("Skin", entityData.get(SKIN));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        home = tag.contains("Home") ? BlockPos.of(tag.getLong("Home")) : null;
        channel = Math.max(1, tag.getInt("Channel"));
        stage = tag.getInt("Stage");
        timer = tag.getInt("Timer");
        index = tag.getInt("Index");
        speed = tag.contains("WalkSpeed") ? tag.getDouble("WalkSpeed") : 1.0;
        rideTicks = tag.contains("RideTicks") ? tag.getInt("RideTicks") : 600;
        entityData.set(SKIN, tag.getInt("Skin"));
        if (stage == RIDING) {
            setInvisible(true);
            setNoGravity(true);
            noPhysics = true;
        }
    }
}
