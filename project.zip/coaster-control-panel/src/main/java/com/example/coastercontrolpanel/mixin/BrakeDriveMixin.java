package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.BrakeController;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Brake Run: Coasters Simulated calls this for every cart on a chain-lift stretch. If that stretch is a Brake Run, the
 * Brake Run handles the cart and the chain drive (which would treat it as an unpowered chain and stop the cart dead)
 * is skipped. For every other stretch this does nothing. Optional: if the target differs, Brake Runs just don't brake.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.cart.CoasterCartChainLiftDrive", remap = false)
public class BrakeDriveMixin {
    @Inject(method = "applySpeedMatch", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$brake(@Coerce Object body, ServerLevel level, @Coerce Object system, @Coerce Object hit,
                                  @Coerce Object basis, double dt, CallbackInfo ci) {
        if (BrakeController.armed && BrakeController.handle(body, level, system, hit, basis, dt)) {
            ci.cancel();
        }
    }
}
