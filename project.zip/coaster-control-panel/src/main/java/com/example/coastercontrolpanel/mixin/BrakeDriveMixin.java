package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.BrakeController;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Brake Run: Coasters Simulated calls this for every cart on a chain-lift stretch. If that stretch is a Brake Run, the
 * Brake Run handles the cart and the chain drive (which would treat it as an unpowered chain and stop the cart dead)
 * is skipped. For every other stretch this does nothing. Optional: if the target differs, Brake Runs just don't brake.
 *
 * The parameter types are compile-time stubs (libs/ccp-compile-stubs.jar, never shipped); at runtime they are the real
 * Sable and Coasters Simulated classes, so the method descriptor matches exactly.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.cart.CoasterCartChainLiftDrive", remap = false)
public class BrakeDriveMixin {
    @Inject(method = "applySpeedMatch", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$brake(ServerSubLevel body, ServerLevel level, SubLevelPhysicsSystem system,
                                  CoasterPathTrackFrame.GraphHit hit, CoasterPathTrackFrame.TrackBasis basis,
                                  double dt, CallbackInfo ci) {
        if (BrakeController.armed && BrakeController.handle(body, level, system, hit, basis, dt)) {
            ci.cancel();
        }
    }
}
