package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Complete rides, placed in one go. The player stands where the ride faces; everything is built from the mod's own
 * blocks plus a seat from the player's mods (Coaster Seats when installed, Create's seats otherwise).
 */
public final class PremadeRides {
    private PremadeRides() {
    }

    public static final int DROP_TOWER = 0;
    public static final int SWING = 1;
    public static final int FERRIS = 2;
    public static final int TEACUP = 3;
    public static final int PIRATE = 4;

    /** Maps ride coordinates (u across, v up, w along the axle) to the world. */
    private static final class Grid {
        final Level level;
        final BlockPos origin;
        final Direction.Axis axis;

        Grid(Level level, BlockPos origin, Direction.Axis axis) {
            this.level = level;
            this.origin = origin;
            this.axis = axis;
        }

        BlockPos at(int u, int v, int w) {
            return axis == Direction.Axis.X ? origin.offset(w, v, u) : origin.offset(u, v, w);
        }

        void set(int u, int v, int w, BlockState state) {
            level.setBlock(at(u, v, w), state, 3);
        }
    }

    private static BlockState seat(int towardU, int towardW) {
        BlockState state = null;
        for (String id : new String[]{"coasterfins:white_coaster_seat", "create:white_seat"}) {
            var opt = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(id));
            if (opt.isPresent()) {
                state = opt.get().defaultBlockState();
                break;
            }
        }
        if (state == null) {
            return Blocks.OAK_STAIRS.defaultBlockState();
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            Direction d = Math.abs(towardU) >= Math.abs(towardW)
                    ? (towardU >= 0 ? Direction.EAST : Direction.WEST)
                    : (towardW >= 0 ? Direction.SOUTH : Direction.NORTH);
            state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, d);
        }
        return state;
    }

    private static BlockState with(Block block, Direction.Axis axis) {
        BlockState s = block.defaultBlockState();
        if (s.hasProperty(FerrisBlocks.WheelPart.AXIS)) {
            s = s.setValue(FerrisBlocks.WheelPart.AXIS, axis);
        } else if (s.hasProperty(SwingBlocks.PivotBlock.AXIS)) {
            s = s.setValue(SwingBlocks.PivotBlock.AXIS, axis);
        }
        return s;
    }

    public static void place(Level level, BlockPos origin, Direction facing, int kind) {
        switch (kind) {
            case DROP_TOWER -> dropTower(level, origin);
            case SWING -> swing(level, origin, facing.getAxis());
            case TEACUP -> teacup(level, origin);
            case PIRATE -> pirate(level, origin, facing.getAxis());
            default -> ferris(level, origin, facing.getAxis());
        }
    }

    private static void platform(Grid g, int u0, int u1, int w0, int w1) {
        for (int u = u0; u <= u1; u++) {
            for (int w = w0; w <= w1; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    // ---------------------------------------------------------------- Drop Tower: a 32 block tower

    private static void dropTower(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Z);
        platform(g, -6, 6, -6, 6);
        g.set(0, 0, 0, CoasterControlPanel.DROP_TOWER_BASE_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.DROP_TOWER_SECTION_BLOCK.get().defaultBlockState();
        // a 3 by 3 tower: the middle column is the one that counts, the rest is the thick body
        for (int y = 1; y <= 32; y++) {
            for (int u = -1; u <= 1; u++) {
                for (int w = -1; w <= 1; w++) {
                    g.set(u, y, w, section);
                }
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, 33, w, Blocks.IRON_BLOCK.defaultBlockState());
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                if (u != 0 || w != 0) {
                    g.set(u, 0, w, Blocks.IRON_BLOCK.defaultBlockState());
                }
            }
        }
        // the carriage: a ring of 24 seats with a frame around them, three blocks tall
        BlockState frame = CoasterControlPanel.DROP_TOWER_FRAME_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 3; y++) {
            for (int u = -4; u <= 4; u++) {
                for (int w = -4; w <= 4; w++) {
                    if (Math.max(Math.abs(u), Math.abs(w)) == 4) {
                        g.set(u, y, w, frame);
                    }
                }
            }
        }
        for (int u = -3; u <= 3; u++) {
            for (int w = -3; w <= 3; w++) {
                if (Math.max(Math.abs(u), Math.abs(w)) == 3) {
                    g.set(u, 1, w, seat(u, w));
                }
            }
        }
        g.set(6, 0, -6, CoasterControlPanel.DROP_TOWER_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Swing Ride, built like Rush: long arm, gondola near the ground

    private static void swing(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int top = 20;
        int arms = 16;
        int hub = top - arms - 1;
        platform(g, -12, 12, -14, 14);
        BlockState section = CoasterControlPanel.SWING_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        // two A-shaped towers, one each side of the swing, with the pivot slung between them
        for (int side : new int[]{-1, 1}) {
            for (int plane = 10; plane <= 11; plane++) {
                for (int leg : new int[]{-1, 1}) {
                    for (int[] p : RideShapes.line(0, top - 1, leg * 8, 0)) {
                        g.set(p[0], p[1], side * plane, section);
                    }
                }
                g.set(0, top, side * plane, beam);
                for (int u = -3; u <= 3; u++) {
                    g.set(u, 6, side * plane, section);
                }
            }
        }
        for (int w = -11; w <= 11; w++) {
            if (w != 0) {
                g.set(0, top, w, beam);
            }
        }
        g.set(0, top, 0, with(CoasterControlPanel.SWING_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, 0, CoasterControlPanel.SWING_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, 0, CoasterControlPanel.SWING_HUB_BLOCK.get().defaultBlockState());
        BlockState frame = CoasterControlPanel.SWING_FRAME_BLOCK.get().defaultBlockState();
        // the gondola: a floor, two vehicles of 16 seats back to back (two rows of 8 each side), bars in front of the riders
        for (int u = -4; u <= 4; u++) {
            for (int w = -3; w <= 3; w++) {
                g.set(u, hub - 1, w, frame);
            }
        }
        for (int u = -4; u <= 4; u++) {
            if (u != 0) {
                for (int w : new int[]{-2, -1, 1, 2}) {
                    g.set(u, hub, w, seat(0, w));
                }
                g.set(u, hub, 0, frame);
            }
            g.set(u, hub + 1, -3, frame);
            g.set(u, hub + 1, 3, frame);
            g.set(u, hub, -3, frame);
            g.set(u, hub, 3, frame);
            if (u != 0) {
                g.set(u, hub + 1, 0, frame);
            }
        }
        for (int w = -3; w <= 3; w++) {
            g.set(-5, hub, w, frame);
            g.set(5, hub, w, frame);
            g.set(-5, hub + 1, w, frame);
            g.set(5, hub + 1, w, frame);
        }
        // boarding platforms level with the gondola floor, with steps up from the ground
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int u = -6; u <= 6; u++) {
                for (int w = 4; w <= 7; w++) {
                    g.set(u, hub - 1, side * w, stone);
                }
                g.set(u, 0, side * 9, stone);
                g.set(u, hub - 2 > 0 ? 1 : 0, side * 8, stone);
            }
        }
        g.set(0, 0, -13, CoasterControlPanel.SWING_BASE_BLOCK.get().defaultBlockState());
        g.set(2, 0, -13, CoasterControlPanel.SWING_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Pirate Ship: 15 block boat on a 9 piece arm

    private static void pirate(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int arms = 9;
        int hub = 4;
        int top = hub + arms + 1;
        platform(g, -14, 14, -11, 11);
        BlockState section = CoasterControlPanel.PIRATE_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int plane = 5; plane <= 6; plane++) {
                for (int leg : new int[]{-1, 1}) {
                    for (int[] p : RideShapes.line(0, top - 1, leg * 9, 0)) {
                        g.set(p[0], p[1], side * plane, section);
                    }
                }
                g.set(0, top, side * plane, beam);
            }
        }
        for (int w = -6; w <= 6; w++) {
            if (w != 0) {
                g.set(0, top, w, beam);
            }
        }
        g.set(0, top, 0, with(CoasterControlPanel.PIRATE_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, 0, CoasterControlPanel.PIRATE_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, 0, CoasterControlPanel.PIRATE_HUB_BLOCK.get().defaultBlockState());
        BlockState hull = CoasterControlPanel.PIRATE_HULL_BLOCK.get().defaultBlockState();
        // the boat: a keel that tapers, a deck, a rail along both sides and a tall bow and stern
        for (int u = -6; u <= 6; u++) {
            for (int w = -2; w <= 2; w++) {
                g.set(u, hub - 1, w, hull);
            }
        }
        for (int u = -4; u <= 4; u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, hub - 2, w, hull);
            }
        }
        for (int u = -2; u <= 2; u++) {
            g.set(u, hub - 3, 0, hull);
        }
        for (int u = -6; u <= 6; u++) {
            g.set(u, hub, -2, hull);
            g.set(u, hub, 2, hull);
            g.set(u, hub + 1, -2, hull);
            g.set(u, hub + 1, 2, hull);
            if (u != 0) {
                g.set(u, hub, 0, hull);
            }
            for (int w : new int[]{-1, 1}) {
                g.set(u, hub, w, seat(0, w));
            }
        }
        for (int h = 0; h <= 3; h++) {
            g.set(-7, hub + h, 0, hull);
            g.set(7, hub + h, 0, hull);
            if (h < 2) {
                g.set(-7, hub + h, -1, hull);
                g.set(-7, hub + h, 1, hull);
                g.set(7, hub + h, -1, hull);
                g.set(7, hub + h, 1, hull);
            }
        }
        g.set(-8, hub + 2, 0, hull);
        g.set(8, hub + 2, 0, hull);
        // steps up to a boarding platform at each end
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int w = -2; w <= 2; w++) {
                g.set(side * 9, hub - 1, w, stone);
                g.set(side * 10, hub - 2, w, stone);
                g.set(side * 11, hub - 3, w, stone);
                g.set(side * 8, hub - 1, w, stone);
            }
        }
        g.set(0, 0, -9, CoasterControlPanel.PIRATE_BASE_BLOCK.get().defaultBlockState());
        g.set(2, 0, -9, CoasterControlPanel.PIRATE_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Teacup Ride: a 19 block platter with four cups

    private static void teacup(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        platform(g, -12, 12, -12, 12);
        BlockState plate = CoasterControlPanel.TEACUP_PLATE_BLOCK.get().defaultBlockState();
        for (int u = -9; u <= 9; u++) {
            for (int w = -9; w <= 9; w++) {
                if (u * u + w * w <= 9.4 * 9.4) {
                    g.set(u, 0, w, plate);
                }
            }
        }
        g.set(0, 0, 0, CoasterControlPanel.TEACUP_HUB_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.TEACUP_SECTION_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 4; y++) {
            g.set(0, y, 0, section);
        }
        BlockState floor = CoasterControlPanel.TEACUP_FLOOR_BLOCK.get().defaultBlockState();
        BlockState wall = CoasterControlPanel.TEACUP_WALL_BLOCK.get().defaultBlockState();
        int[][] centres = {{5, 0}, {0, 5}, {-5, 0}, {0, -5}};
        for (int[] c : centres) {
            int ox = Integer.compare(c[0], 0);
            int oz = Integer.compare(c[1], 0);
            for (int du = -2; du <= 2; du++) {
                for (int dw = -2; dw <= 2; dw++) {
                    int cu = c[0] + du;
                    int cw = c[1] + dw;
                    int ring = Math.max(Math.abs(du), Math.abs(dw));
                    if (du == 0 && dw == 0) {
                        g.set(cu, 1, cw, CoasterControlPanel.TEACUP_CUP_HUB_BLOCK.get().defaultBlockState());
                        continue;
                    }
                    if (Math.abs(du) == 2 && Math.abs(dw) == 2) {
                        continue; // rounded corners
                    }
                    g.set(cu, 1, cw, floor);
                    boolean gap = du == 2 * ox && dw == 2 * oz && (ox != 0 || oz != 0);
                    if (ring == 2 && !gap) {
                        g.set(cu, 2, cw, wall);
                    } else if (ring == 1) {
                        g.set(cu, 2, cw, seat(-du, -dw));
                    }
                }
            }
        }
        g.set(11, 0, -11, CoasterControlPanel.TEACUP_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, -9, CoasterControlPanel.TEACUP_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Ferris Wheel: 24 block wheel, 12 cabins

    private static void ferris(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        RideShapes.Ferris f = RideShapes.ferris(12, 12);
        int ay = 20;
        platform(g, -16, 16, -8, 8);
        g.set(0, ay, 0, with(CoasterControlPanel.FERRIS_AXLE_BLOCK.get(), axis));
        for (long k : f.spokes) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_SPOKE_BLOCK.get(), axis));
        }
        for (long k : f.rim) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        for (long k : f.hangers) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        BlockState frame = CoasterControlPanel.FERRIS_FRAME_BLOCK.get().defaultBlockState();
        for (int[] h : f.hubs) {
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    int ring = Math.max(Math.abs(du), Math.abs(dv));
                    if (ring == 2) {
                        for (int w = -1; w <= 1; w++) {
                            g.set(h[0] + du, ay + h[1] + dv, w, frame);
                        }
                    } else if (ring == 1) {
                        g.set(h[0] + du, ay + h[1] + dv, 0, seat(-du, -dv));
                    } else {
                        g.set(h[0], ay + h[1], 0, CoasterControlPanel.FERRIS_HUB_BLOCK.get().defaultBlockState());
                    }
                }
            }
        }
        // the axle pins and the two A-shaped legs, in front of and behind the wheel
        BlockState section = CoasterControlPanel.FERRIS_SECTION_BLOCK.get().defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            g.set(0, ay, side, section);
            g.set(0, ay, side * 2, section);
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, ay, leg * 14, 0)) {
                    g.set(p[0], p[1], side * 3, section);
                    g.set(p[0] + leg, p[1], side * 3, section);
                }
            }
            for (int u = -6; u <= 6; u++) {
                g.set(u, ay - 8, side * 3, section);
            }
        }
        g.set(-6, 0, -6, CoasterControlPanel.FERRIS_BASE_BLOCK.get().defaultBlockState());
        g.set(-4, 0, -6, CoasterControlPanel.FERRIS_CONTROLLER_BLOCK.get().defaultBlockState());
    }
}
