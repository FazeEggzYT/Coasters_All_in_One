package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Complete rides, placed in one go. The player stands where the ride faces; everything is built from the mod's own
 * blocks plus a seat from the player's mods (Coaster Seats when installed, Create's seats otherwise).
 */
public final class PremadeRides {
    private PremadeRides() {
    }

    public static final int DROP_TOWER = 0;
    public static final int SWING = 1;
    public static final int FERRIS = 2;

    /** Maps ride coordinates (u across, v up, w along the axle) to the world. */
    private static final class Grid {
        final Level level;
        final BlockPos origin;
        final Direction.Axis axis;

        Grid(Level level, BlockPos origin, Direction.Axis axis) {
            this.level = level;
            this.origin = origin;
            this.axis = axis;
        }

        BlockPos at(int u, int v, int w) {
            return axis == Direction.Axis.X ? origin.offset(w, v, u) : origin.offset(u, v, w);
        }

        void set(int u, int v, int w, BlockState state) {
            level.setBlock(at(u, v, w), state, 3);
        }
    }

    private static BlockState seat(int towardU, int towardW) {
        BlockState state = null;
        for (String id : new String[]{"coasterfins:white_coaster_seat", "create:white_seat"}) {
            var opt = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(id));
            if (opt.isPresent()) {
                state = opt.get().defaultBlockState();
                break;
            }
        }
        if (state == null) {
            return Blocks.OAK_STAIRS.defaultBlockState();
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            Direction d = Math.abs(towardU) >= Math.abs(towardW)
                    ? (towardU >= 0 ? Direction.EAST : Direction.WEST)
                    : (towardW >= 0 ? Direction.SOUTH : Direction.NORTH);
            state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, d);
        }
        return state;
    }

    private static BlockState with(Block block, Direction.Axis axis) {
        BlockState s = block.defaultBlockState();
        if (s.hasProperty(FerrisBlocks.WheelPart.AXIS)) {
            s = s.setValue(FerrisBlocks.WheelPart.AXIS, axis);
        } else if (s.hasProperty(SwingBlocks.PivotBlock.AXIS)) {
            s = s.setValue(SwingBlocks.PivotBlock.AXIS, axis);
        }
        return s;
    }

    public static void place(Level level, BlockPos origin, Direction facing, int kind) {
        switch (kind) {
            case DROP_TOWER -> dropTower(level, origin);
            case SWING -> swing(level, origin, facing.getAxis());
            default -> ferris(level, origin, facing.getAxis());
        }
    }

    private static void platform(Grid g, int u0, int u1, int w0, int w1) {
        for (int u = u0; u <= u1; u++) {
            for (int w = w0; w <= w1; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    // ---------------------------------------------------------------- Drop Tower: a 32 block tower

    private static void dropTower(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Z);
        platform(g, -5, 5, -5, 5);
        g.set(0, 0, 0, CoasterControlPanel.DROP_TOWER_BASE_BLOCK.get().defaultBlockState());
        for (int y = 1; y <= 32; y++) {
            g.set(0, y, 0, CoasterControlPanel.DROP_TOWER_SECTION_BLOCK.get().defaultBlockState());
        }
        BlockState frame = CoasterControlPanel.DROP_TOWER_FRAME_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 3; y++) {
            for (int u = -2; u <= 2; u++) {
                for (int w = -2; w <= 2; w++) {
                    if (Math.max(Math.abs(u), Math.abs(w)) == 2) {
                        g.set(u, y, w, frame);
                    }
                }
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                if (u != 0 || w != 0) {
                    g.set(u, 1, w, seat(u, w));
                }
            }
        }
        g.set(4, 0, -4, CoasterControlPanel.DROP_TOWER_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Swing Ride: 18 block frame, 7 piece arm

    private static void swing(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int top = 18;
        int arms = 7;
        platform(g, -8, 8, -9, 9);
        BlockState section = CoasterControlPanel.SWING_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        for (int side : new int[]{-4, 4}) {
            for (int u : new int[]{-1, 1}) {
                for (int y = 0; y < top; y++) {
                    g.set(u, y, side, section);
                }
                g.set(u, top, side, beam);
            }
            g.set(0, top, side, beam);
            for (int y = 4; y < top; y += 5) {
                g.set(0, y, side, Blocks.IRON_BARS.defaultBlockState());
            }
        }
        for (int w = -3; w <= 3; w++) {
            if (w != 0) {
                g.set(0, top, w, beam);
            }
        }
        g.set(0, top, 0, with(CoasterControlPanel.SWING_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, 0, CoasterControlPanel.SWING_ARM_BLOCK.get().defaultBlockState());
        }
        int hub = top - arms - 1;
        g.set(0, hub, 0, CoasterControlPanel.SWING_HUB_BLOCK.get().defaultBlockState());
        BlockState frame = CoasterControlPanel.SWING_FRAME_BLOCK.get().defaultBlockState();
        for (int w = -1; w <= 1; w++) {
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    if (du == 0 && dv == 0 && w == 0) {
                        continue;
                    }
                    if (du == 0 && dv > 0 && w == 0) {
                        continue; // the arm hangs here
                    }
                    int ring = Math.max(Math.abs(du), Math.abs(dv));
                    if (ring == 2) {
                        g.set(du, hub + dv, w, frame);
                    } else {
                        g.set(du, hub + dv, w, seat(du, dv));
                    }
                }
            }
        }
        g.set(0, 0, 7, CoasterControlPanel.SWING_BASE_BLOCK.get().defaultBlockState());
        g.set(2, 0, 7, CoasterControlPanel.SWING_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Ferris Wheel: 24 block wheel, 12 cabins

    private static void ferris(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        RideShapes.Ferris f = RideShapes.ferris(12, 12);
        int ay = 20;
        platform(g, -16, 16, -8, 8);
        g.set(0, ay, 0, with(CoasterControlPanel.FERRIS_AXLE_BLOCK.get(), axis));
        for (long k : f.spokes) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_SPOKE_BLOCK.get(), axis));
        }
        for (long k : f.rim) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        for (long k : f.hangers) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        BlockState frame = CoasterControlPanel.FERRIS_FRAME_BLOCK.get().defaultBlockState();
        for (int[] h : f.hubs) {
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    int ring = Math.max(Math.abs(du), Math.abs(dv));
                    if (ring == 2) {
                        for (int w = -1; w <= 1; w++) {
                            g.set(h[0] + du, ay + h[1] + dv, w, frame);
                        }
                    } else if (ring == 1) {
                        g.set(h[0] + du, ay + h[1] + dv, 0, seat(-du, -dv));
                    } else {
                        g.set(h[0], ay + h[1], 0, CoasterControlPanel.FERRIS_HUB_BLOCK.get().defaultBlockState());
                    }
                }
            }
        }
        // the axle pins and the two A-shaped legs, in front of and behind the wheel
        BlockState section = CoasterControlPanel.FERRIS_SECTION_BLOCK.get().defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            g.set(0, ay, side, section);
            g.set(0, ay, side * 2, section);
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, ay, leg * 14, 0)) {
                    g.set(p[0], p[1], side * 3, section);
                }
            }
        }
        g.set(-6, 0, -6, CoasterControlPanel.FERRIS_BASE_BLOCK.get().defaultBlockState());
        g.set(-4, 0, -6, CoasterControlPanel.FERRIS_CONTROLLER_BLOCK.get().defaultBlockState());
    }
}
