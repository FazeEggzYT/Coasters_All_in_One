package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Complete rides, placed in one go. The player stands where the ride faces; everything is built from the mod's own
 * blocks plus a seat from the player's mods (Coaster Seats when installed, Create's seats otherwise).
 */
public final class PremadeRides {
    private PremadeRides() {
    }

    public static final int DROP_TOWER = 0;
    public static final int SWING = 1;
    public static final int FERRIS = 2;
    public static final int TEACUP = 3;
    public static final int PIRATE = 4;
    public static final int GYRO = 5;
    public static final int CAROUSEL = 6;
    public static final int BUMPER = 7;
    public static final int TIMEMACHINE = 8;

    /** Maps ride coordinates (u across, v up, w along the axle) to the world. */
    private static final class Grid {
        final Level level;
        final BlockPos origin;
        final Direction.Axis axis;

        Grid(Level level, BlockPos origin, Direction.Axis axis) {
            this.level = level;
            this.origin = origin;
            this.axis = axis;
        }

        BlockPos at(int u, int v, int w) {
            return axis == Direction.Axis.X ? origin.offset(w, v, u) : origin.offset(u, v, w);
        }

        void set(int u, int v, int w, BlockState state) {
            level.setBlock(at(u, v, w), state, 3);
        }
    }

    private static BlockState seat(int towardU, int towardW) {
        BlockState state = null;
        for (String id : new String[]{"coasterfins:white_coaster_seat", "create:white_seat"}) {
            var opt = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(id));
            if (opt.isPresent()) {
                state = opt.get().defaultBlockState();
                break;
            }
        }
        if (state == null) {
            return Blocks.OAK_STAIRS.defaultBlockState();
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            Direction d = Math.abs(towardU) >= Math.abs(towardW)
                    ? (towardU >= 0 ? Direction.EAST : Direction.WEST)
                    : (towardW >= 0 ? Direction.SOUTH : Direction.NORTH);
            state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, d);
        }
        return state;
    }

    private static BlockState with(Block block, Direction.Axis axis) {
        BlockState s = block.defaultBlockState();
        if (s.hasProperty(FerrisBlocks.WheelPart.AXIS)) {
            s = s.setValue(FerrisBlocks.WheelPart.AXIS, axis);
        } else if (s.hasProperty(SwingBlocks.PivotBlock.AXIS)) {
            s = s.setValue(SwingBlocks.PivotBlock.AXIS, axis);
        }
        return s;
    }

    public static void place(Level level, BlockPos origin, Direction facing, int kind) {
        switch (kind) {
            case DROP_TOWER -> dropTower(level, origin);
            case SWING -> swing(level, origin, facing.getAxis());
            case TEACUP -> teacup(level, origin);
            case PIRATE -> pirate(level, origin, facing.getAxis());
            case GYRO -> gyro(level, origin, facing.getAxis());
            case CAROUSEL -> carousel(level, origin);
            case BUMPER -> bumper(level, origin);
            case TIMEMACHINE -> timeMachine(level, origin, facing.getAxis());
            default -> ferris(level, origin, facing.getAxis());
        }
    }

    private static void platform(Grid g, int u0, int u1, int w0, int w1) {
        for (int u = u0; u <= u1; u++) {
            for (int w = w0; w <= w1; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    // ---------------------------------------------------------------- Drop Tower: a 32 block tower

    private static void dropTower(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Z);
        platform(g, -6, 6, -6, 6);
        g.set(0, 0, 0, CoasterControlPanel.DROP_TOWER_BASE_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.DROP_TOWER_SECTION_BLOCK.get().defaultBlockState();
        // a 3 by 3 tower: the middle column is the one that counts, the rest is the thick body
        for (int y = 1; y <= 32; y++) {
            for (int u = -1; u <= 1; u++) {
                for (int w = -1; w <= 1; w++) {
                    g.set(u, y, w, section);
                }
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, 33, w, Blocks.IRON_BLOCK.defaultBlockState());
            }
        }
        for (int u = -1; u <= 1; u++) {
            for (int w = -1; w <= 1; w++) {
                if (u != 0 || w != 0) {
                    g.set(u, 0, w, Blocks.IRON_BLOCK.defaultBlockState());
                }
            }
        }
        // the carriage: a ring of 24 seats with a frame around them, three blocks tall
        BlockState frame = CoasterControlPanel.DROP_TOWER_FRAME_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 3; y++) {
            for (int u = -4; u <= 4; u++) {
                for (int w = -4; w <= 4; w++) {
                    if (Math.max(Math.abs(u), Math.abs(w)) == 4) {
                        g.set(u, y, w, frame);
                    }
                }
            }
        }
        for (int u = -3; u <= 3; u++) {
            for (int w = -3; w <= 3; w++) {
                if (Math.max(Math.abs(u), Math.abs(w)) == 3) {
                    g.set(u, 1, w, seat(u, w));
                }
            }
        }
        g.set(6, 0, -6, CoasterControlPanel.DROP_TOWER_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Swing Ride, built like Rush: long arm, gondola near the ground

    private static void swing(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int top = 20;
        int arms = 16;
        int hub = top - arms - 1;
        int aw = 7; // the arm hangs outside the frame, at the end of the axle
        platform(g, -14, 14, -14, 14);
        BlockState section = CoasterControlPanel.SWING_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        // one tall A-frame in the middle, three blocks thick, like Rush
        for (int w = -1; w <= 1; w++) {
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, top - 1, leg * 8, 0)) {
                    g.set(p[0], p[1], w, section);
                    g.set(p[0] + (leg > 0 ? -1 : 1), p[1], w, section);
                }
            }
            g.set(0, top, w, section);
            g.set(1, top - 1, w, section);
            g.set(-1, top - 1, w, section);
            for (int u = -3; u <= 3; u++) {
                g.set(u, 7, w, section);
            }
        }
        BlockState frame = CoasterControlPanel.SWING_FRAME_BLOCK.get().defaultBlockState();
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        // two arms, one each side of the frame, on one axle: they swing opposite ways, like Rush
        for (int side : new int[]{-1, 1}) {
            int pw = side * aw;
            for (int k = 2; k < aw; k++) {
                g.set(0, top, side * k, beam);
            }
            g.set(0, top, pw, with(CoasterControlPanel.SWING_PIVOT_BLOCK.get(), axis));
            for (int i = 1; i <= arms; i++) {
                g.set(0, top - i, pw, CoasterControlPanel.SWING_ARM_BLOCK.get().defaultBlockState());
            }
            g.set(0, hub, pw, CoasterControlPanel.SWING_HUB_BLOCK.get().defaultBlockState());
            // the gondola: 16 seats in two rows back to back, facing out, with lap bars
            for (int u = -2; u <= 2; u++) {
                for (int k = 3; k <= 10; k++) {
                    g.set(u, hub - 1, side * k, frame);
                }
            }
            for (int k = 3; k <= 10; k++) {
                int w = side * k;
                if (w != pw) {
                    g.set(0, hub, w, frame);
                }
                g.set(1, hub, w, seat(1, 0));
                g.set(-1, hub, w, seat(-1, 0));
                g.set(2, hub, w, frame);
                g.set(-2, hub, w, frame);
            }
            for (int u = -2; u <= 2; u++) {
                g.set(u, hub + 1, side * 3, frame);
                g.set(u, hub + 1, side * 10, frame);
            }
            // boarding platforms level with the gondola floor
            for (int sd : new int[]{-1, 1}) {
                for (int u = 3; u <= 6; u++) {
                    for (int k = 2; k <= 11; k++) {
                        g.set(sd * u, hub - 1, side * k, stone);
                    }
                }
                for (int k = 2; k <= 11; k++) {
                    g.set(sd * 7, 0, side * k, stone);
                }
            }
        }
        g.set(11, 0, 0, CoasterControlPanel.SWING_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 2, CoasterControlPanel.SWING_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Gyro Swing: one arm, a ring that turns in the swing plane

    private static void gyro(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int arms = 11;
        int hub = 6;
        int top = hub + arms + 1;
        int aw = 6;
        platform(g, -14, 14, -6, 12);
        BlockState section = CoasterControlPanel.GYRO_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.IRON_BLOCK.defaultBlockState();
        for (int w = -1; w <= 1; w++) {
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, top - 1, leg * 7, 0)) {
                    g.set(p[0], p[1], w, section);
                    g.set(p[0] + (leg > 0 ? -1 : 1), p[1], w, section);
                }
            }
            g.set(0, top, w, section);
            g.set(1, top - 1, w, section);
            g.set(-1, top - 1, w, section);
            for (int u = -3; u <= 3; u++) {
                g.set(u, 6, w, section);
            }
        }
        for (int w = 2; w < aw; w++) {
            g.set(0, top, w, beam);
        }
        g.set(0, top, aw, with(CoasterControlPanel.GYRO_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, aw, CoasterControlPanel.GYRO_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, aw, CoasterControlPanel.GYRO_HUB_BLOCK.get().defaultBlockState());
        BlockState ring = CoasterControlPanel.GYRO_RING_BLOCK.get().defaultBlockState();
        java.util.Set<Long> cells = new java.util.HashSet<>();
        for (int u = -5; u <= 5; u++) {
            for (int v = -5; v <= 5; v++) {
                double d = Math.sqrt(u * u + v * v);
                if (d >= 3.5 && d < 4.5) {
                    cells.add(((long) (u + 8) << 8) | (v + 8));
                    for (int w = aw - 1; w <= aw + 1; w++) {
                        g.set(u, hub + v, w, ring);
                    }
                }
            }
        }
        for (int k = 1; k <= 2; k++) {
            for (int[] dir : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                g.set(dir[0] * k, hub + dir[1] * k, aw, ring);
            }
        }
        for (int u = -4; u <= 4; u++) {
            for (int v = -4; v <= 4; v++) {
                double d = Math.sqrt(u * u + v * v);
                if (d < 2.5 || d >= 3.5) {
                    continue;
                }
                boolean touches = cells.contains(((long) (u + 9) << 8) | (v + 8)) || cells.contains(((long) (u + 7) << 8) | (v + 8))
                        || cells.contains(((long) (u + 8) << 8) | (v + 9)) || cells.contains(((long) (u + 8) << 8) | (v + 7));
                if (touches) {
                    for (int w = aw - 1; w <= aw + 1; w++) {
                        g.set(u, hub + v, w, seat(u, 0));
                    }
                }
            }
        }
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int sd : new int[]{-1, 1}) {
            for (int u = 5; u <= 7; u++) {
                for (int w = aw - 2; w <= aw + 2; w++) {
                    g.set(sd * u, 1, w, stone);
                }
            }
            for (int w = aw - 2; w <= aw + 2; w++) {
                g.set(sd * 8, 0, w, stone);
            }
        }
        g.set(11, 0, 0, CoasterControlPanel.GYRO_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 2, CoasterControlPanel.GYRO_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Carousel: a deck of 8 blocks radius with two rings of horses

    private static void carousel(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        for (int u = -11; u <= 11; u++) {
            for (int w = -11; w <= 11; w++) {
                g.set(u, -1, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
        BlockState deck = CoasterControlPanel.CAROUSEL_DECK_BLOCK.get().defaultBlockState();
        BlockState pole = CoasterControlPanel.CAROUSEL_POLE_BLOCK.get().defaultBlockState();
        BlockState roof = CoasterControlPanel.CAROUSEL_ROOF_BLOCK.get().defaultBlockState();
        BlockState horse = CoasterControlPanel.CAROUSEL_HORSE_BLOCK.get().defaultBlockState();
        for (int u = -9; u <= 9; u++) {
            for (int w = -9; w <= 9; w++) {
                double d = Math.sqrt(u * u + w * w);
                if (d <= 8.5) {
                    g.set(u, 0, w, deck);
                }
                if (d <= 8.5) {
                    g.set(u, 5, w, roof);
                }
            }
        }
        g.set(0, 0, 0, CoasterControlPanel.CAROUSEL_HUB_BLOCK.get().defaultBlockState());
        for (int y = 1; y <= 4; y++) {
            g.set(0, y, 0, pole);
        }
        int[] radii = {3, 6};
        int[] counts = {8, 14};
        for (int r = 0; r < 2; r++) {
            for (int i = 0; i < counts[r]; i++) {
                double a = Math.PI * 2.0 * i / counts[r];
                int hu = (int) Math.round(Math.cos(a) * radii[r]);
                int hw = (int) Math.round(Math.sin(a) * radii[r]);
                int pu = (int) Math.round(Math.cos(a) * (radii[r] - 1));
                int pw = (int) Math.round(Math.sin(a) * (radii[r] - 1));
                g.set(hu, 1, hw, horse);
                g.set(hu, 2, hw, seat((int) -Math.round(Math.sin(a) * 2), (int) Math.round(Math.cos(a) * 2)));
                for (int y = 1; y <= 4; y++) {
                    if (pu != hu || pw != hw) {
                        g.set(pu, y, pw, pole);
                    }
                }
            }
        }
        g.set(10, 0, 0, CoasterControlPanel.CAROUSEL_BASE_BLOCK.get().defaultBlockState());
        g.set(10, 0, 2, CoasterControlPanel.CAROUSEL_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Bumper Cars: a 15 by 15 arena with a padded rail and six cars

    private static void bumper(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        BlockState floor = CoasterControlPanel.BUMPER_FLOOR_BLOCK.get().defaultBlockState();
        BlockState rail = CoasterControlPanel.BUMPER_RAIL_BLOCK.get().defaultBlockState();
        BlockState post = CoasterControlPanel.BUMPER_SECTION_BLOCK.get().defaultBlockState();
        for (int u = -10; u <= 10; u++) {
            for (int w = -10; w <= 10; w++) {
                boolean inside = Math.abs(u) <= 7 && Math.abs(w) <= 7;
                g.set(u, -1, w, inside ? floor : Blocks.POLISHED_ANDESITE.defaultBlockState());
                boolean edge = Math.max(Math.abs(u), Math.abs(w)) == 8;
                if (edge) {
                    g.set(u, 0, w, rail);
                }
            }
        }
        for (int su : new int[]{-8, 8}) {
            for (int sw : new int[]{-8, 8}) {
                for (int y = 1; y <= 5; y++) {
                    g.set(su, y, sw, post);
                }
            }
        }
        // a gap in the rail for the entrance
        g.set(0, 0, -8, Blocks.AIR.defaultBlockState());
        g.set(1, 0, -8, Blocks.AIR.defaultBlockState());
        g.set(11, 0, -2, CoasterControlPanel.BUMPER_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, 0, CoasterControlPanel.BUMPER_CONTROLLER_BLOCK.get().defaultBlockState());
        int[][] spots = {{-5, -4}, {0, -4}, {5, -4}, {-5, 2}, {0, 3}, {5, 2}};
        for (int i = 0; i < spots.length; i++) {
            BlockPos at = g.at(spots[i][0], 0, spots[i][1]);
            BumperCarEntity car = new BumperCarEntity(CoasterControlPanel.BUMPER_CAR.get(), level);
            car.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, 90.0F * (i % 4), 0.0F);
            level.addFreshEntity(car);
        }
    }

    // ---------------------------------------------------------------- Time Machine: a flat boom on a pedestal, a pod on each end

    private static void timeMachine(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int py = 5;
        int armA = 9;
        int armB = 2;
        BlockState black = Blocks.BLACK_CONCRETE.defaultBlockState();
        for (int u = -13; u <= 19; u++) {
            for (int w = -13; w <= 13; w++) {
                double d = Math.sqrt((u - 3) * (u - 3) + w * w);
                if (d <= 12.5 || (u >= 12 && u <= 19 && Math.abs(w) <= 2)) {
                    g.set(u, -1, w, black);
                }
            }
        }
        BlockState section = CoasterControlPanel.TIMEMACHINE_SECTION_BLOCK.get().defaultBlockState();
        BlockState pod = CoasterControlPanel.TIMEMACHINE_POD_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.GOLD_BLOCK.defaultBlockState();
        // the pedestal: two legs and a cross beam, with the axle running between them
        for (int sd : new int[]{-1, 1}) {
            for (int y = 0; y <= py; y++) {
                g.set(0, y, sd * 2, section);
                g.set(1, y, sd * 2, section);
                g.set(-1, y, sd * 2, section);
            }
            g.set(0, py, sd * 1, beam);
        }
        for (int u = -2; u <= 2; u++) {
            g.set(u, 0, -2, section);
            g.set(u, 0, 2, section);
        }
        g.set(0, py, 0, with(CoasterControlPanel.TIMEMACHINE_PIVOT_BLOCK.get(), axis));
        // the boom: a long side to the front and a short one behind the axle
        for (int i = 1; i <= armA; i++) {
            g.set(i, py, 0, CoasterControlPanel.TIMEMACHINE_ARM_BLOCK.get().defaultBlockState());
        }
        for (int i = 1; i <= armB; i++) {
            g.set(-i, py, 0, CoasterControlPanel.TIMEMACHINE_ARM_BLOCK.get().defaultBlockState());
        }
        int hubA = armA + 1;
        int hubB = -(armB + 1);
        g.set(hubA, py, 0, CoasterControlPanel.TIMEMACHINE_HUB_BLOCK.get().defaultBlockState());
        g.set(hubB, py, 0, CoasterControlPanel.TIMEMACHINE_HUB_BLOCK.get().defaultBlockState());
        buildPod(g, hubA, py, 3, pod);
        buildPod(g, hubB, py, 2, pod);
        // steps up to the front pod
        for (int i = 0; i <= 3; i++) {
            for (int w = -1; w <= 1; w++) {
                for (int y = 0; y <= 3 - i; y++) {
                    g.set(hubA + 3 + i, y, w, Blocks.POLISHED_ANDESITE.defaultBlockState());
                }
            }
        }
        g.set(6, 0, -8, CoasterControlPanel.TIMEMACHINE_BASE_BLOCK.get().defaultBlockState());
        g.set(8, 0, -8, CoasterControlPanel.TIMEMACHINE_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    /** A pod around a hub: a solid floor, a wall at each end and each side, and two rows of seats facing outward. */
    private static void buildPod(Grid g, int hubU, int py, int half, BlockState pod) {
        for (int u = hubU - 2; u <= hubU + 2; u++) {
            for (int w = -half - 1; w <= half + 1; w++) {
                g.set(u, py - 1, w, pod);
            }
        }
        int near = hubU > 0 ? -1 : 1;
        for (int w = -half; w <= half; w++) {
            // the boom comes in at w = 0 on the near side, so that spot is left open
            if (w != 0) {
                g.set(hubU + near, py, w, seat(near, 0));
                g.set(hubU, py, w, pod);
                g.set(hubU + 2 * near, py, w, pod);
            }
            g.set(hubU - near, py, w, seat(-near, 0));
            g.set(hubU - 2 * near, py, w, pod);
        }
        for (int u = hubU - 2; u <= hubU + 2; u++) {
            for (int sd : new int[]{-1, 1}) {
                g.set(u, py, sd * (half + 1), pod);
                g.set(u, py + 1, sd * (half + 1), pod);
            }
        }
    }

    // ---------------------------------------------------------------- Pirate Ship: 15 block boat on a 9 piece arm

    private static void pirate(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        int arms = 9;
        int hub = 4;
        int top = hub + arms + 1;
        platform(g, -14, 14, -11, 11);
        BlockState section = CoasterControlPanel.PIRATE_SECTION_BLOCK.get().defaultBlockState();
        BlockState beam = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int plane = 5; plane <= 6; plane++) {
                for (int leg : new int[]{-1, 1}) {
                    for (int[] p : RideShapes.line(0, top - 1, leg * 9, 0)) {
                        g.set(p[0], p[1], side * plane, section);
                    }
                }
                g.set(0, top, side * plane, beam);
            }
        }
        for (int w = -6; w <= 6; w++) {
            if (w != 0) {
                g.set(0, top, w, beam);
            }
        }
        g.set(0, top, 0, with(CoasterControlPanel.PIRATE_PIVOT_BLOCK.get(), axis));
        for (int i = 1; i <= arms; i++) {
            g.set(0, top - i, 0, CoasterControlPanel.PIRATE_ARM_BLOCK.get().defaultBlockState());
        }
        g.set(0, hub, 0, CoasterControlPanel.PIRATE_HUB_BLOCK.get().defaultBlockState());
        BlockState hull = CoasterControlPanel.PIRATE_HULL_BLOCK.get().defaultBlockState();
        // the boat: a keel that tapers, a deck, a rail along both sides and a tall bow and stern
        for (int u = -6; u <= 6; u++) {
            for (int w = -2; w <= 2; w++) {
                g.set(u, hub - 1, w, hull);
            }
        }
        for (int u = -4; u <= 4; u++) {
            for (int w = -1; w <= 1; w++) {
                g.set(u, hub - 2, w, hull);
            }
        }
        for (int u = -2; u <= 2; u++) {
            g.set(u, hub - 3, 0, hull);
        }
        for (int u = -6; u <= 6; u++) {
            g.set(u, hub, -2, hull);
            g.set(u, hub, 2, hull);
            g.set(u, hub + 1, -2, hull);
            g.set(u, hub + 1, 2, hull);
            if (u != 0) {
                g.set(u, hub, 0, hull);
            }
            for (int w : new int[]{-1, 1}) {
                g.set(u, hub, w, seat(0, w));
            }
        }
        for (int h = 0; h <= 3; h++) {
            g.set(-7, hub + h, 0, hull);
            g.set(7, hub + h, 0, hull);
            if (h < 2) {
                g.set(-7, hub + h, -1, hull);
                g.set(-7, hub + h, 1, hull);
                g.set(7, hub + h, -1, hull);
                g.set(7, hub + h, 1, hull);
            }
        }
        g.set(-8, hub + 2, 0, hull);
        g.set(8, hub + 2, 0, hull);
        // steps up to a boarding platform at each end
        BlockState stone = Blocks.POLISHED_ANDESITE.defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            for (int w = -2; w <= 2; w++) {
                g.set(side * 9, hub - 1, w, stone);
                g.set(side * 10, hub - 2, w, stone);
                g.set(side * 11, hub - 3, w, stone);
                g.set(side * 8, hub - 1, w, stone);
            }
        }
        g.set(0, 0, -9, CoasterControlPanel.PIRATE_BASE_BLOCK.get().defaultBlockState());
        g.set(2, 0, -9, CoasterControlPanel.PIRATE_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Teacup Ride: a 19 block platter with four cups

    private static void teacup(Level level, BlockPos origin) {
        Grid g = new Grid(level, origin, Direction.Axis.Y);
        platform(g, -12, 12, -12, 12);
        BlockState plate = CoasterControlPanel.TEACUP_PLATE_BLOCK.get().defaultBlockState();
        for (int u = -9; u <= 9; u++) {
            for (int w = -9; w <= 9; w++) {
                if (u * u + w * w <= 9.4 * 9.4) {
                    g.set(u, 0, w, plate);
                }
            }
        }
        g.set(0, 0, 0, CoasterControlPanel.TEACUP_HUB_BLOCK.get().defaultBlockState());
        BlockState section = CoasterControlPanel.TEACUP_SECTION_BLOCK.get().defaultBlockState();
        for (int y = 1; y <= 4; y++) {
            g.set(0, y, 0, section);
        }
        BlockState floor = CoasterControlPanel.TEACUP_FLOOR_BLOCK.get().defaultBlockState();
        BlockState wall = CoasterControlPanel.TEACUP_WALL_BLOCK.get().defaultBlockState();
        int[][] centres = {{5, 0}, {0, 5}, {-5, 0}, {0, -5}};
        for (int[] c : centres) {
            int ox = Integer.compare(c[0], 0);
            int oz = Integer.compare(c[1], 0);
            for (int du = -2; du <= 2; du++) {
                for (int dw = -2; dw <= 2; dw++) {
                    int cu = c[0] + du;
                    int cw = c[1] + dw;
                    int ring = Math.max(Math.abs(du), Math.abs(dw));
                    if (du == 0 && dw == 0) {
                        g.set(cu, 1, cw, CoasterControlPanel.TEACUP_CUP_HUB_BLOCK.get().defaultBlockState());
                        continue;
                    }
                    if (Math.abs(du) == 2 && Math.abs(dw) == 2) {
                        continue; // rounded corners
                    }
                    g.set(cu, 1, cw, floor);
                    boolean gap = du == 2 * ox && dw == 2 * oz && (ox != 0 || oz != 0);
                    if (ring == 2 && !gap) {
                        g.set(cu, 2, cw, wall);
                    } else if (ring == 1) {
                        g.set(cu, 2, cw, seat(-du, -dw));
                    }
                }
            }
        }
        g.set(11, 0, -11, CoasterControlPanel.TEACUP_BASE_BLOCK.get().defaultBlockState());
        g.set(11, 0, -9, CoasterControlPanel.TEACUP_CONTROLLER_BLOCK.get().defaultBlockState());
    }

    // ---------------------------------------------------------------- Ferris Wheel: 24 block wheel, 12 cabins

    private static void ferris(Level level, BlockPos origin, Direction.Axis axis) {
        Grid g = new Grid(level, origin, axis);
        RideShapes.Ferris f = RideShapes.ferris(12, 12);
        int ay = 20;
        platform(g, -16, 16, -8, 8);
        g.set(0, ay, 0, with(CoasterControlPanel.FERRIS_AXLE_BLOCK.get(), axis));
        for (long k : f.spokes) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_SPOKE_BLOCK.get(), axis));
        }
        for (long k : f.rim) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        for (long k : f.hangers) {
            g.set(RideShapes.ku(k), ay + RideShapes.kv(k), 0, with(CoasterControlPanel.FERRIS_RIM_BLOCK.get(), axis));
        }
        BlockState frame = CoasterControlPanel.FERRIS_FRAME_BLOCK.get().defaultBlockState();
        for (int[] h : f.hubs) {
            for (int du = -2; du <= 2; du++) {
                for (int dv = -2; dv <= 2; dv++) {
                    int ring = Math.max(Math.abs(du), Math.abs(dv));
                    if (ring == 2) {
                        for (int w = -1; w <= 1; w++) {
                            g.set(h[0] + du, ay + h[1] + dv, w, frame);
                        }
                    } else if (ring == 1) {
                        g.set(h[0] + du, ay + h[1] + dv, 0, seat(-du, -dv));
                    } else {
                        g.set(h[0], ay + h[1], 0, CoasterControlPanel.FERRIS_HUB_BLOCK.get().defaultBlockState());
                    }
                }
            }
        }
        // the axle pins and the two A-shaped legs, in front of and behind the wheel
        BlockState section = CoasterControlPanel.FERRIS_SECTION_BLOCK.get().defaultBlockState();
        for (int side : new int[]{-1, 1}) {
            g.set(0, ay, side, section);
            g.set(0, ay, side * 2, section);
            for (int leg : new int[]{-1, 1}) {
                for (int[] p : RideShapes.line(0, ay, leg * 14, 0)) {
                    g.set(p[0], p[1], side * 3, section);
                    g.set(p[0] + leg, p[1], side * 3, section);
                }
            }
            for (int u = -6; u <= 6; u++) {
                g.set(u, ay - 8, side * 3, section);
            }
        }
        g.set(-6, 0, -6, CoasterControlPanel.FERRIS_BASE_BLOCK.get().defaultBlockState());
        g.set(-4, 0, -6, CoasterControlPanel.FERRIS_CONTROLLER_BLOCK.get().defaultBlockState());
    }
}
