package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: what a menu board shows. */
public record MenuBoardPacket(BlockPos pos, String title, String[] lines, boolean auto) implements CustomPacketPayload {
    public static final Type<MenuBoardPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "menu_board"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MenuBoardPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeUtf(p.title, 32);
                buf.writeBoolean(p.auto);
                for (int i = 0; i < RestaurantBlocks.MenuBoardBlockEntity.LINES; i++) {
                    buf.writeUtf(i < p.lines.length ? p.lines[i] : "", 40);
                }
            },
            buf -> {
                BlockPos pos = buf.readBlockPos();
                String title = buf.readUtf(32);
                boolean auto = buf.readBoolean();
                String[] lines = new String[RestaurantBlocks.MenuBoardBlockEntity.LINES];
                for (int i = 0; i < lines.length; i++) {
                    lines[i] = buf.readUtf(40);
                }
                return new MenuBoardPacket(pos, title, lines, auto);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(MenuBoardPacket p, IPayloadContext context) {
        var level = context.player().level();
        if (context.player().distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 144.0
                || !level.isLoaded(p.pos)) {
            return;
        }
        if (level.getBlockEntity(p.pos) instanceof RestaurantBlocks.MenuBoardBlockEntity b) {
            b.apply(p.title, p.lines, p.auto);
        }
    }
}
