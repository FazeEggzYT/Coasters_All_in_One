package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen of the effect block. Left: the effect and how it looks. Right: link, switches, firework settings. */
public class EffectScreen extends AbstractContainerScreen<EffectMenu> {
    private static final int E = EffectBlockEntity.COUNT;
    private final int[] v = EffectBlockEntity.DEF.clone();

    // left column rows, in order
    private static final int[] LEFT = {
            EffectBlockEntity.S_EFFECT, EffectBlockEntity.S_AMOUNT, EffectBlockEntity.S_SPREAD,
            EffectBlockEntity.S_SPEED, EffectBlockEntity.S_RATE, EffectBlockEntity.S_SIZE,
            EffectBlockEntity.S_OFFSET, EffectBlockEntity.S_RUN, EffectBlockEntity.S_DELAY,
            EffectBlockEntity.S_COLOR, EffectBlockEntity.S_FADE};
    private static final String[] NAMES = new String[E];

    static {
        NAMES[EffectBlockEntity.S_EFFECT] = "effect";
        NAMES[EffectBlockEntity.S_AMOUNT] = "amount";
        NAMES[EffectBlockEntity.S_SPREAD] = "spread";
        NAMES[EffectBlockEntity.S_SPEED] = "speed";
        NAMES[EffectBlockEntity.S_RATE] = "rate";
        NAMES[EffectBlockEntity.S_SIZE] = "size";
        NAMES[EffectBlockEntity.S_OFFSET] = "offset";
        NAMES[EffectBlockEntity.S_RUN] = "run";
        NAMES[EffectBlockEntity.S_DELAY] = "delay";
        NAMES[EffectBlockEntity.S_COLOR] = "color";
        NAMES[EffectBlockEntity.S_FADE] = "fade";
        NAMES[EffectBlockEntity.S_SHAPE] = "shape";
        NAMES[EffectBlockEntity.S_FLIGHT] = "flight";
    }

    private static final String[] SHAPES = {"Small ball", "Large ball", "Star", "Creeper", "Burst"};

    public EffectScreen(EffectMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 372;
        this.imageHeight = 232;
    }

    private int step() {
        return Screen.hasShiftDown() ? 5 : 1;
    }

    @Override
    protected void init() {
        super.init();
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof EffectBlockEntity e) {
            for (int i = 0; i < E; i++) {
                v[i] = e.get(i);
            }
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + 146, topPos + 3, 38, 14).build());

        for (int row = 0; row < LEFT.length; row++) {
            addPair(LEFT[row], 80, 166, 20 + row * 18);
        }
        // right column
        addPair(EffectBlockEntity.S_SHAPE, 262, 348, 86);
        addPair(EffectBlockEntity.S_FLIGHT, 262, 348, 104);
        addToggle(EffectBlockEntity.S_SOUND, "sound", 199, 40);
        addToggle(EffectBlockEntity.S_REDSTONE, "redstone", 283, 40);
        addToggle(EffectBlockEntity.S_TRAIL, "trail", 199, 56);
        addToggle(EffectBlockEntity.S_TWINKLE, "twinkle", 283, 56);
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.effect_test"),
                b -> send(true)).bounds(leftPos + 199, topPos + 124, 164, 16).build());
    }

    private void addPair(int index, int minusX, int plusX, int y) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> change(index, -step()))
                .bounds(leftPos + minusX, topPos + y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> change(index, step()))
                .bounds(leftPos + plusX, topPos + y, 18, 16).build());
    }

    private void addToggle(int index, String key, int x, int y) {
        addRenderableWidget(Button.builder(toggleText(index, key), b -> {
            v[index] = v[index] == 1 ? 0 : 1;
            b.setMessage(toggleText(index, key));
        }).bounds(leftPos + x, topPos + y, 80, 16).build());
    }

    private Component toggleText(int index, String key) {
        return Component.translatable("gui.coastercontrolpanel.effect." + key,
                Component.translatable(v[index] == 1 ? "gui.coastercontrolpanel.on" : "gui.coastercontrolpanel.off"));
    }

    private void change(int index, int delta) {
        if (index == EffectBlockEntity.S_EFFECT) {
            // the effect wraps around, one at a time
            int n = EffectBlockEntity.MAX[index] + 1;
            int dir = Integer.signum(delta);
            v[index] = Math.floorMod(v[index] + dir, n);
            EffectType t = EffectType.byIndex(v[index]);
            v[EffectBlockEntity.S_AMOUNT] = t.defAmount;
            v[EffectBlockEntity.S_RATE] = t.defRate;
            v[EffectBlockEntity.S_SPEED] = 100;
            return;
        }
        v[index] = Math.max(EffectBlockEntity.MIN[index], Math.min(EffectBlockEntity.MAX[index], v[index] + delta));
    }

    private void send(boolean test) {
        PacketDistributor.sendToServer(new EffectConfigPacket(menu.getPos(), v.clone(), test));
    }

    @Override
    public void removed() {
        send(false);
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 190, y0 + 4, x0 + 191, y0 + imageHeight - 4, 0xFF3A3E4D);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    private String valueText(int index) {
        int val = v[index];
        return switch (index) {
            case EffectBlockEntity.S_EFFECT -> EffectType.byIndex(val).label;
            case EffectBlockEntity.S_SPREAD, EffectBlockEntity.S_SPEED, EffectBlockEntity.S_SIZE -> val + "%";
            case EffectBlockEntity.S_RATE -> val + " tick" + (val == 1 ? "" : "s");
            case EffectBlockEntity.S_OFFSET -> (val / 10.0) + " blk";
            case EffectBlockEntity.S_RUN -> val == 0 ? "While on" : val + " s";
            case EffectBlockEntity.S_DELAY -> val + " s";
            case EffectBlockEntity.S_COLOR, EffectBlockEntity.S_FADE -> val >= 16 ? "Random"
                    : Component.translatable("color.minecraft." + DyeColor.byId(val).getName()).getString();
            case EffectBlockEntity.S_SHAPE -> SHAPES[Math.min(val, SHAPES.length - 1)];
            default -> String.valueOf(val);
        };
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int dim = 0x7A8098;
        int text = 0xE0E4F0;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        EffectType t = EffectType.byIndex(v[EffectBlockEntity.S_EFFECT]);
        for (int row = 0; row < LEFT.length; row++) {
            int idx = LEFT[row];
            int y = 24 + row * 18;
            boolean greyed = (idx == EffectBlockEntity.S_COLOR && !t.usesColour())
                    || (idx == EffectBlockEntity.S_FADE && !t.usesFade())
                    || (idx == EffectBlockEntity.S_SIZE && !t.usesSize());
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.effect." + NAMES[idx]).getString(),
                    8, y, greyed ? dim : text, false);
            g.drawCenteredString(font, valueText(idx), idx == EffectBlockEntity.S_EFFECT ? 132 : 132, y,
                    greyed ? dim : 0xFFFFFF);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.effect_link"), 199, 24, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.effect_fireworks"), 199, 76, dim, false);
        boolean fw = t.isFirework();
        int c = fw ? text : dim;
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.effect.shape"), 199, 90, c, false);
        g.drawCenteredString(font, valueText(EffectBlockEntity.S_SHAPE), 305, 90, fw ? 0xFFFFFF : dim);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.effect.flight"), 199, 108, c, false);
        g.drawCenteredString(font, valueText(EffectBlockEntity.S_FLIGHT), 305, 108, fw ? 0xFFFFFF : dim);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 199, 142, dim, false);
    }
}
