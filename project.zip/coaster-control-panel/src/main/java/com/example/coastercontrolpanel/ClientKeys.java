package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import org.lwjgl.glfw.GLFW;

import javax.annotation.Nullable;

/** Client-only: the key bindings and which panel is currently pinned on screen. */
public final class ClientKeys {
    public static final String CATEGORY = "key.categories.coastercontrolpanel";

    public static final KeyMapping MOUSE = new KeyMapping("key.coastercontrolpanel.mouse",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY);
    public static final KeyMapping UNPIN = new KeyMapping("key.coastercontrolpanel.unpin",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY);

    public static final KeyMapping POO = new KeyMapping("key.coastercontrolpanel.poo",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Y, CATEGORY);

    /** The panel shown in the bottom left, or null. */
    @Nullable
    public static BlockPos pinned = null;

    private ClientKeys() {
    }
}
