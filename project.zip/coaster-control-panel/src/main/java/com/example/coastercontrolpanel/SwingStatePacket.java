package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client, every tick while a Swing Ride runs: the client moves both moving structures from these numbers. */
public record SwingStatePacket(BlockPos pos, float theta, float spin, int phase, long pivot, long hub, int axis, int mode, boolean twin, long pivot2, long hub2, boolean hasB, long hubB) implements CustomPacketPayload {
    public static final Type<SwingStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "swing_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SwingStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.theta);
                buf.writeFloat(p.spin);
                buf.writeVarInt(p.phase);
                buf.writeLong(p.pivot);
                buf.writeLong(p.hub);
                buf.writeVarInt(p.axis);
                buf.writeVarInt(p.mode);
                buf.writeBoolean(p.twin);
                buf.writeLong(p.pivot2);
                buf.writeLong(p.hub2);
                buf.writeBoolean(p.hasB);
                buf.writeLong(p.hubB);
            },
            buf -> new SwingStatePacket(buf.readBlockPos(), buf.readFloat(), buf.readFloat(), buf.readVarInt(), buf.readLong(),
                    buf.readLong(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readLong(), buf.readLong(), buf.readBoolean(), buf.readLong()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SwingStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof SwingBlockEntity be) {
            be.receiveState(p.theta, p.spin, p.phase, BlockPos.of(p.pivot), BlockPos.of(p.hub), p.axis, p.mode, p.twin, BlockPos.of(p.pivot2), BlockPos.of(p.hub2), p.hasB, BlockPos.of(p.hubB));
        }
    }
}
