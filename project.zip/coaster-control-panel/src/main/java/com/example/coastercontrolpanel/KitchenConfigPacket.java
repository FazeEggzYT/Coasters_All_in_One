package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server for the Order Bell and the Extractor Fan. Actions: 1 ring, 2 reset orders, 10..12 fan Off, Low, High. */
public record KitchenConfigPacket(BlockPos pos, int action) implements CustomPacketPayload {
    public static final Type<KitchenConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "kitchen_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, KitchenConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
            },
            buf -> new KitchenConfigPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(KitchenConfigPacket p, IPayloadContext context) {
        Level level = context.player().level();
        if (context.player().distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 100.0
                || !level.isLoaded(p.pos)) {
            return;
        }
        if (p.action == 1 || p.action == 2) {
            if (level.getBlockEntity(p.pos) instanceof KitchenExtras.BellBlockEntity bell) {
                if (p.action == 1) {
                    bell.ring();
                } else {
                    bell.reset();
                }
            }
        } else if (p.action >= 10 && p.action <= 12) {
            BlockState s = level.getBlockState(p.pos);
            if (s.getBlock() instanceof KitchenExtras.FanBlock) {
                level.setBlock(p.pos, s.setValue(KitchenExtras.FanBlock.SPEED, p.action - 10), 3);
            }
        }
    }
}
