package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Shared by the Station, Launch, Brake and Lift controllers. It detects a train in its zone (a box,
 * or the track between two anchors) and runs the logic of its ZoneType.
 * The first slot of every type is an input: its Redstone Link, and optionally plain redstone, drives it.
 */
public class ZoneBlockEntity extends BlockEntity implements TrackZone {
    private static final int SCAN_EVERY = 5;

    private final ZoneType type;
    private final SimpleContainer frequencies = new SimpleContainer(ZoneType.MAX_SLOTS);

    /** How far from the track line (in blocks) a cart still counts as being on it. */
    private static final double RADIUS = 3.5;

    private int clearDelay = 1;
    private final int[] settings = new int[2];
    private boolean redstoneInput = false;
    private boolean redstoneOutput = true;

    @Nullable
    private BlockPos anchorA;
    @Nullable
    private BlockPos anchorB;
    private List<Vec3> path = List.of();
    private long pathBuilt = -100000L;

    // runtime state
    private boolean occupied = false;
    private long lastSeen = -100000L;
    private long enteredAt = 0L;
    private long arrivedAt = -1L;
    private double progress = 0;
    private final int[] received = new int[ZoneType.MAX_SLOTS];
    private final boolean[] out = new boolean[ZoneType.MAX_SLOTS];
    private final boolean[] sent = new boolean[ZoneType.MAX_SLOTS];
    private boolean prevIn = false;
    private boolean buttonPulse = false;
    private boolean manual = false;
    // station
    private boolean released = false;
    private boolean queued = false;
    // launch
    private int launchState = 0;
    private long launchStart = 0L;
    // brake / lift
    private boolean braking = false;
    private long lastHold = -100000L;
    private long lastOccupiedTick = -100000L;

    private final Link[] links = new Link[ZoneType.MAX_SLOTS];
    private boolean registered = false;
    private boolean loading = false;

    public ZoneBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.ZONE_BE.get(), pos, state);
        this.type = state.getBlock() instanceof ZoneBlock zb ? zb.type : ZoneType.STATION;
        for (int i = 0; i < 2; i++) {
            settings[i] = type.settings[i].def();
        }
        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            links[i] = new Link(i);
        }
        frequencies.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLinks();
                    registerLinks();
                }
            }
        });
    }

    public ZoneType zoneType() {
        return type;
    }

    public SimpleContainer getFrequencies() {
        return frequencies;
    }

    @Nullable
    public BlockPos getAnchorA() {
        return anchorA;
    }

    @Nullable
    public BlockPos getAnchorB() {
        return anchorB;
    }

    public int getClearDelay() {
        return clearDelay;
    }

    public int getSetting(int i) {
        return settings[i];
    }

    public boolean isRedstoneInput() {
        return redstoneInput;
    }

    public boolean isRedstoneOutput() {
        return redstoneOutput;
    }

    public boolean hasTrack() {
        return anchorA != null && anchorB != null;
    }

    @Nullable
    public static ZoneBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof ZoneBlockEntity z ? z : null;
    }

    public void applyConfig(int newClear, int s1, int s2, boolean redstone, boolean redstoneOut) {
        clearDelay = Math.max(0, Math.min(30, newClear));
        int[] in = {s1, s2};
        for (int i = 0; i < 2; i++) {
            ZoneType.Setting s = type.settings[i];
            settings[i] = Math.max(s.min(), Math.min(s.max(), in[i]));
        }
        redstoneInput = redstone;
        boolean outChanged = redstoneOutput != redstoneOut;
        redstoneOutput = redstoneOut;
        sync();
        if (outChanged && level != null && !level.isClientSide) {
            level.updateNeighborsAt(worldPosition, getBlockState().getBlock());
        }
    }

    @Override
    public int setTrack(BlockPos a, BlockPos b) {
        anchorA = a;
        anchorB = b;
        rebuildPath();
        sync();
        return path.size();
    }

    public void clearTrack() {
        anchorA = null;
        anchorB = null;
        path = List.of();
        sync();
    }

    private void sync() {
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    private void rebuildPath() {
        pathBuilt = level != null ? level.getGameTime() : 0L;
        path = (level != null && hasTrack()) ? AnchorTrack.sample(level, anchorA, anchorB) : List.of();
    }

    /** Empty-hand click: the block's own button. */
    public void button(Player player) {
        String key = "gui.coastercontrolpanel.zone." + type.key + ".button";
        switch (type) {
            case STATION, LAUNCH -> {
                buttonPulse = true;
                player.displayClientMessage(Component.translatable(key), true);
            }
            case BRAKE, LIFT -> {
                manual = !manual;
                player.displayClientMessage(Component.translatable(key, Component.translatable(
                        manual ? "message.coastercontrolpanel.on_word" : "message.coastercontrolpanel.off_word")), true);
            }
        }
    }

    /** Draws the track of the zone with particles: green at the start, flame at the end. */
    public void showArea() {
        if (!(level instanceof ServerLevel server) || path.isEmpty()) {
            return;
        }
        int step = Math.max(1, path.size() / 150);
        for (int i = 0; i < path.size(); i += step) {
            Vec3 p = path.get(i);
            server.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        Vec3 a = path.get(0);
        Vec3 b = path.get(path.size() - 1);
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, a.x, a.y + 0.5, a.z, 12, 0.3, 0.3, 0.3, 0);
        server.sendParticles(ParticleTypes.FLAME, b.x, b.y + 0.5, b.z, 12, 0.2, 0.3, 0.2, 0.01);
    }

    // ---------------------------------------------------------------- lifecycle and links

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLinks();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLinks();
    }

    @Override
    public void setRemoved() {
        unregisterLinks();
        super.setRemoved();
    }

    private void registerLinks() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        for (int i = 0; i < type.slots(); i++) {
            ItemStack stack = frequencies.getItem(i);
            links[i].alive = !stack.isEmpty();
            links[i].key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        }
        for (int i = 0; i < type.slots(); i++) {
            if (links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, links[i]);
            }
        }
        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            received[i] = 0;
        }
        for (int i = 0; i < type.slots(); i++) {
            if (links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, links[i]);
            }
        }
    }

    private void unregisterLinks() {
        if (!registered) {
            return;
        }
        registered = false;
        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            if (level != null && links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, links[i]);
            }
            links[i].alive = false;
            received[i] = 0;
        }
    }

    private void push(int slot) {
        if (level != null && !level.isClientSide && links[slot].alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, links[slot]);
        }
    }

    // ---------------------------------------------------------------- ticking and logic

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        long now = level.getGameTime();

        if (now % SCAN_EVERY == 0) {
            double found = -1;
            if (hasTrack()) {
                if (now - pathBuilt >= 100 || (path.isEmpty() && now - pathBuilt >= 20)) {
                    rebuildPath();
                }
                found = CartScanner.maxProgress(level, path, RADIUS);
            }
            if (found >= 0) {
                lastSeen = now;
                progress = found;
            }
            boolean should = now - lastSeen <= clearDelay * 20L;
            if (should != occupied) {
                occupied = should;
                arrivedAt = -1L;
                if (occupied) {
                    enteredAt = now;
                    released = false;
                    queued = false;
                } else {
                    progress = 0;
                }
                BlockState state = getBlockState();
                if (state.hasProperty(ZoneBlock.OCCUPIED)) {
                    level.setBlock(worldPosition, state.setValue(ZoneBlock.OCCUPIED, occupied), 3);
                }
            }
        }

        boolean in = received[0] > 0 || (redstoneInput && level.hasNeighborSignal(worldPosition));
        boolean edge = in && !prevIn;
        prevIn = in;
        boolean pulse = edge || buttonPulse;
        buttonPulse = false;
        if (occupied) {
            lastOccupiedTick = now;
        }

        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            out[i] = false;
        }
        int s1 = settings[0];
        int s2 = settings[1];
        switch (type) {
            case STATION -> {
                if (!occupied) {
                    released = false;
                    queued = false;
                } else {
                    // The stay timer starts once the train has reached the end half of the stretch.
                    if (arrivedAt < 0 && progress >= 0.5) {
                        arrivedAt = now;
                    }
                    boolean dwellDone = arrivedAt >= 0 && now - arrivedAt >= s1 * 20L;
                    if (pulse) {
                        queued = true;
                    }
                    if (!released && dwellDone && (queued || s2 == 1)) {
                        released = true;
                    }
                }
                out[1] = occupied && !released;
                out[2] = occupied;
            }
            case LAUNCH -> {
                if (launchState == 0 && pulse && occupied && progress <= 0.5) {
                    launchState = 1;
                    launchStart = now;
                }
                if (launchState == 1) {
                    if (!occupied) {
                        launchState = 0;
                    } else if (now - launchStart >= s1 * 20L) {
                        launchState = 2;
                        launchStart = now;
                    }
                }
                if (launchState == 2 && now - launchStart >= s2 * 20L) {
                    launchState = 0;
                }
                out[1] = launchState == 1;
                out[2] = launchState == 2;
                out[3] = occupied;
            }
            case BRAKE -> {
                boolean hold = in || manual;
                if (hold) {
                    braking = true;
                    lastHold = now;
                } else if (braking && now - lastHold >= s1 * 20L) {
                    braking = false;
                }
                out[1] = braking && (s2 == 0 || (occupied && progress >= 0.5));
                out[2] = occupied;
            }
            case LIFT -> {
                boolean running = occupied || now - lastOccupiedTick <= s1 * 20L;
                boolean enabled = s2 == 0 || in;
                out[1] = (running && enabled) || manual;
                out[2] = occupied;
            }
        }
        ambientSound(now);
        for (int i = 0; i < type.slots(); i++) {
            if (!type.isInput[i] && out[i] != sent[i]) {
                sent[i] = out[i];
                push(i);
            }
        }
    }

    private boolean brakeWas = false;

    /** Chain clank while a lift runs, a hiss when brakes close, a low hum in the station while a train waits. */
    private void ambientSound(long now) {
        if (level == null) {
            return;
        }
        net.minecraft.sounds.SoundSource src = net.minecraft.sounds.SoundSource.BLOCKS;
        switch (type) {
            case LIFT -> {
                if (out[1] && occupied && now % 40 == 0) {
                    level.playSound(null, worldPosition, CoasterControlPanel.RIDE_CHAIN.get(), src, 1.2F, 1.0F);
                }
            }
            case BRAKE -> {
                if (braking && !brakeWas) {
                    level.playSound(null, worldPosition, CoasterControlPanel.RIDE_BRAKE.get(), src, 1.2F, 1.0F);
                }
                brakeWas = braking;
            }
            case STATION -> {
                if (occupied && now % 60 == 0) {
                    level.playSound(null, worldPosition, CoasterControlPanel.RIDE_HUM.get(), src, 0.5F, 1.0F);
                }
            }
            default -> {
            }
        }
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(ZoneType.MAX_SLOTS, ItemStack.EMPTY);
        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Clear", clearDelay);
        tag.putInt("S1", settings[0]);
        tag.putInt("S2", settings[1]);
        tag.putBoolean("Rs", redstoneInput);
        tag.putBoolean("RsOut", redstoneOutput);
        if (anchorA != null) {
            tag.putLong("AnchorA", anchorA.asLong());
        }
        if (anchorB != null) {
            tag.putLong("AnchorB", anchorB.asLong());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(ZoneType.MAX_SLOTS, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < ZoneType.MAX_SLOTS; i++) {
            frequencies.setItem(i, list.get(i));
        }
        if (tag.contains("S1")) {
            clearDelay = tag.getInt("Clear");
            settings[0] = tag.getInt("S1");
            settings[1] = tag.getInt("S2");
            redstoneInput = tag.getBoolean("Rs");
            redstoneOutput = !tag.contains("RsOut") || tag.getBoolean("RsOut");
        }
        anchorA = tag.contains("AnchorA") ? BlockPos.of(tag.getLong("AnchorA")) : null;
        anchorB = tag.contains("AnchorB") ? BlockPos.of(tag.getLong("AnchorB")) : null;
        pathBuilt = -100000L;
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- Redstone Link endpoints

    private class Link implements IRedstoneLinkable {
        private final int slot;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int slot) {
            this.slot = slot;
        }

        private boolean listening() {
            return slot < type.slots() && type.isInput[slot];
        }

        @Override
        public int getTransmittedStrength() {
            return !listening() && out[slot] ? 15 : 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            if (listening()) {
                received[slot] = power;
            }
        }

        @Override
        public boolean isListening() {
            return listening();
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
