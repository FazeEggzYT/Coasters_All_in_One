package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client only: opens the Seat Timer screen for the seat at this position. */
public final class SeatTimerClient {
    private SeatTimerClient() {
    }

    public static void open(BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getBlockEntity(pos) instanceof SeatTimerAccess seat) {
            mc.setScreen(new SeatTimerScreen(pos, seat.seatTimerOpenDelay(), seat.seatTimerCloseDelay()));
        }
    }
}
