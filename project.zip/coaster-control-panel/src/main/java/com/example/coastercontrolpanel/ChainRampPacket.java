package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the turn-on and turn-off times chosen in the Chain Timer screen. */
public record ChainRampPacket(BlockPos pos, float up, float down) implements CustomPacketPayload {
    public static final Type<ChainRampPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "chain_ramp"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ChainRampPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.up);
                buf.writeFloat(p.down);
            },
            buf -> new ChainRampPacket(buf.readBlockPos(), buf.readFloat(), buf.readFloat()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ChainRampPacket packet, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(packet.pos.getX() + 0.5, packet.pos.getY() + 0.5, packet.pos.getZ() + 0.5) > 2304.0) {
            return;
        }
        if (!player.getMainHandItem().is(CoasterControlPanel.CHAIN_TIMER_ITEM.get())
                && !player.getOffhandItem().is(CoasterControlPanel.CHAIN_TIMER_ITEM.get())) {
            return;
        }
        BlockEntity be = player.level().getBlockEntity(packet.pos);
        if (be instanceof DriveTyre.Holder h) {
            h.ccp$setRamp(packet.up, packet.down);
            h.ccp$sync();
        }
    }
}
