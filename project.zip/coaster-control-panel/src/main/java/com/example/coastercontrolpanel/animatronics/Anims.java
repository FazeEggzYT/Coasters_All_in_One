package com.example.coastercontrolpanel.animatronics;

import static com.example.coastercontrolpanel.animatronics.Pose.*;

import java.util.LinkedHashMap;
import java.util.Map;

/** The animation library. Each animation turns a time in ticks into a pose; every one repeats seamlessly. */
public final class Anims {
    public interface Anim {
        float[] at(float t);
    }

    public static final Map<String, Anim> ALL = new LinkedHashMap<>();

    private static java.util.List<String> ids;

    /** All animation ids in a fixed order; the timeline stores an animation as its index in this list. */
    public static synchronized java.util.List<String> ids() {
        if (ids == null) {
            ids = java.util.List.copyOf(ALL.keySet());
        }
        return ids;
    }

    private Anims() {
    }

    /** Sine with a period in ticks. */
    private static float s(float t, float period) {
        return (float) Math.sin(t * 2.0 * Math.PI / period);
    }

    private static float c(float t, float period) {
        return (float) Math.cos(t * 2.0 * Math.PI / period);
    }

    /** 0..1..0 bounce. */
    private static float hop(float t, float period) {
        return Math.abs(s(t, period * 2.0f));
    }

    private static void add(String id, Anim a) {
        ALL.put(id, a);
    }

    static {
        add("wave", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 20;
            p[AR_ROLL] = 130;
            p[AR_ELBOW] = 30 + 28 * s(t, 16);
            p[HEAD_ROLL] = 4 * s(t, 32);
            p[HEAD_YAW] = -8;
            return p;
        });
        add("welcome", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 60);
            p[AL_ROLL] = 25 + 30 * k;
            p[AR_ROLL] = 25 + 30 * k;
            p[AL_PITCH] = 30;
            p[AR_PITCH] = 30;
            p[AL_ELBOW] = 40 - 20 * k;
            p[AR_ELBOW] = 40 - 20 * k;
            p[HEAD_PITCH] = 6 * s(t, 60);
            return p;
        });
        add("nod", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 14 * Math.max(0, s(t, 30)) - 3;
            p[TORSO_PITCH] = 3 * Math.max(0, s(t, 30));
            p[AL_ROLL] = 6;
            p[AR_ROLL] = 6;
            return p;
        });
        add("dance", t -> {
            float[] p = Pose.rest();
            float h = hop(t, 10);
            p[ROOT_Y] = 1.6f * h;
            p[TORSO_ROLL] = 9 * s(t, 20);
            p[TORSO_YAW] = 12 * s(t, 20);
            p[HEAD_ROLL] = -8 * s(t, 20);
            p[AL_PITCH] = 100 * Math.max(0, s(t, 20)) + 10;
            p[AR_PITCH] = 100 * Math.max(0, -s(t, 20)) + 10;
            p[AL_ROLL] = 25;
            p[AR_ROLL] = 25;
            p[AL_ELBOW] = 30;
            p[AR_ELBOW] = 30;
            p[LL_HIP] = 25 * Math.max(0, s(t, 20));
            p[LL_KNEE] = 30 * Math.max(0, s(t, 20));
            p[LR_HIP] = 25 * Math.max(0, -s(t, 20));
            p[LR_KNEE] = 30 * Math.max(0, -s(t, 20));
            return p;
        });
        add("spin", t -> {
            float[] p = Pose.rest();
            p[ROOT_YAW] = (t * 9.0f) % 360.0f;
            p[AL_ROLL] = 80;
            p[AR_ROLL] = 80;
            p[ROOT_Y] = 0.6f + 0.6f * s(t, 40);
            p[HEAD_PITCH] = -6;
            return p;
        });
        add("disco", t -> {
            float[] p = Pose.rest();
            float on = Math.max(0.0f, Math.min(1.0f, 0.5f + 0.8f * s(t, 24)));
            on = on * on * (3.0f - 2.0f * on); // smooth swap between the two poses
            float off = 1.0f - on;
            p[AR_PITCH] = 150 * on;
            p[AR_ROLL] = 10 + 10 * on;
            p[AL_PITCH] = 150 * off;
            p[AL_ROLL] = 10 + 10 * off;
            p[TORSO_ROLL] = -8 * (on - off);
            p[HEAD_ROLL] = 6 * (on - off);
            p[ROOT_Y] = 0.8f * hop(t, 12);
            p[LL_HIP] = 20 * off;
            p[LR_HIP] = 20 * on;
            return p;
        });
        add("point", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 88;
            p[AR_ELBOW] = 4;
            p[HEAD_YAW] = 28 * s(t, 90);
            p[TORSO_YAW] = 10 * s(t, 90);
            p[AR_ROLL] = 10 + 6 * s(t, 90);
            return p;
        });
        add("swordfight", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 70 + 40 * s(t, 18);
            p[AR_ROLL] = 20 + 20 * c(t, 18);
            p[AR_ELBOW] = 30 + 25 * c(t, 18);
            p[TORSO_YAW] = 18 * s(t, 18);
            p[TORSO_PITCH] = 8;
            p[AL_PITCH] = 20;
            p[AL_ROLL] = 30;
            p[LL_HIP] = 20;
            p[LR_HIP] = -15;
            p[LR_KNEE] = 15;
            return p;
        });
        add("laugh", t -> {
            float[] p = Pose.rest();
            float k = Math.abs(s(t, 14));
            p[HEAD_PITCH] = -22 + 6 * k;
            p[TORSO_PITCH] = -8 + 4 * k;
            p[ROOT_Y] = 0.5f * k;
            p[AL_PITCH] = 20;
            p[AR_PITCH] = 20;
            p[AL_ELBOW] = 70;
            p[AR_ELBOW] = 70;
            p[AL_ROLL] = 12;
            p[AR_ROLL] = 12;
            return p;
        });
        add("drum", t -> {
            float[] p = Pose.rest();
            float a = s(t, 8);
            float b = s(t + 4, 8);
            p[AL_PITCH] = 55 + 22 * a;
            p[AR_PITCH] = 55 + 22 * b;
            p[AL_ELBOW] = 55 + 25 * a;
            p[AR_ELBOW] = 55 + 25 * b;
            p[AL_ROLL] = 8;
            p[AR_ROLL] = 8;
            p[HEAD_PITCH] = 8 * Math.abs(s(t, 8));
            p[LR_HIP] = 18 * Math.max(0, s(t, 16));
            p[TORSO_PITCH] = 6;
            return p;
        });
        add("groove", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 12 * s(t, 20);
            p[TORSO_ROLL] = 5 * s(t, 40);
            p[ROOT_Y] = 0.6f * hop(t, 10);
            p[LL_HIP] = 12 * Math.max(0, s(t, 20));
            p[LR_HIP] = 12 * Math.max(0, -s(t, 20));
            p[AL_PITCH] = 20;
            p[AR_PITCH] = 20;
            p[AL_ELBOW] = 50;
            p[AR_ELBOW] = 50;
            return p;
        });
        add("strum", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 45 + 10 * s(t, 6);
            p[AR_ELBOW] = 75 + 20 * s(t, 6);
            p[AR_ROLL] = 6;
            p[AL_PITCH] = 70;
            p[AL_ELBOW] = 30;
            p[AL_ROLL] = 14;
            p[HEAD_PITCH] = 10 + 6 * s(t, 24);
            p[TORSO_YAW] = -8;
            p[LL_HIP] = 10 * Math.max(0, s(t, 12));
            return p;
        });
        add("rock", t -> {
            float[] p = Pose.rest();
            float k = s(t, 14);
            p[HEAD_PITCH] = 28 * k;
            p[TORSO_PITCH] = 10 + 8 * k;
            p[AR_PITCH] = 45 + 40 * s(t, 7);
            p[AR_ELBOW] = 70;
            p[AL_PITCH] = 70;
            p[AL_ELBOW] = 30;
            p[AL_ROLL] = 14;
            p[LL_HIP] = 18;
            p[LR_HIP] = 18;
            p[LL_KNEE] = 24;
            p[LR_KNEE] = 24;
            p[LL_HIP + 0] = 18 + 4 * k;
            p[ROOT_Y] = -0.8f + 0.8f * Math.abs(k);
            return p;
        });
        add("creep", t -> {
            float[] p = Pose.rest();
            p[TORSO_PITCH] = 26;
            p[HEAD_PITCH] = -10 + 6 * s(t, 50);
            p[HEAD_ROLL] = 10 * s(t, 70);
            p[AL_PITCH] = 50 + 10 * s(t, 40);
            p[AR_PITCH] = 55 + 10 * c(t, 40);
            p[AL_ELBOW] = 20;
            p[AR_ELBOW] = 20;
            p[LL_HIP] = 18 * s(t, 40);
            p[LR_HIP] = -18 * s(t, 40);
            p[LL_KNEE] = 14 * Math.max(0, -s(t, 40));
            p[LR_KNEE] = 14 * Math.max(0, s(t, 40));
            p[ROOT_Y] = 0.5f * hop(t, 20);
            return p;
        });
        add("reach", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 50);
            p[AL_PITCH] = 70 + 25 * k;
            p[AR_PITCH] = 70 + 25 * k;
            p[AL_ELBOW] = 10;
            p[AR_ELBOW] = 10;
            p[AL_ROLL] = 6;
            p[AR_ROLL] = 6;
            p[TORSO_PITCH] = 12 * k;
            p[HEAD_PITCH] = -12;
            p[LL_HIP] = 10 * k;
            return p;
        });
        add("lunge", t -> {
            float[] p = Pose.rest();
            float ph = (t % 60.0f + 60.0f) % 60.0f / 60.0f;
            float k = ph < 0.7f ? ph / 0.7f * 0.25f : (ph < 0.8f ? 0.25f + (ph - 0.7f) / 0.1f * 0.75f : 1.0f - (ph - 0.8f) / 0.2f);
            p[TORSO_PITCH] = -10 * (1 - k) + 40 * k;
            p[HEAD_PITCH] = -20 * (1 - k) + 25 * k;
            p[AL_PITCH] = 20 + 90 * k;
            p[AR_PITCH] = 20 + 90 * k;
            p[AL_ROLL] = 20 + 20 * (1 - k);
            p[AR_ROLL] = 20 + 20 * (1 - k);
            p[ROOT_Y] = 1.2f * k;
            p[LL_HIP] = 25 * k;
            p[LR_HIP] = -10 * k;
            return p;
        });
        add("cast", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 100 + 12 * s(t, 12);
            p[AR_ELBOW] = 20;
            p[AR_ROLL] = 15;
            p[AL_PITCH] = 35;
            p[AL_ROLL] = 40;
            p[AL_ELBOW] = 50;
            p[HEAD_PITCH] = -12;
            p[TORSO_PITCH] = -4;
            p[ROOT_Y] = 0.4f * hop(t, 24);
            return p;
        });
        add("conjure", t -> {
            float[] p = Pose.rest();
            p[AL_PITCH] = 110 + 40 * s(t, 40);
            p[AR_PITCH] = 110 + 40 * c(t, 40);
            p[AL_ROLL] = 30;
            p[AR_ROLL] = 30;
            p[AL_ELBOW] = 20;
            p[AR_ELBOW] = 20;
            p[HEAD_PITCH] = -18;
            p[TORSO_YAW] = 14 * s(t, 80);
            p[ROOT_Y] = 0.9f + 0.9f * s(t, 60);
            return p;
        });
        add("salute", t -> {
            float[] p = Pose.rest();
            float k = Math.min(1.0f, 0.5f + 0.5f * s(t, 80) * 3.0f);
            k = Math.max(0.0f, k);
            p[AR_PITCH] = 90 + 40 * k;
            p[AR_ROLL] = 40 * k;
            p[AR_ELBOW] = 120 * k;
            p[HEAD_PITCH] = -6 * k;
            p[AL_ROLL] = 6;
            return p;
        });
        add("guard", t -> {
            float[] p = Pose.rest();
            p[AL_PITCH] = 55;
            p[AL_ELBOW] = 85;
            p[AL_ROLL] = 6;
            p[AR_PITCH] = 25 + 40 * Math.max(0, s(t, 50)) * Math.max(0, s(t, 50));
            p[AR_ELBOW] = 50;
            p[AR_ROLL] = 18;
            p[TORSO_YAW] = -10;
            p[ROOT_Y] = 0.4f * s(t, 40);
            p[LL_HIP] = 16;
            p[LR_HIP] = -12;
            p[LR_KNEE] = 12;
            return p;
        });
    }
}
