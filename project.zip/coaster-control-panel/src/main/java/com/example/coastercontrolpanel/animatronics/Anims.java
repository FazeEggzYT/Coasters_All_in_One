package com.example.coastercontrolpanel.animatronics;

import static com.example.coastercontrolpanel.animatronics.Pose.*;

import java.util.LinkedHashMap;
import java.util.Map;

/** The animation library. Each animation turns a time in ticks into a pose; every one repeats seamlessly. */
public final class Anims {
    public interface Anim {
        float[] at(float t);
    }

    public static final Map<String, Anim> ALL = new LinkedHashMap<>();

    private static java.util.List<String> ids;

    /** All animation ids in a fixed order; the timeline stores an animation as its index in this list. */
    public static synchronized java.util.List<String> ids() {
        if (ids == null) {
            ids = java.util.List.copyOf(ALL.keySet());
        }
        return ids;
    }

    private Anims() {
    }

    /** Sine with a period in ticks. */
    private static float s(float t, float period) {
        return (float) Math.sin(t * 2.0 * Math.PI / period);
    }

    private static float c(float t, float period) {
        return (float) Math.cos(t * 2.0 * Math.PI / period);
    }

    /** 0..1..0 bounce. */
    private static float hop(float t, float period) {
        return Math.abs(s(t, period * 2.0f));
    }

    private static void add(String id, Anim a) {
        ALL.put(id, a);
    }

    static {
        add("wave", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 20;
            p[AR_ROLL] = 130;
            p[AR_ELBOW] = 30 + 28 * s(t, 16);
            p[HEAD_ROLL] = 4 * s(t, 32);
            p[HEAD_YAW] = -8;
            return p;
        });
        add("welcome", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 60);
            p[AL_ROLL] = 25 + 30 * k;
            p[AR_ROLL] = 25 + 30 * k;
            p[AL_PITCH] = 30;
            p[AR_PITCH] = 30;
            p[AL_ELBOW] = 40 - 20 * k;
            p[AR_ELBOW] = 40 - 20 * k;
            p[HEAD_PITCH] = 6 * s(t, 60);
            return p;
        });
        add("nod", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 14 * Math.max(0, s(t, 30)) - 3;
            p[TORSO_PITCH] = 3 * Math.max(0, s(t, 30));
            p[AL_ROLL] = 6;
            p[AR_ROLL] = 6;
            return p;
        });
        add("dance", t -> {
            float[] p = Pose.rest();
            float h = hop(t, 10);
            p[ROOT_Y] = 1.6f * h;
            p[TORSO_ROLL] = 9 * s(t, 20);
            p[TORSO_YAW] = 12 * s(t, 20);
            p[HEAD_ROLL] = -8 * s(t, 20);
            p[AL_PITCH] = 100 * Math.max(0, s(t, 20)) + 10;
            p[AR_PITCH] = 100 * Math.max(0, -s(t, 20)) + 10;
            p[AL_ROLL] = 25;
            p[AR_ROLL] = 25;
            p[AL_ELBOW] = 30;
            p[AR_ELBOW] = 30;
            p[LL_HIP] = 25 * Math.max(0, s(t, 20));
            p[LL_KNEE] = 30 * Math.max(0, s(t, 20));
            p[LR_HIP] = 25 * Math.max(0, -s(t, 20));
            p[LR_KNEE] = 30 * Math.max(0, -s(t, 20));
            return p;
        });
        add("spin", t -> {
            float[] p = Pose.rest();
            p[ROOT_YAW] = (t * 9.0f) % 360.0f;
            p[AL_ROLL] = 80;
            p[AR_ROLL] = 80;
            p[ROOT_Y] = 0.6f + 0.6f * s(t, 40);
            p[HEAD_PITCH] = -6;
            return p;
        });
        add("disco", t -> {
            float[] p = Pose.rest();
            float on = Math.max(0.0f, Math.min(1.0f, 0.5f + 0.8f * s(t, 24)));
            on = on * on * (3.0f - 2.0f * on); // smooth swap between the two poses
            float off = 1.0f - on;
            p[AR_PITCH] = 150 * on;
            p[AR_ROLL] = 10 + 10 * on;
            p[AL_PITCH] = 150 * off;
            p[AL_ROLL] = 10 + 10 * off;
            p[TORSO_ROLL] = -8 * (on - off);
            p[HEAD_ROLL] = 6 * (on - off);
            p[ROOT_Y] = 0.8f * hop(t, 12);
            p[LL_HIP] = 20 * off;
            p[LR_HIP] = 20 * on;
            return p;
        });
        add("point", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 88;
            p[AR_ELBOW] = 4;
            p[HEAD_YAW] = 28 * s(t, 90);
            p[TORSO_YAW] = 10 * s(t, 90);
            p[AR_ROLL] = 10 + 6 * s(t, 90);
            return p;
        });
        add("swordfight", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 70 + 40 * s(t, 18);
            p[AR_ROLL] = 20 + 20 * c(t, 18);
            p[AR_ELBOW] = 30 + 25 * c(t, 18);
            p[TORSO_YAW] = 18 * s(t, 18);
            p[TORSO_PITCH] = 8;
            p[AL_PITCH] = 20;
            p[AL_ROLL] = 30;
            p[LL_HIP] = 20;
            p[LR_HIP] = -15;
            p[LR_KNEE] = 15;
            return p;
        });
        add("laugh", t -> {
            float[] p = Pose.rest();
            float k = Math.abs(s(t, 14));
            p[HEAD_PITCH] = -22 + 6 * k;
            p[TORSO_PITCH] = -8 + 4 * k;
            p[ROOT_Y] = 0.5f * k;
            p[AL_PITCH] = 20;
            p[AR_PITCH] = 20;
            p[AL_ELBOW] = 70;
            p[AR_ELBOW] = 70;
            p[AL_ROLL] = 12;
            p[AR_ROLL] = 12;
            return p;
        });
        add("drum", t -> {
            float[] p = Pose.rest();
            float a = s(t, 8);
            float b = s(t + 4, 8);
            p[AL_PITCH] = 55 + 22 * a;
            p[AR_PITCH] = 55 + 22 * b;
            p[AL_ELBOW] = 55 + 25 * a;
            p[AR_ELBOW] = 55 + 25 * b;
            p[AL_ROLL] = 8;
            p[AR_ROLL] = 8;
            p[HEAD_PITCH] = 8 * Math.abs(s(t, 8));
            p[LR_HIP] = 18 * Math.max(0, s(t, 16));
            p[TORSO_PITCH] = 6;
            return p;
        });
        add("groove", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 12 * s(t, 20);
            p[TORSO_ROLL] = 5 * s(t, 40);
            p[ROOT_Y] = 0.6f * hop(t, 10);
            p[LL_HIP] = 12 * Math.max(0, s(t, 20));
            p[LR_HIP] = 12 * Math.max(0, -s(t, 20));
            p[AL_PITCH] = 20;
            p[AR_PITCH] = 20;
            p[AL_ELBOW] = 50;
            p[AR_ELBOW] = 50;
            return p;
        });
        add("strum", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 45 + 10 * s(t, 6);
            p[AR_ELBOW] = 75 + 20 * s(t, 6);
            p[AR_ROLL] = 6;
            p[AL_PITCH] = 70;
            p[AL_ELBOW] = 30;
            p[AL_ROLL] = 14;
            p[HEAD_PITCH] = 10 + 6 * s(t, 24);
            p[TORSO_YAW] = -8;
            p[LL_HIP] = 10 * Math.max(0, s(t, 12));
            return p;
        });
        add("rock", t -> {
            float[] p = Pose.rest();
            float k = s(t, 14);
            p[HEAD_PITCH] = 28 * k;
            p[TORSO_PITCH] = 10 + 8 * k;
            p[AR_PITCH] = 45 + 40 * s(t, 7);
            p[AR_ELBOW] = 70;
            p[AL_PITCH] = 70;
            p[AL_ELBOW] = 30;
            p[AL_ROLL] = 14;
            p[LL_HIP] = 18;
            p[LR_HIP] = 18;
            p[LL_KNEE] = 24;
            p[LR_KNEE] = 24;
            p[LL_HIP + 0] = 18 + 4 * k;
            p[ROOT_Y] = -0.8f + 0.8f * Math.abs(k);
            return p;
        });
        add("creep", t -> {
            float[] p = Pose.rest();
            p[TORSO_PITCH] = 26;
            p[HEAD_PITCH] = -10 + 6 * s(t, 50);
            p[HEAD_ROLL] = 10 * s(t, 70);
            p[AL_PITCH] = 50 + 10 * s(t, 40);
            p[AR_PITCH] = 55 + 10 * c(t, 40);
            p[AL_ELBOW] = 20;
            p[AR_ELBOW] = 20;
            p[LL_HIP] = 18 * s(t, 40);
            p[LR_HIP] = -18 * s(t, 40);
            p[LL_KNEE] = 14 * Math.max(0, -s(t, 40));
            p[LR_KNEE] = 14 * Math.max(0, s(t, 40));
            p[ROOT_Y] = 0.5f * hop(t, 20);
            return p;
        });
        add("reach", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 50);
            p[AL_PITCH] = 70 + 25 * k;
            p[AR_PITCH] = 70 + 25 * k;
            p[AL_ELBOW] = 10;
            p[AR_ELBOW] = 10;
            p[AL_ROLL] = 6;
            p[AR_ROLL] = 6;
            p[TORSO_PITCH] = 12 * k;
            p[HEAD_PITCH] = -12;
            p[LL_HIP] = 10 * k;
            return p;
        });
        add("lunge", t -> {
            float[] p = Pose.rest();
            float ph = (t % 60.0f + 60.0f) % 60.0f / 60.0f;
            float k = ph < 0.7f ? ph / 0.7f * 0.25f : (ph < 0.8f ? 0.25f + (ph - 0.7f) / 0.1f * 0.75f : 1.0f - (ph - 0.8f) / 0.2f);
            p[TORSO_PITCH] = -10 * (1 - k) + 40 * k;
            p[HEAD_PITCH] = -20 * (1 - k) + 25 * k;
            p[AL_PITCH] = 20 + 90 * k;
            p[AR_PITCH] = 20 + 90 * k;
            p[AL_ROLL] = 20 + 20 * (1 - k);
            p[AR_ROLL] = 20 + 20 * (1 - k);
            p[ROOT_Y] = 1.2f * k;
            p[LL_HIP] = 25 * k;
            p[LR_HIP] = -10 * k;
            return p;
        });
        add("cast", t -> {
            float[] p = Pose.rest();
            p[AR_PITCH] = 100 + 12 * s(t, 12);
            p[AR_ELBOW] = 20;
            p[AR_ROLL] = 15;
            p[AL_PITCH] = 35;
            p[AL_ROLL] = 40;
            p[AL_ELBOW] = 50;
            p[HEAD_PITCH] = -12;
            p[TORSO_PITCH] = -4;
            p[ROOT_Y] = 0.4f * hop(t, 24);
            return p;
        });
        add("conjure", t -> {
            float[] p = Pose.rest();
            p[AL_PITCH] = 110 + 40 * s(t, 40);
            p[AR_PITCH] = 110 + 40 * c(t, 40);
            p[AL_ROLL] = 30;
            p[AR_ROLL] = 30;
            p[AL_ELBOW] = 20;
            p[AR_ELBOW] = 20;
            p[HEAD_PITCH] = -18;
            p[TORSO_YAW] = 14 * s(t, 80);
            p[ROOT_Y] = 0.9f + 0.9f * s(t, 60);
            return p;
        });
        add("salute", t -> {
            float[] p = Pose.rest();
            float k = Math.min(1.0f, 0.5f + 0.5f * s(t, 80) * 3.0f);
            k = Math.max(0.0f, k);
            p[AR_PITCH] = 90 + 40 * k;
            p[AR_ROLL] = 40 * k;
            p[AR_ELBOW] = 120 * k;
            p[HEAD_PITCH] = -6 * k;
            p[AL_ROLL] = 6;
            return p;
        });
        add("guard", t -> {
            float[] p = Pose.rest();
            p[AL_PITCH] = 55;
            p[AL_ELBOW] = 85;
            p[AL_ROLL] = 6;
            p[AR_PITCH] = 25 + 40 * Math.max(0, s(t, 50)) * Math.max(0, s(t, 50));
            p[AR_ELBOW] = 50;
            p[AR_ROLL] = 18;
            p[TORSO_YAW] = -10;
            p[ROOT_Y] = 0.4f * s(t, 40);
            p[LL_HIP] = 16;
            p[LR_HIP] = -12;
            p[LR_KNEE] = 12;
            return p;
        });
    }

    /** Both arms in one call: left pitch/roll/elbow, right pitch/roll/elbow. */
    private static void arms(float[] p, float lp, float lr, float le, float rp, float rr, float re) {
        p[AL_PITCH] = lp;
        p[AL_ROLL] = lr;
        p[AL_ELBOW] = le;
        p[AR_PITCH] = rp;
        p[AR_ROLL] = rr;
        p[AR_ELBOW] = re;
    }

    private static void legs(float[] p, float lh, float lk, float rh, float rk) {
        p[LL_HIP] = lh;
        p[LL_KNEE] = lk;
        p[LR_HIP] = rh;
        p[LR_KNEE] = rk;
    }

    /** Smooth 0..1..0 pulse over the period. */
    private static float pulse(float t, float period) {
        return 0.5f - 0.5f * c(t, period);
    }

    static {
        add("bow", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 80);
            p[TORSO_PITCH] = 55 * k;
            p[HEAD_PITCH] = 15 * k;
            arms(p, 10, 8, 10, 10, 8, 10);
            return p;
        });
        add("curtsy", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 80);
            p[ROOT_Y] = -2.5f * k;
            p[TORSO_PITCH] = 14 * k;
            p[HEAD_PITCH] = 10 * k;
            legs(p, 30 * k, 55 * k, -10 * k, 20 * k);
            arms(p, 20, 25 + 15 * k, 10, 20, 25 + 15 * k, 10);
            return p;
        });
        add("clap", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 8);
            arms(p, 75, 4 + 24 * k, 70, 75, 4 + 24 * k, 70);
            p[HEAD_PITCH] = 4 * k;
            return p;
        });
        add("clap_overhead", t -> {
            float[] p = Pose.rest();
            float k = 0.5f + 0.5f * s(t, 10);
            arms(p, 165, 4 + 20 * k, 10, 165, 4 + 20 * k, 10);
            p[HEAD_PITCH] = -12;
            p[ROOT_Y] = 0.6f * hop(t, 10);
            return p;
        });
        add("cheer", t -> {
            float[] p = Pose.rest();
            float h = hop(t, 14);
            p[ROOT_Y] = 2.2f * h;
            arms(p, 165 + 10 * s(t, 14), 18, 10, 165 - 10 * s(t, 14), 18, 10);
            p[HEAD_PITCH] = -16;
            legs(p, 14 * (1 - h), 24 * (1 - h), 14 * (1 - h), 24 * (1 - h));
            return p;
        });
        add("wave_both", t -> {
            float[] p = Pose.rest();
            arms(p, 20, 130, 30 + 28 * s(t, 16), 20, 130, 30 - 28 * s(t, 16));
            p[HEAD_ROLL] = 5 * s(t, 32);
            return p;
        });
        add("beckon", t -> {
            float[] p = Pose.rest();
            arms(p, 10, 8, 10, 70, 12, 20 + 70 * pulse(t, 24));
            p[HEAD_PITCH] = 6;
            p[TORSO_PITCH] = 4;
            return p;
        });
        add("shrug", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 60);
            arms(p, 20, 40 * k + 10, 80 * k, 20, 40 * k + 10, 80 * k);
            p[HEAD_ROLL] = 10 * k;
            p[ROOT_Y] = 0.7f * k;
            return p;
        });
        add("think", t -> {
            float[] p = Pose.rest();
            arms(p, 10, 8, 10, 100, 6, 125);
            p[HEAD_PITCH] = 10 + 4 * s(t, 70);
            p[HEAD_ROLL] = -8;
            p[HEAD_YAW] = 14 * s(t, 140);
            return p;
        });
        add("look_around", t -> {
            float[] p = Pose.rest();
            p[HEAD_YAW] = 55 * s(t, 90);
            p[HEAD_PITCH] = 6 * s(t, 45);
            p[TORSO_YAW] = 14 * s(t, 90);
            return p;
        });
        add("shake_head", t -> {
            float[] p = Pose.rest();
            p[HEAD_YAW] = 28 * s(t, 14) * Math.max(0, s(t, 60) + 0.4f);
            arms(p, 10, 10, 60, 10, 10, 60);
            return p;
        });
        add("yes", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 16 * Math.max(0, s(t, 12));
            p[TORSO_PITCH] = 3 * Math.max(0, s(t, 12));
            return p;
        });
        add("breathe", t -> {
            float[] p = Pose.rest();
            p[TORSO_PITCH] = 1.5f * s(t, 80);
            p[HEAD_PITCH] = -1.5f * s(t, 80);
            p[ROOT_Y] = 0.15f * s(t, 80);
            arms(p, 0, 6 + 2 * s(t, 80), 6, 0, 6 + 2 * s(t, 80), 6);
            return p;
        });
        add("sleep", t -> {
            float[] p = Pose.rest();
            p[HEAD_PITCH] = 32 + 3 * s(t, 90);
            p[HEAD_ROLL] = 8;
            p[TORSO_PITCH] = 12 + 2 * s(t, 90);
            arms(p, 10, 8, 20, 10, 8, 20);
            return p;
        });
        add("yawn", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 120);
            p[HEAD_PITCH] = -28 * k;
            p[TORSO_PITCH] = -6 * k;
            arms(p, 10, 8, 10, 100 * k, 8, 130 * k);
            return p;
        });
        add("stretch", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 100);
            arms(p, 175 * k, 20, 5, 175 * k, 20, 5);
            p[TORSO_PITCH] = -12 * k;
            p[HEAD_PITCH] = -14 * k;
            p[ROOT_Y] = 0.8f * k;
            return p;
        });
        add("march", t -> {
            float[] p = Pose.rest();
            float k = s(t, 20);
            legs(p, 45 * Math.max(0, k), 20 * Math.max(0, k), 45 * Math.max(0, -k), 20 * Math.max(0, -k));
            arms(p, -35 * k, 8, 30, 35 * k, 8, 30);
            p[ROOT_Y] = 0.5f * Math.abs(k);
            return p;
        });
        add("walk", t -> {
            float[] p = Pose.rest();
            float k = s(t, 24);
            legs(p, 28 * k, 20 * Math.max(0, -k), -28 * k, 20 * Math.max(0, k));
            arms(p, -26 * k, 6, 12, 26 * k, 6, 12);
            p[ROOT_Y] = 0.35f * Math.abs(k);
            return p;
        });
        add("sway", t -> {
            float[] p = Pose.rest();
            p[TORSO_ROLL] = 9 * s(t, 60);
            p[HEAD_ROLL] = -6 * s(t, 60);
            p[ROOT_Y] = 0.3f * Math.abs(s(t, 60));
            arms(p, 8, 14 + 8 * s(t, 60), 15, 8, 14 - 8 * s(t, 60), 15);
            return p;
        });
        add("hop", t -> {
            float[] p = Pose.rest();
            float h = hop(t, 16);
            p[ROOT_Y] = 3.0f * h;
            legs(p, 20 * (1 - h), 40 * (1 - h), 20 * (1 - h), 40 * (1 - h));
            arms(p, 10, 20 + 40 * h, 10, 10, 20 + 40 * h, 10);
            return p;
        });
        add("stomp", t -> {
            float[] p = Pose.rest();
            float k = s(t, 24);
            legs(p, 60 * Math.max(0, k), 70 * Math.max(0, k), 60 * Math.max(0, -k), 70 * Math.max(0, -k));
            p[ROOT_Y] = 0.8f * Math.abs(s(t, 24));
            arms(p, 20, 20, 60, 20, 20, 60);
            p[HEAD_PITCH] = 8;
            return p;
        });
        add("flex", t -> {
            float[] p = Pose.rest();
            float k = 0.7f + 0.3f * s(t, 30);
            arms(p, 0, 92, 125 * k, 0, 92, 125 * k);
            p[TORSO_PITCH] = -4;
            p[HEAD_PITCH] = -6;
            return p;
        });
        add("fist_pump", t -> {
            float[] p = Pose.rest();
            float k = Math.abs(s(t, 16));
            arms(p, 10, 8, 10, 100 + 70 * k, 12, 70 - 60 * k);
            p[ROOT_Y] = 0.9f * k;
            p[HEAD_PITCH] = -8 * k;
            return p;
        });
        add("high_five", t -> {
            float[] p = Pose.rest();
            arms(p, 10, 8, 10, 165, 22, 6 + 6 * s(t, 40));
            p[HEAD_ROLL] = 5;
            p[HEAD_YAW] = -10;
            return p;
        });
        add("chicken", t -> {
            float[] p = Pose.rest();
            float k = s(t, 8);
            arms(p, 10, 70 + 28 * k, 80, 10, 70 + 28 * k, 80);
            p[ROOT_Y] = 0.7f * Math.abs(k);
            p[HEAD_PITCH] = 8 * k;
            p[HEAD_YAW] = 10 * s(t, 16);
            return p;
        });
        add("headbang", t -> {
            float[] p = Pose.rest();
            float k = Math.max(0, s(t, 10));
            p[HEAD_PITCH] = 45 * k - 8;
            p[TORSO_PITCH] = 14 * k;
            arms(p, 40, 12, 90, 40, 12, 90);
            legs(p, 12, 0, -8, 12);
            return p;
        });
        add("air_guitar", t -> {
            float[] p = Pose.rest();
            arms(p, 70, 10, 40, 40 + 12 * s(t, 5), 8, 80);
            p[TORSO_PITCH] = -8;
            p[HEAD_PITCH] = 10 * s(t, 20);
            legs(p, 10, 0, -14, 20);
            p[ROOT_Y] = 0.4f * hop(t, 10);
            return p;
        });
        add("sing", t -> {
            float[] p = Pose.rest();
            arms(p, 10, 8, 10, 118, 8, 115);
            p[HEAD_PITCH] = -10 + 6 * s(t, 40);
            p[HEAD_ROLL] = 5 * s(t, 80);
            p[TORSO_PITCH] = -4;
            return p;
        });
        add("trumpet", t -> {
            float[] p = Pose.rest();
            float k = s(t, 14);
            arms(p, 105, 14, 125, 105, 14, 125);
            p[HEAD_PITCH] = -24;
            p[TORSO_PITCH] = -6 + 3 * k;
            p[ROOT_Y] = 0.3f * Math.abs(k);
            return p;
        });
        add("piano", t -> {
            float[] p = Pose.rest();
            float a = s(t, 10);
            float b = s(t + 3, 14);
            arms(p, 78 + 10 * a, 8, 40 + 14 * a, 78 + 10 * b, 8, 40 + 14 * b);
            p[TORSO_PITCH] = 10;
            p[HEAD_PITCH] = 6 + 6 * s(t, 40);
            p[HEAD_ROLL] = 5 * s(t, 60);
            return p;
        });
        add("dj_scratch", t -> {
            float[] p = Pose.rest();
            float k = s(t, 9);
            arms(p, 70, 10, 40, 60 + 18 * k, 10, 60 + 30 * k);
            p[HEAD_PITCH] = 8 * k;
            p[TORSO_PITCH] = 5;
            p[HEAD_ROLL] = 8 * s(t, 27);
            p[ROOT_Y] = 0.3f * Math.abs(s(t, 18));
            return p;
        });
        add("conduct", t -> {
            float[] p = Pose.rest();
            arms(p, 40 + 12 * s(t, 40), 20, 30, 80 + 25 * s(t, 24), 18 + 18 * c(t, 48), 40 + 20 * c(t, 24));
            p[TORSO_YAW] = 8 * s(t, 48);
            p[HEAD_PITCH] = 5;
            return p;
        });
        add("twist", t -> {
            float[] p = Pose.rest();
            p[ROOT_YAW] = 40 * s(t, 20);
            p[TORSO_YAW] = -30 * s(t, 20);
            p[ROOT_Y] = 0.5f * Math.abs(s(t, 20));
            arms(p, 10, 40, 80, 10, 40, 80);
            legs(p, 14 * s(t, 20), 12, -14 * s(t, 20), 12);
            return p;
        });
        add("robot", t -> {
            float[] p = Pose.rest();
            int step = (int) Math.floor(t / 15.0f) % 4;
            float[][] ang = {{85, 10}, {10, 85}, {85, 85}, {10, 10}};
            arms(p, ang[step][0], 6, 90, ang[step][1], 6, 90);
            p[HEAD_YAW] = (step % 2 == 0 ? -35 : 35);
            p[TORSO_YAW] = (step < 2 ? 12 : -12);
            return p;
        });
        add("samba", t -> {
            float[] p = Pose.rest();
            float k = s(t, 16);
            p[ROOT_Y] = 1.4f * hop(t, 8);
            p[TORSO_ROLL] = 12 * k;
            p[HEAD_ROLL] = -10 * k;
            arms(p, 110 * Math.max(0, k) + 20, 30, 60, 110 * Math.max(0, -k) + 20, 30, 60);
            legs(p, 30 * Math.max(0, k), 40 * Math.max(0, k), 30 * Math.max(0, -k), 40 * Math.max(0, -k));
            return p;
        });
        add("moonwalk", t -> {
            float[] p = Pose.rest();
            float k = s(t, 30);
            legs(p, 20 * k, 30 * Math.max(0, k), -20 * k, 30 * Math.max(0, -k));
            p[TORSO_PITCH] = -12;
            arms(p, 40, 15, 70, -20, 15, 20);
            p[HEAD_PITCH] = -4;
            return p;
        });
        add("tap_dance", t -> {
            float[] p = Pose.rest();
            float k = s(t, 12);
            legs(p, 24 * Math.max(0, k), 55 * Math.max(0, k), 24 * Math.max(0, -k), 55 * Math.max(0, -k));
            arms(p, 10, 22, 30, 10, 22, 30);
            p[ROOT_Y] = 0.4f * Math.abs(k);
            p[HEAD_ROLL] = 5 * s(t, 24);
            return p;
        });
        add("windmill", t -> {
            float[] p = Pose.rest();
            arms(p, (t * 18) % 360, 4, 6, (t * 18 + 180) % 360, 4, 6);
            p[TORSO_ROLL] = 4 * s(t, 40);
            return p;
        });
        add("helicopter", t -> {
            float[] p = Pose.rest();
            arms(p, 0, 90, 4, 0, 90, 4);
            p[ROOT_YAW] = (t * 22) % 360;
            p[ROOT_Y] = 1.0f + 0.6f * s(t, 30);
            return p;
        });
        add("juggle", t -> {
            float[] p = Pose.rest();
            float a = s(t, 20);
            float b = s(t + 10, 20);
            arms(p, 80 + 40 * a, 20, 70 - 30 * a, 80 + 40 * b, 20, 70 - 30 * b);
            p[HEAD_PITCH] = -10 + 8 * s(t, 40);
            p[HEAD_YAW] = 14 * s(t, 20);
            return p;
        });
        add("zombie_walk", t -> {
            float[] p = Pose.rest();
            float k = s(t, 36);
            legs(p, 24 * k, 14 * Math.max(0, -k), -24 * k, 14 * Math.max(0, k));
            arms(p, 88, 6, 6, 88, 6, 6);
            p[HEAD_ROLL] = 14;
            p[HEAD_PITCH] = 14;
            p[TORSO_PITCH] = 8;
            p[ROOT_Y] = 0.3f * Math.abs(k);
            return p;
        });
        add("scare", t -> {
            float[] p = Pose.rest();
            float tt = t % 60;
            float k = tt < 10 ? tt / 10.0f : Math.max(0, 1 - (tt - 10) / 40.0f);
            k = k * k * (3 - 2 * k);
            arms(p, 150 * k, 70 * k, 10, 150 * k, 70 * k, 10);
            p[HEAD_PITCH] = -30 * k;
            p[TORSO_PITCH] = -14 * k;
            p[ROOT_Y] = 2.5f * k;
            return p;
        });
        add("howl", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 100);
            p[HEAD_PITCH] = -48 * k;
            p[TORSO_PITCH] = -10 * k;
            arms(p, 20, 40 + 30 * k, 20, 20, 40 + 30 * k, 20);
            return p;
        });
        add("shiver", t -> {
            float[] p = Pose.rest();
            p[TORSO_ROLL] = 2.5f * s(t, 2.4f);
            p[HEAD_ROLL] = 3 * s(t, 3.1f);
            p[ROOT_Y] = 0.25f * s(t, 2.0f);
            arms(p, 95, 20, 130, 95, 20, 130);
            legs(p, 4 * s(t, 2.6f), 0, -4 * s(t, 2.6f), 0);
            return p;
        });
        add("claw_swipe", t -> {
            float[] p = Pose.rest();
            float k = Math.max(0, s(t, 24));
            arms(p, 12, 10, 20, 40 + 100 * k, 30 + 40 * k, 20);
            p[TORSO_YAW] = 28 * k - 8;
            p[TORSO_PITCH] = 14 * k;
            p[HEAD_PITCH] = 12;
            return p;
        });
        add("float", t -> {
            float[] p = Pose.rest();
            p[ROOT_Y] = 3 + 1.8f * s(t, 70);
            arms(p, 18, 38, 14, 18, 38, 14);
            p[HEAD_ROLL] = 6 * s(t, 100);
            legs(p, 6, 14, -4, 8);
            p[ROOT_YAW] = 25 * s(t, 140);
            return p;
        });
        add("levitate", t -> {
            float[] p = Pose.rest();
            p[ROOT_Y] = 2.5f + 0.8f * s(t, 60);
            p[ROOT_YAW] = (t * 4) % 360;
            arms(p, 150, 12, 10, 150, 12, 10);
            p[HEAD_PITCH] = -20;
            legs(p, 0, 0, 0, 0);
            return p;
        });
        add("lightning", t -> {
            float[] p = Pose.rest();
            float tt = t % 50;
            float up = tt < 30 ? tt / 30.0f : 1.0f;
            float slam = tt >= 36 ? Math.min(1, (tt - 36) / 4.0f) : 0;
            float k = Math.max(0, up - slam);
            arms(p, 12, 10, 20, 170 * k + 30 * slam, 12, 8);
            p[TORSO_PITCH] = -8 * k + 20 * slam;
            p[HEAD_PITCH] = -18 * k + 10 * slam;
            return p;
        });
        add("stir", t -> {
            float[] p = Pose.rest();
            arms(p, 10, 8, 10, 78 + 14 * s(t, 20), 18 + 16 * c(t, 20), 52 + 12 * c(t, 20));
            p[HEAD_PITCH] = 18;
            p[TORSO_PITCH] = 8;
            return p;
        });
        add("shoot", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 70);
            arms(p, 90, 4, 6, 90 - 10 * k, 4, 4 + 110 * k);
            p[TORSO_YAW] = -20;
            p[HEAD_YAW] = 28;
            p[TORSO_PITCH] = 2;
            return p;
        });
        add("sword_raise", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 80);
            arms(p, 12, 10, 20, 20 + 150 * k, 12 + 8 * k, 20 + 30 * k);
            p[HEAD_PITCH] = -14 * k;
            p[TORSO_PITCH] = -6 * k;
            return p;
        });
        add("shield_bash", t -> {
            float[] p = Pose.rest();
            float k = Math.max(0, s(t, 36));
            k = k * k;
            arms(p, 80 + 20 * k, 30, 70, 20, 12, 30);
            p[TORSO_PITCH] = 22 * k;
            p[TORSO_YAW] = -10 * k;
            legs(p, 28 * k, 8, -18 * k, 22 * k);
            p[HEAD_PITCH] = 6;
            return p;
        });
        add("parade", t -> {
            float[] p = Pose.rest();
            float k = s(t, 22);
            legs(p, 50 * Math.max(0, k), 24 * Math.max(0, k), 50 * Math.max(0, -k), 24 * Math.max(0, -k));
            arms(p, -30 * k, 8, 30, 140, 22, 130);
            p[ROOT_Y] = 0.5f * Math.abs(k);
            p[HEAD_PITCH] = -6;
            return p;
        });
        add("plead", t -> {
            float[] p = Pose.rest();
            arms(p, 100, 4, 120, 100, 4, 120);
            p[HEAD_PITCH] = 14 + 4 * s(t, 40);
            p[TORSO_PITCH] = 8;
            p[ROOT_Y] = -0.4f;
            legs(p, 5, 18, 5, 18);
            return p;
        });
        add("hide", t -> {
            float[] p = Pose.rest();
            float k = pulse(t, 90);
            p[ROOT_Y] = -3 * k;
            p[TORSO_PITCH] = 25 * k;
            p[HEAD_PITCH] = 20 * k;
            legs(p, 60 * k, 100 * k, 60 * k, 100 * k);
            arms(p, 110 * k, 10, 110 * k, 110 * k, 10, 110 * k);
            return p;
        });
        add("peek", t -> {
            float[] p = Pose.rest();
            float tt = t % 80;
            float k = tt < 20 ? tt / 20.0f : tt < 50 ? 1 : Math.max(0, 1 - (tt - 50) / 30.0f);
            p[TORSO_ROLL] = 24 * k;
            p[HEAD_ROLL] = -14 * k;
            p[HEAD_YAW] = 20 * k;
            arms(p, 10, 8 + 10 * k, 10, 10, 8, 10);
            return p;
        });
        add("pray", t -> {
            float[] p = Pose.rest();
            arms(p, 70, 6, 135, 70, 6, 135);
            p[HEAD_PITCH] = 22;
            p[TORSO_PITCH] = 6;
            p[ROOT_Y] = 0.2f * s(t, 80);
            return p;
        });
    }
}
