package com.example.coastercontrolpanel;

import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.createmod.ponder.api.scene.Selection;
import net.createmod.ponder.foundation.PonderIndex;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Create Ponder pages for the blocks and items of this mod. Every page is built from {@link PonderData}:
 * the block (if there is one) stands on a small base plate and the texts are shown one after another.
 */
public class ModPonder implements PonderPlugin {
    @EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Setup {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> PonderIndex.addPlugin(new ModPonder()));
        }
    }

    @Override
    public String getModId() {
        return CoasterControlPanel.MOD_ID;
    }

    @Override
    public void registerScenes(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        for (PonderData.Entry e : PonderData.ALL) {
            PonderStoryBoard board = (scene, util) -> {
                scene.title(e.id(), e.title());
                scene.configureBasePlate(0, 0, 5);
                scene.world().showSection(util.select().layer(0), Direction.UP);
                scene.idle(5);
                int top = e.top();
                if (top > 0) {
                    scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
                }
                scene.idle(10);
                Selection block = util.select().fromTo(2, Math.min(1, top), 2, 2, top, 2);
                for (String text : e.texts()) {
                    scene.overlay().showOutlineWithText(block, 80)
                            .text(text)
                            .pointAt(util.vector().topOf(2, top, 2))
                            .placeNearTarget();
                    scene.idle(90);
                }
                scene.markAsFinished();
            };
            for (String component : e.components()) {
                helper.addStoryBoard(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, component), e.id(), board);
            }
        }
    }
}
