package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Runs the Brake Runs. Coasters Simulated calls "applySpeedMatch" for every cart, every physics step, while the cart
 * is on a chain-lift stretch. A Brake Run is a stretch placed with the Brake Run item, so the same call reaches us
 * first (BrakeDriveMixin). We read the cart's speed along the track, ask {@link BrakeLogic} how much that speed should
 * change in this step, and add exactly that through Sable's normal "add velocity" call, the same one the chain uses.
 * Nothing is teleported and no speed is ever set directly.
 *
 * The base mod and Sable are reached by reflection (no compile dependency). If anything about them differs from
 * what is expected, this switches itself off with one log line, and the stretch behaves like an unpowered chain.
 *
 * Efficiency: until a Brake Run exists in the world ({@link #armed}) the hook returns on its first line. Per cart
 * state lives only while the cart is on a Brake Run and is dropped as soon as it has been gone for a moment.
 */
public final class BrakeController {
    /** True once any anchor with a Brake Run has been loaded or placed. Never costs anything before that. */
    public static volatile boolean armed;

    private static volatile boolean broken;
    private static boolean loggedHook;
    private static boolean loggedBrake;
    private static int errors;
    private static int transitionsLogged;
    private static boolean resolved;
    private static Method findAtGraphHit;
    private static Method chainWorldVelocityAtHit;
    private static Method hitAnchor;
    private static Method hitPath;
    private static Method basisForward;
    private static Method getPipeline;
    private static Method getLinearVelocity;
    private static Method addVelocity;
    private static Method getEndRef;
    private static Method endAnchor;

    /** One entry per cart currently on a Brake Run. Weak, so a removed cart is forgotten with it. */
    private static final Map<Object, BrakeLogic.State> STATES = new WeakHashMap<>();

    private BrakeController() {
    }

    private static Method find(Class<?> c, String name, int params, Class<?>... accepts) {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == params) {
                Class<?>[] p = m.getParameterTypes();
                boolean ok = true;
                for (int i = 0; i < accepts.length && ok; i++) {
                    ok = p[p.length - accepts.length + i].isAssignableFrom(accepts[i]);
                }
                if (ok) {
                    m.setAccessible(true);
                    return m;
                }
            }
        }
        throw new IllegalStateException("missing " + c.getName() + "." + name);
    }

    private static void resolve() throws Exception {
        Class<?> query = Class.forName("dev.silvergold.simulatedcoasters.track.chainlift.ChainLiftSpanQuery");
        findAtGraphHit = find(query, "findAtGraphHit", 3);
        chainWorldVelocityAtHit = find(query, "chainWorldVelocityAtHit", 5);
        Class<?> spanHit = Class.forName("dev.silvergold.simulatedcoasters.track.chainlift.ChainLiftSpanQuery$ChainLiftSpanHit");
        hitAnchor = find(spanHit, "anchor", 0);
        hitPath = find(spanHit, "path", 0);
        basisForward = find(Class.forName("dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame$TrackBasis"), "forward", 0);
        getPipeline = find(Class.forName("dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem"), "getPipeline", 0);
        Class<?> pipeline = Class.forName("dev.ryanhcode.sable.api.physics.PhysicsPipeline");
        getLinearVelocity = find(pipeline, "getLinearVelocity", 2, Vector3d.class);
        addVelocity = find(pipeline, "addLinearAndAngularVelocity", 3, Vector3d.class, Vector3d.class);
        resolved = true;
    }

    /**
     * @return true when this cart is on a Brake Run and has been handled (the caller then skips the chain drive)
     */
    public static boolean handle(Object body, ServerLevel level, Object system, Object graphHit, Object basis, double dt) {
        if (!armed || broken || !(dt > 0.0)) {
            return false;
        }
        try {
            if (!loggedHook) {
                loggedHook = true;
                CoasterControlPanel.LOGGER.info("Brake Run: the cart-drive hook is running (a Brake Run exists in this world).");
            }
            if (!resolved) {
                resolve();
            }
            Object hit = findAtGraphHit.invoke(null, level, graphHit, 0.0);
            if (hit == null) {
                return false;
            }
            Object anchor = hitAnchor.invoke(hit);
            if (!(anchor instanceof DriveTyre.Holder holder) || holder.ccp$brake() == null) {
                return false;
            }
            BrakeSettings settings = holder.ccp$brake();
            if (!loggedBrake) {
                loggedBrake = true;
                CoasterControlPanel.LOGGER.info("Brake Run: first cart found on a Brake Run at {}.", ((BlockEntity) anchor).getBlockPos());
            }
            Vec3 forward = (Vec3) basisForward.invoke(basis);
            if (forward == null || forward.lengthSqr() < 1.0E-12) {
                return true;
            }
            Vector3d t = new Vector3d(forward.x, forward.y, forward.z).normalize();

            // Which way along t is "forward" for this Brake Run (first anchor towards the second)?
            Object path = hitPath.invoke(hit);
            Vec3 chainV = (Vec3) chainWorldVelocityAtHit.invoke(null, level, path, graphHit, 1.0, 0.0);
            double proj = chainV == null ? 0.0 : chainV.x * t.x + chainV.y * t.y + chainV.z * t.z;
            double sign = proj > 0 ? -1.0 : 1.0; // the chain drive uses the negated projection as its target speed

            Object pipeline = getPipeline.invoke(system);
            Vector3d vel = (Vector3d) getLinearVelocity.invoke(pipeline, body, new Vector3d());
            double s = vel.dot(t) * sign;

            long tick = level.getGameTime();
            long anchorKey = ((BlockEntity) anchor).getBlockPos().asLong();
            BrakeLogic.State st = STATES.get(body);
            if (st == null || st.anchor != anchorKey || tick - st.lastTick > 20) {
                st = new BrakeLogic.State();
                st.anchor = anchorKey;
                STATES.put(body, st);
            }
            st.lastTick = tick;

            int before = st.phase;
            double dv = BrakeLogic.step(st, settings, s, dt);
            if (st.phase != before && transitionsLogged < 80) {
                transitionsLogged++;
                CoasterControlPanel.LOGGER.info("Brake Run {}: phase {} -> {} at {} km/h (mode {}).",
                        ((BlockEntity) anchor).getBlockPos(), before, st.phase, String.format("%.1f", s * 3.6), settings.mode);
            }
            if (Math.abs(dv) > 1.0E-9 && Double.isFinite(dv)) {
                Vector3d add = new Vector3d(t).mul(dv * sign);
                addVelocity.invoke(pipeline, body, add, new Vector3d());
            }
            return true;
        } catch (Throwable e) {
            // One bad step must not switch Brake Runs off for the rest of the session: only a failed lookup of the
            // base mod's methods does that. Anything else is logged (a few times) and the cart is left to the base drive.
            if (!resolved) {
                broken = true;
            }
            if (errors++ < 5) {
                CoasterControlPanel.LOGGER.error("Brake Run: error while braking a cart" + (broken ? " (Brake Runs switched off: could not find the base mod's methods)" : ""), e);
            }
            return false;
        }
    }

    // ---- finding the Brake Run an anchor belongs to (used by the wrench)

    /** The first anchor of the Brake Run that {@code clicked} belongs to (as first or second anchor), or null. */
    public static BlockPos findStart(Level level, BlockPos clicked) {
        BlockEntity here = level.getBlockEntity(clicked);
        if (here instanceof DriveTyre.Holder h && h.ccp$brake() != null) {
            return clicked;
        }
        if (!(here instanceof DriveTyre.Holder)) {
            return null; // not a coaster anchor
        }
        try {
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            int cx = clicked.getX() >> 4;
            int cz = clicked.getZ() >> 4;
            for (int dx = -4; dx <= 4; dx++) {
                for (int dz = -4; dz <= 4; dz++) {
                    LevelChunk chunk = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
                    if (chunk == null) {
                        continue;
                    }
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (be instanceof DriveTyre.Holder h && h.ccp$brake() != null) {
                            BlockPos end = endOf(be);
                            if (clicked.equals(end)) {
                                double d = be.getBlockPos().distSqr(clicked);
                                if (d < bestD) {
                                    bestD = d;
                                    best = be.getBlockPos();
                                }
                            }
                        }
                    }
                }
            }
            return best;
        } catch (Throwable e) {
            return null;
        }
    }

    private static BlockPos endOf(BlockEntity anchor) throws Exception {
        if (getEndRef == null) {
            getEndRef = anchor.getClass().getMethod("getChainLiftEndRef");
        }
        Object ref = getEndRef.invoke(anchor);
        if (ref == null) {
            return null;
        }
        if (endAnchor == null) {
            endAnchor = ref.getClass().getMethod("endAnchor");
        }
        return (BlockPos) endAnchor.invoke(ref);
    }

    public static BrakeSettings settingsAt(Level level, BlockPos start) {
        return level.getBlockEntity(start) instanceof DriveTyre.Holder h ? h.ccp$brake() : null;
    }
}
