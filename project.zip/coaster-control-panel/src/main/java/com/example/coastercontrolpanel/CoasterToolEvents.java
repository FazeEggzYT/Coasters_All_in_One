package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Coaster Smoother: right-click a track anchor with it in the main hand. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class CoasterToolEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND
                || !event.getItemStack().is(CoasterControlPanel.COASTER_SMOOTHER_ITEM.get())
                || !AnchorTrack.isAnchor(event.getLevel().getBlockEntity(event.getPos()))) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide || !(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        int[] r = CoasterTools.smooth(event.getLevel(), player, event.getPos());
        if (r[0] < 0) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_none"), true);
        } else {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_done", r[0], r[1]), true);
        }
    }
}
