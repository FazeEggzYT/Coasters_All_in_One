package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Coaster Smoother. Right-click (in the air, on a block, or on an anchor) while aiming at track: everything
 * connected to that track is smoothed. Sneak + right-click: undo. A message always shows what happened.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class CoasterToolEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), event.getPos())) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (handle(event.getEntity(), event.getHand(), event.getLevel(), null)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private static boolean handle(Player player, InteractionHand hand, Level level, BlockPos clicked) {
        if (hand != InteractionHand.MAIN_HAND || !player.getMainHandItem().is(CoasterControlPanel.COASTER_SMOOTHER_ITEM.get())) {
            return false;
        }
        if (level.isClientSide || !(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel sl)) {
            return true;
        }
        if (player.isShiftKeyDown()) {
            int n = CoasterTools.undo(sl, sp);
            sp.displayClientMessage(n < 0 ? Component.translatable("message.coastercontrolpanel.smooth_nothing")
                    : Component.translatable("message.coastercontrolpanel.smooth_undone", n), true);
            return true;
        }
        BlockPos start = CoasterTools.pickTrackAnchor(level, player);
        if (start == null && clicked != null && AnchorTrack.isAnchor(level.getBlockEntity(clicked))) {
            start = clicked;
        }
        if (start == null) {
            sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_aim"), true);
            return true;
        }
        int[] r = CoasterTools.smooth(level, sp, start);
        if (r == null) {
            sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_unsupported"), true);
        } else if (r[2] < 2) {
            sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_none"), true);
        } else {
            sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.smooth_done", r[0], r[1], r[2]), true);
        }
        return true;
    }
}
