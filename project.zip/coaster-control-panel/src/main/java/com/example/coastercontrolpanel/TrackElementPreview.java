package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.util.List;

/** Placement preview: while the selector is held with an element chosen, the planned centre line and anchors are drawn where the click would put them. Green = can be placed, red = cannot. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, value = Dist.CLIENT)
public class TrackElementPreview {
    private static BlockPos cachedPos;
    private static Direction cachedFace;
    private static ElementState cachedState;
    private static int cachedYaw = Integer.MIN_VALUE;
    private static ElementPlacer.Context cached;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !mc.player.getMainHandItem().is(CoasterControlPanel.TRACK_ELEMENT_SELECTOR_ITEM.get())) {
            return;
        }
        ElementState st = ElementState.read(mc.player.getMainHandItem());
        if (st == null || !(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        int yaw = Direction.fromYRot(mc.player.getYRot()).get2DDataValue();
        if (cached == null || !hit.getBlockPos().equals(cachedPos) || hit.getDirection() != cachedFace || !st.equals(cachedState) || yaw != cachedYaw) {
            cached = ElementPlacer.resolve(mc.level, mc.player, hit.getBlockPos(), hit.getDirection(), st);
            cachedPos = hit.getBlockPos();
            cachedFace = hit.getDirection();
            cachedState = st;
            cachedYaw = yaw;
        }
        ElementPlacer.Context c = cached;
        if (c.plan == null) {
            return;
        }
        boolean good = c.problems.isEmpty();
        float r = good ? 0.3f : 1.0f;
        float gr = good ? 1.0f : 0.25f;
        float b = good ? 0.4f : 0.25f;
        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.lines());
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        List<double[]> line = c.plan.line;
        PoseStack.Pose pose = ps.last();
        for (int i = 1; i < line.size(); i++) {
            double[] a = line.get(i - 1);
            double[] q = line.get(i);
            float nx = (float) (q[0] - a[0]);
            float ny = (float) (q[1] - a[1]);
            float nz = (float) (q[2] - a[2]);
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1.0E-6f) {
                continue;
            }
            nx /= l;
            ny /= l;
            nz /= l;
            vc.addVertex(pose, (float) a[0], (float) a[1], (float) a[2]).setColor(r, gr, b, 1.0f).setNormal(pose, nx, ny, nz);
            vc.addVertex(pose, (float) q[0], (float) q[1], (float) q[2]).setColor(r, gr, b, 1.0f).setNormal(pose, nx, ny, nz);
        }
        for (var n : c.plan.nodes) {
            LevelRenderer.renderLineBox(ps, vc, new AABB(n.x(), n.y(), n.z(), n.x() + 1, n.y() + 1, n.z() + 1).deflate(0.3), r, gr, b, 1.0f);
        }
        for (BlockPos bp : c.blocked) {
            LevelRenderer.renderLineBox(ps, vc, new AABB(bp).deflate(0.02), 1.0f, 0.1f, 0.1f, 1.0f);
        }
        ps.popPose();
        buffers.endBatch(RenderType.lines());
    }
}
