package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Station / Launch / Brake / Lift Track items. Click an anchor, then another anchor: the stretch of
 * Coasters Simulated track between them is painted in that purpose's colour and remembered.
 * The next controller you place (Station, Launch, Brake, Lift or Section) takes that stretch automatically.
 * The first anchor is the start, the second the end.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class PurposeTrackEvents {
    private record Kind(ZoneType type, String preset) {
    }

    private static Kind kindOf(ItemStack stack) {
        if (stack.is(CoasterControlPanel.STATION_TRACK_ITEM.get())) {
            return new Kind(ZoneType.STATION, "station");
        }
        if (stack.is(CoasterControlPanel.LAUNCH_TRACK_ITEM.get())) {
            return new Kind(ZoneType.LAUNCH, "launch");
        }
        if (stack.is(CoasterControlPanel.BRAKE_TRACK_ITEM.get())) {
            return new Kind(ZoneType.BRAKE, "brake");
        }
        if (stack.is(CoasterControlPanel.LIFT_TRACK_ITEM.get())) {
            return new Kind(ZoneType.LIFT, "lift");
        }
        return null;
    }

    private static TrackPresets.Preset preset(String key) {
        for (TrackPresets.Preset p : TrackPresets.ALL) {
            if (p.key().equals(key)) {
                return p;
            }
        }
        return TrackPresets.ALL.get(0);
    }

    /** The stretch each player has just set up; the next controller they place takes it. */
    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    private record Pending(BlockPos a, BlockPos b, String key) {
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ItemStack stack = event.getItemStack();
        Kind kind = kindOf(stack);
        if (event.getHand() != InteractionHand.MAIN_HAND || kind == null) {
            return;
        }
        BlockPos pos = event.getPos();
        Level level = event.getLevel();
        if (!AnchorTrack.isAnchor(level.getBlockEntity(pos))) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (level.isClientSide) {
            return;
        }
        Player player = event.getEntity();
        Component name = Component.translatable("item.coastercontrolpanel." + kind.preset() + "_track");
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        if (!tag.contains("From")) {
            tag.putLong("From", pos.asLong());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.piece_from", name), true);
            return;
        }
        BlockPos from = BlockPos.of(tag.getLong("From"));
        tag.remove("From");
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        if (from.equals(pos)) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_cancel"), true);
            return;
        }

        List<BlockPos> route = AnchorTrack.route(level, from, pos);
        if (route.size() < 2) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_none"), true);
            return;
        }
        TrackPresets.Preset pr = preset(kind.preset());
        int rail = AnchorTrack.dyeRgb(pr.rail());
        int beam = AnchorTrack.dyeRgb(pr.beam());
        for (int i = 0; i + 1 < route.size(); i++) {
            AnchorTrack.tint(level, route.get(i), route.get(i + 1), rail, beam);
            AnchorTrack.tint(level, route.get(i + 1), route.get(i), rail, beam);
        }

        PENDING.put(player.getUUID(), new Pending(from, pos, kind.preset()));
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.piece_done", name,
                route.size() - 1), true);
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !(event.getLevel() instanceof Level level)
                || level.isClientSide) {
            return;
        }
        Pending pending = PENDING.get(player.getUUID());
        if (pending == null) {
            return;
        }
        BlockEntity be = level.getBlockEntity(event.getPos());
        if (be instanceof TrackZone zone) {
            zone.setTrack(pending.a(), pending.b());
            PENDING.remove(player.getUUID());
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.piece_taken",
                    Component.translatable("item.coastercontrolpanel." + pending.key() + "_track")), true);
        }
    }
}
