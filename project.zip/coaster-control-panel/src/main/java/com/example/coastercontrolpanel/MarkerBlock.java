package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.InteractionHand;

import javax.annotation.Nullable;

/** A flat pad on the floor that tells guests where to walk. Guests walk straight over it. */
public class MarkerBlock extends BaseEntityBlock {
    public static final MapCodec<MarkerBlock> CODEC = simpleCodec(p -> new MarkerBlock(MarkerKind.QUEUE, p));
    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 2, 15);

    public final MarkerKind kind;

    public MarkerBlock(MarkerKind kind, Properties properties) {
        super(properties);
        this.kind = kind;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MarkerBlockEntity(pos, state);
    }

    /** A new queue marker takes the next number in its channel, so you just place them in order. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && kind == MarkerKind.QUEUE && level.getBlockEntity(pos) instanceof MarkerBlockEntity m) {
            int highest = 0;
            for (MarkerBlockEntity other : MarkerRegistry.find(level, pos, 1, MarkerKind.QUEUE, 24.0)) {
                if (other != m) {
                    highest = Math.max(highest, other.getNumber());
                }
            }
            m.setNumber(highest + 1);
            if (placer instanceof Player player) {
                player.displayClientMessage(Component.translatable("message.coastercontrolpanel.marker_placed",
                        Component.translatable("block.coastercontrolpanel." + kind.id), m.getNumber()), true);
            }
        }
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof WrenchItem) {
            if (level.isClientSide) {
                ClientHooks.openMarker(pos);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    /** Empty hand: tells you its number and channel. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MarkerBlockEntity m) {
            Component name = Component.translatable("block.coastercontrolpanel." + kind.id);
            player.displayClientMessage(kind == MarkerKind.QUEUE
                    ? Component.translatable("message.coastercontrolpanel.marker_info_queue", name, m.getNumber(), m.getChannel())
                    : Component.translatable("message.coastercontrolpanel.marker_info", name, m.getChannel()), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
