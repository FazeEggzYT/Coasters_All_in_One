package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup of the transfer table: four numbers on the left, eight link slots on the right. */
public class TransferScreen extends AbstractContainerScreen<TransferMenu> {
    private static final String[] NAMES = {"stops", "spacing", "speed", "forward"};
    private static final String[] SLOT_NAMES = {"Left", "Right", "Send >", "Send <", "Stop A", "Stop B", "Stop C", "Stop D"};
    private final int[] v = TransferTableBlockEntity.DEF.clone();
    private Button autoButton;

    private Component autoText() {
        return Component.translatable(v[4] == 1 ? "gui.coastercontrolpanel.transfer.auto_on" : "gui.coastercontrolpanel.transfer.auto_off");
    }

    public TransferScreen(TransferMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 300;
        this.imageHeight = 212;
    }

    @Override
    protected void init() {
        super.init();
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof TransferTableBlockEntity t) {
            for (int i = 0; i < v.length; i++) {
                v[i] = t.get(i);
            }
        }
        for (int i = 0; i < NAMES.length; i++) {
            final int idx = i;
            int y = 30 + i * 22;
            addRenderableWidget(Button.builder(Component.literal("-"), b -> change(idx, -1))
                    .bounds(leftPos + 80, topPos + y, 18, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"), b -> change(idx, 1))
                    .bounds(leftPos + 138, topPos + y, 18, 16).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.transfer.setup"),
                b -> PacketDistributor.sendToServer(new TransferCarryPacket(menu.getPos(), 3)))
                .bounds(leftPos + 172, topPos + 102, 56, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.transfer.reset"),
                b -> PacketDistributor.sendToServer(new TransferCarryPacket(menu.getPos(), 4)))
                .bounds(leftPos + 230, topPos + 102, 58, 14).build());
        autoButton = Button.builder(autoText(), b -> {
            change(4, v[4] == 0 ? 1 : -1);
            b.setMessage(autoText());
        }).bounds(leftPos + 222, topPos + 148, 66, 14).build();
        addRenderableWidget(autoButton);
        addRenderableWidget(Button.builder(Component.literal("-"), b -> change(5, -1)).bounds(leftPos + 222, topPos + 164, 14, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> change(5, 1)).bounds(leftPos + 274, topPos + 164, 14, 14).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> change(6, -1)).bounds(leftPos + 222, topPos + 180, 14, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> change(6, 1)).bounds(leftPos + 274, topPos + 180, 14, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + imageWidth - 46, topPos + 4, 40, 14).build());
    }

    private void change(int i, int d) {
        v[i] = Math.max(TransferTableBlockEntity.MIN[i], Math.min(TransferTableBlockEntity.MAX[i], v[i] + d));
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new TransferConfigPacket(menu.getPos(), v.clone()));
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 164, y0 + 22, x0 + 165, y0 + 120, 0xFF3A3E4D);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int text = 0xE0E4F0;
        int dim = 0x7A8098;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        String[] values = {String.valueOf(v[0]), v[1] + " blocks", String.format("%.1f b/s", v[2] * 0.5), v[3] + " blocks"};
        for (int i = 0; i < NAMES.length; i++) {
            int y = 34 + i * 22;
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.transfer." + NAMES[i]), 8, y, text, false);
            g.drawCenteredString(font, values[i], 118, y, 0xFFFFFF);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.transfer_links"), 172, 24, text, false);
        for (int i = 0; i < TransferMenu.N; i++) {
            boolean greyed = i >= 4 && i - 4 >= v[0];
            g.drawCenteredString(font, SLOT_NAMES[i], TransferMenu.slotX(i) + 8, TransferMenu.slotY(i) - 12,
                    greyed ? dim : text);
        }
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof TransferTableBlockEntity t && t.isSetUp()) {
            g.drawString(font, Component.translatable(t.trainOn() ? "gui.coastercontrolpanel.transfer.train_on" : "gui.coastercontrolpanel.transfer.train_off"),
                    172, 122, t.trainOn() ? 0x80FF80 : dim, false);
            g.drawString(font, Component.translatable(t.ready() ? "gui.coastercontrolpanel.transfer.ready" : "gui.coastercontrolpanel.transfer.not_ready"),
                    172, 134, t.ready() ? 0x80FF80 : 0xFFB060, false);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.transfer.auto"), 172, 152, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.transfer.auto_to"), 172, 168, v[4] == 1 ? text : dim, false);
        g.drawCenteredString(font, "Stop " + (char) ('A' + v[5]), 255, 168, v[4] == 1 ? 0xFFFFFF : dim);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.transfer.auto_wait"), 172, 184, v[4] == 1 ? text : dim, false);
        g.drawCenteredString(font, v[6] + " s", 255, 184, v[4] == 1 ? 0xFFFFFF : dim);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 69, 118, dim, false);
    }
}
