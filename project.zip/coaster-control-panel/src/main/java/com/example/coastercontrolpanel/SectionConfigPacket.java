package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: Section Controller box size and delay, and whether to show the box. */
public record SectionConfigPacket(BlockPos pos, int range, int height, int clear, boolean show, boolean clearTrack)
        implements CustomPacketPayload {
    public static final Type<SectionConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "section_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SectionConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.range);
                buf.writeVarInt(p.height);
                buf.writeVarInt(p.clear);
                buf.writeBoolean(p.show);
                buf.writeBoolean(p.clearTrack);
            },
            buf -> new SectionConfigPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(),
                    buf.readVarInt(), buf.readBoolean(), buf.readBoolean()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SectionConfigPacket packet, IPayloadContext context) {
        SectionControllerBlockEntity section = SectionControllerBlockEntity.lookup(context.player(), packet.pos);
        if (section == null) {
            return;
        }
        section.applyConfig(packet.range, packet.height, packet.clear);
        if (packet.clearTrack) {
            section.clearTrack();
        }
        if (packet.show) {
            section.showArea();
        }
    }
}
