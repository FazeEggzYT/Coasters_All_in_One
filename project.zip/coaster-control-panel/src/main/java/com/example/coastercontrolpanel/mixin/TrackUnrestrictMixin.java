package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterTools;
import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Track Unrestrictor. With the item in the off hand, Coasters Simulated's placement limits are skipped.
 * Lives in its own mixin config with every injection optional, so a Coasters Simulated update that moves
 * something turns this tool off instead of stopping the game.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.CoasterTrackPlacement", remap = false)
public class TrackUnrestrictMixin {
    private static final String SECOND = "tryConnectSecondAnchorFromCurve(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/InteractionHand;)Z";

    @Inject(method = "tryConnect", at = @At("HEAD"), remap = false, require = 0)
    private static void ccp$push(Level level, Player player, BlockPos pos, BlockState state, ItemStack stack,
                                 boolean a, boolean b, boolean c, CallbackInfoReturnable<Object> cir) {
        CoasterTools.push(player);
    }

    @Inject(method = "tryConnect", at = @At("RETURN"), remap = false, require = 0)
    private static void ccp$pop(Level level, Player player, BlockPos pos, BlockState state, ItemStack stack,
                                boolean a, boolean b, boolean c, CallbackInfoReturnable<Object> cir) {
        CoasterTools.pop();
    }

    @Inject(method = SECOND, at = @At("HEAD"), remap = false, require = 0)
    private static void ccp$pushSecond(Level level, Player player, ItemStack stack, BlockPos pos, InteractionHand hand,
                                       CallbackInfoReturnable<Boolean> cir) {
        CoasterTools.push(player);
    }

    @Inject(method = SECOND, at = @At("RETURN"), remap = false, require = 0)
    private static void ccp$popSecond(Level level, Player player, ItemStack stack, BlockPos pos, InteractionHand hand,
                                      CallbackInfoReturnable<Boolean> cir) {
        CoasterTools.pop();
    }

    @Redirect(method = SECOND, at = @At(value = "INVOKE",
            target = "Ldev/silvergold/simulatedcoasters/track/anchor/CoasterAnchorpointBlockEntity;legCount()I"),
            remap = false, require = 0)
    private static int ccp$legCap(BlockEntity anchor) {
        return CoasterTools.legCount(anchor);
    }

    @Inject(method = "anchorConnectionExceedsMaxSpan", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$span(Level level, BlockPos a, BlockPos b, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active() && !CoasterTools.acrossSubLevels(level, a, b)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "anchorConnectionTooFar", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$tooFar(Level level, BlockPos a, BlockPos b, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active() && !CoasterTools.acrossSubLevels(level, a, b)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "shouldSkipAnchorPreviewDraw", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$longPreview(Level level, BlockPos a, BlockPos b, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "shouldSkipHeavyCurvePreview", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$sharpPreview(BezierConnection curve, CallbackInfoReturnable<Boolean> cir) {
        if (CoasterTools.active()) {
            cir.setReturnValue(false);
        }
    }
}
