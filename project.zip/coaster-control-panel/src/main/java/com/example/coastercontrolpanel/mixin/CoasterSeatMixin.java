package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.SeatTimerAccess;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds a delay to the restraint seat of "Create: Coasters Simulated Additions".
 * The seat calls setPowered(signal) every server tick. We hold back a change of state until the
 * matching delay (open or close) has passed, and only then let the original method run.
 */
@Mixin(targets = "dev.plushivr.coasterfins.block.CoasterSeatBlockEntity", remap = false)
public abstract class CoasterSeatMixin implements SeatTimerAccess {
    @Shadow
    private boolean powered;
    @Shadow
    public float barProgress;
    @Shadow
    public float prevBarProgress;

    @Unique
    private int coastersaio$speed = 100;

    @Unique
    private int coastersaio$open = 0;
    @Unique
    private int coastersaio$close = 0;
    @Unique
    private long coastersaio$since = -1L;
    @Unique
    private boolean coastersaio$target = false;

    @Override
    public int seatTimerOpenDelay() {
        return coastersaio$open;
    }

    @Override
    public int seatTimerCloseDelay() {
        return coastersaio$close;
    }

    @Override
    public int seatTimerSpeed() {
        return coastersaio$speed;
    }

    @Override
    public void seatTimerSet(int openSeconds, int closeSeconds, int speedPercent) {
        coastersaio$open = Math.max(0, Math.min(60, openSeconds));
        coastersaio$close = Math.max(0, Math.min(60, closeSeconds));
        coastersaio$speed = Math.max(10, Math.min(100, speedPercent));
        coastersaio$since = -1L;
        ((BlockEntity) (Object) this).setChanged();
    }

    @Inject(method = "setPowered", at = @At("HEAD"), cancellable = true)
    private void coastersaio$delay(boolean value, CallbackInfo ci) {
        Level level = ((BlockEntity) (Object) this).getLevel();
        if (level == null || level.isClientSide) {
            return;
        }
        if (value == this.powered) {
            coastersaio$since = -1L;
            return;
        }
        int delay = value ? coastersaio$open : coastersaio$close;
        if (delay <= 0) {
            coastersaio$since = -1L;
            return;
        }
        long now = level.getGameTime();
        if (coastersaio$since < 0 || coastersaio$target != value) {
            coastersaio$since = now;
            coastersaio$target = value;
        }
        if (now - coastersaio$since >= delay * 20L) {
            coastersaio$since = -1L;
            return; // time is up: let the original method change the state
        }
        ci.cancel();
    }

    /** The bar moves a fixed step each tick; keep only the chosen share of that step. */
    @Inject(method = "tickAnimation", at = @At("TAIL"))
    private void coastersaio$slow(CallbackInfo ci) {
        if (coastersaio$speed < 100) {
            barProgress = prevBarProgress + (barProgress - prevBarProgress) * (coastersaio$speed / 100.0F);
            float target = this.powered ? 0.0F : 1.0F;
            if (Math.abs(target - barProgress) < 0.004F) {
                barProgress = target;
            }
        }
    }

    @Override
    public void seatTimerLoad(int openSeconds, int closeSeconds, int speedPercent) {
        coastersaio$open = openSeconds;
        coastersaio$close = closeSeconds;
        coastersaio$speed = Math.max(10, Math.min(100, speedPercent));
        coastersaio$since = -1L;
    }
}
