package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** The blocks of the Ferris Wheel: Base (engine), Axle Hub, Spoke, Rim, Cabin Hub and Cabin Frame. */
public final class FerrisBlocks {
    private FerrisBlocks() {
    }

    public static final int REACH = 40;

    /** The nearest Axle Hub within reach of a position. */
    @Nullable
    public static BlockPos findAxle(Level level, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(from.offset(-REACH, -REACH, -REACH), from.offset(REACH, REACH, REACH))) {
            if (level.getBlockState(p).getBlock() instanceof AxleBlock) {
                double d = p.distSqr(from);
                if (d < bestD) {
                    bestD = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    /** The engine. Right-click to open the ride settings and controls. */
    public static class BaseBlock extends BaseEntityBlock {
        public static final MapCodec<BaseBlock> CODEC = simpleCodec(BaseBlock::new);
        private static final VoxelShape SHAPE = net.minecraft.world.phys.shapes.Shapes.or(Block.box(0, 0, 0, 16, 6, 16), Block.box(1, 6, 1, 15, 14, 15));

        public BaseBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new FerrisBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return createTickerHelper(type, CoasterControlPanel.FERRIS_BE.get(), (l, p, s, be) -> {
                if (l.isClientSide) {
                    be.clientTick();
                } else {
                    be.serverTick();
                }
            });
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openRide(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof FerrisBlockEntity be) {
                be.baseRemoved();
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof FerrisBlockEntity be) {
                be.refreshRedstone();
            }
        }
    }

    /** A piece of the wheel. AXIS is the line of the axle; the piece is a thin disc around it. */
    public abstract static class WheelPart extends Block {
        public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;
        private final VoxelShape shapeZ;
        private final VoxelShape shapeX;

        protected WheelPart(Properties properties, double inset, double thin) {
            super(properties);
            registerDefaultState(stateDefinition.any().setValue(AXIS, Direction.Axis.Z));
            shapeZ = Block.box(inset, inset, 8 - thin, 16 - inset, 16 - inset, 8 + thin);
            shapeX = Block.box(8 - thin, inset, inset, 8 + thin, 16 - inset, 16 - inset);
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(AXIS);
        }

        @Nullable
        @Override
        public BlockState getStateForPlacement(BlockPlaceContext context) {
            return defaultBlockState().setValue(AXIS, context.getHorizontalDirection().getAxis());
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return state.getValue(AXIS) == Direction.Axis.X ? shapeX : shapeZ;
        }
    }

    /** The centre of the wheel: it turns around this block. */
    public static class AxleBlock extends WheelPart {
        public AxleBlock(Properties properties) {
            super(properties, 2, 3);
        }
    }

    public static class SpokeBlock extends WheelPart {
        public SpokeBlock(Properties properties) {
            super(properties, 5, 1.5);
        }
    }

    public static class RimBlock extends WheelPart {
        public RimBlock(Properties properties) {
            super(properties, 1, 2);
        }
    }

    /** The point a cabin hangs from and turns around. Build the cabin around it. */
    public static class HubBlock extends SwingBlocks.HubBlock {
        public HubBlock(Properties properties) {
            super(properties);
        }
    }

    /** Cabin walls. Stick to each other and to touching seats. */
    public static class CabinFrameBlock extends SwingBlocks.GondolaFrameBlock {
        public CabinFrameBlock(Properties properties) {
            super(properties);
        }
    }
}
