package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen of the Guest Spawner. Left: the settings. Right: park-open link, test, and a check of your markers. */
public class GuestSpawnerScreen extends AbstractContainerScreen<GuestSpawnerMenu> {
    private static final int N = GuestSpawnerBlockEntity.COUNT;
    private static final int[] STEP = {1, 1, 1, 10, 5, 10, 1};
    private final int[] v = GuestSpawnerBlockEntity.DEF.clone();
    private Button openButton;

    // rows of the left column, in order
    private static final int[] ROWS = {
            GuestSpawnerBlockEntity.S_CHANNEL, GuestSpawnerBlockEntity.S_RATE, GuestSpawnerBlockEntity.S_MAX,
            GuestSpawnerBlockEntity.S_SPEED, GuestSpawnerBlockEntity.S_RIDE, GuestSpawnerBlockEntity.S_KIDS};
    private static final String[] NAMES = {"channel", "rate", "max", "speed", "ride", "kids"};

    public GuestSpawnerScreen(GuestSpawnerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 372;
        this.imageHeight = 212;
    }

    @Override
    protected void init() {
        super.init();
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof GuestSpawnerBlockEntity e) {
            for (int i = 0; i < N; i++) {
                v[i] = e.get(i);
            }
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + 146, topPos + 3, 38, 14).build());
        for (int row = 0; row < ROWS.length; row++) {
            final int idx = ROWS[row];
            int y = topPos + 22 + row * 20;
            addRenderableWidget(Button.builder(Component.literal("-"), b -> change(idx, -1))
                    .bounds(leftPos + 100, y, 18, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"), b -> change(idx, 1))
                    .bounds(leftPos + 166, y, 18, 16).build());
        }
        openButton = Button.builder(openText(), b -> {
            v[GuestSpawnerBlockEntity.S_OPEN] = (v[GuestSpawnerBlockEntity.S_OPEN] + 1) % 3;
            b.setMessage(openText());
        }).bounds(leftPos + 100, topPos + 146, 84, 16).build();
        addRenderableWidget(openButton);
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.spawner_test"),
                b -> send(true)).bounds(leftPos + 199, topPos + 44, 164, 16).build());
    }

    private Component openText() {
        return Component.translatable("gui.coastercontrolpanel.spawner_open." + v[GuestSpawnerBlockEntity.S_OPEN]);
    }

    private void change(int index, int dir) {
        int step = STEP[index] * (Screen.hasShiftDown() && index != GuestSpawnerBlockEntity.S_CHANNEL ? 5 : 1);
        v[index] = Math.max(GuestSpawnerBlockEntity.MIN[index],
                Math.min(GuestSpawnerBlockEntity.MAX[index], v[index] + dir * step));
    }

    private void send(boolean spawnOne) {
        PacketDistributor.sendToServer(new GuestSpawnerConfigPacket(menu.getPos(), v.clone(), spawnOne));
    }

    @Override
    public void removed() {
        send(false);
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 190, y0 + 4, x0 + 191, y0 + imageHeight - 4, 0xFF3A3E4D);
        // the check box under the settings
        g.fill(x0 + 6, y0 + 168, x0 + 184, y0 + 206, 0xFF3A3E4D);
        g.fill(x0 + 7, y0 + 169, x0 + 183, y0 + 205, 0xFF12141A);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    private String valueText(int index) {
        int val = v[index];
        return switch (index) {
            case GuestSpawnerBlockEntity.S_RATE -> val + " / min";
            case GuestSpawnerBlockEntity.S_SPEED, GuestSpawnerBlockEntity.S_KIDS -> val + "%";
            case GuestSpawnerBlockEntity.S_RIDE -> val + " s";
            default -> String.valueOf(val);
        };
    }

    private void tick(GuiGraphics g, String label, int count, boolean needed, int y) {
        boolean ok = count > 0;
        int colour = ok ? 0xFF6FE08A : (needed ? 0xFFE07070 : 0xFF6A6F80);
        g.fill(12, y + 1, 18, y + 7, colour);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner_found." + label, count), 24, y,
                0xE0E4F0, false);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int dim = 0x7A8098;
        int text = 0xE0E4F0;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        for (int row = 0; row < ROWS.length; row++) {
            int y = 26 + row * 20;
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner." + NAMES[row]), 8, y, text, false);
            g.drawCenteredString(font, valueText(ROWS[row]), 142, y, 0xFFFFFF);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner.open"), 8, 150, text, false);

        GuestSpawnerBlockEntity e = minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof GuestSpawnerBlockEntity s ? s : null;
        int queues = e == null ? 0 : e.getQueueMarkers();
        int stations = e == null ? 0 : e.getStationMarkers();
        int exits = e == null ? 0 : e.getExitMarkers();
        tick(g, "queue", queues, true, 174);
        tick(g, "station", stations, false, 185);
        tick(g, "exit", exits, false, 196);

        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner.link"), 199, 24, text, false);
        boolean open = e != null && e.isOpen();
        g.drawString(font, Component.translatable(open ? "gui.coastercontrolpanel.spawner_state_open"
                : "gui.coastercontrolpanel.spawner_state_closed"), 199, 66, open ? 0x6FE08A : 0xE07070, false);
        int guests = e == null ? 0 : e.getGuests();
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner_guests", guests, v[GuestSpawnerBlockEntity.S_MAX]),
                199, 78, text, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner_hint1"), 199, 94, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.spawner_hint2"), 199, 104, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 199, 118, dim, false);
    }
}
