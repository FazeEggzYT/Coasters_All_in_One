package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.equipment.wrench.WrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * The operator's panel. Six buttons on the top face:
 * <pre>
 *   Station 1 | Station 2
 *   Restraints| E-STOP
 *   Entrance  | Exit
 * </pre>
 * Right-click a button to press it. Right-click with a Create wrench to open the setup screen.
 */
public class PanelBlock extends BaseEntityBlock {
    public static final MapCodec<PanelBlock> CODEC = simpleCodec(PanelBlock::new);

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty[] LIT = new BooleanProperty[PanelBlockEntity.ROWS];

    static {
        for (int i = 0; i < LIT.length; i++) {
            LIT[i] = BooleanProperty.create("lit_" + i);
        }
    }

    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 10, 16);

    public PanelBlock(Properties properties) {
        super(properties);
        BlockState state = this.stateDefinition.any().setValue(FACING, Direction.NORTH);
        for (BooleanProperty p : LIT) {
            state = state.setValue(p, false);
        }
        registerDefaultState(state);
    }

    public static int lightFor(BlockState state) {
        for (BooleanProperty p : LIT) {
            if (state.getValue(p)) {
                return 5;
            }
        }
        return 0;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
        builder.add(LIT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PanelBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return createTickerHelper(type, CoasterControlPanel.PANEL_BE.get(),
                (lvl, pos, st, be) -> be.serverTick());
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof PanelBlockEntity panel)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        // Wrench: open the setup screen.
        if (stack.getItem() instanceof WrenchItem) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                sp.openMenu(new SimpleMenuProvider(
                                (id, inv, p) -> new PanelMenu(id, inv, panel.getFrequencies(), pos),
                                Component.translatable("gui.coastercontrolpanel.title")),
                        buf -> buf.writeBlockPos(pos));
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        // Anything else: try to press a button.
        if (hit.getDirection() != Direction.UP) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        int index = buttonAt(state.getValue(FACING), hit.getLocation().subtract(pos.getX(), pos.getY(), pos.getZ()));
        if (index < 0) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            level.playSound(null, pos, SoundEvents.STONE_BUTTON_CLICK_ON, SoundSource.BLOCKS, 0.4F, 0.7F);
            panel.press(index, player);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Which button (0-5) is under the hit point, or -1. */
    static int buttonAt(Direction facing, Vec3 local) {
        double x = local.x;
        double z = local.z;
        double x0;
        double z0;
        switch (facing) {
            case EAST -> {
                x0 = z;
                z0 = 1 - x;
            }
            case SOUTH -> {
                x0 = 1 - x;
                z0 = 1 - z;
            }
            case WEST -> {
                x0 = 1 - z;
                z0 = x;
            }
            default -> {
                x0 = x;
                z0 = z;
            }
        }
        double[] colX = {0.75, 0.25};
        double[] rowZ = {13.33 / 16.0, 0.5, 2.67 / 16.0};
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 2; col++) {
                if (Math.abs(x0 - colX[col]) <= 0.22 && Math.abs(z0 - rowZ[row]) <= 0.16) {
                    return row * 2 + col;
                }
            }
        }
        return -1;
    }
}
