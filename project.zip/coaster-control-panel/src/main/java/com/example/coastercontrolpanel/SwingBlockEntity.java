package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * The engine of a Swing Ride. Two Create moving structures are used: the arm (Pivot Head + Arm pieces) turns around the
 * pivot's axis, and the gondola (Hub + Frames + seats) is carried along the end of the arm while it turns around the
 * same axis on its own.
 */
public class SwingBlockEntity extends BlockEntity implements IControlContraption, RideEngine {
    public SwingSettings cfg = new SwingSettings();
    public final SwingMotion motion = new SwingMotion();

    @Nullable
    private ControlledContraptionEntity arm;
    @Nullable
    private ControlledContraptionEntity gondola;
    @Nullable
    private ControlledContraptionEntity arm2;
    @Nullable
    private ControlledContraptionEntity gondola2;
    private BlockPos pivot2 = BlockPos.ZERO;
    private BlockPos hub2 = BlockPos.ZERO;
    /** True when a second Pivot Head sits on the same axle: its arm swings the opposite way, like Rush. */
    private boolean twin;
    private BlockPos pivot = BlockPos.ZERO;
    private BlockPos hub = BlockPos.ZERO;
    private Direction.Axis axis = Direction.Axis.X;
    private int preTicks;
    private int orphanTicks;
    private int syncTicks;
    private boolean lastPower;
    private final RideLinks links = new RideLinks(this);
    private boolean justFinished;
    private int lastPhase;
    private int lastStep = -1;

    /** Client: swing numbers received from the server, for the screen and for moving the structures. */
    public float theta;
    private float spinAngle;
    private boolean stateSeen;
    private boolean needRestore;

    public SwingBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SWING_BE.get(), pos, state);
        if (state.is(CoasterControlPanel.PIRATE_BASE_BLOCK.get())) {
            cfg.preset(4);
        } else if (state.is(CoasterControlPanel.GYRO_BASE_BLOCK.get())) {
            cfg.preset(8);
        }
    }

    /** True when this engine belongs to a Pirate Ship: the boat is fixed to the arm and never spins. */
    public boolean isPirate() {
        return getBlockState().is(CoasterControlPanel.PIRATE_BASE_BLOCK.get());
    }

    /** True when this engine belongs to a Gyro Swing: the ring spins in the plane of the swing. */
    public boolean isGyro() {
        return getBlockState().is(CoasterControlPanel.GYRO_BASE_BLOCK.get());
    }

    private int gondolaMode() {
        return isPirate() ? 0 : cfg.gondolaMode;
    }

    // ---- IControlContraption

    private static boolean isArm(ControlledContraptionEntity e) {
        return e.getContraption() != null && SwingCarriage.isArm(e.getContraption());
    }

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return contraption == arm || contraption == gondola || contraption == arm2 || contraption == gondola2;
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        boolean second = twin && contraption.getContraption() != null;
        BlockPos anchor = contraption.getContraption() != null ? contraption.getContraption().anchor : BlockPos.ZERO;
        if (isArm(contraption)) {
            if (second && anchor.equals(pivot2)) {
                arm2 = contraption;
            } else {
                arm = contraption;
            }
        } else if (second && anchor.equals(hub2)) {
            gondola2 = contraption;
        } else {
            gondola = contraption;
        }
        contraption.setRotationAxis(axis);
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && motion.phase == SwingMotion.RUNNING) {
            motion.halt();
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    /** Runs every server tick, also while the ride stands still: reads the three inputs, drives the two outputs. */
    private void pollLinks() {
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.HALT) && !idle()) {
            control(ACTION_HALT);
        }
        links.tickOutputs(!idle(), motion.phase == SwingMotion.HALTED);
        justFinished = false;
    }

    // ---- controls

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return motion.phase == SwingMotion.IDLE;
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        if (!idle()) {
            return;
        }
        cfg = SwingSettings.fromTag(tag);
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> startRide();
            case ACTION_PAUSE -> {
                if (motion.phase == SwingMotion.COUNTDOWN) {
                    motion.phase = SwingMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.togglePause();
                }
            }
            case ACTION_END -> {
                if (motion.phase == SwingMotion.COUNTDOWN) {
                    motion.phase = SwingMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.end(cfg);
                }
            }
            case ACTION_HALT -> motion.halt();
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        redstone(level.hasNeighborSignal(worldPosition) || DropTowerBlocks.controllerPowered(level, worldPosition) || links.on(RideLinks.START));
    }

    public void redstone(boolean power) {
        if (power == lastPower) {
            return;
        }
        lastPower = power;
        if (power && idle()) {
            control(ACTION_START);
        } else if (!power && cfg.redstoneMode == 1 && !idle()) {
            control(ACTION_END);
        }
    }

    private void startRide() {
        if (!idle() || level == null) {
            return;
        }
        BlockPos p = SwingBlocks.findPivot(level, worldPosition);
        if (p == null) {
            tell("no_pivot");
            return;
        }
        int arms = armLength(p);
        if (arms <= 0) {
            tell("no_arm");
            return;
        }
        if (!(level.getBlockState(p.below(arms + 1)).getBlock() instanceof SwingBlocks.HubBlock)) {
            tell("no_hub");
            return;
        }
        preTicks = Math.round(cfg.preDelay * 20.0F);
        motion.phase = SwingMotion.COUNTDOWN;
        if (preTicks <= 0) {
            beginRide();
        } else {
            tell("starting");
        }
    }

    /** Another Pivot Head on the same axle (same height, same direction), at least three blocks away. */
    @Nullable
    private BlockPos findTwin(BlockPos p, Direction.Axis ax) {
        if (level == null) {
            return null;
        }
        Direction dir = Direction.fromAxisAndDirection(ax, Direction.AxisDirection.POSITIVE);
        for (int sign = -1; sign <= 1; sign += 2) {
            for (int k = 3; k <= SwingBlocks.REACH; k++) {
                BlockPos q = p.relative(dir, k * sign);
                BlockState st = level.getBlockState(q);
                if (st.getBlock() instanceof SwingBlocks.PivotBlock && st.getValue(SwingBlocks.PivotBlock.AXIS) == ax) {
                    return q;
                }
            }
        }
        return null;
    }

    private int armLength(BlockPos p) {
        int n = 0;
        BlockPos q = p.below();
        while (n < 64 && level != null && level.getBlockState(q).getBlock() instanceof SwingBlocks.ArmBlock) {
            n++;
            q = q.below();
        }
        return n;
    }

    // ---- assembling

    private void beginRide() {
        if (level == null) {
            return;
        }
        BlockPos p = SwingBlocks.findPivot(level, worldPosition);
        if (p == null) {
            motion.phase = SwingMotion.IDLE;
            tell("no_pivot");
            return;
        }
        int arms = armLength(p);
        BlockPos h = p.below(arms + 1);
        if (arms <= 0 || !(level.getBlockState(h).getBlock() instanceof SwingBlocks.HubBlock)) {
            motion.phase = SwingMotion.IDLE;
            tell(arms <= 0 ? "no_arm" : "no_hub");
            return;
        }
        Direction.Axis ax = level.getBlockState(p).getValue(SwingBlocks.PivotBlock.AXIS);
        SwingCarriage.Part armPart = new SwingCarriage.Part();
        SwingCarriage.Part gondolaPart = new SwingCarriage.Part();
        try {
            if (!armPart.assemble(level, p) || armPart.getBlocks().isEmpty()) {
                motion.phase = SwingMotion.IDLE;
                tell("empty");
                return;
            }
            // look at the gondola before the arm is taken out of the world
            SwingCarriage.Carry.begin(cfg.carryAll, h, 7, 7, 7);
            try {
                if (!gondolaPart.assemble(level, h) || gondolaPart.getBlocks().isEmpty()) {
                    motion.phase = SwingMotion.IDLE;
                    tell("empty");
                    return;
                }
            } finally {
                SwingCarriage.Carry.end();
            }
        } catch (AssemblyException e) {
            motion.phase = SwingMotion.IDLE;
            for (ServerPlayer sp : nearby()) {
                sp.displayClientMessage(e.component, true);
            }
            return;
        }
        if (gondolaPart.getBlocks().size() < 1) {
            motion.phase = SwingMotion.IDLE;
            return;
        }
        // a second Pivot Head on the same axle gets its own arm and gondola, swinging the other way
        BlockPos p2 = findTwin(p, ax);
        SwingCarriage.Part armPart2 = null;
        SwingCarriage.Part gondolaPart2 = null;
        BlockPos h2 = BlockPos.ZERO;
        if (p2 != null) {
            int arms2 = armLength(p2);
            h2 = p2.below(arms2 + 1);
            if (arms2 > 0 && level.getBlockState(h2).getBlock() instanceof SwingBlocks.HubBlock) {
                try {
                    armPart2 = new SwingCarriage.Part();
                    gondolaPart2 = new SwingCarriage.Part();
                    if (!armPart2.assemble(level, p2) || armPart2.getBlocks().isEmpty()) {
                        armPart2 = null;
                    } else {
                        SwingCarriage.Carry.begin(cfg.carryAll, h2, 7, 7, 7);
                        try {
                            if (!gondolaPart2.assemble(level, h2) || gondolaPart2.getBlocks().isEmpty()) {
                                armPart2 = null;
                            }
                        } finally {
                            SwingCarriage.Carry.end();
                        }
                    }
                } catch (AssemblyException e) {
                    armPart2 = null;
                }
            }
        }
        armPart.removeBlocksFromWorld(level, BlockPos.ZERO);
        gondolaPart.removeBlocksFromWorld(level, BlockPos.ZERO);
        twin = armPart2 != null && gondolaPart2 != null;
        if (twin) {
            armPart2.removeBlocksFromWorld(level, BlockPos.ZERO);
            gondolaPart2.removeBlocksFromWorld(level, BlockPos.ZERO);
            pivot2 = p2;
            hub2 = h2;
        }
        pivot = p;
        hub = h;
        axis = ax;
        arm = ControlledContraptionEntity.create(level, this, armPart);
        arm.setRotationAxis(ax);
        arm.setPos(p.getX(), p.getY(), p.getZ());
        level.addFreshEntity(arm);
        gondola = ControlledContraptionEntity.create(level, this, gondolaPart);
        gondola.setRotationAxis(ax);
        gondola.setPos(h.getX(), h.getY(), h.getZ());
        level.addFreshEntity(gondola);
        if (twin) {
            arm2 = ControlledContraptionEntity.create(level, this, armPart2);
            arm2.setRotationAxis(ax);
            arm2.setPos(p2.getX(), p2.getY(), p2.getZ());
            level.addFreshEntity(arm2);
            gondola2 = ControlledContraptionEntity.create(level, this, gondolaPart2);
            gondola2.setRotationAxis(ax);
            gondola2.setPos(h2.getX(), h2.getY(), h2.getZ());
            level.addFreshEntity(gondola2);
        }
        motion.start(cfg.period > 0 ? cfg.period : SwingMotion.autoPeriod(arms + 1));
        orphanTicks = 0;
        syncNow();
    }

    /** Puts both structures back as blocks where they started. */
    void landAll() {
        if (level != null && !level.isClientSide) {
            if (arm != null) {
                arm.setAngle(0);
                arm.setPos(pivot.getX(), pivot.getY(), pivot.getZ());
                arm.setContraptionMotion(Vec3.ZERO);
            }
            if (gondola != null) {
                gondola.setAngle(0);
                gondola.setPos(hub.getX(), hub.getY(), hub.getZ());
                gondola.setContraptionMotion(Vec3.ZERO);
            }
            if (arm2 != null) {
                arm2.setAngle(0);
                arm2.setPos(pivot2.getX(), pivot2.getY(), pivot2.getZ());
                arm2.setContraptionMotion(Vec3.ZERO);
            }
            if (gondola2 != null) {
                gondola2.setAngle(0);
                gondola2.setPos(hub2.getX(), hub2.getY(), hub2.getZ());
                gondola2.setContraptionMotion(Vec3.ZERO);
            }
            if (arm != null) {
                arm.disassemble();
                arm.discard();
            }
            if (gondola != null) {
                gondola.disassemble();
                gondola.discard();
            }
            if (arm2 != null) {
                arm2.disassemble();
                arm2.discard();
            }
            if (gondola2 != null) {
                gondola2.disassemble();
                gondola2.discard();
            }
        }
        arm = null;
        gondola = null;
        arm2 = null;
        gondola2 = null;
        twin = false;
        motion.phi = 0;
        motion.amp = 0;
        motion.spin = 0;
        motion.spinRate = 0;
    }

    // ---- placing the two structures for the current numbers (used on both sides)

    private void place(double thetaDeg, double spinDeg, int gondolaMode, boolean server) {
        placePair(arm, gondola, pivot, hub, thetaDeg, spinDeg, gondolaMode);
        if (twin) {
            placePair(arm2, gondola2, pivot2, hub2, -thetaDeg, -spinDeg, gondolaMode);
        }
    }

    private void placePair(@Nullable ControlledContraptionEntity a, @Nullable ControlledContraptionEntity g, BlockPos pv, BlockPos hb,
                           double thetaDeg, double spinDeg, int gondolaMode) {
        if (a == null || g == null || !a.isAlive() || !g.isAlive()) {
            return;
        }
        a.setRotationAxis(axis);
        g.setRotationAxis(axis);
        a.setAngle((float) thetaDeg);
        Vec3 pivotCentre = Vec3.atCenterOf(pv);
        Vec3 offset = Vec3.atCenterOf(hb).subtract(pivotCentre);
        Vec3 hubCentre = pivotCentre.add(a.applyRotation(offset, 1.0F));
        double dx = hubCentre.x - 0.5 - g.getX();
        double dy = hubCentre.y - 0.5 - g.getY();
        double dz = hubCentre.z - 0.5 - g.getZ();
        if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) > 1.0E-7) {
            g.setContraptionMotion(new Vec3(dx, dy, dz));
            g.move(dx, dy, dz);
        }
        g.setAngle((float) ((gondolaMode == 0 ? thetaDeg : 0.0) + spinDeg));
    }

    // ---- client side

    public void receiveState(float th, float spin, int phase, BlockPos p, BlockPos h, int ax, int mode, boolean tw, BlockPos p2, BlockPos h2) {
        twin = tw;
        pivot2 = p2;
        hub2 = h2;
        theta = th;
        spinAngle = spin;
        motion.phase = phase;
        pivot = p;
        hub = h;
        axis = ax == 2 ? Direction.Axis.Z : Direction.Axis.X;
        cfg.gondolaMode = mode;
        stateSeen = true;
    }

    public void clientTick() {
        if (!stateSeen || motion.phase == SwingMotion.IDLE) {
            return;
        }
        place(theta, spinAngle, gondolaMode(), false);
    }

    // ---- ticking (server)

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        pollLinks();
        if (needRestore) {
            needRestore = false;
            motion.restoreAfterLoad(cfg);
        }
        if (motion.phase == SwingMotion.IDLE) {
            return;
        }
        if (motion.phase == SwingMotion.COUNTDOWN) {
            if (--preTicks <= 0) {
                beginRide();
            }
            return;
        }
        if (arm == null || gondola == null || !arm.isAlive() || !gondola.isAlive()
                || (twin && (arm2 == null || gondola2 == null || !arm2.isAlive() || !gondola2.isAlive()))) {
            if (++orphanTicks > 200) {
                motion.phase = SwingMotion.IDLE;
                arm = null;
                gondola = null;
                arm2 = null;
                gondola2 = null;
                twin = false;
                tell("lost");
                syncNow();
            }
            return;
        }
        orphanTicks = 0;
        motion.tick(cfg, 1.0 / 20.0);
        if (motion.landed) {
            landAll();
            motion.landed = false;
            justFinished = true;
            tell("finished");
            syncNow();
            return;
        }
        theta = (float) motion.theta();
        spinAngle = (float) motion.spin;
        place(theta, spinAngle, gondolaMode(), true);
        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                new SwingStatePacket(worldPosition, theta, spinAngle, motion.phase, pivot.asLong(), hub.asLong(),
                        axis == Direction.Axis.Z ? 2 : 0, gondolaMode(), twin, pivot2.asLong(), hub2.asLong()));
        if (motion.phase == SwingMotion.PAUSED && motion.finished && lastPhase != motion.phase) {
            tell("waiting_end");
        }
        if (motion.phase != lastPhase || motion.stepIndex != lastStep || ++syncTicks >= 10) {
            lastPhase = motion.phase;
            lastStep = motion.stepIndex;
            syncNow();
        }
    }

    private java.util.List<ServerPlayer> nearby() {
        if (level == null) {
            return java.util.List.of();
        }
        return ((ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 900.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.swing." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** The base was broken mid-ride: the arm and gondola are put down where they are. */
    public void baseRemoved() {
        if (level != null && !level.isClientSide && (arm != null || gondola != null || arm2 != null || gondola2 != null)) {
            landAll();
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putInt("Phase", motion.phase);
        tag.putInt("Step", motion.stepIndex);
        tag.putInt("Loop", motion.loop);
        tag.putDouble("Phi", motion.phi);
        tag.putDouble("Amp", motion.amp);
        tag.putDouble("Rate", motion.rateFactor);
        tag.putDouble("SpinRate", motion.spinRate);
        tag.putDouble("Spin", motion.spin);
        tag.putDouble("Period", motion.period);
        tag.putBoolean("Finished", motion.finished);
        tag.putLong("Pivot", pivot.asLong());
        tag.putLong("Hub", hub.asLong());
        tag.putBoolean("Twin", twin);
        tag.putLong("Pivot2", pivot2.asLong());
        tag.putLong("Hub2", hub2.asLong());
        tag.putInt("Axis", axis == Direction.Axis.Z ? 2 : 0);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = SwingSettings.fromTag(tag.getCompound("Cfg"));
        motion.phase = tag.getInt("Phase");
        motion.stepIndex = tag.getInt("Step");
        motion.loop = tag.getInt("Loop");
        motion.phi = tag.getDouble("Phi");
        motion.amp = tag.getDouble("Amp");
        motion.rateFactor = tag.contains("Rate") ? tag.getDouble("Rate") : 1.0;
        motion.spinRate = tag.getDouble("SpinRate");
        motion.spin = tag.getDouble("Spin");
        motion.period = tag.contains("Period") ? tag.getDouble("Period") : 5.0;
        motion.finished = tag.getBoolean("Finished");
        pivot = BlockPos.of(tag.getLong("Pivot"));
        hub = BlockPos.of(tag.getLong("Hub"));
        twin = tag.getBoolean("Twin");
        pivot2 = BlockPos.of(tag.getLong("Pivot2"));
        hub2 = BlockPos.of(tag.getLong("Hub2"));
        axis = tag.getInt("Axis") == 2 ? Direction.Axis.Z : Direction.Axis.X;
        links.load(tag, registries);
        needRestore = true;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
