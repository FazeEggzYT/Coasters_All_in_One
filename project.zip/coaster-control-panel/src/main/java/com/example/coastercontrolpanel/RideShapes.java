package com.example.coastercontrolpanel;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The block layouts of the premade rides, as plain numbers (no Minecraft types) so they can be checked on their own. */
public final class RideShapes {
    private RideShapes() {
    }

    /** A Ferris Wheel in a plane: u across, v up, centre of the axle at 0,0. */
    public static final class Ferris {
        public final int radius;
        public final int cabins;
        public final int hubRadius;
        public final Set<Long> rim = new LinkedHashSet<>();
        public final Set<Long> spokes = new LinkedHashSet<>();
        public final Set<Long> hangers = new LinkedHashSet<>();
        public final List<int[]> hubs = new ArrayList<>();

        Ferris(int radius, int cabins) {
            this.radius = radius;
            this.cabins = cabins;
            this.hubRadius = radius + 5;
        }
    }

    public static long key(int u, int v) {
        return ((long) u << 32) ^ (v & 0xFFFFFFFFL);
    }

    public static int ku(long k) {
        return (int) (k >> 32);
    }

    public static int kv(long k) {
        return (int) k;
    }

    /** Cells of a four-connected line (no diagonal steps), both ends included. */
    public static List<int[]> line(int x0, int y0, int x1, int y1) {
        List<int[]> out = new ArrayList<>();
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = Integer.compare(x1, x0);
        int sy = Integer.compare(y1, y0);
        int x = x0;
        int y = y0;
        int err = dx - dy;
        out.add(new int[]{x, y});
        while (x != x1 || y != y1) {
            int e2 = 2 * err;
            boolean mx = e2 > -dy && x != x1;
            boolean my = e2 < dx && y != y1;
            if (mx) {
                err -= dy;
                x += sx;
                out.add(new int[]{x, y});
            }
            if (my) {
                err += dx;
                y += sy;
                out.add(new int[]{x, y});
            }
        }
        return out;
    }

    /** Cabin 0 hangs at the bottom; the others follow evenly around. */
    public static Ferris ferris(int radius, int cabins) {
        Ferris f = new Ferris(radius, cabins);
        int steps = (int) Math.ceil(Math.PI * 8 * radius);
        int[] prev = null;
        for (int i = 0; i <= steps; i++) {
            double a = 2 * Math.PI * i / steps;
            int[] c = {(int) Math.round(radius * Math.cos(a)), (int) Math.round(radius * Math.sin(a))};
            if (prev != null && (prev[0] != c[0] || prev[1] != c[1])) {
                for (int[] p : line(prev[0], prev[1], c[0], c[1])) {
                    f.rim.add(key(p[0], p[1]));
                }
            } else if (prev == null) {
                f.rim.add(key(c[0], c[1]));
            }
            prev = c;
        }
        for (int i = 0; i < cabins; i++) {
            double a = 2 * Math.PI * i / cabins;
            double du = Math.sin(a);
            double dv = -Math.cos(a);
            int[] tip = {(int) Math.round(radius * du), (int) Math.round(radius * dv)};
            for (int[] p : line(0, 0, tip[0], tip[1])) {
                if (p[0] != 0 || p[1] != 0) {
                    f.spokes.add(key(p[0], p[1]));
                }
            }
            int[] hub = {(int) Math.round(f.hubRadius * du), (int) Math.round(f.hubRadius * dv)};
            f.hubs.add(hub);
            int[] from = {(int) Math.round((radius + 1) * du), (int) Math.round((radius + 1) * dv)};
            int[] to = {(int) Math.round((f.hubRadius - 3.2) * du), (int) Math.round((f.hubRadius - 3.2) * dv)};
            for (int[] p : line(from[0], from[1], to[0], to[1])) {
                if (Math.abs(p[0] - hub[0]) > 2 || Math.abs(p[1] - hub[1]) > 2) {
                    f.hangers.add(key(p[0], p[1]));
                }
            }
        }
        // keep only hanger cells that really connect to the wheel, so nothing is left behind when the wheel is lifted
        Set<Long> wheel = new LinkedHashSet<>(f.rim);
        wheel.addAll(f.spokes);
        wheel.addAll(f.hangers);
        wheel.add(key(0, 0));
        Set<Long> seen = new LinkedHashSet<>();
        List<Long> queue = new ArrayList<>();
        queue.add(key(0, 0));
        seen.add(key(0, 0));
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int i = 0; i < queue.size(); i++) {
            long k = queue.get(i);
            for (int[] d : dirs) {
                long n = key(ku(k) + d[0], kv(k) + d[1]);
                if (wheel.contains(n) && seen.add(n)) {
                    queue.add(n);
                }
            }
        }
        f.hangers.retainAll(seen);
        return f;
    }
}
