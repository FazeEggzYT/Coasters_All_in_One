package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: names, modes, seconds and colours typed into the setup screen. */
public record ConfigPacket(BlockPos pos, String[] names, int[] modes, int[] seconds, int[] colors, String ride)
        implements CustomPacketPayload {
    public static final Type<ConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ConfigPacket> CODEC =
            StreamCodec.of(ConfigPacket::write, ConfigPacket::read);

    private static void write(RegistryFriendlyByteBuf buf, ConfigPacket p) {
        buf.writeBlockPos(p.pos);
        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            buf.writeUtf(p.names[r], 32);
            buf.writeVarInt(p.modes[r]);
            buf.writeVarInt(p.seconds[r]);
            buf.writeVarInt(p.colors[r]);
        }
        buf.writeUtf(p.ride, 64);
    }

    private static ConfigPacket read(RegistryFriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        String[] names = new String[PanelBlockEntity.ROWS];
        int[] modes = new int[PanelBlockEntity.ROWS];
        int[] seconds = new int[PanelBlockEntity.ROWS];
        int[] colors = new int[PanelBlockEntity.ROWS];
        for (int r = 0; r < PanelBlockEntity.ROWS; r++) {
            names[r] = buf.readUtf(32);
            modes[r] = buf.readVarInt();
            seconds[r] = buf.readVarInt();
            colors[r] = buf.readVarInt();
        }
        String ride = buf.readUtf(64);
        return new ConfigPacket(pos, names, modes, seconds, colors, ride);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ConfigPacket packet, IPayloadContext context) {
        PanelBlockEntity panel = PanelBlockEntity.lookup(context.player(), packet.pos);
        if (panel != null) {
            panel.applyConfig(packet.names, packet.modes, packet.seconds, packet.colors, packet.ride);
        }
    }
}
