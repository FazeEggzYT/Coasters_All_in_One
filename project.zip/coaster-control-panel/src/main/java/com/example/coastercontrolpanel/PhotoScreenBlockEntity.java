package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/** Remembers which camera it is linked to and which photo version it should show. */
public class PhotoScreenBlockEntity extends BlockEntity {
    /** What the renderer needs to know about the wall this screen is part of. */
    public record Wall(@Nullable BlockPos camera, int version, int col, int cols, int row, int rows) {
    }

    @Nullable
    private BlockPos camera;
    private int version = 0;

    private Wall wall;
    private long wallTime = -1000;

    public PhotoScreenBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.PHOTO_SCREEN_BE.get(), pos, state);
    }

    @Nullable
    public BlockPos getCamera() {
        return camera;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
        sync();
    }

    /** Link to a camera (server side). */
    public void link(@Nullable BlockPos newCamera) {
        if (level == null || level.isClientSide) {
            return;
        }
        if (camera != null && level.getBlockEntity(camera) instanceof CameraBlockEntity old) {
            old.removeScreen(worldPosition);
        }
        camera = newCamera;
        version = 0;
        if (camera != null && level.getBlockEntity(camera) instanceof CameraBlockEntity cam) {
            cam.addScreen(worldPosition);
            version = cam.getVersion();
        }
        sync();
    }

    @Override
    public void setRemoved() {
        if (level != null && !level.isClientSide && camera != null
                && level.getBlockEntity(camera) instanceof CameraBlockEntity cam) {
            cam.removeScreen(worldPosition);
        }
        super.setRemoved();
    }

    private void sync() {
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---------------------------------------------------------------- the wall (client side)

    /**
     * Finds all connected screens that face the same way, and where this one sits in them.
     * The picture is taken from the first linked screen of the wall. Refreshed about once a second.
     */
    @Nullable
    public Wall wall() {
        if (level == null) {
            return null;
        }
        long now = level.getGameTime();
        if (wall != null && now - wallTime < 20) {
            return wall;
        }
        wallTime = now;
        Direction facing = getBlockState().getValue(PhotoScreenBlock.FACING);
        Direction right = facing.getCounterClockWise();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> todo = new ArrayDeque<>();
        todo.add(worldPosition);
        seen.add(worldPosition);
        int minDot = Integer.MAX_VALUE;
        int maxDot = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE;
        PhotoScreenBlockEntity source = null;
        Direction[] steps = {right, right.getOpposite(), Direction.UP, Direction.DOWN};
        while (!todo.isEmpty() && seen.size() < 400) {
            BlockPos p = todo.poll();
            int dot = p.getX() * right.getStepX() + p.getZ() * right.getStepZ();
            minDot = Math.min(minDot, dot);
            maxDot = Math.max(maxDot, dot);
            maxY = Math.max(maxY, p.getY());
            minY = Math.min(minY, p.getY());
            if (level.getBlockEntity(p) instanceof PhotoScreenBlockEntity ps && ps.camera != null
                    && (source == null || p.asLong() < source.worldPosition.asLong())) {
                source = ps;
            }
            for (Direction d : steps) {
                BlockPos n = p.relative(d);
                if (seen.contains(n)) {
                    continue;
                }
                BlockState s = level.getBlockState(n);
                if (s.getBlock() instanceof PhotoScreenBlock && s.getValue(PhotoScreenBlock.FACING) == facing) {
                    seen.add(n);
                    todo.add(n);
                }
            }
        }
        int myDot = worldPosition.getX() * right.getStepX() + worldPosition.getZ() * right.getStepZ();
        wall = new Wall(source == null ? null : source.camera, source == null ? 0 : source.version,
                myDot - minDot, maxDot - minDot + 1, maxY - worldPosition.getY(), maxY - minY + 1);
        return wall;
    }

    // ---------------------------------------------------------------- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (camera != null) {
            tag.putLong("Camera", camera.asLong());
        }
        tag.putInt("Version", version);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        camera = tag.contains("Camera") ? BlockPos.of(tag.getLong("Camera")) : null;
        version = tag.getInt("Version");
        wallTime = -1000;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
