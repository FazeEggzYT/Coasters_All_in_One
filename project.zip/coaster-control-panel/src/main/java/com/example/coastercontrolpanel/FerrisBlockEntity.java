package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The engine of a Ferris Wheel. The wheel (Axle Hub, Spokes and Rim) is one Create moving structure turning around the
 * axle. Every cabin (a Cabin Hub with its frames and seats) is a moving structure of its own that is carried around on
 * the wheel but never turned, so it stays level.
 */
public class FerrisBlockEntity extends BlockEntity implements IControlContraption, RideEngine {
    public FerrisSettings cfg = new FerrisSettings();
    public final FerrisMotion motion = new FerrisMotion();

    @Nullable
    private ControlledContraptionEntity wheel;
    /** Cabin structures by the block position of their hub before the ride. */
    private final Map<BlockPos, ControlledContraptionEntity> cabins = new HashMap<>();
    private BlockPos axle = BlockPos.ZERO;
    private Direction.Axis axis = Direction.Axis.Z;
    private int preTicks;
    private int orphanTicks;
    private int syncTicks;
    private int expectedCabins;
    private boolean lastPower;
    private final RideLinks links = new RideLinks(this);
    private boolean justFinished;
    private int lastPhase;
    private int lastStep = -1;
    private boolean needRestore;

    /** Shown angle in degrees (direction applied) and the cabin at the bottom, for the screen and for the client. */
    public float shownAngle;
    public int station = -1;
    private boolean stateSeen;

    public FerrisBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.FERRIS_BE.get(), pos, state);
    }

    // ---- IControlContraption

    private static boolean isWheel(ControlledContraptionEntity e) {
        return e.getContraption() != null && SwingCarriage.isWheel(e.getContraption());
    }

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return contraption == wheel || cabins.containsValue(contraption);
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        if (isWheel(contraption)) {
            wheel = contraption;
        } else if (contraption.getContraption() != null && contraption.getContraption().anchor != null) {
            cabins.put(contraption.getContraption().anchor, contraption);
        }
        contraption.setRotationAxis(axis);
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && motion.phase == FerrisMotion.RUNNING) {
            motion.halt();
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    private void pollLinks() {
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.END) && !idle()) {
            control(ACTION_END);
        }
        if (links.rising(RideLinks.HALT) && !idle()) {
            control(ACTION_HALT);
        }
        links.tickOutputs(!idle(), justFinished);
        justFinished = false;
    }

    // ---- controls

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return motion.phase == FerrisMotion.IDLE;
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        if (!idle()) {
            return;
        }
        cfg = FerrisSettings.fromTag(tag);
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> startRide();
            case ACTION_PAUSE -> {
                if (motion.phase == FerrisMotion.COUNTDOWN) {
                    motion.phase = FerrisMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.togglePause();
                }
            }
            case ACTION_END -> {
                if (motion.phase == FerrisMotion.COUNTDOWN) {
                    motion.phase = FerrisMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.end(cfg);
                }
            }
            case ACTION_HALT -> motion.halt();
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        redstone(level.hasNeighborSignal(worldPosition) || DropTowerBlocks.controllerPowered(level, worldPosition) || links.on(RideLinks.START));
    }

    public void redstone(boolean power) {
        if (power == lastPower) {
            return;
        }
        lastPower = power;
        if (power && idle()) {
            control(ACTION_START);
        } else if (!power && cfg.redstoneMode == 1 && !idle()) {
            control(ACTION_END);
        }
    }

    private void startRide() {
        if (!idle() || level == null) {
            return;
        }
        BlockPos a = FerrisBlocks.findAxle(level, worldPosition);
        if (a == null) {
            tell("no_axle");
            return;
        }
        if (findCabins(a).isEmpty()) {
            tell("no_cabin");
            return;
        }
        preTicks = Math.round(cfg.preDelay * 20.0F);
        motion.phase = FerrisMotion.COUNTDOWN;
        if (preTicks <= 0) {
            beginRide();
        } else {
            tell("starting");
        }
    }

    /** Cabin Hubs around the axle in the plane of the wheel (up to one block either side). */
    private List<BlockPos> findCabins(BlockPos a) {
        List<BlockPos> out = new ArrayList<>();
        if (level == null) {
            return out;
        }
        Direction.Axis ax = level.getBlockState(a).getValue(FerrisBlocks.WheelPart.AXIS);
        int span = 30;
        BlockPos lo = a.offset(-span, -span, -span);
        BlockPos hi = a.offset(span, span, span);
        for (BlockPos p : BlockPos.betweenClosed(lo, hi)) {
            if (level.getBlockState(p).getBlock() instanceof FerrisBlocks.HubBlock) {
                int along = ax == Direction.Axis.X ? p.getX() - a.getX() : p.getZ() - a.getZ();
                if (Math.abs(along) <= 1) {
                    out.add(p.immutable());
                }
            }
        }
        return out;
    }

    // ---- assembling

    private void beginRide() {
        if (level == null) {
            return;
        }
        BlockPos a = FerrisBlocks.findAxle(level, worldPosition);
        if (a == null) {
            motion.phase = FerrisMotion.IDLE;
            tell("no_axle");
            return;
        }
        List<BlockPos> hubs = findCabins(a);
        if (hubs.isEmpty()) {
            motion.phase = FerrisMotion.IDLE;
            tell("no_cabin");
            return;
        }
        Direction.Axis ax = level.getBlockState(a).getValue(FerrisBlocks.WheelPart.AXIS);
        SwingCarriage.Part wheelPart = new SwingCarriage.Part();
        List<SwingCarriage.Part> cabinParts = new ArrayList<>();
        try {
            if (!wheelPart.assemble(level, a) || wheelPart.getBlocks().isEmpty()) {
                motion.phase = FerrisMotion.IDLE;
                tell("empty");
                return;
            }
            for (BlockPos h : hubs) {
                SwingCarriage.Part part = new SwingCarriage.Part();
                if (!part.assemble(level, h) || part.getBlocks().isEmpty()) {
                    motion.phase = FerrisMotion.IDLE;
                    tell("empty");
                    return;
                }
                cabinParts.add(part);
            }
        } catch (AssemblyException e) {
            motion.phase = FerrisMotion.IDLE;
            for (ServerPlayer sp : nearby()) {
                sp.displayClientMessage(e.component, true);
            }
            return;
        }
        wheelPart.removeBlocksFromWorld(level, BlockPos.ZERO);
        for (SwingCarriage.Part part : cabinParts) {
            part.removeBlocksFromWorld(level, BlockPos.ZERO);
        }
        axle = a;
        axis = ax;
        cabins.clear();
        wheel = ControlledContraptionEntity.create(level, this, wheelPart);
        wheel.setRotationAxis(ax);
        wheel.setPos(a.getX(), a.getY(), a.getZ());
        level.addFreshEntity(wheel);
        for (int i = 0; i < hubs.size(); i++) {
            BlockPos h = hubs.get(i);
            ControlledContraptionEntity e = ControlledContraptionEntity.create(level, this, cabinParts.get(i));
            e.setRotationAxis(ax);
            e.setPos(h.getX(), h.getY(), h.getZ());
            level.addFreshEntity(e);
            cabins.put(h, e);
        }
        expectedCabins = hubs.size();
        motion.start(hubs.size());
        orphanTicks = 0;
        syncNow();
    }

    /** Puts everything back as blocks where it started (the wheel always ends on a whole turn). */
    void landAll() {
        if (level != null && !level.isClientSide) {
            if (wheel != null) {
                wheel.setAngle(0);
                wheel.setPos(axle.getX(), axle.getY(), axle.getZ());
                wheel.setContraptionMotion(Vec3.ZERO);
            }
            for (Map.Entry<BlockPos, ControlledContraptionEntity> en : cabins.entrySet()) {
                en.getValue().setAngle(0);
                en.getValue().setPos(en.getKey().getX(), en.getKey().getY(), en.getKey().getZ());
                en.getValue().setContraptionMotion(Vec3.ZERO);
            }
            if (wheel != null) {
                wheel.disassemble();
                wheel.discard();
            }
            for (ControlledContraptionEntity e : cabins.values()) {
                e.disassemble();
                e.discard();
            }
        }
        wheel = null;
        cabins.clear();
        motion.angle = 0;
        motion.vel = 0;
    }

    // ---- placing everything for the current angle (both sides)

    private void place(double angleDeg) {
        if (wheel == null || !wheel.isAlive() || cabins.isEmpty()) {
            return;
        }
        wheel.setRotationAxis(axis);
        wheel.setAngle((float) angleDeg);
        Vec3 centre = Vec3.atCenterOf(axle);
        for (Map.Entry<BlockPos, ControlledContraptionEntity> en : cabins.entrySet()) {
            ControlledContraptionEntity e = en.getValue();
            if (!e.isAlive()) {
                continue;
            }
            e.setRotationAxis(axis);
            Vec3 offset = Vec3.atCenterOf(en.getKey()).subtract(centre);
            Vec3 now = centre.add(wheel.applyRotation(offset, 1.0F));
            double dx = now.x - 0.5 - e.getX();
            double dy = now.y - 0.5 - e.getY();
            double dz = now.z - 0.5 - e.getZ();
            if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) > 1.0E-7) {
                e.setContraptionMotion(new Vec3(dx, dy, dz));
                e.move(dx, dy, dz);
            }
            e.setAngle(0);
        }
    }

    // ---- client side

    public void receiveState(float angle, int phase, BlockPos a, int ax, int stationCabin) {
        shownAngle = angle;
        motion.phase = phase;
        axle = a;
        axis = ax == 0 ? Direction.Axis.X : Direction.Axis.Z;
        station = stationCabin;
        stateSeen = true;
    }

    public void clientTick() {
        if (!stateSeen || motion.phase == FerrisMotion.IDLE) {
            return;
        }
        place(shownAngle);
    }

    // ---- ticking (server)

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        pollLinks();
        if (needRestore) {
            needRestore = false;
            motion.restoreAfterLoad();
        }
        if (motion.phase == FerrisMotion.IDLE) {
            return;
        }
        if (motion.phase == FerrisMotion.COUNTDOWN) {
            if (--preTicks <= 0) {
                beginRide();
            }
            return;
        }
        boolean complete = wheel != null && wheel.isAlive() && cabins.size() >= Math.max(1, expectedCabins)
                && cabins.values().stream().allMatch(AbstractContraptionEntity::isAlive);
        if (!complete) {
            if (++orphanTicks > 200) {
                motion.phase = FerrisMotion.IDLE;
                wheel = null;
                cabins.clear();
                tell("lost");
                syncNow();
            }
            return;
        }
        orphanTicks = 0;
        motion.tick(cfg, 1.0 / 20.0);
        if (motion.landed) {
            landAll();
            motion.landed = false;
            justFinished = true;
            tell("finished");
            syncNow();
            return;
        }
        shownAngle = (float) (motion.angle * (cfg.direction == 0 ? 1.0 : -1.0));
        station = motion.stationCabin();
        place(shownAngle);
        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                new FerrisStatePacket(worldPosition, shownAngle, motion.phase, axle.asLong(), axis == Direction.Axis.X ? 0 : 2, station));
        if (motion.phase == FerrisMotion.PAUSED && motion.finished && lastPhase != motion.phase) {
            tell("waiting_end");
        }
        if (motion.phase != lastPhase || motion.stepIndex != lastStep || ++syncTicks >= 10) {
            lastPhase = motion.phase;
            lastStep = motion.stepIndex;
            syncNow();
        }
    }

    private List<ServerPlayer> nearby() {
        if (level == null) {
            return List.of();
        }
        return ((ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 2500.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.ferris." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** The base was broken mid-ride: everything is put down where it is. */
    public void baseRemoved() {
        if (level != null && !level.isClientSide && (wheel != null || !cabins.isEmpty())) {
            landAll();
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putInt("Phase", motion.phase);
        tag.putInt("Step", motion.stepIndex);
        tag.putInt("Loop", motion.loop);
        tag.putDouble("StepTime", motion.stepTime);
        tag.putDouble("Angle", motion.angle);
        tag.putDouble("Vel", motion.vel);
        tag.putDouble("Spacing", motion.spacing);
        tag.putBoolean("Finished", motion.finished);
        tag.putLong("Axle", axle.asLong());
        tag.putInt("Axis", axis == Direction.Axis.X ? 0 : 2);
        tag.putInt("Cabins", expectedCabins);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = FerrisSettings.fromTag(tag.getCompound("Cfg"));
        motion.phase = tag.getInt("Phase");
        motion.stepIndex = tag.getInt("Step");
        motion.loop = tag.getInt("Loop");
        motion.stepTime = tag.getDouble("StepTime");
        motion.angle = tag.getDouble("Angle");
        motion.vel = tag.getDouble("Vel");
        motion.spacing = tag.contains("Spacing") ? tag.getDouble("Spacing") : 30.0;
        motion.finished = tag.getBoolean("Finished");
        axle = BlockPos.of(tag.getLong("Axle"));
        axis = tag.getInt("Axis") == 0 ? Direction.Axis.X : Direction.Axis.Z;
        expectedCabins = tag.getInt("Cabins");
        links.load(tag, registries);
        needRestore = true;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
