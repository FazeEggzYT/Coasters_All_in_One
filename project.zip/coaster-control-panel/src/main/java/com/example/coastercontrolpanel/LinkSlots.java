package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

/** N Redstone Link inputs for one block entity: the frequency slots, the registration and the received strengths. */
public class LinkSlots {
    private final BlockEntity owner;
    private final int count;
    private final SimpleContainer frequencies;
    private final int[] received;
    private final Link[] links;
    private boolean registered = false;
    private boolean loading = false;

    public LinkSlots(BlockEntity owner, int count) {
        this.owner = owner;
        this.count = count;
        this.frequencies = new SimpleContainer(count);
        this.received = new int[count];
        this.links = new Link[count];
        for (int i = 0; i < count; i++) {
            links[i] = new Link(i);
        }
        frequencies.addListener(c -> {
            if (!loading) {
                owner.setChanged();
                if (owner.getLevel() != null && !owner.getLevel().isClientSide) {
                    unregister();
                    register();
                }
            }
        });
    }

    public SimpleContainer container() {
        return frequencies;
    }

    public int strength(int slot) {
        return received[slot];
    }

    public void register() {
        if (owner.getLevel() == null || owner.getLevel().isClientSide || registered) {
            return;
        }
        registered = true;
        for (int i = 0; i < count; i++) {
            ItemStack stack = frequencies.getItem(i);
            links[i].alive = !stack.isEmpty();
            links[i].key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
            received[i] = 0;
            if (links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(owner.getLevel(), links[i]);
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(owner.getLevel(), links[i]);
            }
        }
    }

    public void unregister() {
        if (!registered) {
            return;
        }
        registered = false;
        for (int i = 0; i < count; i++) {
            if (owner.getLevel() != null && links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(owner.getLevel(), links[i]);
            }
            links[i].alive = false;
            received[i] = 0;
        }
    }

    public void save(CompoundTag tag, HolderLookup.Provider registries) {
        NonNullList<ItemStack> list = NonNullList.withSize(count, ItemStack.EMPTY);
        for (int i = 0; i < count; i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
    }

    public void load(CompoundTag tag, HolderLookup.Provider registries) {
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(count, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < count; i++) {
            frequencies.setItem(i, list.get(i));
        }
        loading = false;
    }

    private class Link implements IRedstoneLinkable {
        private final int index;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int index) {
            this.index = index;
        }

        @Override
        public int getTransmittedStrength() {
            return 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            received[index] = power;
        }

        @Override
        public boolean isListening() {
            return true;
        }

        @Override
        public boolean isAlive() {
            return alive && !owner.isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return owner.getBlockPos();
        }
    }
}
