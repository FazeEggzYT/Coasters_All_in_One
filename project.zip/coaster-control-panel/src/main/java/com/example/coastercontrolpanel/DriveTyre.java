package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Drive Tyre support. The Drive Tyre is its own item, but Coasters Simulated only knows the vanilla Chain. While one
 * of its chain-lift placement methods is running ("scope"), a held Drive Tyre answers "yes, I am a Chain" to the
 * mod's own check. The server remembers that the lift was placed with a Drive Tyre (a flag on the start anchor,
 * saved with it and sent to clients) and the renderer draws such lifts with the tyre texture.
 * The real Chain is never touched: it does not pass through any of this.
 */
public final class DriveTyre {
    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/drive_tyre.png");

    public static final ResourceLocation BRAKE_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/brake_run.png");

    /** Set by the wheel renderer once it has drawn wheels; until then (or if it breaks) the tyre-belt texture is shown. */
    public static volatile boolean wheelsOk;

    public static final ResourceLocation HIDDEN =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/drive_tyre_hidden.png");

    /** [0] = how many chain-lift methods are running on this thread, [1] = which item was accepted in them (see markHit). */
    private static final ThreadLocal<int[]> SCOPE = ThreadLocal.withInitial(() -> new int[2]);
    private static final ThreadLocal<BlockPos> RENDERING = new ThreadLocal<>();

    private DriveTyre() {
    }

    /** Implemented by the anchor block entity through a mixin. */
    public interface Holder {
        boolean ccp$isDriveTyre();

        /** Settings if this anchor starts a Brake Run, otherwise null. */
        BrakeSettings ccp$brake();

        void ccp$setBrake(BrakeSettings settings);

        /** Marks the anchor changed and sends it to clients (server side only). */
        void ccp$sync();
    }

    public static void enter() {
        SCOPE.get()[0]++;
    }

    public static void exit() {
        int[] s = SCOPE.get();
        if (s[0] > 0) {
            s[0]--;
        }
        if (s[0] == 0) {
            s[1] = 0;
        }
    }

    public static boolean inScope() {
        return SCOPE.get()[0] > 0;
    }

    /** kind 1 = Drive Tyre, 2 = Brake Run. */
    public static void markHit(int kind) {
        SCOPE.get()[1] = kind;
    }

    /** Returns 0 (plain chain), 1 (Drive Tyre) or 2 (Brake Run) and clears it. */
    public static int consumeHit() {
        int[] s = SCOPE.get();
        int hit = s[1];
        s[1] = 0;
        return hit;
    }

    // ---- client rendering

    public static void rendering(BlockPos anchor) {
        RENDERING.set(anchor);
    }

    public static ResourceLocation textureFor(ResourceLocation original) {
        BlockPos pos = RENDERING.get();
        Minecraft mc = Minecraft.getInstance();
        if (pos != null && mc != null && mc.level != null) {
            BlockEntity be = mc.level.getBlockEntity(pos);
            if (be instanceof Holder h) {
                if (h.ccp$isDriveTyre()) {
                    return wheelsOk ? HIDDEN : TEXTURE;
                }
                if (h.ccp$brake() != null) {
                    return BRAKE_TEXTURE;
                }
            }
        }
        return original;
    }
}
