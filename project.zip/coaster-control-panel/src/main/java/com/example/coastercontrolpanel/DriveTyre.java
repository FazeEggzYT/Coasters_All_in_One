package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Drive Tyre support. The Drive Tyre is its own item, but Coasters Simulated only knows the vanilla Chain. While one
 * of its chain-lift placement methods is running ("scope"), a held Drive Tyre answers "yes, I am a Chain" to the
 * mod's own check. The server remembers that the lift was placed with a Drive Tyre (a flag on the start anchor,
 * saved with it and sent to clients) and the renderer draws such lifts with the tyre texture.
 * The real Chain is never touched: it does not pass through any of this.
 */
public final class DriveTyre {
    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/drive_tyre.png");

    /** [0] = how many chain-lift methods are running on this thread, [1] = a Drive Tyre was accepted in them. */
    private static final ThreadLocal<int[]> SCOPE = ThreadLocal.withInitial(() -> new int[2]);
    private static final ThreadLocal<BlockPos> RENDERING = new ThreadLocal<>();

    private DriveTyre() {
    }

    /** Implemented by the anchor block entity through a mixin. */
    public interface Holder {
        boolean ccp$isDriveTyre();
    }

    public static void enter() {
        SCOPE.get()[0]++;
    }

    public static void exit() {
        int[] s = SCOPE.get();
        if (s[0] > 0) {
            s[0]--;
        }
        if (s[0] == 0) {
            s[1] = 0;
        }
    }

    public static boolean inScope() {
        return SCOPE.get()[0] > 0;
    }

    public static void markHit() {
        SCOPE.get()[1] = 1;
    }

    public static boolean consumeHit() {
        int[] s = SCOPE.get();
        boolean hit = s[1] == 1;
        s[1] = 0;
        return hit;
    }

    // ---- client rendering

    public static void rendering(BlockPos anchor) {
        RENDERING.set(anchor);
    }

    public static ResourceLocation textureFor(ResourceLocation original) {
        BlockPos pos = RENDERING.get();
        Minecraft mc = Minecraft.getInstance();
        if (pos != null && mc != null && mc.level != null) {
            BlockEntity be = mc.level.getBlockEntity(pos);
            if (be instanceof Holder h && h.ccp$isDriveTyre()) {
                return TEXTURE;
            }
        }
        return original;
    }
}
