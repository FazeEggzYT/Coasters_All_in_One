package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Plays a sound. Modes:
 * TRIGGER: a Redstone Link signal plays it once.
 * BUTTON: click the block to play it once.
 * SWITCH: click (or signal on) to start repeating, click (or signal off) to stop.
 */
public class AnnouncerBlockEntity extends BlockEntity {
    public static final int TRIGGER = 0;
    public static final int BUTTON = 1;
    public static final int SWITCH = 2;

    private final SimpleContainer frequency = new SimpleContainer(1);
    private int mode = TRIGGER;
    private int sound = 0;
    private int volume = 100;   // percent. 100% is about 16 blocks.
    private int pitch = 100;    // percent
    private int repeat = 5;     // seconds, for Switch mode
    private int delay = 0;      // seconds before it plays

    private boolean on = false;
    private int pending = -1;
    private int repeatCounter = 0;
    private int received = 0;
    private boolean lastSignal = false;

    private final Link link = new Link();
    private boolean registered = false;
    private boolean loading = false;

    public AnnouncerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.ANNOUNCER_BE.get(), pos, state);
        frequency.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLink();
                    registerLink();
                }
            }
        });
    }

    public SimpleContainer getFrequency() {
        return frequency;
    }

    public int getMode() {
        return mode;
    }

    public int getSound() {
        return sound;
    }

    public int getVolume() {
        return volume;
    }

    public int getPitch() {
        return pitch;
    }

    public int getRepeat() {
        return repeat;
    }

    public int getDelay() {
        return delay;
    }

    @Nullable
    public static AnnouncerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        BlockEntity be = player.level().getBlockEntity(pos);
        return be instanceof AnnouncerBlockEntity a ? a : null;
    }

    // ---------------------------------------------------------------- link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLink();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLink();
    }

    @Override
    public void setRemoved() {
        unregisterLink();
        super.setRemoved();
    }

    private void registerLink() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        ItemStack stack = frequency.getItem(0);
        link.alive = !stack.isEmpty();
        link.key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
        received = 0;
        if (link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, link);
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, link);
        }
    }

    private void unregisterLink() {
        if (!registered) {
            return;
        }
        registered = false;
        if (level != null && link.alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, link);
        }
        link.alive = false;
        received = 0;
    }

    // ---------------------------------------------------------------- behaviour

    public void startPlayback() {
        pending = delay * 20;
    }

    private void setOn(boolean value) {
        on = value;
        if (value) {
            startPlayback();
        } else {
            pending = -1;
        }
        setChanged();
    }

    /** Right-click on the block. */
    public void click(Player player) {
        if (mode == SWITCH) {
            setOn(!on);
            player.displayClientMessage(Component.translatable(
                    on ? "message.coastercontrolpanel.announcer_on" : "message.coastercontrolpanel.announcer_off"), true);
        } else {
            startPlayback();
        }
    }

    private void play() {
        if (level == null) {
            return;
        }
        level.playSound(null, worldPosition, AnnouncerSounds.get(sound), SoundSource.RECORDS,
                volume / 100.0F, pitch / 100.0F);
    }

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean signal = received > 0;
        if (signal && !lastSignal) {
            if (mode == SWITCH) {
                setOn(true);
            } else if (mode == TRIGGER) {
                startPlayback();
            }
        } else if (!signal && lastSignal && mode == SWITCH) {
            setOn(false);
        }
        lastSignal = signal;

        if (pending >= 0) {
            if (pending == 0) {
                pending = -1;
                play();
                if (mode == SWITCH && on) {
                    repeatCounter = repeat * 20;
                }
            } else {
                pending--;
            }
        } else if (mode == SWITCH && on) {
            repeatCounter--;
            if (repeatCounter <= 0) {
                play();
                repeatCounter = repeat * 20;
            }
        }
    }

    public void applyConfig(int newMode, int newSound, int newVolume, int newPitch, int newRepeat, int newDelay) {
        if (level == null || level.isClientSide) {
            return;
        }
        int clampedMode = Math.max(0, Math.min(2, newMode));
        if (clampedMode != mode) {
            on = false;
            pending = -1;
        }
        mode = clampedMode;
        sound = Math.max(0, Math.min(AnnouncerSounds.count() - 1, newSound));
        volume = Math.max(10, Math.min(600, newVolume));
        pitch = Math.max(50, Math.min(200, newPitch));
        repeat = Math.max(1, Math.min(300, newRepeat));
        delay = Math.max(0, Math.min(60, newDelay));
        setChanged();
        BlockState state = getBlockState();
        level.sendBlockUpdated(worldPosition, state, state, 3);
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        list.set(0, frequency.getItem(0));
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Mode", mode);
        tag.putInt("Sound", sound);
        tag.putInt("Volume", volume);
        tag.putInt("Pitch", pitch);
        tag.putInt("Repeat", repeat);
        tag.putInt("Delay", delay);
        tag.putBoolean("On", on);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(1, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        frequency.setItem(0, list.get(0));
        if (tag.contains("Mode")) {
            mode = tag.getInt("Mode");
            sound = tag.getInt("Sound");
            volume = tag.getInt("Volume");
            pitch = tag.getInt("Pitch");
            repeat = Math.max(1, tag.getInt("Repeat"));
            delay = tag.getInt("Delay");
        }
        on = tag.getBoolean("On");
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- the Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        @Override
        public int getTransmittedStrength() {
            return 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            received = power;
        }

        @Override
        public boolean isListening() {
            return true;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
