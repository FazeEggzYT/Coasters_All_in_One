package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Wireless Create Redstone Link connections of a ride: two inputs (Start, Emergency Stop) and two outputs
 * (Running, Stopped). A frequency is one item; use the same item on the other end, like a Redstone Link.
 */
public class RideLinks {
    /** Input: starts the ride. */
    public static final int START = 0;
    /** Output: on while the ride is running (from the countdown until it has landed). */
    public static final int RUNNING = 1;
    /** Input: emergency stop. */
    public static final int HALT = 2;
    /** Output: on while the ride is held by an emergency stop. */
    public static final int STOPPED = 3;
    public static final int COUNT = 4;
    /** Screen rows (y offsets) of the four slots: Start in/out, then Emergency stop in/out. */
    public static final int[] ROW_Y = {74, 96, 140, 162};

    private final BlockEntity owner;
    private final ItemStack[] stacks = new ItemStack[COUNT];
    private final int[] received = new int[COUNT];
    private final boolean[] last = new boolean[COUNT];
    private final int[] sent = new int[COUNT];
    private final Link[] links = new Link[COUNT];
    private boolean registered;

    public RideLinks(BlockEntity owner) {
        this.owner = owner;
        for (int i = 0; i < COUNT; i++) {
            stacks[i] = ItemStack.EMPTY;
            links[i] = new Link(i);
        }
    }

    public static boolean isInput(int slot) {
        return slot == START || slot == HALT;
    }

    public ItemStack stack(int slot) {
        return stacks[slot];
    }

    /** Sets the frequency of one slot from an item (the player's held item) or clears it. */
    public void set(int slot, ItemStack item) {
        if (slot < 0 || slot >= COUNT) {
            return;
        }
        unregister();
        stacks[slot] = item.isEmpty() ? ItemStack.EMPTY : item.copyWithCount(1);
        register();
        owner.setChanged();
        if (owner.getLevel() != null && !owner.getLevel().isClientSide) {
            owner.getLevel().sendBlockUpdated(owner.getBlockPos(), owner.getBlockState(), owner.getBlockState(), 3);
        }
    }

    public void register() {
        if (owner.getLevel() == null || owner.getLevel().isClientSide || registered) {
            return;
        }
        registered = true;
        for (int i = 0; i < COUNT; i++) {
            links[i].alive = !stacks[i].isEmpty();
            links[i].key = Couple.create(Frequency.of(stacks[i]), Frequency.EMPTY);
            received[i] = 0;
            last[i] = false;
            if (links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(owner.getLevel(), links[i]);
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(owner.getLevel(), links[i]);
            }
        }
    }

    public void unregister() {
        if (!registered) {
            return;
        }
        registered = false;
        for (int i = 0; i < COUNT; i++) {
            if (owner.getLevel() != null && links[i].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(owner.getLevel(), links[i]);
            }
            links[i].alive = false;
            received[i] = 0;
        }
    }

    public boolean on(int slot) {
        return isInput(slot) && received[slot] > 0;
    }

    /** True once when an input turns on. */
    public boolean rising(int slot) {
        boolean now = received[slot] > 0;
        boolean r = now && !last[slot];
        last[slot] = now;
        return r;
    }

    /** True when the input changed since the last call (either way). */
    public boolean changed(int slot) {
        boolean now = received[slot] > 0;
        boolean c = now != last[slot];
        last[slot] = now;
        return c;
    }

    /** Called every server tick: drives the two outputs. */
    public void tickOutputs(boolean running, boolean stopped) {
        setOut(RUNNING, running ? 15 : 0);
        setOut(STOPPED, stopped ? 15 : 0);
    }

    private void setOut(int slot, int strength) {
        if (sent[slot] == strength) {
            return;
        }
        sent[slot] = strength;
        if (links[slot].alive && owner.getLevel() != null) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(owner.getLevel(), links[slot]);
        }
    }

    public void save(CompoundTag tag, HolderLookup.Provider registries) {
        NonNullList<ItemStack> list = NonNullList.withSize(COUNT, ItemStack.EMPTY);
        for (int i = 0; i < COUNT; i++) {
            list.set(i, stacks[i]);
        }
        CompoundTag t = new CompoundTag();
        ContainerHelper.saveAllItems(t, list, registries);
        tag.put("Links", t);
    }

    public void load(CompoundTag tag, HolderLookup.Provider registries) {
        NonNullList<ItemStack> list = NonNullList.withSize(COUNT, ItemStack.EMPTY);
        if (tag.contains("Links")) {
            ContainerHelper.loadAllItems(tag.getCompound("Links"), list, registries);
        }
        for (int i = 0; i < COUNT; i++) {
            stacks[i] = list.get(i);
        }
    }

    private class Link implements IRedstoneLinkable {
        private final int slot;
        private boolean alive;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int slot) {
            this.slot = slot;
        }

        @Override
        public int getTransmittedStrength() {
            return isInput(slot) ? 0 : sent[slot];
        }

        @Override
        public void setReceivedStrength(int power) {
            if (isInput(slot)) {
                received[slot] = power;
            }
        }

        @Override
        public boolean isListening() {
            return isInput(slot);
        }

        @Override
        public boolean isAlive() {
            return alive && !owner.isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return owner.getBlockPos();
        }
    }
}
