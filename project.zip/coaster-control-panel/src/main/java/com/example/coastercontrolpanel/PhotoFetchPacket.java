package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: "send me the latest photo of this camera". */
public record PhotoFetchPacket(BlockPos camera) implements CustomPacketPayload {
    public static final Type<PhotoFetchPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "photo_fetch"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PhotoFetchPacket> CODEC = StreamCodec.of(
            (buf, p) -> buf.writeBlockPos(p.camera),
            buf -> new PhotoFetchPacket(buf.readBlockPos()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(PhotoFetchPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        if (player.distanceToSqr(p.camera.getX() + 0.5, p.camera.getY() + 0.5, p.camera.getZ() + 0.5) > 256.0 * 256.0) {
            return;
        }
        byte[] png = PhotoStore.load(player.server, p.camera);
        if (png == null) {
            return;
        }
        int version = player.level().getBlockEntity(p.camera) instanceof CameraBlockEntity c ? c.getVersion() : 1;
        int total = (png.length + PhotoStore.CHUNK - 1) / PhotoStore.CHUNK;
        for (int i = 0; i < total; i++) {
            int from = i * PhotoStore.CHUNK;
            int to = Math.min(png.length, from + PhotoStore.CHUNK);
            PacketDistributor.sendToPlayer(player, new PhotoDataPacket(p.camera, version, i, total, java.util.Arrays.copyOfRange(png, from, to)));
        }
    }
}
