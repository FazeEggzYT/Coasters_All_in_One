package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Works out where the support blocks go for a stretch of track. Nothing is placed here. */
public final class SupportPlanner {
    public static final int MAX_BLOCKS = 8000;
    private static final int MAX_DROP = 256;

    /** blocks = every position to fill; supports = how many columns; skipped = columns that could not be built. */
    public record Plan(List<BlockPos> blocks, int supports, int skipped, boolean tooBig, boolean noTrack) {
    }

    private SupportPlanner() {
    }

    public static Plan plan(ServerLevel level, BlockPos a, BlockPos b, SupportSettings s) {
        List<Vec3> samples = AnchorTrack.sample(level, a, b);
        if (samples.size() < 2) {
            return new Plan(List.of(), 0, 0, false, true);
        }
        Set<BlockPos> out = new LinkedHashSet<>();
        int supports = 0;
        int skipped = 0;
        int step = Math.max(1, s.spacing());
        // always support the very start; the end is covered by the last step
        for (int i = 0; i < samples.size(); i += step) {
            Vec3 p = samples.get(i);
            Vec3 q = i + 1 < samples.size() ? samples.get(i + 1) : p;
            Vec3 prev = i > 0 ? samples.get(i - 1) : p;
            double dx = q.x - prev.x;
            double dz = q.z - prev.z;
            double len = Math.sqrt(dx * dx + dz * dz);
            // a unit vector sideways to the track
            double nx = len < 0.01 ? 1 : -dz / len;
            double nz = len < 0.01 ? 0 : dx / len;

            int cx = (int) Math.floor(p.x);
            int cz = (int) Math.floor(p.z);
            int topY = (int) Math.floor(p.y) - 1 - s.gap();
            int ground = findGround(level, cx, cz, topY);
            if (ground == Integer.MIN_VALUE || topY - ground < 1 || blockedByTrack(samples, i, p, ground)) {
                skipped++;
                continue;
            }
            int before = out.size();
            build(level, out, s, cx, cz, topY, ground + 1, nx, nz);
            if (out.size() == before) {
                skipped++;
            } else {
                supports++;
            }
            if (out.size() > MAX_BLOCKS) {
                return new Plan(new ArrayList<>(out), supports, skipped, true, false);
            }
        }
        return new Plan(new ArrayList<>(out), supports, skipped, false, false);
    }

    /** First solid block below the track, or MIN_VALUE if there is none within reach. */
    private static int findGround(ServerLevel level, int x, int z, int fromY) {
        int minY = Math.max(level.getMinBuildHeight(), fromY - MAX_DROP);
        for (int y = fromY; y >= minY; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) {
                return Integer.MIN_VALUE;
            }
            BlockState state = level.getBlockState(pos);
            if (!state.getCollisionShape(level, pos).isEmpty()) {
                return y;
            }
        }
        return Integer.MIN_VALUE;
    }

    /** True if another part of this track passes underneath this point, so a column would cut through it. */
    private static boolean blockedByTrack(List<Vec3> samples, int index, Vec3 p, int ground) {
        for (int j = 0; j < samples.size(); j++) {
            if (Math.abs(j - index) < 12) {
                continue;
            }
            Vec3 o = samples.get(j);
            if (Math.abs(o.x - p.x) < 1.8 && Math.abs(o.z - p.z) < 1.8 && o.y < p.y - 2.0 && o.y > ground) {
                return true;
            }
        }
        return false;
    }

    private static void column(ServerLevel level, Set<BlockPos> out, int x, int z, int top, int bottom, int thick) {
        int lo = -(thick - 1) / 2;
        for (int dx = 0; dx < thick; dx++) {
            for (int dz = 0; dz < thick; dz++) {
                for (int y = bottom; y <= top; y++) {
                    add(level, out, new BlockPos(x + lo + dx, y, z + lo + dz));
                }
            }
        }
    }

    private static void add(ServerLevel level, Set<BlockPos> out, BlockPos pos) {
        if (!level.hasChunkAt(pos)) {
            return;
        }
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || state.canBeReplaced()) {
            out.add(pos);
        }
    }

    private static void build(ServerLevel level, Set<BlockPos> out, SupportSettings s, int cx, int cz, int top,
                              int bottom, double nx, double nz) {
        int t = s.thickness();
        switch (s.style()) {
            case 0 -> column(level, out, cx, cz, top, bottom, t);
            case 1 -> {
                int off = 1 + t;
                column(level, out, cx + (int) Math.round(nx * off), cz + (int) Math.round(nz * off), top, bottom, t);
                column(level, out, cx - (int) Math.round(nx * off), cz - (int) Math.round(nz * off), top, bottom, t);
                // a cross beam joining them at the top
                for (int k = -off; k <= off; k++) {
                    add(level, out, new BlockPos(cx + (int) Math.round(nx * k), top, cz + (int) Math.round(nz * k)));
                }
            }
            case 2 -> {
                for (int y = top; y >= bottom; y--) {
                    int off = 1 + (top - y) / 4;
                    for (int k = 0; k < t; k++) {
                        add(level, out, new BlockPos(cx + (int) Math.round(nx * (off + k)), y, cz + (int) Math.round(nz * (off + k))));
                        add(level, out, new BlockPos(cx - (int) Math.round(nx * (off + k)), y, cz - (int) Math.round(nz * (off + k))));
                    }
                }
                for (int k = -1; k <= 1; k++) {
                    add(level, out, new BlockPos(cx + (int) Math.round(nx * k), top, cz + (int) Math.round(nz * k)));
                }
            }
            default -> {
                // four corner posts, and a ring of blocks every few layers
                int[][] corners = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}};
                for (int[] c : corners) {
                    for (int y = bottom; y <= top; y++) {
                        add(level, out, new BlockPos(cx + c[0], y, cz + c[1]));
                    }
                }
                for (int y = bottom; y <= top; y++) {
                    if ((top - y) % 4 == 0) {
                        for (int k = -1; k <= 1; k++) {
                            add(level, out, new BlockPos(cx + k, y, cz - 1));
                            add(level, out, new BlockPos(cx + k, y, cz + 1));
                            add(level, out, new BlockPos(cx - 1, y, cz + k));
                            add(level, out, new BlockPos(cx + 1, y, cz + k));
                        }
                    }
                }
            }
        }
    }
}
