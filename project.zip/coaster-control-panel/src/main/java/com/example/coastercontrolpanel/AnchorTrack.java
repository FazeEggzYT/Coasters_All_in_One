package com.example.coastercontrolpanel;

import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads the track anchors of Coasters Simulated. Each anchor knows the curves that connect it to
 * its neighbouring anchors. We walk from one anchor to another along those curves and collect
 * points on the way. The anchor class is reached by name at runtime, so nothing here needs the mod to compile.
 */
public final class AnchorTrack {
    private static final String ANCHOR_BE = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity";
    private static final int MAX_ANCHORS = 400;

    private static Method peersMethod;
    private static boolean triedMethod = false;

    private AnchorTrack() {
    }

    public static boolean isAnchor(BlockEntity be) {
        for (Class<?> c = be == null ? null : be.getClass(); c != null; c = c.getSuperclass()) {
            if (c.getName().equals(ANCHOR_BE)) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    public static Map<BlockPos, BezierConnection> peers(BlockEntity be) {
        try {
            if (!triedMethod) {
                triedMethod = true;
                peersMethod = be.getClass().getMethod("getAnchorPeerCurvesView");
            }
            if (peersMethod != null) {
                Object o = peersMethod.invoke(be);
                if (o instanceof Map<?, ?> m) {
                    return (Map<BlockPos, BezierConnection>) m;
                }
            }
        } catch (Throwable t) {
            peersMethod = null;
        }
        return Collections.emptyMap();
    }

    public static BlockEntity loadedAnchor(Level level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) {
            return null;
        }
        BlockEntity be = level.getBlockEntity(pos);
        return isAnchor(be) ? be : null;
    }

    /**
     * Points along the track from anchor a to anchor b, about one per block. Empty if the two are
     * not connected (or not loaded). With branches, the route with the fewest anchors is used.
     */
    public static List<Vec3> sample(Level level, BlockPos a, BlockPos b) {
        List<BlockPos> route = route(level, a, b);
        List<Vec3> points = new ArrayList<>();
        for (int i = 0; i + 1 < route.size(); i++) {
            BlockEntity be = loadedAnchor(level, route.get(i));
            if (be == null) {
                return List.of();
            }
            BezierConnection curve = peers(be).get(route.get(i + 1));
            if (curve == null) {
                return List.of();
            }
            int n = Math.max(2, (int) Math.ceil(curve.getLength()));
            for (int k = 0; k <= n; k++) {
                points.add(curve.getPosition(k / (double) n));
            }
        }
        return points;
    }

    /** The anchors from a to b along connected curves (fewest anchors). Empty if not connected. */
    public static List<BlockPos> route(Level level, BlockPos a, BlockPos b) {
        if (a.equals(b) || loadedAnchor(level, a) == null) {
            return List.of();
        }
        Map<BlockPos, BlockPos> parent = new HashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        parent.put(a, a);
        queue.add(a);
        boolean found = false;
        while (!queue.isEmpty() && parent.size() < MAX_ANCHORS) {
            BlockPos cur = queue.poll();
            if (cur.equals(b)) {
                found = true;
                break;
            }
            BlockEntity be = loadedAnchor(level, cur);
            if (be == null) {
                continue;
            }
            for (BlockPos next : peers(be).keySet()) {
                if (!parent.containsKey(next)) {
                    parent.put(next, cur);
                    queue.add(next);
                }
            }
        }
        if (!found && !parent.containsKey(b)) {
            return List.of();
        }
        List<BlockPos> route = new ArrayList<>();
        for (BlockPos p = b; ; p = parent.get(p)) {
            route.add(0, p);
            if (p.equals(a)) {
                break;
            }
        }
        return route;
    }

    private static Method tintMethod;
    private static Method dyeRgbMethod;
    private static boolean triedTint = false;

    /** Rail/beam colour value the Coasters Simulated dye system uses for a dye colour. */
    public static int dyeRgb(DyeColor dye) {
        try {
            if (dyeRgbMethod == null) {
                dyeRgbMethod = Class.forName("dev.silvergold.simulatedcoasters.track.CoasterCurveTintColors", true,
                        AnchorTrack.class.getClassLoader()).getMethod("diffuseRgbFromDye", DyeColor.class);
            }
            return (Integer) dyeRgbMethod.invoke(null, dye);
        } catch (Throwable t) {
            return dye.getTextureDiffuseColor();
        }
    }

    /** Sets the rail and beam colours of the curve from anchor p to its neighbour q. */
    public static boolean tint(Level level, BlockPos p, BlockPos q, int railRgb, int beamRgb) {
        BlockEntity be = loadedAnchor(level, p);
        if (be == null || !peers(be).containsKey(q)) {
            return false;
        }
        try {
            if (!triedTint) {
                triedTint = true;
                for (Method m : be.getClass().getMethods()) {
                    if (m.getName().equals("setPeerCurveTieredTints") && m.getParameterCount() == 3) {
                        tintMethod = m;
                    }
                }
            }
            if (tintMethod != null) {
                return Boolean.TRUE.equals(tintMethod.invoke(be, q, railRgb, beamRgb));
            }
        } catch (Throwable t) {
            CoasterControlPanel.LOGGER.warn("Track Painter could not set colours: {}", t.toString());
        }
        return false;
    }
}
