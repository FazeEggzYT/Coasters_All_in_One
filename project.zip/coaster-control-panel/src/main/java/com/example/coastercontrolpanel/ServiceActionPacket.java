package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Client to server for the Guest Services screens. Actions: 1 info desk guide book, 2 brochure leaflet,
 * 20..23 ATM swaps (a = how many), 24 photo wall set slot a from hand, 25 photo wall clear slot a,
 * 30 stroller hire, 31 stroller return, 32 capacity change, 33 price change, 34 collect takings, 40 clear feedback (staff).
 */
public record ServiceActionPacket(BlockPos pos, int action, int a, int b) implements CustomPacketPayload {
    public static final Type<ServiceActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "service_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ServiceActionPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.a + 1000);
                buf.writeVarInt(p.b + 1000);
            },
            buf -> new ServiceActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt() - 1000, buf.readVarInt() - 1000));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ServiceActionPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        Level level = player.level();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 144.0 || !level.isLoaded(p.pos)) {
            return;
        }
        var be = level.getBlockEntity(p.pos);
        switch (p.action) {
            case 1, 2 -> {
                if (be instanceof GuestBlocks.TextBlockEntity t) {
                    List<String> lines = t.list();
                    if (p.action == 1) {
                        ArcadeBlocks.give(player, GuestBlocks.book("Park Guide", "Information Desk", lines));
                    } else {
                        String title = lines.isEmpty() ? "" : lines.get(0);
                        ArcadeBlocks.give(player, GuestBlocks.book(title.isBlank() ? "Park Leaflet" : title, "Brochure Stand",
                                new ArrayList<>(lines.subList(Math.min(1, lines.size()), lines.size()))));
                    }
                }
            }
            case 20, 21, 22, 23 -> {
                if (level.getBlockState(p.pos).getBlock() instanceof GuestBlocks.AtmBlock) {
                    GuestBlocks.AtmBlock.exchange(player, p.action, p.a);
                }
            }
            case 24, 25 -> {
                if (be instanceof GuestBlocks.PhotoWallBlockEntity w && p.a >= 0 && p.a < 4) {
                    if (p.action == 24) {
                        ItemStack held = player.getMainHandItem();
                        if (!held.isEmpty()) {
                            w.shown[p.a] = held.copyWithCount(1);
                        }
                    } else {
                        w.shown[p.a] = ItemStack.EMPTY;
                    }
                    w.changed();
                }
            }
            case 30, 31, 32, 33, 34 -> {
                if (be instanceof GuestBlocks.StrollerBlockEntity s) {
                    switch (p.action) {
                        case 30 -> s.hire(player);
                        case 31 -> s.giveBack(player);
                        case 32 -> {
                            s.capacity = Math.max(1, Math.min(8, s.capacity + p.a));
                            s.changed();
                        }
                        case 33 -> {
                            s.price = Math.max(1, Math.min(64, s.price + p.a));
                            s.changed();
                        }
                        default -> s.collect(player);
                    }
                }
            }
            case 40 -> {
                if (be instanceof GuestBlocks.FeedbackBlockEntity f && StaffBlocks.hasBadge(player)) {
                    f.notes.clear();
                    f.changed();
                }
            }
            case 50, 51, 52, 54 -> {
                if (be instanceof ResortBlocks.ReceptionBlockEntity r) {
                    switch (p.action) {
                        case 50 -> r.checkIn(player);
                        case 51 -> r.checkOut(player);
                        case 52 -> r.changePrice(p.a);
                        default -> r.collect(player);
                    }
                }
            }
            case 53, 55 -> {
                if (be instanceof ResortBlocks.RoomDoorBlockEntity r && StaffBlocks.hasBadge(player)) {
                    if (p.action == 53) {
                        r.changeNumber(p.a);
                    } else {
                        r.vacate();
                    }
                }
            }
            case 60 -> {
                if (level.getBlockState(p.pos).getBlock() instanceof MaintBlocks.WorkshopBenchBlock) {
                    MaintBlocks.WorkshopBenchBlock.repair(player, p.a);
                }
            }
            case 61, 62, 63 -> {
                if (be instanceof MaintBlocks.ChecklistBlockEntity c && StaffBlocks.hasBadge(player)) {
                    switch (p.action) {
                        case 61 -> c.toggle(p.a);
                        case 62 -> c.sign(player);
                        default -> c.reset();
                    }
                }
            }
            case 70 -> BathroomBlocks.poo(player);
            default -> {
            }
        }
    }
}
