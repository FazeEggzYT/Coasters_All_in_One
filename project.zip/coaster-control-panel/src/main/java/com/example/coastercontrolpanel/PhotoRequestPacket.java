package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client: "a train just passed, please take the picture from this camera". */
public record PhotoRequestPacket(BlockPos camera, float yaw) implements CustomPacketPayload {
    public static final Type<PhotoRequestPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "photo_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PhotoRequestPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.camera);
                buf.writeFloat(p.yaw);
            },
            buf -> new PhotoRequestPacket(buf.readBlockPos(), buf.readFloat()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(PhotoRequestPacket p, IPayloadContext context) {
        PhotoClient.request(p.camera, p.yaw);
    }
}
