package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The blocks of the Pirate Ship. They behave exactly like the Swing Ride blocks (the same engine runs them); only the
 * look differs, and the Hull is solid. The boat is always fixed to the arm and never spins.
 */
public final class PirateBlocks {
    private PirateBlocks() {
    }

    public static class BaseBlock extends SwingBlocks.BaseBlock {
        public BaseBlock(Properties properties) {
            super(properties);
        }
    }

    public static class PivotBlock extends SwingBlocks.PivotBlock {
        public PivotBlock(Properties properties) {
            super(properties);
        }
    }

    public static class ArmBlock extends SwingBlocks.ArmBlock {
        public ArmBlock(Properties properties) {
            super(properties);
        }
    }

    public static class HubBlock extends SwingBlocks.HubBlock {
        public HubBlock(Properties properties) {
            super(properties);
        }
    }

    /** A solid hull plank. Sticks to other boat blocks and to touching seats. */
    public static class HullBlock extends SwingBlocks.GondolaFrameBlock {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 16, 16);

        public HullBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return false;
        }
    }
}
