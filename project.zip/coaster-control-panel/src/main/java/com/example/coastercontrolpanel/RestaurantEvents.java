package com.example.coastercontrolpanel;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.component.CustomData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;

/** Sauce from the Condiment Stand gives +1 hunger per sauce when the food is eaten. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class RestaurantEvents {
    @SubscribeEvent
    public static void onFinish(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof Player player && !player.level().isClientSide) {
            CustomData data = event.getItem().get(DataComponents.CUSTOM_DATA);
            if (data != null) {
                CompoundTag tag = data.copyTag();
                int sauce = tag.getInt("Sauce");
                if (sauce > 0) {
                    player.getFoodData().eat(sauce, 0.2F);
                }
            }
        }
    }
}
