package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.elements.ElementPlan;
import com.example.coastercontrolpanel.elements.Params;
import com.example.coastercontrolpanel.elements.TrackElement;
import com.example.coastercontrolpanel.elements.TrackElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** Track Element Selector: categories, element list, a side and top preview of the shape, and size, direction and turn controls. */
public class TrackElementScreen extends Screen {
    private static final int W = 330;
    private static final int H = 196;

    private String category = TrackElements.CATEGORIES.get(0);
    private TrackElement selected;
    private Params params = Params.DEFAULT;
    private int rotation;
    private final List<Button> listButtons = new ArrayList<>();
    private static final int ROWS = 5;
    private int scroll;

    public TrackElementScreen() {
        super(Component.translatable("gui.coastercontrolpanel.element_title"));
        ElementState st = Minecraft.getInstance().player == null ? null
                : ElementState.read(Minecraft.getInstance().player.getMainHandItem());
        if (st != null) {
            selected = st.element();
            params = st.params();
            rotation = st.rotation();
            category = st.element().category();
        }
    }

    @Override
    protected void init() {
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        int cx = x + 8;
        for (String c : TrackElements.CATEGORIES) {
            final String cat = c;
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_cat." + c), b -> {
                category = cat;
                scroll = 0;
                rebuildList();
            }).bounds(cx, y + 20, 62, 16).build());
            cx += 64;
        }
        addRenderableWidget(Button.builder(Component.literal("^"), b -> scrollBy(-ROWS)).bounds(x + 8, y + 141, 50, 13).build());
        addRenderableWidget(Button.builder(Component.literal("v"), b -> scrollBy(ROWS)).bounds(x + 62, y + 141, 50, 13).build());
        showSelected();
        rebuildList();
        int rx = x + 120;
        int ry = y + 128;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> params = new Params(params.size() - 1, params.side(), params.rise()).clamped())
                .bounds(rx + 60, ry, 16, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> params = new Params(params.size() + 1, params.side(), params.rise()).clamped())
                .bounds(rx + 110, ry, 16, 14).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> params = new Params(params.size(), params.side(), params.rise() - 1).clamped())
                .bounds(rx + 60, ry + 16, 16, 14).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> params = new Params(params.size(), params.side(), params.rise() + 1).clamped())
                .bounds(rx + 110, ry + 16, 16, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_flip"), b -> params = new Params(params.size(), -params.side(), params.rise()))
                .bounds(rx + 60, ry + 32, 66, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_rotate"), b -> rotation = (rotation + 1) % 4)
                .bounds(rx + 130, ry + 32, 66, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_select"), b -> confirm())
                .bounds(x + W - 148, y + H - 24, 70, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.element_cancel"), b -> super.onClose())
                .bounds(x + W - 74, y + H - 24, 66, 18).build());
    }

    private List<TrackElement> inCategory() {
        List<TrackElement> out = new ArrayList<>();
        for (TrackElement e : TrackElements.ALL) {
            if (e.category().equals(category)) {
                out.add(e);
            }
        }
        return out;
    }

    private void showSelected() {
        if (selected != null && selected.category().equals(category)) {
            int i = inCategory().indexOf(selected);
            if (i >= 0) {
                scroll = (i / ROWS) * ROWS;
            }
        }
    }

    private void scrollBy(int d) {
        int n = inCategory().size();
        scroll = Math.max(0, Math.min(Math.max(0, n - ROWS), scroll + d));
        rebuildList();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (mx < (width - W) / 2.0 + 116) {
            scrollBy(sy > 0 ? -1 : 1);
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    private void rebuildList() {
        for (Button b : listButtons) {
            removeWidget(b);
        }
        listButtons.clear();
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        List<TrackElement> all = inCategory();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, all.size() - ROWS)));
        for (int row = 0; row < ROWS && scroll + row < all.size(); row++) {
            final TrackElement el = all.get(scroll + row);
            Button b = Button.builder(Component.translatable("element.coastercontrolpanel." + el.id()), btn -> selected = el)
                    .bounds(x + 8, y + 40 + row * 20, 104, 18).build();
            listButtons.add(b);
            addRenderableWidget(b);
        }
    }

    private void confirm() {
        if (selected != null) {
            Params p = params.clamped();
            PacketDistributor.sendToServer(new TrackElementSelectPacket(selected.id(), p.size(), p.side(), p.rise(), rotation));
        }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xF0202830);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xF0384450);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.drawString(font, title, x + 8, y + 7, 0xFFFFFF, false);
        int px = x + 120;
        int py = y + 40;
        g.fill(px, py, px + 202, py + 84, 0xFF101820);
        if (selected == null) {
            g.drawCenteredString(font, Component.translatable("gui.coastercontrolpanel.element_pick"), px + 101, py + 38, 0xB0B8C0);
            return;
        }
        Params p = params.clamped();
        ElementPlan.Plan plan = ElementPlan.plan(selected, p, 1, 0, 0, 0);
        drawProfile(g, plan, px + 2, py + 2, 130, 80, true);
        drawProfile(g, plan, px + 136, py + 2, 64, 80, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_side"), px + 2, py + 74, 0x707880, false);
        int ry = y + 128;
        int rx = x + 120;
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_size"), rx, ry + 3, 0xFFFFFF, false);
        g.drawString(font, String.valueOf(p.size()), rx + 90, ry + 3, 0xFFFFFF, false);
        if (selected.usesRise()) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_rise"), rx, ry + 19, 0xFFFFFF, false);
            g.drawString(font, String.valueOf(p.rise()), rx + 90, ry + 19, 0xFFFFFF, false);
        }
        String dir = Component.translatable(p.side() < 0 ? "gui.coastercontrolpanel.element_left" : "gui.coastercontrolpanel.element_right").getString();
        g.drawString(font, dir, rx, ry + 35, selected.usesSide() ? 0xFFFFFF : 0x707880, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_turned", rotation * 90), rx + 200, ry + 35, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_desc." + selected.id()), x + 8, y + H - 40, 0xC0C8D0, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.element_hint"), x + 8, y + H - 20, 0x909AA4, false);
    }

    /** Draws the centre line of the planned shape: side view (forward and up) or top view (forward and sideways). */
    private void drawProfile(GuiGraphics g, ElementPlan.Plan plan, int bx, int by, int bw, int bh, boolean side) {
        List<double[]> pts = plan.line;
        if (pts.size() < 2) {
            return;
        }
        double minA = 1e9, maxA = -1e9, minB = 1e9, maxB = -1e9;
        for (double[] q : pts) {
            double a = q[0];
            double b = side ? q[1] : q[2];
            minA = Math.min(minA, a);
            maxA = Math.max(maxA, a);
            minB = Math.min(minB, b);
            maxB = Math.max(maxB, b);
        }
        double scale = Math.min((bw - 6) / Math.max(1.0, maxA - minA), (bh - 6) / Math.max(1.0, maxB - minB));
        scale = Math.min(scale, 8.0);
        double offA = bx + 3 + ((bw - 6) - (maxA - minA) * scale) / 2.0;
        double offB = by + 3 + ((bh - 6) - (maxB - minB) * scale) / 2.0;
        int color = plan.problems.isEmpty() ? 0xFF60E070 : 0xFFE06060;
        for (int i = 1; i < pts.size(); i++) {
            double a0 = pts.get(i - 1)[0], a1 = pts.get(i)[0];
            double b0 = side ? pts.get(i - 1)[1] : pts.get(i - 1)[2];
            double b1 = side ? pts.get(i)[1] : pts.get(i)[2];
            int steps = (int) Math.max(1, Math.ceil(Math.max(Math.abs(a1 - a0), Math.abs(b1 - b0)) * scale));
            for (int s = 0; s <= steps; s++) {
                double t = s / (double) steps;
                double a = a0 + (a1 - a0) * t;
                double b = b0 + (b1 - b0) * t;
                int sx = (int) (offA + (a - minA) * scale);
                int sy = side ? (int) (offB + (maxB - b) * scale) : (int) (offB + (b - minB) * scale);
                g.fill(sx, sy, sx + 1, sy + 1, color);
            }
        }
    }
}
