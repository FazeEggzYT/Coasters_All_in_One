package com.example.coastercontrolpanel;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Right-clicking a restraint seat with the Seat Timer opens the timer screen.
 * Done as an event so the seat's own right-click (its link screen) does not get in the way.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class SeatTimerEvents {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND
                || !event.getItemStack().is(CoasterControlPanel.SEAT_TIMER_ITEM.get())) {
            return;
        }
        if (!(event.getLevel().getBlockEntity(event.getPos()) instanceof SeatTimerAccess)) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            SeatTimerClient.open(event.getPos());
        }
    }
}
