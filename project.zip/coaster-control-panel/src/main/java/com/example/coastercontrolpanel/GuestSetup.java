package com.example.coastercontrolpanel;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

/** Registers the guest's attributes, and clears the marker list when a world closes. */
public class GuestSetup {
    @EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void onAttributes(EntityAttributeCreationEvent event) {
            event.put(CoasterControlPanel.GUEST.get(), GuestEntity.createAttributes().build());
        }
    }

    @EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
    public static class GameBus {
        @SubscribeEvent
        public static void onServerStopped(ServerStoppedEvent event) {
            MarkerRegistry.clear();
        }
    }
}
