package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * The buildings: Keeper Hut, Sheriff Office, Hot Chocolate Hut, Snow Cabin and the Tent. Each is an item. Right-click the
 * ground and the whole building appears in front of you, door facing you, furnished inside. They are built from ordinary
 * blocks (and a few of this mod's blocks), so you can change anything afterwards.
 */
public final class ParkStructure {
    private ParkStructure() {
    }

    public static class Kit extends Item {
        private final String id;

        public Kit(String id, Properties p) {
            super(p);
            this.id = id;
        }

        @Override
        public InteractionResult useOn(UseOnContext c) {
            Level level = c.getLevel();
            if (!(level instanceof ServerLevel sl)) {
                return InteractionResult.SUCCESS;
            }
            Player player = c.getPlayer();
            BlockPos origin = c.getClickedPos().relative(c.getClickedFace());
            if (player != null && !sl.mayInteract(player, origin)) {
                return InteractionResult.FAIL;
            }
            B b = new B(sl, origin, c.getHorizontalDirection());
            switch (id) {
                case "keeper_hut" -> keeper(b);
                case "sheriff_office" -> sheriff(b);
                case "hot_chocolate_hut" -> chocolate(b);
                case "snow_cabin" -> cabin(b);
                case "tent" -> tent(b);
                default -> {
                    return InteractionResult.FAIL;
                }
            }
            sl.playSound(null, origin, SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 1.2F, 0.8F);
            if (player == null || !player.getAbilities().instabuild) {
                c.getItemInHand().shrink(1);
            }
            return InteractionResult.CONSUME;
        }
    }

    // ------------------------------------------------------------------ the builder

    /**
     * Local frame: the building grows towards +z (south), x runs east, the front (with the door) is the north side at z = 0.
     * Everything is turned so that the front faces the player.
     */
    static final class B {
        final ServerLevel lv;
        final BlockPos o;
        final Rotation rot;

        B(ServerLevel lv, BlockPos o, Direction look) {
            this.lv = lv;
            this.o = o;
            this.rot = switch (look) {
                case WEST -> Rotation.CLOCKWISE_90;
                case NORTH -> Rotation.CLOCKWISE_180;
                case EAST -> Rotation.COUNTERCLOCKWISE_90;
                default -> Rotation.NONE;
            };
        }

        BlockPos at(int x, int y, int z) {
            int rx;
            int rz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    rx = -z;
                    rz = x;
                }
                case CLOCKWISE_180 -> {
                    rx = -x;
                    rz = -z;
                }
                case COUNTERCLOCKWISE_90 -> {
                    rx = z;
                    rz = -x;
                }
                default -> {
                    rx = x;
                    rz = z;
                }
            }
            return o.offset(rx, y, rz);
        }

        void set(int x, int y, int z, BlockState s) {
            lv.setBlock(at(x, y, z), s, 3);
        }

        void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
            for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
                for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                    for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                        set(x, y, z, s);
                    }
                }
            }
        }

        void clear(int x1, int y1, int z1, int x2, int y2, int z2) {
            fill(x1, y1, z1, x2, y2, z2, Blocks.AIR.defaultBlockState());
        }

        /** Turn a state that has a horizontal facing so it faces the given local direction. */
        BlockState f(BlockState s, Direction local) {
            return s.hasProperty(BlockStateProperties.HORIZONTAL_FACING)
                    ? s.setValue(BlockStateProperties.HORIZONTAL_FACING, rot.rotate(local)) : s;
        }

        BlockState f(Block b, Direction local) {
            return f(b.defaultBlockState(), local);
        }

        void door(int x, int y, int z, Block door, Direction local) {
            BlockState s = f(door, local);
            set(x, y, z, s.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
            set(x, y + 1, z, s.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        }

        void bed(int x, int y, int z, Direction towardHead, Block bed) {
            BlockState s = f(bed, towardHead);
            set(x, y, z, s.setValue(BlockStateProperties.BED_PART, BedPart.FOOT));
            set(x + towardHead.getStepX(), y, z + towardHead.getStepZ(), s.setValue(BlockStateProperties.BED_PART, BedPart.HEAD));
        }

        void bag(int x, int y, int z, Direction towardHead) {
            BlockState s = CoasterControlPanel.SLEEPING_BAG_BLOCK.get().defaultBlockState()
                    .setValue(ParkConnect.Bag.FACING, rot.rotate(towardHead));
            set(x, y, z, s.setValue(ParkConnect.Bag.PART, BedPart.FOOT));
            set(x + towardHead.getStepX(), y, z + towardHead.getStepZ(), s.setValue(ParkConnect.Bag.PART, BedPart.HEAD));
        }

        void lantern(int x, int y, int z) {
            set(x, y, z, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        }

        void barrel(int x, int y, int z) {
            set(x, y, z, Blocks.BARREL.defaultBlockState().setValue(BarrelBlock.FACING, Direction.UP));
        }

        void mod(int x, int y, int z, Block block, Direction local) {
            set(x, y, z, f(block, local));
        }

        /** Stone under the floor so the building does not float over a hole. */
        void foundation(int x1, int z1, int x2, int z2) {
            for (int x = x1; x <= x2; x++) {
                for (int z = z1; z <= z2; z++) {
                    for (int y = -2; y >= -5; y--) {
                        BlockPos p = at(x, y, z);
                        if (!lv.getBlockState(p).canBeReplaced()) {
                            break;
                        }
                        lv.setBlock(p, Blocks.COBBLESTONE.defaultBlockState(), 3);
                    }
                }
            }
        }
    }

    private static BlockState d(Block b) {
        return b.defaultBlockState();
    }

    /** A 7 by 7 house with a gabled roof, a door in the middle of the front and windows. About the size of a village house. */
    private static void shell(B b, Block planks, Block log, Block floor, Block stairs, Block ridge, Block gable, Block door) {
        b.clear(-4, 0, -1, 4, 9, 7);
        b.foundation(-3, 0, 3, 6);
        b.fill(-3, -1, 0, 3, -1, 6, d(floor));
        b.fill(-3, 0, 0, 3, 3, 0, d(planks));
        b.fill(-3, 0, 6, 3, 3, 6, d(planks));
        b.fill(-3, 0, 1, -3, 3, 5, d(planks));
        b.fill(3, 0, 1, 3, 3, 5, d(planks));
        for (int cx : new int[] {-3, 3}) {
            for (int cz : new int[] {0, 6}) {
                b.fill(cx, 0, cz, cx, 3, cz, d(log));
            }
        }
        for (int z : new int[] {0, 6}) {
            b.fill(-2, 4, z, 2, 4, z, d(gable));
            b.fill(-1, 5, z, 1, 5, z, d(gable));
            b.set(0, 6, z, d(gable));
        }
        for (int z = -1; z <= 7; z++) {
            for (int i = 0; i < 4; i++) {
                b.set(-(4 - i), 3 + i, z, b.f(stairs, Direction.EAST));
                b.set(4 - i, 3 + i, z, b.f(stairs, Direction.WEST));
            }
            b.set(0, 7, z, d(ridge));
        }
        b.door(0, 0, 0, door, Direction.SOUTH);
        for (int y = 1; y <= 2; y++) {
            for (int x : new int[] {-2, 2}) {
                b.set(x, y, 0, d(Blocks.GLASS_PANE));
                b.set(x, y, 6, d(Blocks.GLASS_PANE));
            }
            for (int z : new int[] {2, 4}) {
                b.set(-3, y, z, d(Blocks.GLASS_PANE));
                b.set(3, y, z, d(Blocks.GLASS_PANE));
            }
        }
        b.lantern(0, 6, 2);
        b.lantern(0, 6, 4);
    }

    // ------------------------------------------------------------------ the five buildings

    private static void keeper(B b) {
        shell(b, Blocks.OAK_PLANKS, Blocks.OAK_LOG, Blocks.SPRUCE_PLANKS, Blocks.DARK_OAK_STAIRS, Blocks.DARK_OAK_PLANKS,
                Blocks.OAK_PLANKS, Blocks.OAK_DOOR);
        b.fill(-1, 0, 2, 1, 0, 4, d(Blocks.GREEN_CARPET));
        b.bed(-2, 0, 4, Direction.SOUTH, Blocks.RED_BED);
        b.set(2, 0, 1, d(Blocks.CRAFTING_TABLE));
        b.set(2, 0, 5, b.f(Blocks.CHEST, Direction.WEST));
        b.barrel(2, 0, 4);
        b.mod(2, 0, 3, CoasterControlPanel.FEEDING_TROUGH_BLOCK.get(), Direction.WEST);
        b.set(-2, 0, 1, d(Blocks.CAULDRON));
        b.set(-2, 0, 2, d(Blocks.HAY_BLOCK));
        b.set(-1, 0, 1, d(Blocks.HAY_BLOCK));
        b.mod(0, 1, 5, CoasterControlPanel.HABITAT_SIGN_BLOCK.get(), Direction.NORTH);
        b.set(2, 0, -1, d(Blocks.HAY_BLOCK));
        b.set(3, 0, -1, d(Blocks.HAY_BLOCK));
    }

    private static void sheriff(B b) {
        shell(b, Blocks.ACACIA_PLANKS, Blocks.DARK_OAK_LOG, Blocks.DARK_OAK_PLANKS, Blocks.ACACIA_STAIRS, Blocks.ACACIA_PLANKS,
                Blocks.ACACIA_PLANKS, Blocks.DARK_OAK_DOOR);
        b.mod(-1, 0, 3, CoasterControlPanel.SHERIFF_DESK_BLOCK.get(), Direction.NORTH);
        b.set(-1, 0, 4, b.f(Blocks.ACACIA_STAIRS, Direction.SOUTH));
        b.mod(-2, 1, 3, CoasterControlPanel.WANTED_BOARD_BLOCK.get(), Direction.EAST);
        b.set(-2, 0, 1, b.f(Blocks.LECTERN, Direction.EAST));
        b.set(-2, 0, 5, b.f(Blocks.CHEST, Direction.EAST));
        b.barrel(-2, 0, 4);
        // the cell: bars at x = 0 with an iron door, bars across the front
        for (int y = 0; y <= 3; y++) {
            b.set(0, y, 3, d(Blocks.IRON_BARS));
            b.set(0, y, 5, d(Blocks.IRON_BARS));
            b.set(1, y, 2, d(Blocks.IRON_BARS));
            b.set(2, y, 2, d(Blocks.IRON_BARS));
        }
        b.set(0, 2, 4, d(Blocks.IRON_BARS));
        b.set(0, 3, 4, d(Blocks.IRON_BARS));
        b.door(0, 0, 4, Blocks.IRON_DOOR, Direction.EAST);
        b.bed(2, 0, 4, Direction.SOUTH, Blocks.GRAY_BED);
        b.mod(-2, 0, -1, CoasterControlPanel.HITCHING_POST_BLOCK.get(), Direction.NORTH);
    }

    private static void chocolate(B b) {
        shell(b, Blocks.SPRUCE_PLANKS, Blocks.STRIPPED_SPRUCE_LOG, Blocks.SPRUCE_PLANKS, Blocks.BRICK_STAIRS, Blocks.BRICKS,
                Blocks.SPRUCE_PLANKS, Blocks.SPRUCE_DOOR);
        b.fill(-2, 0, 1, 2, 0, 5, d(Blocks.RED_CARPET));
        // the serving window: the counter sits in the west wall, facing outwards
        b.mod(-3, 0, 3, CoasterControlPanel.HOT_CHOCOLATE_COUNTER_BLOCK.get(), Direction.WEST);
        b.set(-3, 1, 3, d(Blocks.AIR));
        b.set(-3, 2, 3, d(Blocks.GLASS_PANE));
        b.set(-3, 2, 2, d(Blocks.SPRUCE_PLANKS));
        b.set(-3, 2, 4, d(Blocks.SPRUCE_PLANKS));
        b.set(-3, 1, 2, d(Blocks.SPRUCE_PLANKS));
        b.set(-3, 1, 4, d(Blocks.SPRUCE_PLANKS));
        b.set(-2, 0, 2, d(Blocks.CAULDRON));
        b.set(-2, 0, 4, b.f(Blocks.SMOKER, Direction.EAST));
        b.set(-2, 0, 5, d(Blocks.BREWING_STAND));
        b.barrel(2, 0, 1);
        b.barrel(2, 0, 2);
        b.set(2, 0, 5, b.f(Blocks.CHEST, Direction.WEST));
        // a table and two stools for guests
        b.set(1, 0, 3, d(Blocks.SPRUCE_FENCE));
        b.set(1, 1, 3, d(Blocks.SPRUCE_PRESSURE_PLATE));
        b.set(2, 0, 3, b.f(Blocks.SPRUCE_STAIRS, Direction.WEST));
        b.set(0, 0, 3, b.f(Blocks.SPRUCE_STAIRS, Direction.EAST));
        b.set(2, 0, -1, d(Blocks.SNOW_BLOCK));
        b.set(-2, 0, -1, d(Blocks.SNOW_BLOCK));
    }

    private static void cabin(B b) {
        shell(b, Blocks.STRIPPED_SPRUCE_LOG, Blocks.SPRUCE_LOG, Blocks.SPRUCE_PLANKS, Blocks.SMOOTH_QUARTZ_STAIRS, Blocks.SNOW_BLOCK,
                Blocks.SPRUCE_PLANKS, Blocks.SPRUCE_DOOR);
        b.fill(-1, 0, 1, 1, 0, 4, d(Blocks.RED_CARPET));
        // fireplace on the back wall
        b.set(-1, 0, 5, d(Blocks.STONE_BRICKS));
        b.set(1, 0, 5, d(Blocks.STONE_BRICKS));
        b.set(-1, 1, 5, d(Blocks.STONE_BRICKS));
        b.set(1, 1, 5, d(Blocks.STONE_BRICKS));
        b.set(0, 1, 5, d(Blocks.STONE_BRICKS));
        b.set(0, 0, 5, d(Blocks.CAMPFIRE));
        b.bed(-2, 0, 2, Direction.SOUTH, Blocks.WHITE_BED);
        b.set(2, 0, 1, d(Blocks.BOOKSHELF));
        b.set(2, 1, 1, d(Blocks.BOOKSHELF));
        b.set(2, 0, 2, d(Blocks.BOOKSHELF));
        b.set(2, 1, 2, d(Blocks.BOOKSHELF));
        b.set(2, 0, 4, b.f(Blocks.CHEST, Direction.WEST));
        b.set(-2, 0, 4, d(Blocks.SPRUCE_FENCE));
        b.set(-2, 1, 4, d(Blocks.SPRUCE_PRESSURE_PLATE));
        b.mod(2, 0, -1, CoasterControlPanel.TOBOGGAN_BLOCK.get(), Direction.NORTH);
        b.mod(-2, 0, -1, CoasterControlPanel.SKI_RACK_BLOCK.get(), Direction.NORTH);
        b.set(-3, 0, -1, d(Blocks.SNOW_BLOCK));
        b.set(3, 0, -1, d(Blocks.SNOW_BLOCK));
    }

    /** A 6 by 6 tent: red and white stripes, two sleeping bags inside, a fire pit in front. */
    private static void tent(B b) {
        b.clear(-4, 0, -3, 3, 5, 6);
        BlockState red = d(Blocks.RED_WOOL);
        BlockState white = d(Blocks.WHITE_WOOL);
        for (int z = 0; z <= 5; z++) {
            BlockState c = z % 2 == 1 ? red : white;
            b.fill(-3, 0, z, -3, 2, z, c);
            b.fill(2, 0, z, 2, 2, z, c);
            b.fill(-2, 2, z, -2, 3, z, c);
            b.fill(1, 2, z, 1, 3, z, c);
            b.fill(-1, 3, z, 0, 3, z, c);
        }
        for (int z : new int[] {0, 5}) {
            b.fill(-3, 0, z, 2, 2, z, white);
            b.fill(-2, 3, z, 1, 3, z, white);
        }
        b.clear(-1, 0, 0, 0, 1, 0);
        b.bag(-2, 0, 1, Direction.SOUTH);
        b.bag(1, 0, 1, Direction.SOUTH);
        b.lantern(0, 2, 2);
        b.set(-1, 0, 4, b.f(Blocks.CHEST, Direction.NORTH));
        b.barrel(0, 0, 4);
        // fire pit, two tiles joined, with a log seat each side
        Direction west = b.rot.rotate(Direction.WEST);
        Direction east = b.rot.rotate(Direction.EAST);
        BlockState pit = CoasterControlPanel.CAMPFIRE_PIT_BLOCK.get().defaultBlockState().setValue(ParkConnect.LIT, true);
        b.set(-1, 0, -2, pit.setValue(ParkConnect.prop(east), true));
        b.set(0, 0, -2, pit.setValue(ParkConnect.prop(west), true));
        b.mod(-3, 0, -2, CoasterControlPanel.LOG_SEAT_BLOCK.get(), Direction.EAST);
        b.mod(2, 0, -2, CoasterControlPanel.LOG_SEAT_BLOCK.get(), Direction.WEST);
    }
}
