package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterControlPanel;
import com.example.coastercontrolpanel.TabSections;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/** Replaces the contents of our own tab with the sectioned layout (with empty header rows). */
@Mixin(CreativeModeTab.class)
public abstract class CreativeModeTabMixin {
    @Shadow
    @Mutable
    private Collection<ItemStack> displayItems;

    @Shadow
    @Mutable
    private Set<ItemStack> displayItemsSearchTab;

    @Inject(method = "buildContents", at = @At("TAIL"))
    private void coastercontrolpanel$sectionise(CreativeModeTab.ItemDisplayParameters parameters, CallbackInfo ci) {
        if ((Object) this != CoasterControlPanel.MAIN_TAB.get()) {
            return;
        }
        // A plain list, because the default collection would merge the identical empty slots.
        ArrayList<ItemStack> grid = new ArrayList<>();
        LinkedHashSet<ItemStack> search = new LinkedHashSet<>();
        TabSections.build(grid::add, search::add);
        this.displayItems = grid;
        this.displayItemsSearchTab = search;
    }
}
