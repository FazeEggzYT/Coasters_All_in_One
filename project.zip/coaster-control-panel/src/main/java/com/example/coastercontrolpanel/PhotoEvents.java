package com.example.coastercontrolpanel;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Game-bus client events for the ride photos. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, value = Dist.CLIENT)
public class PhotoEvents {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        PhotoClient.tick();
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            PhotoClient.afterLevel();
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        PhotoClient.reset();
    }
}
