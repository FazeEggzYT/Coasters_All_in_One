package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: number and channel of a marker. */
public record MarkerConfigPacket(BlockPos pos, int number, int channel) implements CustomPacketPayload {
    public static final Type<MarkerConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "marker_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MarkerConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.number);
                buf.writeVarInt(p.channel);
            },
            buf -> new MarkerConfigPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(MarkerConfigPacket p, IPayloadContext context) {
        MarkerBlockEntity m = MarkerBlockEntity.lookup(context.player(), p.pos);
        if (m != null) {
            m.apply(p.number, p.channel);
        }
    }
}
