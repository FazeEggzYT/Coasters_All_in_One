package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;

/** Finds the ride engine at a position for a player who is close enough to use it. */
public final class RideLookup {
    private RideLookup() {
    }

    @Nullable
    public static RideEngine find(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 400.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof RideEngine e ? e : null;
    }
}
