package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client to server, for every button in the restaurant screens.
 * Actions: 0 kiosk order (a = menu row), 1 kiosk price (a = row, b = change), 2 kiosk remove row (a),
 * 10 register ready (a = order number), 11 register ready all, 12 register clear all,
 * 20 pickup collect, 30 squeeze sauce (a = 0 ketchup, 1 mustard), 100 set option (a = option, b = value).
 */
public record RestaurantActionPacket(BlockPos pos, int action, int a, int b) implements CustomPacketPayload {
    public static final Type<RestaurantActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "restaurant_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, RestaurantActionPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
                buf.writeVarInt(p.a);
                buf.writeVarInt(p.b + 1000);
            },
            buf -> new RestaurantActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt() - 1000));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(RestaurantActionPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        Level level = player.level();
        if (player.distanceToSqr(p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5) > 144.0 || !level.isLoaded(p.pos)) {
            return;
        }
        switch (p.action) {
            case 0, 1, 2 -> {
                if (level.getBlockEntity(p.pos) instanceof RestaurantBlocks.KioskBlockEntity k) {
                    if (p.action == 0) {
                        k.placeOrder(player, p.a);
                    } else if (p.action == 1) {
                        k.changePrice(p.a, p.b);
                    } else {
                        k.clearOffer(p.a);
                    }
                }
            }
            case 10, 11, 12 -> {
                RestaurantBlocks.KioskBlockEntity k = RestaurantBlocks.findKiosk(level, p.pos);
                if (k != null) {
                    if (p.action == 10) {
                        k.markReady(p.a);
                    } else if (p.action == 11) {
                        k.markAllReady();
                    } else {
                        k.clearOrders();
                    }
                }
            }
            case 20 -> {
                RestaurantBlocks.KioskBlockEntity k = RestaurantBlocks.findKiosk(level, p.pos);
                int n = k == null ? 0 : k.collect(player);
                player.displayClientMessage(Component.translatable(n > 0 ? "message.coastercontrolpanel.pickup_ok"
                        : "message.coastercontrolpanel.pickup_none", n), true);
            }
            case 30 -> {
                if (level.getBlockEntity(p.pos) instanceof RestaurantBlocks.CondimentBlockEntity c) {
                    c.squeeze(player, p.a);
                }
            }
            case 100 -> {
                BlockState s = level.getBlockState(p.pos);
                if (s.getBlock() instanceof RestaurantConfigurable c && p.a >= 0 && p.a < c.options().length) {
                    level.setBlock(p.pos, RestaurantConfigurable.set(s, c.options()[p.a], p.b), 3);
                }
            }
            default -> {
            }
        }
    }
}
