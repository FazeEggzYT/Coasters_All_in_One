package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * The Park Hotel and Resort pack. The Reception Desk checks guests in (for gold nuggets) and gives them a Room Key Card;
 * a Hotel Room Door only opens for the card of its current stay, or for staff with a badge.
 */
public final class ResortBlocks {
    private ResortBlocks() {
    }

    public static final int ROOM_RADIUS = 40;

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    // ------------------------------------------------------------------ key card

    public static class RoomKeyItem extends Item {
        public RoomKeyItem(Properties p) {
            super(p.stacksTo(1));
        }

        public static ItemStack make(UUID room, UUID stay, int number) {
            ItemStack s = new ItemStack(CoasterControlPanel.ROOM_KEY.get());
            CompoundTag t = new CompoundTag();
            t.putUUID("Room", room);
            t.putUUID("Stay", stay);
            t.putInt("Number", number);
            s.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
            return s;
        }

        public static CompoundTag data(ItemStack s) {
            return s.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        }

        public static boolean fits(ItemStack s, RoomDoorBlockEntity room) {
            if (!(s.getItem() instanceof RoomKeyItem) || room.stay == null) {
                return false;
            }
            CompoundTag t = data(s);
            return t.hasUUID("Room") && t.hasUUID("Stay") && t.getUUID("Room").equals(room.roomId) && t.getUUID("Stay").equals(room.stay);
        }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            tip.add(Component.translatable("item.coastercontrolpanel.room_key_card.tip", data(stack).getInt("Number")));
        }
    }

    public static boolean canEnter(Player p, RoomDoorBlockEntity room) {
        if (StaffBlocks.hasBadge(p)) {
            return true;
        }
        for (ItemStack s : p.getInventory().items) {
            if (RoomKeyItem.fits(s, room)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ room door

    public static class RoomDoorBlockEntity extends RestaurantBlocks.Syncing {
        public UUID roomId = UUID.randomUUID();
        public int number;
        @Nullable
        public UUID stay;
        public String guestName = "";

        public RoomDoorBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.ROOM_DOOR_BE.get(), pos, state);
            number = 101 + (int) Math.floorMod(pos.asLong(), 300L);
        }

        public void changeNumber(int d) {
            number = Math.max(1, Math.min(9999, number + d));
            changed();
        }

        public void vacate() {
            stay = null;
            guestName = "";
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putUUID("Room", roomId);
            tag.putInt("Number", number);
            tag.putString("Guest", guestName);
            if (stay != null) {
                tag.putUUID("Stay", stay);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            if (tag.hasUUID("Room")) {
                roomId = tag.getUUID("Room");
            }
            number = tag.contains("Number") ? tag.getInt("Number") : number;
            guestName = tag.getString("Guest");
            stay = tag.hasUUID("Stay") ? tag.getUUID("Stay") : null;
        }
    }

    public static List<RoomDoorBlockEntity> rooms(Level level, BlockPos pos, int radius) {
        List<RoomDoorBlockEntity> out = new ArrayList<>();
        for (int cx = (pos.getX() - radius) >> 4; cx <= (pos.getX() + radius) >> 4; cx++) {
            for (int cz = (pos.getZ() - radius) >> 4; cz <= (pos.getZ() + radius) >> 4; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (be instanceof RoomDoorBlockEntity r && r.getBlockPos().distSqr(pos) <= (double) radius * radius) {
                        out.add(r);
                    }
                }
            }
        }
        out.sort(Comparator.comparingInt((RoomDoorBlockEntity r) -> r.number));
        return out;
    }

    public static class RoomDoorBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<RoomDoorBlock> CODEC = simpleCodec(RoomDoorBlock::new);

        public RoomDoorBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(GuestBlocks.OPEN, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            super.createBlockStateDefinition(b);
            b.add(GuestBlocks.OPEN);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(GuestBlocks.OPEN, false);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return s.getValue(GuestBlocks.OPEN) ? DecorBlocks.dbox(f, 0, 0, 6, 3, 16, 16) : DecorBlocks.dbox(f, 0, 0, 6, 16, 16, 10);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new RoomDoorBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!(level.getBlockEntity(pos) instanceof RoomDoorBlockEntity be)) {
                return InteractionResult.PASS;
            }
            boolean info = player.isShiftKeyDown() || !canEnter(player, be);
            if (level.isClientSide) {
                if (info) {
                    ClientHooks.openResort(1, pos);
                }
                return InteractionResult.SUCCESS;
            }
            if (info) {
                level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.3F, 1.9F);
                return InteractionResult.CONSUME;
            }
            boolean open = !s.getValue(GuestBlocks.OPEN);
            level.setBlock(pos, s.setValue(GuestBlocks.OPEN, open), 3);
            level.playSound(null, pos, open ? SoundEvents.WOODEN_DOOR_OPEN : SoundEvents.WOODEN_DOOR_CLOSE, SoundSource.BLOCKS, 0.8F, 1.0F);
            if (open) {
                level.scheduleTick(pos, this, 100);
            }
            return InteractionResult.CONSUME;
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(GuestBlocks.OPEN)) {
                if (StaffBlocks.someoneInDoorway(level, pos, s.getValue(DecorBlocks.FACING))) {
                    level.scheduleTick(pos, this, 10);
                    return;
                }
                level.setBlock(pos, s.setValue(GuestBlocks.OPEN, false), 3);
                level.playSound(null, pos, SoundEvents.WOODEN_DOOR_CLOSE, SoundSource.BLOCKS, 0.8F, 1.0F);
            }
        }
    }

    // ------------------------------------------------------------------ reception desk

    public static class ReceptionBlockEntity extends RestaurantBlocks.Syncing {
        public int price = 12;
        public int takings;

        public ReceptionBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.RECEPTION_BE.get(), pos, state);
        }

        public void checkIn(ServerPlayer p) {
            if (level == null) {
                return;
            }
            List<RoomDoorBlockEntity> rooms = rooms(level, worldPosition, ROOM_RADIUS);
            for (RoomDoorBlockEntity r : rooms) {
                for (ItemStack s : p.getInventory().items) {
                    if (RoomKeyItem.fits(s, r)) {
                        say(p, "hotel_already", r.number);
                        return;
                    }
                }
            }
            RoomDoorBlockEntity free = null;
            for (RoomDoorBlockEntity r : rooms) {
                if (r.stay == null) {
                    free = r;
                    break;
                }
            }
            if (free == null) {
                say(p, "hotel_full");
                return;
            }
            if (!p.getAbilities().instabuild) {
                if (ArcadeBlocks.count(p, Items.GOLD_NUGGET) < price) {
                    say(p, "shop_poor", price);
                    return;
                }
                ArcadeBlocks.take(p, Items.GOLD_NUGGET, price);
                takings += price;
            }
            free.stay = UUID.randomUUID();
            free.guestName = p.getGameProfile().getName();
            free.changed();
            ArcadeBlocks.give(p, RoomKeyItem.make(free.roomId, free.stay, free.number));
            level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 0.9F, 1.4F);
            say(p, "hotel_checked_in", free.number);
            changed();
        }

        public void checkOut(ServerPlayer p) {
            if (level == null) {
                return;
            }
            List<RoomDoorBlockEntity> rooms = rooms(level, worldPosition, ROOM_RADIUS);
            for (ItemStack s : p.getInventory().items) {
                for (RoomDoorBlockEntity r : rooms) {
                    if (RoomKeyItem.fits(s, r)) {
                        s.shrink(1);
                        r.vacate();
                        say(p, "hotel_checked_out", r.number);
                        return;
                    }
                }
            }
            say(p, "hotel_no_stay");
        }

        public void changePrice(int d) {
            price = Math.max(1, Math.min(200, price + d));
            changed();
        }

        public void collect(ServerPlayer p) {
            int left = takings;
            takings = 0;
            if (left <= 0) {
                say(p, "shop_no_takings");
                return;
            }
            while (left > 0) {
                int t = Math.min(64, left);
                ArcadeBlocks.give(p, new ItemStack(Items.GOLD_NUGGET, t));
                left -= t;
            }
            changed();
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            tag.putInt("Price", price);
            tag.putInt("Takings", takings);
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            price = tag.contains("Price") ? Math.max(1, tag.getInt("Price")) : 12;
            takings = tag.getInt("Takings");
        }
    }

    public static class ReceptionBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<ReceptionBlock> CODEC = simpleCodec(ReceptionBlock::new);

        public ReceptionBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 2, 16, 16, 14);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new ReceptionBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openResort(0, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ storage (luggage trolley, parts shelf)

    public static class StorageBlockEntity extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);

        public StorageBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.STORAGE_BE.get(), pos, state);
        }

        @Override
        public int getContainerSize() {
            return 27;
        }

        @Override
        protected Component getDefaultName() {
            return Component.translatable(getBlockState().getBlock().getDescriptionId());
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return ChestMenu.threeRows(id, inv, this);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
        }
    }

    public abstract static class StorageBlock extends RestaurantBlocks.FacingEntityBlock {
        protected StorageBlock(Properties p) {
            super(p);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new StorageBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof StorageBlockEntity be) {
                player.openMenu(be);
                level.playSound(null, pos, SoundEvents.BARREL_OPEN, SoundSource.BLOCKS, 0.5F, 1.1F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof StorageBlockEntity c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    public static class LuggageBlock extends StorageBlock {
        public static final MapCodec<LuggageBlock> CODEC = simpleCodec(LuggageBlock::new);

        public LuggageBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 0, 2, 15, 16, 14);
        }
    }

    public static class PartsShelfBlock extends StorageBlock {
        public static final MapCodec<PartsShelfBlock> CODEC = simpleCodec(PartsShelfBlock::new);

        public PartsShelfBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 0, 3, 16, 16, 13);
        }
    }

    // ------------------------------------------------------------------ bellhop stand, pool bar, bed

    public static class BellStandBlock extends DecorBlocks.Facing {
        public BellStandBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 2, 0, 3, 14, 16, 13);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                level.playSound(null, pos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.2F, 1.5F);
                say(player, "bell_ring");
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    public static class PoolBarBlock extends DecorBlocks.Facing {
        public PoolBarBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 0, 0, 3, 16, 16, 13);
        }
    }

    /** A real two-block bed: sleep in it at night, and it sets your respawn point. */
    public static class HotelBedBlock extends net.minecraft.world.level.block.BedBlock {
        public HotelBedBlock(Properties p) {
            super(net.minecraft.world.item.DyeColor.WHITE, p);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return null;
        }

        @Override
        protected net.minecraft.world.level.block.RenderShape getRenderShape(BlockState state) {
            return net.minecraft.world.level.block.RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(FACING);
            boolean head = s.getValue(PART) == net.minecraft.world.level.block.state.properties.BedPart.HEAD;
            VoxelShape base = DecorBlocks.dbox(f, 0, 0, 0, 16, 10, 16);
            return head ? Shapes.or(base, DecorBlocks.dbox(f, 0, 10, 0, 16, 20, 2))
                    : Shapes.or(base, DecorBlocks.dbox(f, 0, 10, 14, 16, 12, 16));
        }
    }

    // ------------------------------------------------------------------ resort sign

    public static class ResortSignBlock extends RestaurantBlocks.FacingEntityBlock implements GuestBlocks.TextHolder {
        public static final MapCodec<ResortSignBlock> CODEC = simpleCodec(ResortSignBlock::new);

        public ResortSignBlock(Properties p) {
            super(p);
        }

        @Override
        public int textLines() {
            return 3;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 4, 13, 16, 16, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new GuestBlocks.TextBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openResort(2, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
