package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterControlPanel;
import com.example.coastercontrolpanel.CoasterTools;
import com.example.coastercontrolpanel.TransferPlatform;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Transfer track: Coasters Simulated refuses to connect an anchor on a moving structure to an anchor in the normal
 * world ("Cannot connect anchorpoints between sublevels"). While the player holds the Track Unrestrictor, or when either anchor is on a Transfer
 * Table platform, that rule is switched off, so the joins between a Transfer Table platform and the side track can be built. Optional.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.CoasterTrackPlacement", remap = false)
public class AnchorAcrossSubLevelsMixin {
    private static int logged;

    @Inject(method = "anchorConnectionAcrossSubLevels", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void ccp$across(Level level, BlockPos a, BlockPos b, CallbackInfoReturnable<Boolean> cir) {
        boolean tool = CoasterTools.active();
        boolean platform = TransferPlatform.isOnPlatform(level, a) || TransferPlatform.isOnPlatform(level, b);
        if (logged < 12) {
            logged++;
            CoasterControlPanel.LOGGER.info("Transfer track: anchor join between sub-levels asked for {} and {} (Track Unrestrictor {}, on a platform {}).",
                    a.toShortString(), b.toShortString(), tool, platform);
        }
        if (tool || platform) {
            cir.setReturnValue(false);
        }
    }
}
