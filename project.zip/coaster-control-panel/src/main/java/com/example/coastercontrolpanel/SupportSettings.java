package com.example.coastercontrolpanel;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/** The settings of the Support Tool, kept on the item itself. */
public record SupportSettings(int style, int spacing, int thickness, int material, int gap) {
    public static final String[] STYLES = {"Pillar", "Twin pillars", "A-frame", "Lattice tower"};
    public static final String[] MATERIAL_NAMES = {"Stone bricks", "Polished andesite", "Smooth stone", "Iron block",
            "White concrete", "Grey concrete", "Black concrete", "Red concrete", "Dark oak planks", "Quartz",
            "Block in off-hand"};
    public static final Block[] MATERIALS = {Blocks.STONE_BRICKS, Blocks.POLISHED_ANDESITE, Blocks.SMOOTH_STONE,
            Blocks.IRON_BLOCK, Blocks.WHITE_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.BLACK_CONCRETE,
            Blocks.RED_CONCRETE, Blocks.DARK_OAK_PLANKS, Blocks.QUARTZ_BLOCK};
    /** Colours used by the settings screen's little preview. */
    public static final int[] MATERIAL_COLORS = {0xFF7A7A7A, 0xFF8A8D8F, 0xFF9A9A9A, 0xFFD8D8D8, 0xFFE8E8E8, 0xFF4A4D52,
            0xFF1A1A1E, 0xFFB03030, 0xFF4A3220, 0xFFEDE8E0, 0xFFB09060};

    public static final int[] MIN = {0, 3, 1, 0, -2};
    public static final int[] MAX = {3, 20, 3, 10, 6};
    public static final int[] DEF = {0, 6, 1, 0, 0};

    public static SupportSettings of(ItemStack stack) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return new SupportSettings(
                get(tag, "Style", 0), get(tag, "Spacing", 1), get(tag, "Thick", 2),
                get(tag, "Material", 3), get(tag, "Gap", 4));
    }

    private static int get(CompoundTag tag, String key, int i) {
        int v = tag.contains(key) ? tag.getInt(key) : DEF[i];
        return Math.max(MIN[i], Math.min(MAX[i], v));
    }

    public static void write(ItemStack stack, int style, int spacing, int thickness, int material, int gap) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        tag.putInt("Style", Math.max(MIN[0], Math.min(MAX[0], style)));
        tag.putInt("Spacing", Math.max(MIN[1], Math.min(MAX[1], spacing)));
        tag.putInt("Thick", Math.max(MIN[2], Math.min(MAX[2], thickness)));
        tag.putInt("Material", Math.max(MIN[3], Math.min(MAX[3], material)));
        tag.putInt("Gap", Math.max(MIN[4], Math.min(MAX[4], gap)));
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    /** The block the supports are made of. */
    public Block block(Player player) {
        if (material >= MATERIALS.length) {
            ItemStack off = player.getOffhandItem();
            if (off.getItem() instanceof BlockItem bi) {
                return bi.getBlock();
            }
            return Blocks.STONE_BRICKS;
        }
        return MATERIALS[material];
    }
}
