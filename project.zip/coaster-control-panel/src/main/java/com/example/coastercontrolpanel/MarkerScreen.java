package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen of a guest marker: its number (queue markers) and its channel. */
public class MarkerScreen extends Screen {
    private static final int W = 232;
    private static final int H = 124;

    private final BlockPos pos;
    private MarkerKind kind = MarkerKind.QUEUE;
    private int number = 1;
    private int channel = 1;
    private int left;
    private int top;

    public MarkerScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.marker_title"));
        this.pos = pos;
    }

    private int step() {
        return Screen.hasShiftDown() ? 5 : 1;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof MarkerBlockEntity m) {
            kind = m.kind();
            number = m.getNumber();
            channel = m.getChannel();
        }
        int row = 0;
        if (kind == MarkerKind.QUEUE) {
            addPair(top + 26, () -> number = Math.max(1, number - step()), () -> number = Math.min(99, number + step()));
            row = 1;
        }
        addPair(top + 26 + row * 22, () -> channel = Math.max(1, channel - 1), () -> channel = Math.min(16, channel + 1));
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(left + W - 52, top + H - 24, 44, 16).build());
    }

    private void addPair(int y, Runnable minus, Runnable plus) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> minus.run())
                .bounds(left + 108, y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> plus.run())
                .bounds(left + 194, y, 18, 16).build());
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new MarkerConfigPacket(pos, number, channel));
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        Component name = Component.translatable("block.coastercontrolpanel." + kind.id);
        g.drawString(font, name, left + 8, top + 7, 0xFFFFFF, false);
        int text = 0xE0E4F0;
        int row = 0;
        if (kind == MarkerKind.QUEUE) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.marker_number"), left + 8, top + 30, text, false);
            g.drawCenteredString(font, "#" + number, left + 160, top + 30, 0xFFFFFF);
            row = 1;
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.marker_channel"), left + 8, top + 30 + row * 22, text, false);
        g.drawCenteredString(font, String.valueOf(channel), left + 160, top + 30 + row * 22, 0xFFFFFF);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.marker_hint." + kind.id), left + 8,
                top + H - 52, 0x7A8098, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.marker_hint_channel"), left + 8,
                top + H - 40, 0x7A8098, false);
    }
}
