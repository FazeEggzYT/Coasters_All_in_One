package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Setup for the Announcement Panel: per row a name, a sound, a volume and a pitch. */
public class AnnounceSetupScreen extends Screen {
    private static final int ROWS = AnnouncePanelBlockEntity.ROWS;
    private static final int W = 380;
    private static final int H = 262;
    private static final int ROW_Y = 44;
    private static final int ROW_STEP = 19;

    private final BlockPos pos;
    private final String[] names = new String[ROWS];
    private final int[] sounds = new int[ROWS];
    private final int[] volumes = new int[ROWS];
    private final int[] pitches = new int[ROWS];
    private final EditBox[] nameBoxes = new EditBox[ROWS];
    private final Button[] soundButtons = new Button[ROWS];
    private final Button[] fileButtons = new Button[ROWS];
    private final boolean[] hasClip = new boolean[ROWS];
    private int armed = -1;

    public AnnounceSetupScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.announce_setup_title"));
        this.pos = pos;
    }

    private int step(int normal, int big) {
        return Screen.hasShiftDown() ? big : normal;
    }

    @Override
    protected void init() {
        AnnouncePanelBlockEntity p = minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof AnnouncePanelBlockEntity a ? a : null;
        for (int r = 0; r < ROWS; r++) {
            names[r] = p != null ? p.getName(r) : "";
            sounds[r] = p != null ? p.getSound(r) : 0;
            volumes[r] = p != null ? p.getVolume(r) : 200;
            pitches[r] = p != null ? p.getPitch(r) : 100;
            hasClip[r] = p != null && !p.getClip(r).isEmpty();
        }
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(x + W - 48, y + 6, 40, 16).build());
        for (int r = 0; r < ROWS; r++) {
            final int row = r;
            int ry = y + ROW_Y + ROW_STEP * r;
            EditBox box = new EditBox(font, x + 8, ry, 88, 16, Component.empty());
            box.setMaxLength(14);
            box.setValue(names[r]);
            box.setHint(Component.translatable("gui.coastercontrolpanel.unused"));
            nameBoxes[r] = box;
            addRenderableWidget(box);

            soundButtons[r] = Button.builder(soundLabel(r), b -> {
                if (hasClip[row]) {
                    // first click: go back to the built-in sounds
                    hasClip[row] = false;
                    PacketDistributor.sendToServer(new ClipUploadPacket(pos, row, 0, 0, new byte[0]));
                } else {
                    sounds[row] = (sounds[row] + 1) % AnnouncerSounds.count();
                }
                b.setMessage(soundLabel(row));
            }).bounds(x + 100, ry, 96, 16).build();
            addRenderableWidget(soundButtons[r]);

            fileButtons[r] = Button.builder(Component.translatable("gui.coastercontrolpanel.file_button"), b -> {
                armed = armed == row ? -1 : row;
            }).bounds(x + 348, ry, 28, 16).build();
            addRenderableWidget(fileButtons[r]);

            addRenderableWidget(Button.builder(Component.literal("-"),
                    b -> volumes[row] = Math.max(10, volumes[row] - step(10, 50)))
                    .bounds(x + 202, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"),
                    b -> volumes[row] = Math.min(AnnouncePanelBlockEntity.MAX_VOLUME, volumes[row] + step(10, 50)))
                    .bounds(x + 252, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("-"),
                    b -> pitches[row] = Math.max(50, pitches[row] - step(10, 25)))
                    .bounds(x + 280, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"),
                    b -> pitches[row] = Math.min(200, pitches[row] + step(10, 25)))
                    .bounds(x + 330, ry, 14, 16).build());
        }
    }

    private Component soundLabel(int r) {
        return hasClip[r] ? Component.translatable("gui.coastercontrolpanel.clip_label")
                : Component.literal(AnnouncerSounds.NAMES[sounds[r]]);
    }

    private void say(String key) {
        if (minecraft != null && minecraft.player != null) {
            minecraft.player.displayClientMessage(Component.translatable(key), true);
        }
    }

    /** Drag an .ogg file from the desktop onto the game window: it goes to the row whose File button is on. */
    @Override
    public void onFilesDrop(List<Path> files) {
        if (armed < 0) {
            say("message.coastercontrolpanel.clip_pick_row");
            return;
        }
        if (files.isEmpty()) {
            return;
        }
        Path file = files.get(0);
        try {
            if (!file.getFileName().toString().toLowerCase().endsWith(".ogg")) {
                say("message.coastercontrolpanel.clip_not_ogg");
                return;
            }
            if (Files.size(file) > ClipStore.MAX_BYTES) {
                say("message.coastercontrolpanel.clip_too_big");
                return;
            }
            byte[] bytes = Files.readAllBytes(file);
            int total = (bytes.length + ClipStore.CHUNK - 1) / ClipStore.CHUNK;
            for (int i = 0; i < total; i++) {
                int from = i * ClipStore.CHUNK;
                int to = Math.min(bytes.length, from + ClipStore.CHUNK);
                byte[] part = new byte[to - from];
                System.arraycopy(bytes, from, part, 0, part.length);
                PacketDistributor.sendToServer(new ClipUploadPacket(pos, armed, i, total, part));
            }
            hasClip[armed] = true;
            soundButtons[armed].setMessage(soundLabel(armed));
            armed = -1;
        } catch (IOException e) {
            say("message.coastercontrolpanel.clip_unreadable");
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        String[] outNames = new String[ROWS];
        for (int r = 0; r < ROWS; r++) {
            outNames[r] = nameBoxes[r] != null ? nameBoxes[r].getValue() : names[r];
        }
        PacketDistributor.sendToServer(new AnnounceConfigPacket(pos, outNames, sounds.clone(), volumes.clone(),
                pitches.clone()));
        super.removed();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xFF3A3E4D);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xFF1B1D24);
        g.drawString(font, title, x + 8, y + 9, 0xFFFFFF, false);
        int dim = 0x7A8098;
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_name"), x + 10, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_sound"), x + 102, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_volume"), x + 204, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_pitch"), x + 282, y + 32, dim, false);
        for (int r = 0; r < ROWS; r++) {
            int ry = y + ROW_Y + ROW_STEP * r;
            g.drawCenteredString(font, volumes[r] + "%", x + 234, ry + 4, 0xFFFFFF);
            g.drawCenteredString(font, pitches[r] + "%", x + 312, ry + 4, 0xFFFFFF);
        }
        if (armed >= 0) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.clip_drop_hint", armed + 1),
                    x + 8, y + H - 14, 0xFFD060, false);
        } else {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_setup_hint"),
                    x + 8, y + H - 14, dim, false);
        }
    }
}
