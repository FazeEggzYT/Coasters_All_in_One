package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup for the Announcement Panel: per row a name, a sound, a volume and a pitch. */
public class AnnounceSetupScreen extends Screen {
    private static final int ROWS = AnnouncePanelBlockEntity.ROWS;
    private static final int W = 380;
    private static final int H = 262;
    private static final int ROW_Y = 44;
    private static final int ROW_STEP = 19;

    private final BlockPos pos;
    private final String[] names = new String[ROWS];
    private final int[] sounds = new int[ROWS];
    private final int[] volumes = new int[ROWS];
    private final int[] pitches = new int[ROWS];
    private final EditBox[] nameBoxes = new EditBox[ROWS];
    private final Button[] soundButtons = new Button[ROWS];

    public AnnounceSetupScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.announce_setup_title"));
        this.pos = pos;
    }

    private int step(int normal, int big) {
        return Screen.hasShiftDown() ? big : normal;
    }

    @Override
    protected void init() {
        AnnouncePanelBlockEntity p = minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof AnnouncePanelBlockEntity a ? a : null;
        for (int r = 0; r < ROWS; r++) {
            names[r] = p != null ? p.getName(r) : "";
            sounds[r] = p != null ? p.getSound(r) : 0;
            volumes[r] = p != null ? p.getVolume(r) : 200;
            pitches[r] = p != null ? p.getPitch(r) : 100;
        }
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(x + W - 48, y + 6, 40, 16).build());
        for (int r = 0; r < ROWS; r++) {
            final int row = r;
            int ry = y + ROW_Y + ROW_STEP * r;
            EditBox box = new EditBox(font, x + 8, ry, 88, 16, Component.empty());
            box.setMaxLength(14);
            box.setValue(names[r]);
            box.setHint(Component.translatable("gui.coastercontrolpanel.unused"));
            nameBoxes[r] = box;
            addRenderableWidget(box);

            soundButtons[r] = Button.builder(Component.literal(AnnouncerSounds.NAMES[sounds[r]]), b -> {
                sounds[row] = (sounds[row] + 1) % AnnouncerSounds.count();
                b.setMessage(Component.literal(AnnouncerSounds.NAMES[sounds[row]]));
            }).bounds(x + 100, ry, 96, 16).build();
            addRenderableWidget(soundButtons[r]);

            addRenderableWidget(Button.builder(Component.literal("-"),
                    b -> volumes[row] = Math.max(10, volumes[row] - step(10, 50)))
                    .bounds(x + 202, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"),
                    b -> volumes[row] = Math.min(AnnouncePanelBlockEntity.MAX_VOLUME, volumes[row] + step(10, 50)))
                    .bounds(x + 252, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("-"),
                    b -> pitches[row] = Math.max(50, pitches[row] - step(10, 25)))
                    .bounds(x + 280, ry, 14, 16).build());
            addRenderableWidget(Button.builder(Component.literal("+"),
                    b -> pitches[row] = Math.min(200, pitches[row] + step(10, 25)))
                    .bounds(x + 330, ry, 14, 16).build());
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        String[] outNames = new String[ROWS];
        for (int r = 0; r < ROWS; r++) {
            outNames[r] = nameBoxes[r] != null ? nameBoxes[r].getValue() : names[r];
        }
        PacketDistributor.sendToServer(new AnnounceConfigPacket(pos, outNames, sounds.clone(), volumes.clone(),
                pitches.clone()));
        super.removed();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xFF3A3E4D);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xFF1B1D24);
        g.drawString(font, title, x + 8, y + 9, 0xFFFFFF, false);
        int dim = 0x7A8098;
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.col_name"), x + 10, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_sound"), x + 102, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_volume"), x + 204, y + 32, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_col_pitch"), x + 282, y + 32, dim, false);
        for (int r = 0; r < ROWS; r++) {
            int ry = y + ROW_Y + ROW_STEP * r;
            g.drawCenteredString(font, volumes[r] + "%", x + 234, ry + 4, 0xFFFFFF);
            g.drawCenteredString(font, pitches[r] + "%", x + 312, ry + 4, 0xFFFFFF);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.announce_setup_hint"), x + 8, y + H - 14, dim, false);
    }
}
