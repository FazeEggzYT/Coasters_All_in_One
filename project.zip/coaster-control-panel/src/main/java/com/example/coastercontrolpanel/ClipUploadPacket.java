package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Client to server: a piece of an uploaded .ogg file for one row of an Announcement Panel.
 * total = 0 means "remove the uploaded file from this row".
 */
public record ClipUploadPacket(BlockPos pos, int row, int index, int total, byte[] data)
        implements CustomPacketPayload {
    public static final Type<ClipUploadPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip_upload"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ClipUploadPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.row);
                buf.writeVarInt(p.index);
                buf.writeVarInt(p.total);
                buf.writeByteArray(p.data);
            },
            buf -> new ClipUploadPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readByteArray(ClipStore.CHUNK + 16)));

    private static final class Upload {
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        BlockPos pos;
        int row;
        int next = 0;
        int total;
    }

    private static final Map<UUID, Upload> UPLOADS = new HashMap<>();

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ClipUploadPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        AnnouncePanelBlockEntity panel = AnnouncePanelBlockEntity.lookup(player, p.pos);
        if (panel == null || p.row < 0 || p.row >= AnnouncePanelBlockEntity.ROWS) {
            return;
        }
        if (p.total == 0) {
            panel.setClip(p.row, "");
            return;
        }
        int maxChunks = ClipStore.MAX_BYTES / ClipStore.CHUNK + 2;
        if (p.total < 1 || p.total > maxChunks) {
            return;
        }
        Upload up;
        if (p.index == 0) {
            up = new Upload();
            up.pos = p.pos;
            up.row = p.row;
            up.total = p.total;
            UPLOADS.put(player.getUUID(), up);
        } else {
            up = UPLOADS.get(player.getUUID());
            if (up == null || !up.pos.equals(p.pos) || up.row != p.row || up.next != p.index) {
                UPLOADS.remove(player.getUUID());
                return;
            }
        }
        up.bytes.writeBytes(p.data);
        up.next = p.index + 1;
        if (up.bytes.size() > ClipStore.MAX_BYTES) {
            UPLOADS.remove(player.getUUID());
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.clip_too_big"), true);
            return;
        }
        if (up.next < up.total) {
            return;
        }
        UPLOADS.remove(player.getUUID());
        byte[] file = up.bytes.toByteArray();
        if (!ClipStore.looksLikeOgg(file)) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.clip_not_ogg"), true);
            return;
        }
        String hash = ClipStore.save(player.server, file);
        if (hash == null) {
            return;
        }
        panel.setClip(p.row, hash);
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.clip_saved"), true);
    }
}
