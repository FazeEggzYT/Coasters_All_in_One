package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;

/** A block that can follow the track between two anchors (set with the Section Linker). */
public interface TrackZone {
    /** @return how many track points were found, 0 if the anchors are not connected */
    int setTrack(BlockPos a, BlockPos b);
}
