package com.example.coastercontrolpanel.animatronics;

/**
 * The skeleton rig. Plain Java, no Minecraft classes, so the poses can be checked outside the game.
 *
 * Coordinates are in pixels (16 per block) of the rest pose, x to the figure's right, y up, the front is -z.
 * The figure is 32 pixels tall and is drawn at 0.9 scale, so it is 1.8 blocks tall, the same as the player.
 *
 * Joint angles are degrees: pitch positive swings forward, roll positive swings outward, elbow positive bends
 * the forearm forward, knee positive bends the shin backward.
 */
public final class Rig {
    private Rig() {
    }

    // parts, parents come before their children
    public static final int TORSO = 0;
    public static final int HEAD = 1;
    public static final int ARM_L = 2;
    public static final int FORE_L = 3;
    public static final int ARM_R = 4;
    public static final int FORE_R = 5;
    public static final int LEG_L = 6;
    public static final int SHIN_L = 7;
    public static final int LEG_R = 8;
    public static final int SHIN_R = 9;
    /** Not a bone: stage props (drums and so on) that stay on the floor and only follow the figure's spin and bounce. */
    public static final int STAGE = 10;
    public static final int PARTS = 11;

    /** Parent part of each part, -1 for the top of the chain. */
    public static final int[] PARENT = {-1, TORSO, TORSO, ARM_L, TORSO, ARM_R, -1, LEG_L, -1, LEG_R, -1};

    /** Pivot of each part in rest coordinates. */
    public static final float[][] PIVOT = {
            {0, 12, 0}, {0, 24, 0}, {-6, 22, 0}, {-6, 16, 0}, {6, 22, 0}, {6, 16, 0},
            {-2, 12, 0}, {-2, 6, 0}, {2, 12, 0}, {2, 6, 0}, {0, 0, 0}};

    /** One coloured box in rest coordinates. glow = drawn fully bright. */
    public record Box(int part, float x0, float y0, float z0, float x1, float y1, float z1, int rgb, boolean glow) {
    }

    public static Box box(int part, float x0, float y0, float z0, float x1, float y1, float z1, int rgb) {
        return new Box(part, x0, y0, z0, x1, y1, z1, rgb, false);
    }

    public static Box glow(int part, float x0, float y0, float z0, float x1, float y1, float z1, int rgb) {
        return new Box(part, x0, y0, z0, x1, y1, z1, rgb, true);
    }

    public static final int BONE = 0xE8E4D4;
    public static final int BONE_SHADE = 0xBDB8A4;
    public static final int DARK = 0x1C1C20;

    /** The bare skeleton every character is built on. */
    public static java.util.List<Box> skeleton(int bone) {
        java.util.List<Box> b = new java.util.ArrayList<>();
        // skull, eye sockets, nose, teeth
        b.add(box(HEAD, -4, 24, -4, 4, 32, 4, bone));
        b.add(box(HEAD, -3, 27.5f, -4.1f, -1, 29.5f, -3.9f, DARK));
        b.add(box(HEAD, 1, 27.5f, -4.1f, 3, 29.5f, -3.9f, DARK));
        b.add(box(HEAD, -0.5f, 26, -4.1f, 0.5f, 27.5f, -3.9f, DARK));
        b.add(box(HEAD, -2.5f, 24.6f, -4.1f, 2.5f, 25.4f, -3.9f, DARK));
        // ribcage: torso with dark gaps between the ribs, spine behind
        b.add(box(TORSO, -4, 12, -2, 4, 24, 2, bone));
        for (int i = 0; i < 4; i++) {
            float y = 14.5f + i * 2.5f;
            b.add(box(TORSO, -3.5f, y, -2.1f, 3.5f, y + 0.8f, -1.9f, DARK));
        }
        b.add(box(TORSO, -0.5f, 12, -1, 0.5f, 24, 1, bone));
        // limbs: two bones each
        for (int side = -1; side <= 1; side += 2) {
            int arm = side < 0 ? ARM_L : ARM_R;
            int fore = side < 0 ? FORE_L : FORE_R;
            int leg = side < 0 ? LEG_L : LEG_R;
            int shin = side < 0 ? SHIN_L : SHIN_R;
            float ax = side * 6;
            float lx = side * 2;
            b.add(box(arm, ax - 1, 16, -1, ax + 1, 22, 1, bone));
            b.add(box(fore, ax - 1, 10, -1, ax + 1, 16, 1, bone));
            b.add(box(leg, lx - 1, 6, -1, lx + 1, 12, 1, bone));
            b.add(box(shin, lx - 1, 0, -1, lx + 1, 6, 1, bone));
            b.add(box(shin, lx - 1.5f, 0, -3, lx + 1.5f, 1, 1, bone_shade(bone)));
        }
        return b;
    }

    private static int bone_shade(int bone) {
        int r = (int) (((bone >> 16) & 255) * 0.85f);
        int g = (int) (((bone >> 8) & 255) * 0.85f);
        int bl = (int) ((bone & 255) * 0.85f);
        return (r << 16) | (g << 8) | bl;
    }
}
