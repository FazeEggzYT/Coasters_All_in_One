package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;

/**
 * Something an Animation Controller can drive with a timeline that is made of angles: a Swivel, Flip or Spin Bearing.
 * Anything else that wants to be on a timeline later (a door, a light) can implement this too.
 */
public interface TimelineTarget {
    /** The name on this thing's track. */
    Component timelineLabel();

    /** Server side: called every tick while the timeline plays, with the angle this thing should be at now. */
    void timelineSet(float degrees);

    /** Server side: the timeline stopped or let go of this thing. */
    void timelineRelease();
}
