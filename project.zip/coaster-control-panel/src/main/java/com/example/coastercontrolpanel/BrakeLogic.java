package com.example.coastercontrolpanel;

/**
 * The braking rules of a Brake Run, kept free of any Minecraft types so they can be checked on their own.
 *
 * All speeds are blocks per second measured along the Brake Run's own forward direction ("forward coordinates"):
 * positive = moving from the first anchor towards the second. {@link #step} is given a cart's current speed and the
 * time step and returns how much to ADD to that speed. Nothing here sets a speed directly, so the carts always
 * change speed through the normal physics (an acceleration limited by the brake strength), never by a jump.
 */
public final class BrakeLogic {
    public static final int NEW = 0;
    public static final int BRAKING = 1;
    public static final int HOLD = 2;
    public static final int RELEASE = 3;
    public static final int DONE = 4;
    public static final int PASS = 5;

    private static final double STOPPED = 0.08;
    private static final double MAX_ASSIST = 24.0;

    /** One cart's progress through one Brake Run. */
    public static final class State {
        public int phase = NEW;
        /** Seconds spent in the current phase. */
        public double time;
        /** The direction the cart travels while being braked / released: +1 forward, -1 reverse. */
        public int dir = 1;
        /** Seconds a Full Stop cart has been sitting still after its hold ended. */
        public double idle;
        public long lastTick = Long.MIN_VALUE;
        public long anchor;
    }

    private BrakeLogic() {
    }

    private static double ramp(BrakeSettings c, double t) {
        // never starts from zero, so braking and pushing begin straight away but still ease in
        return Math.min(1.0, 0.2 + 0.8 * t / Math.max(0.05, c.rampSeconds()));
    }

    /** Speed change (blocks per second) to add this step. */
    public static double step(State st, BrakeSettings c, double s, double dt) {
        double a = Math.abs(s);
        st.time += dt;
        switch (st.phase) {
            case NEW:
                return enter(st, c, s, a, dt);
            case PASS:
                return 0.0;
            case BRAKING:
                return braking(st, c, s, a, dt);
            case HOLD:
                return hold(st, c, s, dt);
            case RELEASE:
                return push(st, c, s, dt, BrakeSettings.toBlocksPerSecond(c.releaseKmh), true);
            case DONE:
                return done(st, c, s, dt);
            default:
                return 0.0;
        }
    }

    private static double enter(State st, BrakeSettings c, double s, double a, double dt) {
        boolean stopped = a < STOPPED;
        if (stopped) {
            st.dir = c.direction == BrakeSettings.DIR_REVERSE ? -1 : 1;
        } else {
            st.dir = s > 0 ? 1 : -1;
            boolean ok = c.direction == BrakeSettings.DIR_BOTH
                    || (c.direction == BrakeSettings.DIR_FORWARD && st.dir > 0)
                    || (c.direction == BrakeSettings.DIR_REVERSE && st.dir < 0);
            if (!ok) {
                st.phase = PASS;
                return 0.0;
            }
        }
        st.time = 0;
        if (c.mode == BrakeSettings.MODE_SLOWDOWN) {
            st.phase = BRAKING;
        } else {
            st.phase = stopped ? HOLD : BRAKING;
        }
        return step(st, c, s, dt);
    }

    private static double braking(State st, BrakeSettings c, double s, double a, double dt) {
        boolean slow = c.mode == BrakeSettings.MODE_SLOWDOWN;
        if (a >= STOPPED) {
            st.dir = s > 0 ? 1 : -1; // a cart that rolls back is braked in the direction it is now moving
        }
        double target = slow ? BrakeSettings.toBlocksPerSecond(c.targetKmh) : 0.0;
        double floor = slow ? Math.min(BrakeSettings.toBlocksPerSecond(c.minKmh), target) : 0.0;
        double decel = c.decel();
        if (c.limitEntry && a > BrakeSettings.toBlocksPerSecond(c.maxEntryKmh)) {
            decel = Math.max(decel, MAX_ASSIST); // too fast on entry: brake hard first, then follow the chosen strength
        }
        if (a > target + (slow ? 0.0 : STOPPED)) {
            double eased = decel * ramp(c, st.time);
            double d = Math.min(eased, Math.max(0.5 * eased, 3.0 * (a - target))); // soft landing near the target
            double cut = Math.min(d * dt, a - target);
            return -Math.signum(s) * cut;
        }
        if (!slow) {
            // reached a standstill
            st.phase = HOLD;
            st.time = 0;
            return -s;
        }
        if (a < floor) {
            double dir = a < STOPPED ? st.dir : Math.signum(s);
            return dir * Math.min(c.releaseAccel() * dt, floor - a);
        }
        return 0.0;
    }

    private static double hold(State st, BrakeSettings c, double s, double dt) {
        if (st.time >= c.stopSeconds) {
            st.time = 0;
            st.idle = 0;
            st.phase = c.mode == BrakeSettings.MODE_STOP_RELEASE ? RELEASE : DONE;
            return 0.0;
        }
        return -s; // keeps the cart still, also on a slope
    }

    /** Accelerates the cart along its direction towards {@code target}; returns the speed change. */
    private static double push(State st, BrakeSettings c, double s, double dt, double target, boolean toDone) {
        double along = s * st.dir;
        if (along >= target) {
            if (toDone) {
                st.phase = DONE;
                st.time = 0;
            }
            return 0.0;
        }
        double acc = c.releaseAccel() * ramp(c, st.time);
        return st.dir * Math.min(acc * dt, target - along);
    }

    private static double done(State st, BrakeSettings c, double s, double dt) {
        double target = BrakeSettings.toBlocksPerSecond(c.releaseKmh);
        double along = s * st.dir;
        if (c.mode == BrakeSettings.MODE_STOP_RELEASE) {
            // handed back, but a cart that slows to a crawl on a flat brake run is kept moving so it can never get stuck
            if (along < 0.8 * target) {
                return push(st, c, s, dt, 0.8 * target, false);
            }
            return 0.0;
        }
        // Full Stop: let go. If the cart just sits there for 3 s, give it a gentle push so it is never stuck for good.
        if (st.idle > 3.0) {
            if (along < 0.6 * target) {
                return push(st, c, s, dt * 0.5, 0.6 * target, false);
            }
            st.idle = 0;
            return 0.0;
        }
        if (Math.abs(along) < 0.3) {
            st.idle += dt;
        } else {
            st.idle = 0;
        }
        return 0.0;
    }
}
