package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * The transfer table: a platform that slides sideways between stops and forward/back, driven by 8 Redstone Link
 * inputs (left, right, forward, back, stop A to D). It also gives out a redstone signal equal to the stop it is at.
 * The platform is a moving prop with a signal output; it does not carry trains by itself.
 */
public class TransferTableBlockEntity extends BlockEntity {
    public static final int INPUTS = 8;
    public static final int S_STOPS = 0;
    public static final int S_SPACING = 1;
    public static final int S_SPEED = 2;
    public static final int S_FORWARD = 3;
    public static final int[] MIN = {2, 2, 1, 0};
    public static final int[] MAX = {4, 9, 8, 6};
    public static final int[] DEF = {3, 4, 3, 2};

    private final int[] s = DEF.clone();
    private final LinkSlots links = new LinkSlots(this, INPUTS);

    private float side = 0.0F;      // blocks, positive = to the right of FACING
    private float forward = 0.0F;   // blocks, positive = along FACING
    private float targetSide = Float.NaN;
    private final boolean[] prev = new boolean[INPUTS];
    private boolean moving = false;

    // client smoothing
    public float drawSide = 0.0F;
    public float drawForward = 0.0F;

    public TransferTableBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.TRANSFER_BE.get(), pos, state);
    }

    public SimpleContainer getFrequencies() {
        return links.container();
    }

    public int get(int i) {
        return s[i];
    }

    public float side() {
        return side;
    }

    public float forward() {
        return forward;
    }

    @Nullable
    public static TransferTableBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof TransferTableBlockEntity t ? t : null;
    }

    public void applyConfig(int[] values) {
        if (level == null || level.isClientSide || values.length < s.length) {
            return;
        }
        for (int i = 0; i < s.length; i++) {
            s[i] = Math.max(MIN[i], Math.min(MAX[i], values[i]));
        }
        side = Math.max(-sideLimit(), Math.min(sideLimit(), side));
        forward = Math.max(-s[S_FORWARD], Math.min(s[S_FORWARD], forward));
        sync();
    }

    private float sideLimit() {
        return (s[S_STOPS] - 1) / 2.0F * s[S_SPACING];
    }

    private float stopPos(int i) {
        return (i - (s[S_STOPS] - 1) / 2.0F) * s[S_SPACING];
    }

    private void sync() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            links.register();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    // ---------------------------------------------------------------- movement

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        float step = s[S_SPEED] * 0.5F / 20.0F;
        boolean manual = false;
        float dSide = 0;
        float dFwd = 0;
        if (links.strength(0) > 0) {
            dSide -= step;
        }
        if (links.strength(1) > 0) {
            dSide += step;
        }
        if (links.strength(2) > 0) {
            dFwd += step;
        }
        if (links.strength(3) > 0) {
            dFwd -= step;
        }
        if (dSide != 0 || dFwd != 0) {
            manual = true;
            targetSide = Float.NaN;
        }
        for (int i = 0; i < 4; i++) {
            boolean on = links.strength(4 + i) > 0;
            if (on && !prev[4 + i] && i < s[S_STOPS]) {
                targetSide = stopPos(i);
            }
            prev[4 + i] = on;
        }
        float oldSide = side;
        float oldFwd = forward;
        if (!manual && !Float.isNaN(targetSide)) {
            float diff = targetSide - side;
            if (Math.abs(diff) <= step) {
                side = targetSide;
                targetSide = Float.NaN;
            } else {
                side += Math.signum(diff) * step;
            }
        } else {
            side += dSide;
            forward += dFwd;
        }
        side = Math.max(-sideLimit(), Math.min(sideLimit(), side));
        forward = Math.max(-s[S_FORWARD], Math.min(s[S_FORWARD], forward));

        boolean nowMoving = side != oldSide || forward != oldFwd;
        if (nowMoving || moving) {
            sync();
        }
        moving = nowMoving;
        updatePower();
    }

    private void updatePower() {
        int power = 0;
        if (Math.abs(forward) < 0.05F) {
            for (int i = 0; i < s[S_STOPS]; i++) {
                if (Math.abs(side - stopPos(i)) < 0.06F) {
                    power = i + 1;
                    break;
                }
            }
        }
        BlockState state = getBlockState();
        if (state.hasProperty(TransferTableBlock.POWER) && state.getValue(TransferTableBlock.POWER) != power) {
            level.setBlock(worldPosition, state.setValue(TransferTableBlock.POWER, power), 3);
        }
    }

    /** The platform can slide out of the block's own space, so it must still be drawn then. */
    @Override
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return new net.minecraft.world.phys.AABB(worldPosition).inflate(12.0);
    }

    public Direction facing() {
        BlockState state = getBlockState();
        return state.hasProperty(TransferTableBlock.FACING) ? state.getValue(TransferTableBlock.FACING) : Direction.NORTH;
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        links.save(tag, registries);
        tag.putInt("Stops", s[S_STOPS]);
        tag.putInt("Spacing", s[S_SPACING]);
        tag.putInt("Speed", s[S_SPEED]);
        tag.putInt("Fwd", s[S_FORWARD]);
        tag.putFloat("Side", side);
        tag.putFloat("Forward", forward);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        links.load(tag, registries);
        if (tag.contains("Stops")) {
            s[S_STOPS] = Math.max(MIN[0], Math.min(MAX[0], tag.getInt("Stops")));
            s[S_SPACING] = Math.max(MIN[1], Math.min(MAX[1], tag.getInt("Spacing")));
            s[S_SPEED] = Math.max(MIN[2], Math.min(MAX[2], tag.getInt("Speed")));
            s[S_FORWARD] = Math.max(MIN[3], Math.min(MAX[3], tag.getInt("Fwd")));
            side = tag.getFloat("Side");
            forward = tag.getFloat("Forward");
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
