package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaterniond;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * The transfer table: a platform that slides sideways between stops and forward/back, driven by 8 Redstone Link
 * inputs (left, right, forward, back, stop A to D). It also gives out a redstone signal equal to the stop it is at.
 * The platform is a moving prop with a signal output; it does not carry trains by itself.
 */
public class TransferTableBlockEntity extends BlockEntity {
    public static final int INPUTS = 8;
    public static final int S_STOPS = 0;
    public static final int S_SPACING = 1;
    public static final int S_SPEED = 2;
    public static final int S_FORWARD = 3;
    public static final int S_AUTO = 4;
    public static final int S_TARGET = 5;
    public static final int S_WAIT = 6;
    public static final int[] MIN = {2, 2, 1, 0, 0, 0, 0};
    public static final int[] MAX = {4, 9, 8, 6, 1, 3, 30};
    public static final int[] DEF = {3, 4, 3, 2, 0, 1, 3};

    private final int[] s = DEF.clone();
    private final LinkSlots links = new LinkSlots(this, INPUTS);

    private float side = 0.0F;      // blocks, positive = to the right of FACING
    private float forward = 0.0F;   // blocks, positive = along FACING
    private float targetSide = Float.NaN;
    private final boolean[] prev = new boolean[INPUTS];
    private boolean moving = false;

    // ---- carrying platform (a real Sable structure with real track on it)
    private UUID platform;
    private Vec3 base = Vec3.ZERO;
    private Quaterniond baseRot = new Quaterniond();
    private volatile float pSide = 0.0F;     // where the platform really is, blocks along the rail
    private int dockedStop = -1;
    /** Per stop: the track joins recorded there (platform anchor, fixed anchor, and both curves). */
    private final List<List<CompoundTag>> docks = new ArrayList<>();
    private boolean docksReady;
    private List<BlockEntity> brakes = List.of();
    private long brakeScan = -100;
    private boolean canMove = true;
    private boolean trainOn;
    private boolean ready;
    private int sendDir;
    private boolean heldNow;
    private boolean joinedNow;
    private long sinceNow = Long.MAX_VALUE / 4;
    // automatic sequence: 0 idle, 1 waiting, 2 driving to the target stop, 3 sending the train out, 4 driving home
    private int autoPhase;
    private long autoStart;
    private int autoHome = -1;

    // client smoothing
    public float drawSide = 0.0F;
    public float drawForward = 0.0F;

    public TransferTableBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.TRANSFER_BE.get(), pos, state);
    }

    public UUID platformId() {
        return platform;
    }

    public boolean hasPlatform() {
        return platform != null;
    }

    private List<CompoundTag> dock(int i) {
        while (docks.size() < 4) {
            docks.add(new ArrayList<>());
        }
        return docks.get(i);
    }

    private net.minecraft.world.phys.Vec3 rightStep() {
        Direction r = facing().getClockWise();
        return new Vec3(r.getStepX(), 0, r.getStepZ());
    }

    /** Called by a player action: build the platform from the blocks on top of the table. Returns a message. */
    public String assemblePlatform() {
        if (!(level instanceof ServerLevel sl)) {
            return "";
        }
        if (platform != null && TransferPlatform.subLevel(sl, platform) != null) {
            return "The platform is already assembled.";
        }
        TransferPlatform.Assembled a = TransferPlatform.assemble(sl, worldPosition, facing());
        if (a.error() != null) {
            return a.error();
        }
        platform = a.id();
        base = a.base().subtract(rightStep().scale(side));
        baseRot = a.orientation();
        pSide = side;
        dockedStop = -1;
        TransferPlatform.ACTIVE.add(this);
        sync();
        return "Platform assembled. Move it to a stop, build the track joins, then press Record.";
    }

    /** Player action: put the platform back into the world as ordinary blocks, where it stands. */
    public String disassemblePlatform() {
        if (!(level instanceof ServerLevel sl) || platform == null) {
            return "There is no platform to take apart.";
        }
        if (currentStop() < 0 || Math.abs(side - pSide) > 0.03F) {
            return "Move the platform to a stop first.";
        }
        if (!canMove || trainOn) {
            return "A train is on the platform or near it.";
        }
        int stop = currentStop();
        rememberJoins(stop);
        if (dockedStop >= 0) {
            undockFrom(dockedStop);
            dockedStop = -1;
        }
        String error = TransferPlatform.disassemble(sl, platform);
        if (error != null) {
            if (!dock(stop).isEmpty()) {
                dockAt(stop);
                dockedStop = stop;
            }
            return error;
        }
        TransferPlatform.ACTIVE.remove(this);
        platform = null;
        dockedStop = -1;
        brakes = List.of();
        sync();
        return "Platform put back as normal blocks. Press Assemble to build it again.";
    }

    /** Finds the track joins that exist right now between the platform and the fixed track. */
    private List<CompoundTag> scanJoins(ServerLevel sl) throws Exception {
        List<CompoundTag> found = new ArrayList<>();
        for (net.minecraft.world.level.block.entity.BlockEntity fixed : TransferPlatform.fixedAnchorsNear(sl, worldPosition)) {
            if (TransferPlatform.inStructureSpace(sl, fixed.getBlockPos())) {
                continue;
            }
            for (java.util.Map.Entry<BlockPos, Object> e : TransferPlatform.peers(fixed).entrySet()) {
                BlockPos peer = e.getKey();
                if (!TransferPlatform.inStructureSpace(sl, peer)) {
                    continue;
                }
                net.minecraft.world.level.block.entity.BlockEntity pbe = sl.getBlockEntity(peer);
                Object platformCurve = pbe != null && TransferPlatform.isAnchor(pbe) ? TransferPlatform.peers(pbe).get(fixed.getBlockPos()) : null;
                CompoundTag t = new CompoundTag();
                t.putLong("Plat", peer.asLong());
                t.putLong("Fixed", fixed.getBlockPos().asLong());
                t.put("FixedCurve", TransferPlatform.bezierTag(e.getValue()));
                if (platformCurve != null) {
                    t.put("PlatCurve", TransferPlatform.bezierTag(platformCurve));
                }
                found.add(t);
            }
        }
        return found;
    }

    /** Remembers the joins that exist at this stop right now. Done automatically whenever the platform leaves a stop. */
    private void rememberJoins(int stop) {
        if (!(level instanceof ServerLevel sl)) {
            return;
        }
        try {
            List<CompoundTag> found = scanJoins(sl);
            if (!found.isEmpty()) {
                dock(stop).clear();
                dock(stop).addAll(found);
                CoasterControlPanel.LOGGER.info("Transfer platform: remembered {} join(s) for stop {} of table {}.", found.size(), stop, worldPosition);
            }
        } catch (Throwable t) {
            CoasterControlPanel.LOGGER.error("Transfer platform: remembering the track joins failed", t);
        }
    }

    /** Manual version of the above (the old Record button). */
    public String recordDock() {
        if (platform == null) {
            return "Assemble the platform first.";
        }
        int stop = dockedStop >= 0 ? dockedStop : currentStop();
        if (stop < 0) {
            return "Move the platform exactly to a stop first.";
        }
        rememberJoins(stop);
        return dock(stop).isEmpty() ? "No track joins found at this stop." : "Remembered " + dock(stop).size() + " join(s) for this stop.";
    }

    private int currentStop() {
        for (int i = 0; i < s[S_STOPS]; i++) {
            if (Math.abs(pSide - stopPos(i)) < 0.03F) {
                return i;
            }
        }
        return -1;
    }

    private void dockAt(int stop) {
        if (!(level instanceof ServerLevel sl)) {
            return;
        }
        int ok = 0;
        for (CompoundTag t : dock(stop)) {
            try {
                BlockPos plat = BlockPos.of(t.getLong("Plat"));
                BlockPos fixed = BlockPos.of(t.getLong("Fixed"));
                net.minecraft.world.level.block.entity.BlockEntity pbe = sl.getBlockEntity(plat);
                net.minecraft.world.level.block.entity.BlockEntity fbe = sl.getBlockEntity(fixed);
                if (!TransferPlatform.isAnchor(pbe) || !TransferPlatform.isAnchor(fbe)) {
                    continue;
                }
                Object fixedCurve = TransferPlatform.newBezier(t.getCompound("FixedCurve"));
                Object platCurve = t.contains("PlatCurve") ? TransferPlatform.newBezier(t.getCompound("PlatCurve")) : fixedCurve;
                TransferPlatform.putPeer(sl, pbe, fixed, platCurve);
                if (!TransferPlatform.peers(fbe).containsKey(plat)) {
                    TransferPlatform.putPeer(sl, fbe, plat, fixedCurve);
                }
                ok++;
            } catch (Throwable e) {
                CoasterControlPanel.LOGGER.error("Transfer platform: docking a track join failed", e);
            }
        }
        CoasterControlPanel.LOGGER.info("Transfer platform: docked at stop {} ({} of {} join(s)).", stop, ok, dock(stop).size());
    }

    private void undockFrom(int stop) {
        if (!(level instanceof ServerLevel sl)) {
            return;
        }
        for (CompoundTag t : dock(stop)) {
            try {
                BlockPos plat = BlockPos.of(t.getLong("Plat"));
                BlockPos fixed = BlockPos.of(t.getLong("Fixed"));
                net.minecraft.world.level.block.entity.BlockEntity pbe = sl.getBlockEntity(plat);
                net.minecraft.world.level.block.entity.BlockEntity fbe = sl.getBlockEntity(fixed);
                if (TransferPlatform.isAnchor(pbe) && TransferPlatform.peers(pbe).containsKey(fixed)) {
                    TransferPlatform.removePeer(sl, pbe, fixed);
                }
                if (TransferPlatform.isAnchor(fbe) && TransferPlatform.peers(fbe).containsKey(plat)) {
                    TransferPlatform.removePeer(sl, fbe, plat);
                }
            } catch (Throwable e) {
                CoasterControlPanel.LOGGER.error("Transfer platform: undocking a track join failed", e);
            }
        }
        CoasterControlPanel.LOGGER.info("Transfer platform: undocked from stop {}.", stop);
    }

    /** Server tick part of carrying: undock when it is told to leave, dock when it has arrived. */
    /** Looks at the Brake Run(s) on the platform: is a train on it, is it standing still, may the platform move. */
    private void refreshPlatformState() {
        if (platform == null || !(level instanceof ServerLevel sl)) {
            canMove = true;
            sendDir = 0;
            heldNow = false;
            if (trainOn || ready) {
                trainOn = false;
                ready = false;
                sync();
            }
            return;
        }
        long now = level.getGameTime();
        if (now - brakeScan >= 10) {
            brakes = TransferPlatform.brakeAnchors(sl, platform);
            brakeScan = now;
        }
        boolean any = false;
        boolean allHeld = true;
        long since = Long.MAX_VALUE / 4;
        for (BlockEntity be : brakes) {
            if (be.isRemoved()) {
                continue;
            }
            BlockPos p = be.getBlockPos();
            since = Math.min(since, BrakeController.ticksSinceCart(level, p));
            if (BrakeController.occupied(level, p)) {
                any = true;
                if (!BrakeController.trainHeld(level, p)) {
                    allHeld = false;
                }
            }
        }
        // a cart waiting on the track joins (or about to enter them) must not have them taken away
        boolean joinBusy = false;
        if (!any && dockedStop >= 0 && CartScanner.isAvailable()) {
            for (CompoundTag t : dock(dockedStop)) {
                BlockPos f = BlockPos.of(t.getLong("Fixed"));
                if (CartScanner.anyCartIn(level, new net.minecraft.world.phys.AABB(f).inflate(5.0))) {
                    joinBusy = true;
                    break;
                }
            }
        }
        // the platform may only move with a train that stands still on it, or with no train near it at all
        canMove = ((any && allHeld) || (!any && since > 40)) && !joinBusy;
        int stop = dockedStop >= 0 ? dockedStop : currentStop();
        boolean joined = dockedStop >= 0 || (stop >= 0 && dock(stop).isEmpty());
        int want = links.strength(2) > 0 ? 1 : (links.strength(3) > 0 ? -1 : 0);
        if (autoPhase == 3) {
            want = 1;
        }
        sendDir = joined ? want : 0;
        heldNow = any && allHeld;
        joinedNow = joined;
        sinceNow = since;
        for (BlockEntity be : brakes) {
            if (be instanceof DriveTyre.Holder h && h.ccp$brake() != null) {
                h.ccp$brake().send = sendDir;
            }
        }
        boolean nowReady = stop >= 0 && joined && canMove && Math.abs(side - pSide) < 0.03F;
        if (any != trainOn || nowReady != ready) {
            trainOn = any;
            ready = nowReady;
            sync();
            level.updateNeighbourForOutputSignal(worldPosition, getBlockState().getBlock());
        }
    }

    /** The automatic sequence: train arrives and stops, wait, platform goes to the chosen stop, train is sent out, platform returns. */
    private void autoTick(boolean cancel) {
        if (s[S_AUTO] == 0 || platform == null || cancel) {
            autoPhase = 0;
            return;
        }
        long now = level.getGameTime();
        int stop = dockedStop >= 0 ? dockedStop : currentStop();
        int target = Math.min(s[S_TARGET], s[S_STOPS] - 1);
        switch (autoPhase) {
            case 0 -> {
                if (heldNow && stop >= 0 && joinedNow) {
                    autoHome = stop;
                    autoPhase = 1;
                    autoStart = now;
                }
            }
            case 1 -> {
                if (!heldNow) {
                    autoPhase = 0;
                } else if (now - autoStart >= s[S_WAIT] * 20L) {
                    autoStart = now;
                    if (stop == target) {
                        autoPhase = 3;
                    } else {
                        targetSide = stopPos(target);
                        autoPhase = 2;
                    }
                }
            }
            case 2 -> {
                if (Float.isNaN(targetSide) && dockedStop == target) {
                    autoPhase = 3;
                    autoStart = now;
                } else if (now - autoStart > 1200) {
                    autoPhase = 0;
                }
            }
            case 3 -> {
                if (!trainOn && sinceNow > 60) {
                    autoStart = now;
                    if (autoHome >= 0 && autoHome != target) {
                        targetSide = stopPos(autoHome);
                        autoPhase = 4;
                    } else {
                        autoPhase = 0;
                    }
                } else if (now - autoStart > 600) {
                    autoPhase = 0;
                }
            }
            case 4 -> {
                if ((Float.isNaN(targetSide) && dockedStop == autoHome) || now - autoStart > 1200) {
                    autoPhase = 0;
                }
            }
            default -> autoPhase = 0;
        }
    }

    public boolean trainOn() {
        return trainOn;
    }

    public boolean ready() {
        return ready;
    }

    private void carryTick() {
        if (platform == null || !(level instanceof ServerLevel sl)) {
            return;
        }
        if (dockedStop >= 0 && (Math.abs(side - stopPos(dockedStop)) > 0.01F || Math.abs(pSide - stopPos(dockedStop)) > 0.03F)) {
            rememberJoins(dockedStop); // whatever was built at this stop is remembered automatically before it is taken apart
            undockFrom(dockedStop);
            dockedStop = -1;
            setChanged();
        }
        if (dockedStop < 0 && Math.abs(side - pSide) < 0.02F) {
            int stop = currentStop();
            if (stop >= 0 && Math.abs(side - stopPos(stop)) < 0.02F) {
                if (!dock(stop).isEmpty()) {
                    dockAt(stop);
                    dockedStop = stop;
                    setChanged();
                } else if (level.getGameTime() % 20 == 0) {
                    // nothing remembered here yet: if the player has built track joins, remember them now
                    rememberJoins(stop);
                    if (!dock(stop).isEmpty()) {
                        dockedStop = stop;
                        setChanged();
                    }
                }
            }
        }
    }

    /** Physics-step part of carrying: steer the platform to its place on the rail. */
    void physicsStep(Object pipeline, double dt) throws Exception {
        if (platform == null || !(level instanceof ServerLevel sl)) {
            return;
        }
        Object sub = TransferPlatform.subLevel(sl, platform);
        if (sub == null) {
            return;
        }
        float want = side;
        // stay put until the joins are removed
        if (dockedStop >= 0 && Math.abs(want - stopPos(dockedStop)) > 0.01F) {
            want = pSide;
        }
        float maxStep = (float) (s[S_SPEED] * 0.5 * dt);
        float diff = want - pSide;
        pSide += Math.abs(diff) <= maxStep ? diff : Math.signum(diff) * maxStep;
        Vec3 target = base.add(rightStep().scale(pSide));
        TransferPlatform.steer(pipeline, sub, target, baseRot, dt);
    }

    public SimpleContainer getFrequencies() {
        return links.container();
    }

    public int get(int i) {
        return s[i];
    }

    public float side() {
        return side;
    }

    public float forward() {
        return forward;
    }

    @Nullable
    public static TransferTableBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 100.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof TransferTableBlockEntity t ? t : null;
    }

    public void applyConfig(int[] values) {
        if (level == null || level.isClientSide || values.length < s.length) {
            return;
        }
        for (int i = 0; i < s.length; i++) {
            s[i] = Math.max(MIN[i], Math.min(MAX[i], values[i]));
        }
        side = Math.max(-sideLimit(), Math.min(sideLimit(), side));
        forward = Math.max(-s[S_FORWARD], Math.min(s[S_FORWARD], forward));
        sync();
    }

    private float sideLimit() {
        return (s[S_STOPS] - 1) / 2.0F * s[S_SPACING];
    }

    private float stopPos(int i) {
        return (i - (s[S_STOPS] - 1) / 2.0F) * s[S_SPACING];
    }

    private void sync() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            links.register();
            if (platform != null) {
                TransferPlatform.ACTIVE.add(this);
            }
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        TransferPlatform.ACTIVE.remove(this);
        links.unregister();
    }

    @Override
    public void setRemoved() {
        TransferPlatform.ACTIVE.remove(this);
        links.unregister();
        super.setRemoved();
    }

    // ---------------------------------------------------------------- movement

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        float step = s[S_SPEED] * 0.5F / 20.0F;
        boolean manual = false;
        float dSide = 0;
        float dFwd = 0;
        if (links.strength(0) > 0) {
            dSide -= step;
        }
        if (links.strength(1) > 0) {
            dSide += step;
        }
        if (platform == null) {
            if (links.strength(2) > 0) {
                dFwd += step;
            }
            if (links.strength(3) > 0) {
                dFwd -= step;
            }
        }
        refreshPlatformState();
        if (!canMove) {
            dSide = 0; // a train is rolling on the platform, or has only just left it
        }
        if (dSide != 0 || dFwd != 0) {
            manual = true;
            targetSide = Float.NaN;
        }
        boolean stopPressed = false;
        for (int i = 0; i < 4; i++) {
            boolean on = links.strength(4 + i) > 0;
            if (on && !prev[4 + i] && i < s[S_STOPS]) {
                targetSide = stopPos(i);
                stopPressed = true;
            }
            prev[4 + i] = on;
        }
        autoTick(manual || stopPressed);
        float oldSide = side;
        float oldFwd = forward;
        if (!manual && !Float.isNaN(targetSide) && canMove) {
            float diff = targetSide - side;
            if (Math.abs(diff) <= step) {
                side = targetSide;
                targetSide = Float.NaN;
            } else {
                side += Math.signum(diff) * step;
            }
        } else {
            side += dSide;
            forward += dFwd;
        }
        side = Math.max(-sideLimit(), Math.min(sideLimit(), side));
        forward = Math.max(-s[S_FORWARD], Math.min(s[S_FORWARD], forward));

        boolean nowMoving = side != oldSide || forward != oldFwd;
        if (nowMoving || moving) {
            sync();
        }
        moving = nowMoving;
        updatePower();
        carryTick();
    }

    private void updatePower() {
        int power = 0;
        if (Math.abs(forward) < 0.05F) {
            for (int i = 0; i < s[S_STOPS]; i++) {
                if (Math.abs(side - stopPos(i)) < 0.06F) {
                    power = i + 1;
                    break;
                }
            }
        }
        BlockState state = getBlockState();
        if (state.hasProperty(TransferTableBlock.POWER) && state.getValue(TransferTableBlock.POWER) != power) {
            level.setBlock(worldPosition, state.setValue(TransferTableBlock.POWER, power), 3);
        }
    }

    /** The platform can slide out of the block's own space, so it must still be drawn then. */
    public net.minecraft.world.phys.AABB getRenderBoundingBox() {
        return new net.minecraft.world.phys.AABB(worldPosition).inflate(12.0);
    }

    public Direction facing() {
        BlockState state = getBlockState();
        return state.hasProperty(TransferTableBlock.FACING) ? state.getValue(TransferTableBlock.FACING) : Direction.NORTH;
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        links.save(tag, registries);
        tag.putInt("Stops", s[S_STOPS]);
        tag.putInt("Spacing", s[S_SPACING]);
        tag.putInt("Speed", s[S_SPEED]);
        tag.putInt("Fwd", s[S_FORWARD]);
        tag.putInt("Auto", s[S_AUTO]);
        tag.putInt("AutoStop", s[S_TARGET]);
        tag.putInt("AutoWait", s[S_WAIT]);
        tag.putFloat("Side", side);
        tag.putFloat("Forward", forward);
        tag.putBoolean("TrainOn", trainOn);
        tag.putBoolean("Ready", ready);
        if (platform != null) {
            tag.putUUID("Platform", platform);
            tag.putDouble("BaseX", base.x);
            tag.putDouble("BaseY", base.y);
            tag.putDouble("BaseZ", base.z);
            tag.putDouble("RotX", baseRot.x);
            tag.putDouble("RotY", baseRot.y);
            tag.putDouble("RotZ", baseRot.z);
            tag.putDouble("RotW", baseRot.w);
            tag.putFloat("PSide", pSide);
            tag.putInt("Docked", dockedStop);
            ListTag stops = new ListTag();
            for (int i = 0; i < 4; i++) {
                ListTag one = new ListTag();
                one.addAll(dock(i));
                stops.add(one);
            }
            tag.put("Docks", stops);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        links.load(tag, registries);
        if (tag.contains("Stops")) {
            s[S_STOPS] = Math.max(MIN[0], Math.min(MAX[0], tag.getInt("Stops")));
            s[S_SPACING] = Math.max(MIN[1], Math.min(MAX[1], tag.getInt("Spacing")));
            s[S_SPEED] = Math.max(MIN[2], Math.min(MAX[2], tag.getInt("Speed")));
            s[S_FORWARD] = Math.max(MIN[3], Math.min(MAX[3], tag.getInt("Fwd")));
            s[S_AUTO] = Math.max(MIN[4], Math.min(MAX[4], tag.getInt("Auto")));
            s[S_TARGET] = tag.contains("AutoStop") ? Math.max(MIN[5], Math.min(MAX[5], tag.getInt("AutoStop"))) : DEF[5];
            s[S_WAIT] = tag.contains("AutoWait") ? Math.max(MIN[6], Math.min(MAX[6], tag.getInt("AutoWait"))) : DEF[6];
            side = tag.getFloat("Side");
            forward = tag.getFloat("Forward");
        }
        trainOn = tag.getBoolean("TrainOn");
        ready = tag.getBoolean("Ready");
        if (tag.hasUUID("Platform")) {
            platform = tag.getUUID("Platform");
            base = new Vec3(tag.getDouble("BaseX"), tag.getDouble("BaseY"), tag.getDouble("BaseZ"));
            baseRot = new Quaterniond(tag.getDouble("RotX"), tag.getDouble("RotY"), tag.getDouble("RotZ"), tag.getDouble("RotW"));
            pSide = tag.getFloat("PSide");
            dockedStop = tag.getInt("Docked");
            docks.clear();
            ListTag stops = tag.getList("Docks", Tag.TAG_LIST);
            for (int i = 0; i < 4; i++) {
                List<CompoundTag> list = new ArrayList<>();
                if (i < stops.size()) {
                    ListTag one = stops.getList(i);
                    for (int k = 0; k < one.size(); k++) {
                        list.add(one.getCompound(k));
                    }
                }
                docks.add(list);
            }
        } else {
            platform = null;
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
