package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** The screens of the First Aid and Safety pack. */
public final class SafetyScreens {
    private SafetyScreens() {
    }

    private static String clock(long ticks) {
        long s = Math.max(0, (ticks + 19) / 20);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    private static void bar(GuiGraphics g, int x, int y, int bw, float frac, int colour) {
        g.fill(x, y, x + bw, y + 8, 0xFF0B0C10);
        g.fill(x + 1, y + 1, x + bw - 1, y + 7, 0xFF2A2D3A);
        int fill = Math.round((bw - 2) * Math.max(0, Math.min(1, frac)));
        g.fill(x + 1, y + 1, x + 1 + fill, y + 7, colour);
    }

    // ------------------------------------------------------------------ first aid station

    public static class FirstAidScreen extends GiftScreens.ParkScreen {
        private boolean setup;
        private Button treat;
        private Button[] setupButtons;
        private Button[] playButtons;

        public FirstAidScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.first_aid_station"), pos, 244, 188, 0xFF2E8B57);
        }

        @Override
        protected void build() {
            treat = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.aid_treat"), b -> act(10, 0, 0))
                    .bounds(left + 62, top + 100, 120, 22).build());
            playButtons = new Button[]{treat};
            Button cm = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(11, hasShiftDown() ? -30 : -10, 0)).bounds(left + 150, top + 70, 20, 16).build());
            Button cp = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(11, hasShiftDown() ? 30 : 10, 0)).bounds(left + 174, top + 70, 20, 16).build());
            Button sm = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(12, -1, 0)).bounds(left + 150, top + 92, 20, 16).build());
            Button sp = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(12, 1, 0)).bounds(left + 174, top + 92, 20, 16).build());
            Button cure = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.aid_cure_toggle"), b -> act(13, 0, 0))
                    .bounds(left + 150, top + 114, 70, 16).build());
            setupButtons = new Button[]{cm, cp, sm, sp, cure};
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup)
                    .bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            SafetyBlocks.FirstAidBlockEntity be = entity(SafetyBlocks.FirstAidBlockEntity.class);
            long now = minecraft != null && minecraft.level != null ? minecraft.level.getGameTime() : 0;
            long remain = be == null ? 0 : be.readyAt - now;
            boolean ready = remain <= 0;
            for (Button b : setupButtons) {
                b.visible = setup;
            }
            for (Button b : playButtons) {
                b.visible = !setup;
            }
            treat.active = ready;
            super.render(g, mx, my, pt);
            // the patient
            row(g, this.left + 8, top + 24, w - 16, 36);
            if (minecraft != null && minecraft.player != null) {
                float hp = minecraft.player.getHealth();
                float max = minecraft.player.getMaxHealth();
                for (int i = 0; i < (int) Math.ceil(max / 2.0F) && i < 20; i++) {
                    int x = this.left + 14 + (i % 10) * 11;
                    int y = top + 29 + (i / 10) * 12;
                    g.fill(x, y, x + 9, y + 9, 0xFF3A1519);
                    float v = hp - i * 2;
                    int fill = v >= 2 ? 9 : v >= 1 ? 5 : 0;
                    g.fill(x, y, x + fill, y + 9, 0xFFE0303F);
                }
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_patient"), this.left + 130, top + 30, 0xC8C8D8, false);
            if (!setup) {
                // pulsing cross
                int pulse = 4 + (int) (2.0 * Math.sin((now + pt) / 6.0));
                int cx = this.left + 36;
                int cy = top + 90;
                g.fill(cx - 22, cy - 22, cx + 22, cy + 22, 0xFFF4F4F4);
                g.fill(cx - pulse - 4, cy - 14, cx + pulse + 4, cy + 14, 0xFF2E8B57);
                g.fill(cx - 14, cy - pulse - 4, cx + 14, cy + pulse + 4, 0xFF2E8B57);
                bar(g, this.left + 62, top + 78, 120, ready ? 1.0F : 1.0F - (float) remain / Math.max(1, be.cooldownSec * 20), ready ? 0xFF3FD07A : 0xFFE0A030);
                g.drawString(font, ready ? Component.translatable("gui.coastercontrolpanel.aid_ready")
                                : Component.translatable("gui.coastercontrolpanel.aid_recharge", clock(remain)),
                        this.left + 62, top + 66, ready ? 0x7CFFB0 : 0xFFC860, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_help"), this.left + 8, top + 130, 0x8A8FA3, false);
            } else if (be != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_cooldown", be.cooldownSec), this.left + 14, top + 74, 0xFFE070, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_strength", be.strength + 1), this.left + 14, top + 96, 0xFFE070, false);
                g.drawString(font, Component.translatable(be.cure ? "gui.coastercontrolpanel.aid_cure_on" : "gui.coastercontrolpanel.aid_cure_off"),
                        this.left + 14, top + 118, be.cure ? 0x7CFFB0 : 0xFF8A8A, false);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_count", be.treated), this.left + 14, top + 140, 0x8A8FA3, false);
            }
        }
    }

    // ------------------------------------------------------------------ defibrillator

    public static class DefibScreen extends GiftScreens.ParkScreen {
        private boolean setup;
        private Button test;
        private Button cm;
        private Button cp;

        public DefibScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.defibrillator_cabinet"), pos, 236, 160, 0xFFB0802A);
        }

        @Override
        protected void build() {
            test = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.defib_test"), b -> act(15, 0, 0))
                    .bounds(left + 8, top + 100, 100, 18).build());
            cm = addRenderableWidget(Button.builder(Component.literal("-"), b -> act(14, hasShiftDown() ? -60 : -15, 0)).bounds(left + 160, top + 70, 20, 16).build());
            cp = addRenderableWidget(Button.builder(Component.literal("+"), b -> act(14, hasShiftDown() ? 60 : 15, 0)).bounds(left + 184, top + 70, 20, 16).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.kiosk_setup"), b -> setup = !setup)
                    .bounds(left + 8, top + h - 22, 70, 16).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            SafetyBlocks.DefibBlockEntity be = entity(SafetyBlocks.DefibBlockEntity.class);
            long now = minecraft != null && minecraft.level != null ? minecraft.level.getGameTime() : 0;
            long wait = be == null ? 0 : be.readyAt - now;
            boolean ready = wait <= 0;
            cm.visible = setup;
            cp.visible = setup;
            test.visible = !setup;
            test.active = ready;
            super.render(g, mx, my, pt);
            row(g, left + 8, top + 24, w - 16, 66);
            boolean blink = ready && ((now / 10) % 2 == 0);
            g.fill(left + 16, top + 32, left + 40, top + 50, blink ? 0xFF3FD07A : ready ? 0xFF1F7A47 : 0xFF7A3A1F);
            g.drawString(font, Component.translatable(ready ? "gui.coastercontrolpanel.defib_ready" : "gui.coastercontrolpanel.defib_charging", clock(wait)),
                    left + 48, top + 36, ready ? 0x7CFFB0 : 0xFFC860, false);
            bar(g, left + 16, top + 58, w - 32, ready || be == null ? 1.0F : 1.0F - (float) wait / Math.max(1, be.cooldownSec * 20), ready ? 0xFF3FD07A : 0xFFE0A030);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.defib_range", SafetyBlocks.DEFIB_RADIUS), left + 16, top + 72, 0xC8C8D8, false);
            if (be != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.defib_count", be.revived), left + 16, top + 82, 0x8A8FA3, false);
            }
            if (setup && be != null) {
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.aid_cooldown", be.cooldownSec), left + 120, top + 52, 0xFFE070, false);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.defib_help"), left + 8, top + 124, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ lost child point

    public static class ChildScreen extends GiftScreens.ParkScreen {
        private Button call;
        private Button found;

        public ChildScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.lost_child_point"), pos, 232, 150, 0xFF2E64B0);
        }

        @Override
        protected void build() {
            call = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.child_call"), b -> act(16, 0, 0))
                    .bounds(left + 16, top + 54, w - 32, 24).build());
            found = addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.child_found"), b -> act(17, 0, 0))
                    .bounds(left + 16, top + 84, w - 32, 18).build());
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            SafetyBlocks.ChildPointBlockEntity be = entity(SafetyBlocks.ChildPointBlockEntity.class);
            long now = minecraft != null && minecraft.level != null ? minecraft.level.getGameTime() : 0;
            long wait = be == null ? 0 : be.until - now;
            boolean active = wait > 0;
            call.active = !active;
            found.active = active;
            super.render(g, mx, my, pt);
            row(g, left + 8, top + 24, w - 16, 24);
            if (active) {
                boolean blink = (now / 8) % 2 == 0;
                g.fill(left + 14, top + 30, left + 26, top + 42, blink ? 0xFFE04040 : 0xFF702020);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.child_active", clock(wait)), left + 34, top + 32, 0xFFB0B0, false);
            } else {
                g.fill(left + 14, top + 30, left + 26, top + 42, 0xFF3FD07A);
                g.drawString(font, Component.translatable("gui.coastercontrolpanel.child_idle"), left + 34, top + 32, 0x7CFFB0, false);
            }
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.child_help"), left + 8, top + 110, 0x8A8FA3, false);
        }
    }

    // ------------------------------------------------------------------ emergency phone

    public static class PhoneScreen extends GiftScreens.ParkScreen {
        public PhoneScreen(BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel.emergency_phone"), pos, 232, 150, 0xFFB03A2E);
        }

        @Override
        protected void build() {
            for (int i = 0; i < 4; i++) {
                final int r = i;
                addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.phone_reason_" + i), b -> act(18, r, 0))
                        .bounds(left + 16 + (i % 2) * 104, top + 54 + (i / 2) * 28, 96, 22).build());
            }
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            long now = minecraft != null && minecraft.level != null ? minecraft.level.getGameTime() : 0;
            row(g, left + 8, top + 24, w - 16, 22);
            g.fill(left + 14, top + 29, left + 24, top + 41, (now / 10) % 2 == 0 ? 0xFFE04040 : 0xFF702020);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.phone_prompt"), left + 32, top + 31, 0xFFFFFF, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.phone_help"), left + 8, top + 112, 0x8A8FA3, false);
        }
    }
}
