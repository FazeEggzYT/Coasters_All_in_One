package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Support Tool: click two anchors to preview supports under that stretch, right-click in the air to build them,
 * sneak + right-click in the air for settings. Support Eraser: right-click in the air to undo the last build.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class SupportToolEvents {
    private static final int PER_TICK = 500;
    private static final int PREVIEW_LIFETIME = 20 * 90;

    private static final class Pending {
        final ResourceKey<Level> dim;
        final List<BlockPos> blocks;
        final Block block;
        long expires;

        Pending(ResourceKey<Level> dim, List<BlockPos> blocks, Block block, long expires) {
            this.dim = dim;
            this.blocks = blocks;
            this.block = block;
            this.expires = expires;
        }
    }

    private static final class Build {
        final UUID player;
        final ServerLevel level;
        final Block block;
        final Deque<BlockPos> todo;
        final List<BlockPos> done = new ArrayList<>();

        Build(UUID player, ServerLevel level, Block block, List<BlockPos> blocks) {
            this.player = player;
            this.level = level;
            this.block = block;
            this.todo = new ArrayDeque<>(blocks);
        }
    }

    private record Undo(ResourceKey<Level> dim, Block block, List<BlockPos> blocks) {
    }

    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Map<UUID, Deque<Undo>> UNDO = new HashMap<>();
    private static final List<Build> BUILDS = new ArrayList<>();

    // ---------------------------------------------------------------- clicks

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (event.getHand() != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.SUPPORT_TOOL_ITEM.get())) {
            return;
        }
        Level level = event.getLevel();
        BlockPos pos = event.getPos();
        if (!AnchorTrack.isAnchor(level.getBlockEntity(pos))) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (level.isClientSide || !(level instanceof ServerLevel server)) {
            return;
        }
        Player player = event.getEntity();
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        if (!tag.contains("From")) {
            tag.putLong("From", pos.asLong());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_from"), true);
            return;
        }
        BlockPos from = BlockPos.of(tag.getLong("From"));
        tag.remove("From");
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        if (from.equals(pos)) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_cancel"), true);
            return;
        }
        SupportSettings settings = SupportSettings.of(stack);
        SupportPlanner.Plan plan = SupportPlanner.plan(server, from, pos, settings);
        if (plan.noTrack()) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_none"), true);
            return;
        }
        if (plan.tooBig()) {
            PENDING.remove(player.getUUID());
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_big",
                    SupportPlanner.MAX_BLOCKS), true);
            return;
        }
        if (plan.blocks().isEmpty()) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_empty"), true);
            return;
        }
        PENDING.put(player.getUUID(), new Pending(server.dimension(), plan.blocks(), settings.block(player),
                server.getGameTime() + PREVIEW_LIFETIME));
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_preview",
                plan.supports(), plan.blocks().size(), plan.skipped()), true);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        ItemStack stack = event.getItemStack();
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        boolean tool = stack.is(CoasterControlPanel.SUPPORT_TOOL_ITEM.get());
        boolean eraser = stack.is(CoasterControlPanel.SUPPORT_ERASER_ITEM.get());
        if (!tool && !eraser) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        Level level = event.getLevel();
        Player player = event.getEntity();
        if (level.isClientSide) {
            if (tool && player.isShiftKeyDown()) {
                ClientHooks.openSupportSettings();
            }
            return;
        }
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        if (eraser) {
            undo(server, player);
        } else if (player.isShiftKeyDown()) {
            PENDING.remove(player.getUUID());
        } else {
            confirm(server, player);
        }
    }

    private static void confirm(ServerLevel server, Player player) {
        Pending pending = PENDING.remove(player.getUUID());
        if (pending == null || !pending.dim.equals(server.dimension())) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_nothing"), true);
            return;
        }
        BUILDS.add(new Build(player.getUUID(), server, pending.block, pending.blocks));
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_building",
                pending.blocks.size()), true);
    }

    private static void undo(ServerLevel server, Player player) {
        Deque<Undo> stack = UNDO.get(player.getUUID());
        if (stack == null || stack.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_no_undo"), true);
            return;
        }
        Undo u = stack.pop();
        if (!u.dim.equals(server.dimension())) {
            stack.push(u);
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_other_dim"), true);
            return;
        }
        int removed = 0;
        for (BlockPos p : u.blocks) {
            if (server.hasChunkAt(p) && server.getBlockState(p).is(u.block)) {
                server.setBlock(p, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 2);
                removed++;
            }
        }
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_undone", removed), true);
    }

    // ---------------------------------------------------------------- building and preview

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        // place the blocks of running builds, a few hundred a tick
        Iterator<Build> it = BUILDS.iterator();
        while (it.hasNext()) {
            Build b = it.next();
            BlockState state = b.block.defaultBlockState();
            int n = 0;
            while (!b.todo.isEmpty() && n < PER_TICK) {
                BlockPos p = b.todo.poll();
                if (b.level.hasChunkAt(p)) {
                    BlockState existing = b.level.getBlockState(p);
                    if (existing.isAir() || existing.canBeReplaced()) {
                        b.level.setBlock(p, state, 2);
                        b.done.add(p);
                    }
                }
                n++;
            }
            if (b.todo.isEmpty()) {
                it.remove();
                Deque<Undo> stack = UNDO.computeIfAbsent(b.player, k -> new ArrayDeque<>());
                stack.push(new Undo(b.level.dimension(), b.block, b.done));
                while (stack.size() > 5) {
                    stack.removeLast();
                }
                ServerPlayer sp = event.getServer().getPlayerList().getPlayer(b.player);
                if (sp != null) {
                    sp.displayClientMessage(Component.translatable("message.coastercontrolpanel.support_built",
                            b.done.size()), true);
                }
            }
        }
        // green sparkles show where the supports will go
        if (event.getServer().getTickCount() % 10 != 0) {
            return;
        }
        Iterator<Map.Entry<UUID, Pending>> pit = PENDING.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, Pending> e = pit.next();
            ServerPlayer sp = event.getServer().getPlayerList().getPlayer(e.getKey());
            Pending p = e.getValue();
            if (sp == null || !(sp.level() instanceof ServerLevel level) || !level.dimension().equals(p.dim)
                    || level.getGameTime() > p.expires) {
                pit.remove();
                continue;
            }
            int stride = Math.max(1, p.blocks.size() / 250);
            for (int i = 0; i < p.blocks.size(); i += stride) {
                BlockPos pos = p.blocks.get(i);
                level.sendParticles(sp, ParticleTypes.HAPPY_VILLAGER, false,
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1, 0.1, 0.1, 0.1, 0.0);
            }
        }
    }
}
