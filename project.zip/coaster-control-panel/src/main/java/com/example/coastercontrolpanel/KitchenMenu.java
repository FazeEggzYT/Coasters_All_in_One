package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Two ingredient slots, one output slot, and your inventory. */
public class KitchenMenu extends AbstractContainerMenu {
    public final BlockPos pos;
    private final ContainerData data;

    public KitchenMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, new SimpleContainer(3), new SimpleContainerData(2), buf.readBlockPos());
    }

    public KitchenMenu(int id, Inventory playerInv, Container container, ContainerData data, BlockPos pos) {
        super(CoasterControlPanel.KITCHEN_MENU.get(), id);
        this.pos = pos;
        this.data = data;
        addSlot(new Slot(container, 0, 44, 26));
        addSlot(new Slot(container, 1, 44, 52));
        addSlot(new Slot(container, 2, 124, 39) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 102 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInv, col, 8 + col * 18, 160));
        }
        addDataSlots(data);
    }

    /** Progress from 0 to 1. */
    public float progress() {
        int total = data.get(1);
        return total <= 0 ? 0 : Math.min(1.0F, data.get(0) / (float) total);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            boolean moved;
            if (index < 3) {
                moved = moveItemStackTo(stack, 3, 39, true);
            } else {
                moved = moveItemStackTo(stack, 0, 2, false);
            }
            if (!moved) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }
}
