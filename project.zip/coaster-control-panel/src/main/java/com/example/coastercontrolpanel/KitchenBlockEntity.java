package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** Holds the two ingredient slots and the output slot of a kitchen machine, and does the cooking. */
public class KitchenBlockEntity extends BlockEntity implements MenuProvider {
    public final SimpleContainer inv = new SimpleContainer(3);
    private int progress;
    private int total = 1;
    private int fan;

    public final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index == 0 ? progress : total;
        }

        @Override
        public void set(int index, int value) {
            if (index == 0) {
                progress = value;
            } else {
                total = value;
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    };

    public KitchenBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.KITCHEN_BE.get(), pos, state);
        inv.addListener(c -> setChanged());
    }

    public KitchenKind kind() {
        return getBlockState().getBlock() instanceof KitchenBlock kb ? kb.kind : KitchenKind.GRILL;
    }

    /** Which slots feed the recipe: {a slot, b slot}, b = -1 when the recipe has one input. Null if nothing matches. */
    @Nullable
    private static int[] assign(KitchenKind.Recipe r, ItemStack s0, ItemStack s1) {
        if (r.b() == null) {
            if (ok(s0, r.a().get(), r.ca())) {
                return new int[]{0, -1};
            }
            if (ok(s1, r.a().get(), r.ca())) {
                return new int[]{1, -1};
            }
            return null;
        }
        if (ok(s0, r.a().get(), r.ca()) && ok(s1, r.b().get(), r.cb())) {
            return new int[]{0, 1};
        }
        if (ok(s1, r.a().get(), r.ca()) && ok(s0, r.b().get(), r.cb())) {
            return new int[]{1, 0};
        }
        return null;
    }

    private static boolean ok(ItemStack s, net.minecraft.world.item.Item item, int count) {
        return s.is(item) && s.getCount() >= count;
    }

    private boolean outputFits(KitchenKind.Recipe r) {
        ItemStack out = inv.getItem(2);
        if (out.isEmpty()) {
            return true;
        }
        return out.is(r.out().get()) && out.getCount() + r.outCount() <= out.getMaxStackSize();
    }

    private void shrinkSlot(int slot, int count) {
        ItemStack s = inv.getItem(slot);
        boolean milk = s.is(Items.MILK_BUCKET);
        s.shrink(count);
        if (s.isEmpty()) {
            inv.setItem(slot, milk ? new ItemStack(Items.BUCKET) : ItemStack.EMPTY);
        } else {
            inv.setChanged();
        }
    }

    public void serverTick() {
        Level level = this.level;
        if (!(level instanceof ServerLevel sl)) {
            return;
        }
        KitchenKind kind = kind();
        ItemStack s0 = inv.getItem(0);
        ItemStack s1 = inv.getItem(1);
        KitchenKind.Recipe found = null;
        int[] slots = null;
        for (KitchenKind.Recipe r : kind.recipes) {
            int[] a = assign(r, s0, s1);
            if (a != null) {
                found = r;
                slots = a;
                break;
            }
        }
        boolean cooking = found != null && outputFits(found);
        if (level.getGameTime() % 20 == 0 || fan < 0) {
            fan = KitchenExtras.FanBlock.bonus(level, worldPosition);
        }
        total = kind.cookTicks * 2;
        if (cooking) {
            progress += 2 + fan;
            if (progress >= total) {
                shrinkSlot(slots[0], found.ca());
                if (slots[1] >= 0) {
                    shrinkSlot(slots[1], found.cb());
                }
                ItemStack out = inv.getItem(2);
                if (out.isEmpty()) {
                    inv.setItem(2, new ItemStack(found.out().get(), found.outCount()));
                } else {
                    out.grow(found.outCount());
                    inv.setChanged();
                }
                progress = 0;
                level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 0.8F, 1.4F);
            }
        } else if (progress > 0) {
            progress = Math.max(0, progress - 2);
        }
        BlockState st = getBlockState();
        if (st.hasProperty(KitchenBlock.LIT) && st.getValue(KitchenBlock.LIT) != cooking) {
            level.setBlock(worldPosition, st.setValue(KitchenBlock.LIT, cooking), 3);
        }
        if (cooking && level.getGameTime() % 8 == 0) {
            effects(sl, kind, fan);
        }
    }

    private void effects(ServerLevel sl, KitchenKind kind, int fan) {
        double x = worldPosition.getX() + 0.5;
        double y = worldPosition.getY() + 1.05;
        double z = worldPosition.getZ() + 0.5;
        switch (kind) {
            case GRILL -> {
                if (fan == 0) {
                    sl.sendParticles(ParticleTypes.SMOKE, x, y, z, 3, 0.2, 0.05, 0.2, 0.01);
                }
                sl.playSound(null, worldPosition, SoundEvents.CAMPFIRE_CRACKLE, SoundSource.BLOCKS, 0.5F, 1.0F);
            }
            case OVEN -> {
                if (fan == 0) {
                    sl.sendParticles(ParticleTypes.SMOKE, x, y + 0.9, z, 2, 0.1, 0.05, 0.1, 0.01);
                }
                sl.playSound(null, worldPosition, SoundEvents.FURNACE_FIRE_CRACKLE, SoundSource.BLOCKS, 0.5F, 1.0F);
            }
            case FRYER -> {
                sl.sendParticles(ParticleTypes.BUBBLE_POP, x, y + 0.1, z, 3, 0.2, 0.0, 0.2, 0.01);
                sl.playSound(null, worldPosition, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.3F, 1.5F);
            }
            case SOFT_SERVE -> sl.sendParticles(ParticleTypes.SNOWFLAKE, x, y + 0.3, z, 2, 0.15, 0.1, 0.15, 0.0);
            case POPCORN -> {
                sl.sendParticles(ParticleTypes.CRIT, x, y + 0.4, z, 2, 0.2, 0.2, 0.2, 0.05);
                sl.playSound(null, worldPosition, SoundEvents.CHICKEN_EGG, SoundSource.BLOCKS, 0.3F, 1.8F);
            }
            case DRINKS -> sl.sendParticles(ParticleTypes.FALLING_WATER, x, y - 0.4, z - 0.3, 2, 0.05, 0.05, 0.05, 0.0);
            default -> sl.playSound(null, worldPosition, SoundEvents.WOOD_HIT, SoundSource.BLOCKS, 0.3F, 1.2F);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        for (int i = 0; i < 3; i++) {
            list.set(i, inv.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        tag.putInt("Progress", progress);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(3, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < 3; i++) {
            inv.setItem(i, list.get(i));
        }
        progress = tag.getInt("Progress");
    }

    @Override
    public Component getDisplayName() {
        return getBlockState().getBlock().getName();
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory playerInv, Player player) {
        return new KitchenMenu(id, playerInv, inv, data, worldPosition);
    }
}
