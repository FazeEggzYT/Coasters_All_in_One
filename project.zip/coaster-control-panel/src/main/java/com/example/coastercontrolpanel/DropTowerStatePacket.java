package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Server to client, every tick while a Drop Tower runs. Create ignores server position updates for the moving
 * structure of a controller block, so the client moves it from these numbers (the same job Create's own pulley does
 * on the client with its own speed).
 */
public record DropTowerStatePacket(BlockPos pos, double rise, double vel, int phase, long anchor) implements CustomPacketPayload {
    public static final Type<DropTowerStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "drop_tower_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DropTowerStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeDouble(p.rise);
                buf.writeDouble(p.vel);
                buf.writeVarInt(p.phase);
                buf.writeLong(p.anchor);
            },
            buf -> new DropTowerStatePacket(buf.readBlockPos(), buf.readDouble(), buf.readDouble(), buf.readVarInt(), buf.readLong()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(DropTowerStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof DropTowerBlockEntity be) {
            be.receiveState(p.rise, p.vel, p.phase, BlockPos.of(p.anchor));
        }
    }
}
