package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the sequence and settings of a Drop Tower (only used while the ride stands still). */
public record DropTowerConfigPacket(BlockPos pos, CompoundTag settings) implements CustomPacketPayload {
    public static final Type<DropTowerConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "drop_tower_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DropTowerConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                ByteBufCodecs.COMPOUND_TAG.encode(buf, p.settings);
            },
            buf -> new DropTowerConfigPacket(buf.readBlockPos(), ByteBufCodecs.COMPOUND_TAG.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(DropTowerConfigPacket p, IPayloadContext context) {
        DropTowerBlockEntity be = DropTowerBlockEntity.lookup(context.player(), p.pos);
        if (be != null) {
            be.applyConfig(p.settings);
        }
    }
}
