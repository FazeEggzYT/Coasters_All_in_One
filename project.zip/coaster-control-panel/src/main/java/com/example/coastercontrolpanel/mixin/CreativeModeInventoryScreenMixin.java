package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterControlPanel;
import com.example.coastercontrolpanel.TabSections;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the section headings over the empty header rows of our tab. */
@Mixin(CreativeModeInventoryScreen.class)
public abstract class CreativeModeInventoryScreenMixin {
    private static final int VISIBLE_ROWS = 5;
    private static final int[] ACCENTS = {0xFF3CC85A, 0xFFE6A028, 0xFF3C78DC, 0xFFD24646};

    @Shadow
    private static CreativeModeTab selectedTab;

    @Shadow
    private float scrollOffs;

    @Inject(method = "render", at = @At("TAIL"))
    private void coastercontrolpanel$sectionLabels(GuiGraphics g, int mouseX, int mouseY, float partialTick,
                                                   CallbackInfo ci) {
        if (selectedTab != CoasterControlPanel.MAIN_TAB.get()) {
            return;
        }
        AbstractContainerScreenAccessor screen = (AbstractContainerScreenAccessor) (Object) this;
        int left = screen.coastercontrolpanel$leftPos();
        int top = screen.coastercontrolpanel$topPos();
        Font font = Minecraft.getInstance().font;

        CreativeModeInventoryScreen self = (CreativeModeInventoryScreen) (Object) this;
        int slotCount = self.getMenu().items.size();
        int totalRows = (slotCount + 8) / 9;
        int maxScroll = Math.max(0, totalRows - VISIBLE_ROWS);
        int firstRow = (int) (this.scrollOffs * maxScroll + 0.5D);

        for (int i = 0; i < TabSections.SECTIONS.size(); i++) {
            int relRow = TabSections.SECTION_ROWS[i] - firstRow;
            if (relRow < 0 || relRow >= VISIBLE_ROWS) {
                continue;
            }
            int accent = ACCENTS[i % ACCENTS.length];
            int x0 = left + 8;
            int x1 = x0 + 162;
            int y0 = top + 17 + relRow * 18;
            int y1 = y0 + 18;
            g.fillGradient(x0, y0, x1, y1, 0xE01A1A1A, 0xE00C0C0C);
            g.fill(x0, y0, x0 + 3, y1, accent);
            g.fill(x0, y1 - 1, x1, y1, accent & 0x66FFFFFF);
            Component title = Component.translatable("gui.coastercontrolpanel.section." + TabSections.SECTIONS.get(i).key());
            g.drawString(font, title, x0 + 8, y0 + 5, 0xFFF3E4C0, true);
        }
    }
}
