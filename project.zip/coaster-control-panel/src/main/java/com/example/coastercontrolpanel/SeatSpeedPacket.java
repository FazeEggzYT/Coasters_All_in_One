package com.example.coastercontrolpanel;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the restraint speed chosen in the Seat Speed screen. */
public record SeatSpeedPacket(BlockPos pos, int speed) implements CustomPacketPayload {
    public static final Type<SeatSpeedPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "seat_speed"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SeatSpeedPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.speed);
            },
            buf -> new SeatSpeedPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SeatSpeedPacket packet, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(packet.pos.getX() + 0.5, packet.pos.getY() + 0.5, packet.pos.getZ() + 0.5) > 2304.0) {
            return;
        }
        boolean holding = player.getMainHandItem().is(CoasterControlPanel.SEAT_SPEED_ITEM.get())
                || player.getOffhandItem().is(CoasterControlPanel.SEAT_SPEED_ITEM.get());
        if (!holding) {
            return;
        }
        BlockEntity be = player.level().getBlockEntity(packet.pos);
        if (be instanceof SeatTimerAccess access) {
            access.seatTimerSet(access.seatTimerOpenDelay(), access.seatTimerCloseDelay(), packet.speed);
            if (be instanceof SmartBlockEntity smart) {
                smart.sendData();
            }
        }
    }
}
