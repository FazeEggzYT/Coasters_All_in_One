package com.example.coastercontrolpanel;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/** Every effect an Effect Block can make. Particles, plus real fireworks. */
public enum EffectType {
    // ---- smoke
    SMOKE("smoke", "Smoke", Cat.SMOKE, 0.06, 2, 2, plain(ParticleTypes.CAMPFIRE_COSY_SMOKE), null),
    THICK_SMOKE("thick_smoke", "Thick smoke", Cat.SMOKE, 0.08, 1, 4, plain(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE), null),
    DARK_SMOKE("dark_smoke", "Dark smoke", Cat.SMOKE, 0.05, 3, 2, plain(ParticleTypes.LARGE_SMOKE), null),
    LIGHT_SMOKE("light_smoke", "Light smoke", Cat.SMOKE, 0.05, 4, 2, plain(ParticleTypes.SMOKE), null),
    STEAM("steam", "Steam / fog", Cat.SMOKE, 0.06, 3, 2, plain(ParticleTypes.CLOUD), SoundEvents.FIRE_EXTINGUISH),
    POOF("poof", "Poof", Cat.SMOKE, 0.1, 4, 3, plain(ParticleTypes.POOF), null),
    ASH("ash", "Ash", Cat.SMOKE, 0.04, 6, 2, plain(ParticleTypes.ASH), null),
    WHITE_ASH("white_ash", "White ash", Cat.SMOKE, 0.04, 6, 2, plain(ParticleTypes.WHITE_ASH), null),
    SNEEZE("sneeze", "Mist puff", Cat.SMOKE, 0.08, 3, 3, plain(ParticleTypes.SNEEZE), null),
    // ---- fire
    FIRE_JET("fire_jet", "Fire jet", Cat.FIRE, 0.18, 4, 1, plain(ParticleTypes.FLAME), SoundEvents.FIRE_AMBIENT),
    SOUL_FIRE("soul_fire", "Soul fire jet", Cat.FIRE, 0.18, 4, 1, plain(ParticleTypes.SOUL_FIRE_FLAME), SoundEvents.FIRE_AMBIENT),
    SMALL_FLAMES("small_flames", "Small flames", Cat.FIRE, 0.08, 3, 2, plain(ParticleTypes.SMALL_FLAME), null),
    LAVA_SPARKS("lava_sparks", "Lava sparks", Cat.FIRE, 0.12, 2, 3, plain(ParticleTypes.LAVA), SoundEvents.LAVA_POP),
    DRIPPING_LAVA("dripping_lava", "Dripping lava", Cat.FIRE, 0.0, 1, 4, plain(ParticleTypes.DRIPPING_LAVA), null),
    EXPLOSION("explosion", "Small explosion", Cat.FIRE, 0.0, 1, 10, plain(ParticleTypes.EXPLOSION), SoundEvents.GENERIC_EXPLODE.value()),
    FLASH("flash", "Flash", Cat.FIRE, 0.0, 1, 6, plain(ParticleTypes.FLASH), null),
    // ---- sparks
    ELECTRIC("electric", "Electric sparks", Cat.SPARKS, 0.25, 6, 1, plain(ParticleTypes.ELECTRIC_SPARK), null),
    FIREWORK_SPARKS("firework_sparks", "Firework sparks", Cat.SPARKS, 0.2, 6, 1, plain(ParticleTypes.FIREWORK), null),
    GLITTER("glitter", "Glitter", Cat.SPARKS, 0.1, 4, 2, plain(ParticleTypes.END_ROD), null),
    CRIT("crit", "Crit sparks", Cat.SPARKS, 0.3, 6, 1, plain(ParticleTypes.CRIT), null),
    MAGIC_CRIT("magic_crit", "Magic sparks", Cat.SPARKS, 0.3, 6, 1, plain(ParticleTypes.ENCHANTED_HIT), null),
    TOTEM("totem", "Totem sparkle", Cat.SPARKS, 0.35, 8, 2, plain(ParticleTypes.TOTEM_OF_UNDYING), null),
    WAX_ON("wax_on", "Gold sparkle", Cat.SPARKS, 0.15, 4, 2, plain(ParticleTypes.WAX_ON), null),
    WAX_OFF("wax_off", "Pale sparkle", Cat.SPARKS, 0.15, 4, 2, plain(ParticleTypes.WAX_OFF), null),
    SCRAPE("scrape", "Scrape sparks", Cat.SPARKS, 0.15, 4, 2, plain(ParticleTypes.SCRAPE), null),
    GLOW("glow", "Glow", Cat.SPARKS, 0.08, 3, 2, plain(ParticleTypes.GLOW), null),
    // ---- coloured
    CONFETTI("confetti", "Confetti", Cat.COLOUR, 0.28, 8, 1, (c, f, s) -> dust(randomRgb(), s), null),
    COLOUR_DUST("colour_dust", "Coloured dust", Cat.COLOUR, 0.12, 5, 1, (c, f, s) -> dust(c, s), null),
    DUST_FADE("dust_fade", "Fading dust", Cat.COLOUR, 0.12, 5, 1, (c, f, s) -> fade(c, f, s), null),
    RAINBOW_FADE("rainbow_fade", "Rainbow fade", Cat.COLOUR, 0.14, 6, 1, (c, f, s) -> fade(randomRgb(), randomRgb(), s), null),
    // ---- water
    SNOW("snow", "Snow", Cat.WATER, 0.06, 6, 2, plain(ParticleTypes.SNOWFLAKE), null),
    BUBBLES("bubbles", "Bubbles", Cat.WATER, 0.1, 4, 2, plain(ParticleTypes.BUBBLE), null),
    BUBBLE_POP("bubble_pop", "Bubble pops", Cat.WATER, 0.08, 4, 2, plain(ParticleTypes.BUBBLE_POP), null),
    BUBBLE_COLUMN("bubble_column", "Bubble column", Cat.WATER, 0.2, 3, 1, plain(ParticleTypes.BUBBLE_COLUMN_UP), null),
    SPLASH("splash", "Splash", Cat.WATER, 0.2, 6, 2, plain(ParticleTypes.SPLASH), SoundEvents.PLAYER_SPLASH),
    WATER_DRIP("water_drip", "Water drips", Cat.WATER, 0.0, 1, 4, plain(ParticleTypes.DRIPPING_WATER), null),
    UNDERWATER("underwater", "Underwater specks", Cat.WATER, 0.05, 4, 2, plain(ParticleTypes.UNDERWATER), null),
    NAUTILUS("nautilus", "Nautilus swirl", Cat.WATER, 0.2, 4, 2, plain(ParticleTypes.NAUTILUS), null),
    HONEY("honey", "Honey drips", Cat.WATER, 0.0, 1, 4, plain(ParticleTypes.DRIPPING_HONEY), null),
    // ---- magic and fun
    HEARTS("hearts", "Hearts", Cat.MAGIC, 0.08, 2, 4, plain(ParticleTypes.HEART), null),
    HAPPY("happy", "Happy sparkles", Cat.MAGIC, 0.08, 3, 3, plain(ParticleTypes.HAPPY_VILLAGER), null),
    ANGRY("angry", "Angry clouds", Cat.MAGIC, 0.05, 1, 5, plain(ParticleTypes.ANGRY_VILLAGER), null),
    NOTES("notes", "Music notes", Cat.MAGIC, 0.2, 2, 4, plain(ParticleTypes.NOTE), null),
    ENCHANT("enchant", "Enchant glyphs", Cat.MAGIC, 0.5, 8, 2, plain(ParticleTypes.ENCHANT), null),
    PORTAL("portal", "Portal swirl", Cat.MAGIC, 0.6, 8, 2, plain(ParticleTypes.PORTAL), null),
    WITCH("witch", "Witch magic", Cat.MAGIC, 0.2, 4, 2, plain(ParticleTypes.WITCH), null),
    DRAGON("dragon", "Dragon breath", Cat.MAGIC, 0.08, 4, 2, plain(ParticleTypes.DRAGON_BREATH), null),
    SOUL("soul", "Souls", Cat.MAGIC, 0.04, 2, 4, plain(ParticleTypes.SOUL), null),
    SCULK_SOUL("sculk_soul", "Sculk souls", Cat.MAGIC, 0.04, 2, 4, plain(ParticleTypes.SCULK_SOUL), null),
    INK("ink", "Squid ink", Cat.MAGIC, 0.15, 4, 2, plain(ParticleTypes.SQUID_INK), null),
    GLOW_INK("glow_ink", "Glow ink", Cat.MAGIC, 0.15, 4, 2, plain(ParticleTypes.GLOW_SQUID_INK), null),
    SPORES("spores", "Spore blossom", Cat.MAGIC, 0.04, 5, 2, plain(ParticleTypes.SPORE_BLOSSOM_AIR), null),
    CHERRY("cherry", "Cherry petals", Cat.MAGIC, 0.05, 4, 3, plain(ParticleTypes.CHERRY_LEAVES), null),
    MYCELIUM("mycelium", "Mycelium dust", Cat.MAGIC, 0.05, 6, 2, plain(ParticleTypes.MYCELIUM), null),
    CRIMSON("crimson", "Crimson spores", Cat.MAGIC, 0.05, 6, 2, plain(ParticleTypes.CRIMSON_SPORE), null),
    WARPED("warped", "Warped spores", Cat.MAGIC, 0.05, 6, 2, plain(ParticleTypes.WARPED_SPORE), null),
    SWEEP("sweep", "Sweep slash", Cat.MAGIC, 0.0, 1, 6, plain(ParticleTypes.SWEEP_ATTACK), null),
    DAMAGE("damage", "Damage marks", Cat.MAGIC, 0.1, 2, 4, plain(ParticleTypes.DAMAGE_INDICATOR), null),
    // ---- real fireworks
    ROCKET("rocket", "Firework rocket", Cat.FIREWORK, 0.5, 1, 4, null, null),
    BARRAGE("barrage", "Firework barrage", Cat.FIREWORK, 0.5, 5, 6, null, null),
    CANNON("cannon", "Firework cannon", Cat.FIREWORK, 0.35, 1, 2, null, null);

    public enum Cat {
        SMOKE, FIRE, SPARKS, COLOUR, WATER, MAGIC, FIREWORK
    }

    public interface Maker {
        ParticleOptions make(int rgb, int fadeRgb, float size);
    }

    public final String key;
    public final String label;
    public final Cat cat;
    public final double baseSpeed;
    public final int defAmount;
    public final int defRate;
    @Nullable
    private final Maker maker;
    @Nullable
    public final SoundEvent sound;

    EffectType(String key, String label, Cat cat, double baseSpeed, int defAmount, int defRate,
               @Nullable Maker maker, @Nullable SoundEvent sound) {
        this.key = key;
        this.label = label;
        this.cat = cat;
        this.baseSpeed = baseSpeed;
        this.defAmount = defAmount;
        this.defRate = defRate;
        this.maker = maker;
        this.sound = sound;
    }

    public boolean isFirework() {
        return cat == Cat.FIREWORK;
    }

    public boolean usesColour() {
        return this == COLOUR_DUST || this == DUST_FADE || isFirework();
    }

    public boolean usesFade() {
        return this == DUST_FADE || isFirework();
    }

    public boolean usesSize() {
        return cat == Cat.COLOUR;
    }

    @Nullable
    public ParticleOptions options(int rgb, int fadeRgb, float size) {
        return maker == null ? null : maker.make(rgb, fadeRgb, size);
    }

    public static EffectType byIndex(int i) {
        EffectType[] all = values();
        return all[Math.floorMod(i, all.length)];
    }

    private static Maker plain(ParticleOptions o) {
        return (c, f, s) -> o;
    }

    private static Vector3f vec(int rgb) {
        return new Vector3f(((rgb >> 16) & 255) / 255.0F, ((rgb >> 8) & 255) / 255.0F, (rgb & 255) / 255.0F);
    }

    private static ParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(vec(rgb), size);
    }

    private static ParticleOptions fade(int rgb, int to, float size) {
        return new DustColorTransitionOptions(vec(rgb), vec(to), size);
    }

    private static int randomRgb() {
        return net.minecraft.world.item.DyeColor.byId(
                (int) (Math.random() * 16)).getFireworkColor();
    }
}
