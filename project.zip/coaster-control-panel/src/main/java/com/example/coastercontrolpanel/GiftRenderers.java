package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemDisplayContext;

/** The Window Display turntable and the text of the Price Tag. */
public final class GiftRenderers {
    private GiftRenderers() {
    }

    private static final int FULL_BRIGHT = 15728880;

    public static class WindowDisplay implements BlockEntityRenderer<GiftBlocks.WindowBlockEntity> {
        private final ItemRenderer items;

        public WindowDisplay(BlockEntityRendererProvider.Context context) {
            this.items = context.getItemRenderer();
        }

        @Override
        public void render(GiftBlocks.WindowBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            if (be.shown.isEmpty() || be.getLevel() == null) {
                return;
            }
            float time = be.getLevel().getGameTime() + partialTick;
            pose.pushPose();
            pose.translate(0.5, 0.72 + Math.sin(time / 12.0) * 0.02, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(time * be.spin * 2.0F));
            pose.scale(0.65F, 0.65F, 0.65F);
            items.renderStatic(be.shown, ItemDisplayContext.FIXED, light, overlay, pose, buffers, be.getLevel(), (int) be.getBlockPos().asLong());
            pose.popPose();
        }
    }

    public static class PriceTag implements BlockEntityRenderer<GiftBlocks.PriceTagBlockEntity> {
        private final Font font;

        public PriceTag(BlockEntityRendererProvider.Context context) {
            this.font = context.getFont();
        }

        private void line(String s, int colour, float y, float baseScale, float maxWidth, PoseStack pose, MultiBufferSource buffers) {
            if (s.isEmpty()) {
                return;
            }
            Component text = Component.literal(s);
            int w = Math.max(1, font.width(text));
            float scale = Math.min(baseScale, maxWidth / w);
            pose.pushPose();
            pose.translate(0.0, y, 0.0);
            pose.scale(scale, -scale, scale);
            font.drawInBatch(text, -w / 2.0F, 0.0F, colour, false, pose.last().pose(), buffers, Font.DisplayMode.NORMAL, 0, FULL_BRIGHT);
            pose.popPose();
        }

        @Override
        public void render(GiftBlocks.PriceTagBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                           int light, int overlay) {
            Direction facing = be.getBlockState().getValue(DecorBlocks.FACING);
            pose.pushPose();
            pose.translate(0.5, 0.5, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
            pose.translate(0.0, 0.0, 0.0625 + 0.004);
            if (be.price < 0) {
                line("---", 0xFF555555, 0.17F, 0.03F, 0.7F, pose, buffers);
            } else {
                line(be.name, 0xFF222222, 0.11F, 0.02F, 0.75F, pose, buffers);
                line(be.price + " gold", 0xFFB02020, 0.22F, 0.035F, 0.75F, pose, buffers);
            }
            pose.popPose();
        }
    }
}
