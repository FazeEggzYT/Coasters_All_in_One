package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** One screen class for every amenity block with a UI. What it shows depends on the block id. */
public final class PropScreens {
    private PropScreens() {
    }

    static Component t(String key, Object... args) {
        return Component.translatable("gui.coastercontrolpanel.prop." + key, args);
    }

    public static class PropScreen extends GiftScreens.ParkScreen {
        private final String id;

        public PropScreen(String id, BlockPos pos) {
            super(Component.translatable("block.coastercontrolpanel." + id), pos, 220, heightOf(id), accentOf(id));
            this.id = id;
        }

        static int heightOf(String id) {
            return switch (id) {
                case "hob", "walkie_talkie_charger" -> 150;
                case "sign_in_terminal" -> 190;
                case "bathtub", "ice_machine", "chopping_board", "coffee_machine", "blood_pressure_monitor", "fire_alarm_pull",
                     "charging_station", "rice_cooker" -> 118;
                case "blender", "jukebox", "air_freshener" -> 142;
                default -> 128;
            };
        }

        static int accentOf(String id) {
            int h = 0;
            for (char c : id.toCharArray()) {
                h = h * 31 + c;
            }
            int[] cols = {0xFF2E64B0, 0xFF9A4A2E, 0xFF2A8A6A, 0xFF8A3A7A, 0xFF5A4A9A, 0xFFB0802E, 0xFF3A7A3A, 0xFFA03A3A};
            return cols[Math.floorMod(h, cols.length)];
        }

        private void btn(String key, int x, int y, int bw, int action, int a) {
            addRenderableWidget(Button.builder(t(key), b -> send(action, a)).bounds(left + x, top + y, bw, 16).build());
        }

        private void send(int action, int a) {
            PacketDistributor.sendToServer(new PropActionPacket(pos, action, a));
        }

        /** A row of numbered choices, each sending (action, index). */
        private void choices(String[] keys, int action, int y) {
            int n = keys.length;
            int bw = (w - 16 - (n - 1) * 4) / n;
            for (int i = 0; i < n; i++) {
                btn(keys[i], 8 + i * (bw + 4), y, bw, action, i);
            }
        }

        @Override
        protected void build() {
            switch (id) {
                case "bathtub" -> {
                    btn("fill", 8, 62, 64, 1, 0);
                    btn("drain", 78, 62, 64, 2, 0);
                    btn("stop", 148, 62, 64, 3, 0);
                }
                case "air_freshener" -> {
                    btn("on_off", 8, 62, 90, 1, 0);
                    btn("scent", 104, 62, 108, 3, 0);
                    btn("minus", 8, 84, 40, 2, -5);
                    btn("plus", 54, 84, 40, 2, 5);
                }
                case "hob" -> {
                    btn("burner_1", 8, 34, 98, 1, 0);
                    btn("burner_2", 114, 34, 98, 2, 0);
                    btn("burner_3", 8, 56, 98, 3, 0);
                    btn("burner_4", 114, 56, 98, 4, 0);
                    btn("all_off", 8, 84, 98, 5, 0);
                    btn("cook", 114, 84, 98, 6, 0);
                }
                case "rice_cooker" -> {
                    btn("add_rice", 8, 62, 64, 1, 0);
                    btn("start", 78, 62, 64, 2, 0);
                    btn("collect", 148, 62, 64, 3, 0);
                }
                case "blender" -> {
                    btn("apple", 8, 34, 98, 1, 0);
                    btn("carrot", 114, 34, 98, 2, 0);
                    btn("melon", 8, 56, 98, 3, 0);
                    btn("berry", 114, 56, 98, 4, 0);
                    btn("glow", 8, 78, 98, 5, 0);
                }
                case "ice_machine" -> {
                    btn("take_one", 8, 62, 98, 1, 0);
                    btn("take_all", 114, 62, 98, 2, 0);
                }
                case "chopping_board" -> {
                    btn("chop_one", 8, 62, 98, 1, 0);
                    btn("chop_stack", 114, 62, 98, 2, 0);
                }
                case "coffee_machine" -> {
                    btn("coffee", 8, 62, 98, 1, 0);
                    btn("chocolate", 114, 62, 98, 2, 0);
                }
                case "photo_booth" -> choices(new String[]{"castle", "space", "beach", "jungle"}, 1, 62);
                case "balloon_stand" -> choices(new String[]{"red", "yellow", "blue", "green"}, 1, 62);
                case "coin_press" -> choices(new String[]{"dragon", "castle", "star", "rocket"}, 1, 62);
                case "face_paint_station" -> choices(new String[]{"tiger", "butterfly", "star", "clown"}, 1, 62);
                case "blood_pressure_monitor" -> btn("measure", 8, 62, 204, 1, 0);
                case "fire_alarm_pull" -> {
                    btn("pull", 8, 62, 98, 1, 0);
                    btn("reset", 114, 62, 98, 2, 0);
                }
                case "charging_station" -> btn("charge_me", 8, 62, 204, 1, 0);
                case "walkie_talkie_charger" -> {
                    btn("walkie_1", 8, 34, 204, 1, 0);
                    btn("walkie_2", 8, 54, 204, 2, 0);
                    btn("walkie_3", 8, 74, 204, 3, 0);
                    btn("walkie_4", 8, 94, 204, 4, 0);
                }
                case "sign_in_terminal" -> {
                    btn("sign_in", 8, 34, 98, 1, 0);
                    btn("sign_out", 114, 34, 98, 2, 0);
                }
                case "jukebox" -> {
                    btn("tune_1", 8, 34, 98, 1, 0);
                    btn("tune_2", 114, 34, 98, 2, 0);
                    btn("tune_3", 8, 56, 98, 3, 0);
                    btn("tune_4", 114, 56, 98, 4, 0);
                    btn("stop", 8, 84, 98, 5, 0);
                    btn("loop", 114, 84, 98, 6, 0);
                }
                default -> {
                }
            }
        }

        private List<Component> info(ParkProps.PropBE be, BlockState st) {
            List<Component> out = new ArrayList<>();
            int s = st.getBlock() instanceof ParkProps.Act ? st.getValue(ParkProps.ST) : 0;
            switch (id) {
                case "bathtub" -> out.add(t("water", s * 33 + (s == 3 ? 1 : 0)));
                case "air_freshener" -> {
                    out.add(t(be.v[2] == 1 ? "state_on" : "state_off"));
                    out.add(t("interval", be.v[0]));
                    out.add(t("sprays", be.v[3]));
                }
                case "hob" -> {
                    for (int i = 0; i < 4; i++) {
                        out.add(t("burner_heat", i + 1, be.v[i]));
                    }
                }
                case "rice_cooker" -> out.add(t("rice_state_" + Math.max(0, Math.min(3, be.v[0]))));
                case "ice_machine" -> out.add(t("ice_stock", be.v[0]));
                case "coffee_machine" -> out.add(t(be.v[0] == 1 ? "brewing" : "ready"));
                case "photo_booth", "balloon_stand", "coin_press" -> out.add(t("cost_" + id));
                case "face_paint_station" -> out.add(t("cost_face_paint_station"));
                case "chopping_board" -> out.add(t("chop_help"));
                case "blender" -> out.add(t("blender_help"));
                case "blood_pressure_monitor" -> {
                    if (be.v[0] > 0) {
                        out.add(t("bp_reading", be.v[0], be.v[1]));
                        out.add(t("pulse", be.v[2]));
                        out.add(t("bp_patient", be.text));
                    } else {
                        out.add(t("bp_none"));
                    }
                }
                case "fire_alarm_pull" -> out.add(t(be.v[0] == 1 ? "alarm_ringing" : "alarm_quiet"));
                case "charging_station" -> out.add(t("charge_level", be.v[0]));
                case "walkie_talkie_charger" -> out.add(t("walkie_help"));
                case "sign_in_terminal" -> {
                    String[] names = be.text.split("\n");
                    int n = 0;
                    for (String nm : names) {
                        if (!nm.isBlank()) {
                            out.add(Component.literal("• " + nm));
                            n++;
                        }
                    }
                    if (n == 0) {
                        out.add(t("nobody"));
                    }
                }
                case "jukebox" -> out.add(t(be.v[2] == 1 ? "now_playing" : "silent", be.v[0] + 1));
                default -> {
                }
            }
            return out;
        }

        @Override
        public void render(GuiGraphics g, int mx, int my, float pt) {
            super.render(g, mx, my, pt);
            ParkProps.PropBE be = entity(ParkProps.PropBE.class);
            if (be == null || minecraft == null || minecraft.level == null) {
                return;
            }
            BlockState st = minecraft.level.getBlockState(pos);
            List<Component> lines = info(be, st);
            int y = switch (id) {
                case "sign_in_terminal" -> top + 58;
                case "hob", "jukebox" -> top + 108;
                case "blender" -> top + 100;
                case "walkie_talkie_charger" -> top + 118;
                default -> top + 26;
            };
            int step = id.equals("hob") ? 10 : 11;
            for (Component c : lines) {
                g.drawString(font, c, left + 10, y, 0xE0E4F0, false);
                y += step;
            }
            if (id.equals("bathtub")) {
                int s = st.getValue(ParkProps.ST);
                g.fill(left + 10, top + 42, left + w - 10, top + 54, 0xFF0B0C10);
                g.fill(left + 11, top + 43, left + 11 + (w - 22) * s / 3, top + 53, 0xFF3A8AD8);
            } else if (id.equals("charging_station")) {
                g.fill(left + 10, top + 42, left + w - 10, top + 54, 0xFF0B0C10);
                g.fill(left + 11, top + 43, left + 11 + (w - 22) * Math.min(100, be.v[0]) / 100, top + 53, 0xFF50D060);
            }
        }
    }
}
