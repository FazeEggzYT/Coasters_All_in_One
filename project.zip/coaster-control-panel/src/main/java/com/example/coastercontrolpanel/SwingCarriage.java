package com.example.coastercontrolpanel;

import com.simibubi.create.AllTags;
import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.pulley.PulleyContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

/** The two moving parts of a Swing Ride, carried by Create's moving-structure system. */
public final class SwingCarriage {
    private SwingCarriage() {
    }

    /** A moving structure that starts at the block it is built from and has nothing that counts as a rope. */
    public static class Part extends PulleyContraption {
        public Part() {
            super(0);
        }

        @Override
        protected boolean isAnchoringBlockAt(BlockPos pos) {
            return false;
        }
    }

    /** The arm (Pivot Head and Arm pieces) has them; the gondola never does. Also true after a world reload. */
    public static boolean isArm(Contraption contraption) {
        for (StructureTemplate.StructureBlockInfo info : contraption.getBlocks().values()) {
            if (info.state().getBlock() instanceof SwingBlocks.PivotBlock || info.state().getBlock() instanceof SwingBlocks.ArmBlock) {
                return true;
            }
        }
        return false;
    }

    /**
     * While a riding part is gathered with "carry everything" on, any block that touches it is attached, except the
     * fixed parts of the ride, unbreakable blocks, natural ground, and anything outside a box around the start block.
     */
    public static final class Carry {
        private static boolean on;
        private static BlockPos start = BlockPos.ZERO;
        private static int horiz;
        private static int up;
        private static int down;

        private Carry() {
        }

        public static void begin(boolean enabled, BlockPos from, int horizReach, int upReach, int downReach) {
            on = enabled;
            start = from;
            horiz = horizReach;
            up = upReach;
            down = downReach;
        }

        public static void end() {
            on = false;
        }

        static boolean takes(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos) {
            if (!on || state.isAir()) {
                return false;
            }
            int dx = Math.abs(pos.getX() - start.getX());
            int dz = Math.abs(pos.getZ() - start.getZ());
            int dy = pos.getY() - start.getY();
            if (dx > horiz || dz > horiz || dy > up || -dy > down) {
                return false;
            }
            net.minecraft.world.level.block.Block b = state.getBlock();
            if (b instanceof DropTowerBlocks.BaseBlock || b instanceof DropTowerBlocks.SectionBlock || b instanceof DropTowerBlocks.ControllerBlock
                    || b instanceof SwingBlocks.BaseBlock || b instanceof SwingBlocks.PivotBlock || b instanceof SwingBlocks.ArmBlock
                    || b instanceof FerrisBlocks.BaseBlock || b instanceof FerrisBlocks.WheelPart
                    || b instanceof SwivelBlocks.BearingBlock || b instanceof TeacupBlocks.BaseBlock || b instanceof TeacupBlocks.PlatterPart) {
                return false;
            }
            if (state.getDestroySpeed(level, pos) < 0.0F
                    || state.is(net.minecraft.tags.BlockTags.DIRT) || state.is(net.minecraft.tags.BlockTags.BASE_STONE_OVERWORLD)
                    || state.is(net.minecraft.tags.BlockTags.SAND)) {
                return false;
            }
            return true;
        }
    }

    /** True for the platter of a Teacup Ride (it has a Platter Hub). */
    public static boolean isPlatter(Contraption contraption) {
        for (StructureTemplate.StructureBlockInfo info : contraption.getBlocks().values()) {
            if (info.state().getBlock() instanceof TeacupBlocks.PlatterHub) {
                return true;
            }
        }
        return false;
    }

    /** True for the wheel of a Ferris Wheel (it has an Axle Hub). Also true after a world reload. */
    public static boolean isWheel(Contraption contraption) {
        for (StructureTemplate.StructureBlockInfo info : contraption.getBlocks().values()) {
            if (info.state().getBlock() instanceof FerrisBlocks.AxleBlock) {
                return true;
            }
        }
        return false;
    }

    private static boolean armPart(BlockState s) {
        return s.getBlock() instanceof SwingBlocks.PivotBlock || s.getBlock() instanceof SwingBlocks.ArmBlock;
    }

    /** Registered once at start: which blocks stick to which when Create gathers a moving structure. */
    public static void registerChecks() {
        BlockMovementChecks.registerAttachedCheck((state, level, pos, direction) -> {
            BlockState other = level.getBlockState(pos.relative(direction));
            if (Carry.takes(state, level, pos)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            if (state.getBlock() instanceof CarouselBlocks.Horse && AllTags.AllBlockTags.SEATS.matches(other)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            if (other.getBlock() instanceof CarouselBlocks.Horse && AllTags.AllBlockTags.SEATS.matches(state)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            if (state.getBlock() instanceof TeacupBlocks.PlatterPart) {
                return other.getBlock() instanceof TeacupBlocks.PlatterPart ? BlockMovementChecks.CheckResult.SUCCESS : BlockMovementChecks.CheckResult.PASS;
            }
            if (state.getBlock() instanceof FerrisBlocks.WheelPart) {
                return other.getBlock() instanceof FerrisBlocks.WheelPart ? BlockMovementChecks.CheckResult.SUCCESS : BlockMovementChecks.CheckResult.PASS;
            }
            if (armPart(state)) {
                return armPart(other) ? BlockMovementChecks.CheckResult.SUCCESS : BlockMovementChecks.CheckResult.PASS;
            }
            boolean gondolaState = SwingBlocks.isGondolaPart(state);
            boolean gondolaOther = SwingBlocks.isGondolaPart(other);
            if (gondolaState && (gondolaOther || AllTags.AllBlockTags.SEATS.matches(other))) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            if (gondolaOther && AllTags.AllBlockTags.SEATS.matches(state)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            return BlockMovementChecks.CheckResult.PASS;
        });
        BlockMovementChecks.registerAttachedCheck((state, level, pos, direction) -> {
            // seats touching a Drop Tower frame are carried with it, too
            if (AllTags.AllBlockTags.SEATS.matches(state) && level.getBlockState(pos.relative(direction)).getBlock() instanceof DropTowerBlocks.FrameBlock) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            return BlockMovementChecks.CheckResult.PASS;
        });
    }
}
