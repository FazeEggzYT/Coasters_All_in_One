package com.example.coastercontrolpanel;

import com.simibubi.create.AllTags;
import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.pulley.PulleyContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

/** The two moving parts of a Swing Ride, carried by Create's moving-structure system. */
public final class SwingCarriage {
    private SwingCarriage() {
    }

    /** A moving structure that starts at the block it is built from and has nothing that counts as a rope. */
    public static class Part extends PulleyContraption {
        public Part() {
            super(0);
        }

        @Override
        protected boolean isAnchoringBlockAt(BlockPos pos) {
            return false;
        }
    }

    /** The arm (Pivot Head and Arm pieces) has them; the gondola never does. Also true after a world reload. */
    public static boolean isArm(Contraption contraption) {
        for (StructureTemplate.StructureBlockInfo info : contraption.getBlocks().values()) {
            if (info.state().getBlock() instanceof SwingBlocks.PivotBlock || info.state().getBlock() instanceof SwingBlocks.ArmBlock) {
                return true;
            }
        }
        return false;
    }

    /** True for the wheel of a Ferris Wheel (it has an Axle Hub). Also true after a world reload. */
    public static boolean isWheel(Contraption contraption) {
        for (StructureTemplate.StructureBlockInfo info : contraption.getBlocks().values()) {
            if (info.state().getBlock() instanceof FerrisBlocks.AxleBlock) {
                return true;
            }
        }
        return false;
    }

    private static boolean armPart(BlockState s) {
        return s.getBlock() instanceof SwingBlocks.PivotBlock || s.getBlock() instanceof SwingBlocks.ArmBlock;
    }

    /** Registered once at start: which blocks stick to which when Create gathers a moving structure. */
    public static void registerChecks() {
        BlockMovementChecks.registerAttachedCheck((state, level, pos, direction) -> {
            BlockState other = level.getBlockState(pos.relative(direction));
            if (state.getBlock() instanceof FerrisBlocks.WheelPart) {
                return other.getBlock() instanceof FerrisBlocks.WheelPart ? BlockMovementChecks.CheckResult.SUCCESS : BlockMovementChecks.CheckResult.PASS;
            }
            if (armPart(state)) {
                return armPart(other) ? BlockMovementChecks.CheckResult.SUCCESS : BlockMovementChecks.CheckResult.PASS;
            }
            boolean gondolaState = SwingBlocks.isGondolaPart(state);
            boolean gondolaOther = SwingBlocks.isGondolaPart(other);
            if (gondolaState && (gondolaOther || AllTags.AllBlockTags.SEATS.matches(other))) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            if (gondolaOther && AllTags.AllBlockTags.SEATS.matches(state)) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            return BlockMovementChecks.CheckResult.PASS;
        });
        BlockMovementChecks.registerAttachedCheck((state, level, pos, direction) -> {
            // seats touching a Drop Tower frame are carried with it, too
            if (AllTags.AllBlockTags.SEATS.matches(state) && level.getBlockState(pos.relative(direction)).getBlock() instanceof DropTowerBlocks.FrameBlock) {
                return BlockMovementChecks.CheckResult.SUCCESS;
            }
            return BlockMovementChecks.CheckResult.PASS;
        });
    }
}
