package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.CoasterControlPanel;
import com.example.coastercontrolpanel.DriveTyre;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Drive Tyre: inside Coasters Simulated's chain-lift placement methods only, a held Drive Tyre counts as a Chain. Optional. */
@Mixin(ItemStack.class)
public abstract class ItemStackChainMixin {
    @Inject(method = "is(Lnet/minecraft/world/item/Item;)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccp$tyreAsChain(Item item, CallbackInfoReturnable<Boolean> cir) {
        if (item == Items.CHAIN && DriveTyre.inScope()) {
            ItemStack self = (ItemStack) (Object) this;
            if (self.getItem() == CoasterControlPanel.DRIVE_TYRE_ITEM.get()) {
                DriveTyre.markHit();
                cir.setReturnValue(true);
            }
        }
    }
}
