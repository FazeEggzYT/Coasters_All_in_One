package com.example.coastercontrolpanel;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.function.Supplier;

/** The seven cooking machines of the Kitchen Pack and what each one makes. */
public enum KitchenKind {
    GRILL("grill", 160, 0, List.of(
            r(() -> CoasterControlPanel.RAW_PATTY.get(), 1, null, 0, () -> CoasterControlPanel.COOKED_PATTY.get(), 1),
            r(() -> CoasterControlPanel.RAW_SAUSAGE.get(), 1, null, 0, () -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1),
            r(() -> Items.BEEF, 1, null, 0, () -> Items.COOKED_BEEF, 1),
            r(() -> Items.PORKCHOP, 1, null, 0, () -> Items.COOKED_PORKCHOP, 1),
            r(() -> Items.CHICKEN, 1, null, 0, () -> Items.COOKED_CHICKEN, 1))),
    FRYER("fryer", 120, 0, List.of(
            r(() -> CoasterControlPanel.POTATO_STRIPS.get(), 1, null, 0, () -> CoasterControlPanel.CHIPS.get(), 1),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, null, 0, () -> CoasterControlPanel.DOUGHNUT.get(), 2))),
    PREP("prep", 40, 0, List.of(
            r(() -> Items.WHEAT, 2, () -> Items.SUGAR, 1, () -> CoasterControlPanel.BUN.get(), 2),
            r(() -> Items.WHEAT, 3, () -> Items.EGG, 1, () -> CoasterControlPanel.DOUGH.get(), 2),
            r(() -> Items.BEEF, 1, null, 0, () -> CoasterControlPanel.RAW_PATTY.get(), 2),
            r(() -> Items.PORKCHOP, 1, null, 0, () -> CoasterControlPanel.RAW_SAUSAGE.get(), 2),
            r(() -> Items.POTATO, 1, null, 0, () -> CoasterControlPanel.POTATO_STRIPS.get(), 3),
            r(() -> CoasterControlPanel.COOKED_PATTY.get(), 1, () -> CoasterControlPanel.BUN.get(), 1, () -> CoasterControlPanel.BURGER.get(), 1),
            r(() -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1, () -> CoasterControlPanel.BUN.get(), 1, () -> CoasterControlPanel.HOT_DOG.get(), 1))),
    OVEN("oven", 200, 0, List.of(
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.BEETROOT, 1, () -> CoasterControlPanel.PIZZA_SLICE.get(), 3),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.COOKED_PORKCHOP, 1, () -> CoasterControlPanel.PIZZA_SLICE.get(), 4),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, null, 0, () -> Items.BREAD, 1),
            r(() -> Items.POTATO, 1, null, 0, () -> Items.BAKED_POTATO, 1))),
    SOFT_SERVE("soft_serve", 100, 0, List.of(
            r(() -> Items.MILK_BUCKET, 1, () -> Items.SUGAR, 1, () -> CoasterControlPanel.ICE_CREAM.get(), 4),
            r(() -> Items.MILK_BUCKET, 1, () -> Items.SWEET_BERRIES, 2, () -> CoasterControlPanel.ICE_CREAM.get(), 4))),
    POPCORN("popcorn", 80, 0, List.of(
            r(() -> Items.WHEAT_SEEDS, 4, () -> Items.SUGAR, 1, () -> CoasterControlPanel.POPCORN_ITEM.get(), 3),
            r(() -> Items.WHEAT_SEEDS, 4, null, 0, () -> CoasterControlPanel.POPCORN_ITEM.get(), 2))),
    DRINKS("drinks", 60, 0, List.of(
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.APPLE, 1, () -> CoasterControlPanel.APPLE_JUICE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.SWEET_BERRIES, 2, () -> CoasterControlPanel.BERRY_FIZZ.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.MELON_SLICE, 2, () -> CoasterControlPanel.MELON_JUICE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.COCOA_BEANS, 2, () -> CoasterControlPanel.COLA.get(), 1)));

    /** One recipe: inputs a (and optionally b) make count of out. */
    public record Recipe(Supplier<Item> a, int ca, Supplier<Item> b, int cb, Supplier<Item> out, int outCount) {
    }

    private static Recipe r(Supplier<Item> a, int ca, Supplier<Item> b, int cb, Supplier<Item> out, int outCount) {
        return new Recipe(a, ca, b, cb, out, outCount);
    }

    public final String id;
    public final int cookTicks;
    public final List<Recipe> recipes;

    KitchenKind(String id, int cookTicks, int unused, List<Recipe> recipes) {
        this.id = id;
        this.cookTicks = cookTicks;
        this.recipes = recipes;
    }

    /** True if this machine uses the item as an ingredient. */
    public boolean accepts(net.minecraft.world.item.ItemStack stack) {
        for (Recipe rec : recipes) {
            if (stack.is(rec.a().get()) || (rec.b() != null && stack.is(rec.b().get()))) {
                return true;
            }
        }
        return false;
    }
}
