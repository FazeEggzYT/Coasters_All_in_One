package com.example.coastercontrolpanel;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.function.Supplier;

/** The seven cooking machines of the Kitchen Pack and what each one makes. */
public enum KitchenKind {
    GRILL("grill", 160, 0, List.of(
            r(() -> CoasterControlPanel.RAW_PATTY.get(), 1, null, 0, () -> CoasterControlPanel.COOKED_PATTY.get(), 1),
            r(() -> CoasterControlPanel.RAW_SAUSAGE.get(), 1, null, 0, () -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1),
            r(() -> Items.BEEF, 1, null, 0, () -> Items.COOKED_BEEF, 1),
            r(() -> Items.PORKCHOP, 1, null, 0, () -> Items.COOKED_PORKCHOP, 1),
            r(() -> Items.CHICKEN, 1, null, 0, () -> Items.COOKED_CHICKEN, 1),
            r(() -> Items.COD, 1, null, 0, () -> Items.COOKED_COD, 1),
            r(() -> Items.SALMON, 1, null, 0, () -> Items.COOKED_SALMON, 1),
            r(() -> Items.MUTTON, 1, null, 0, () -> Items.COOKED_MUTTON, 1),
            r(() -> Items.RABBIT, 1, null, 0, () -> Items.COOKED_RABBIT, 1),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, null, 0, () -> CoasterControlPanel.TORTILLA.get(), 2))),
    FRYER("fryer", 120, 0, List.of(
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.SUGAR, 1, () -> CoasterControlPanel.CHURRO.get(), 2),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1, () -> CoasterControlPanel.CORN_DOG.get(), 1),
            r(() -> Items.CHICKEN, 1, () -> Items.WHEAT, 1, () -> CoasterControlPanel.NUGGETS.get(), 4),
            r(() -> CoasterControlPanel.POTATO_STRIPS.get(), 1, null, 0, () -> CoasterControlPanel.CHIPS.get(), 1),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, null, 0, () -> CoasterControlPanel.DOUGHNUT.get(), 2),
            r(() -> Items.CHICKEN, 1, null, 0, () -> CoasterControlPanel.FRIED_CHICKEN.get(), 1),
            r(() -> Items.COD, 1, null, 0, () -> CoasterControlPanel.FISH_FINGERS.get(), 3),
            r(() -> CoasterControlPanel.TORTILLA.get(), 1, null, 0, () -> CoasterControlPanel.TORTILLA_CHIPS.get(), 3))),
    PREP("prep", 40, 0, List.of(
            r(() -> Items.WHEAT, 2, () -> Items.SUGAR, 1, () -> CoasterControlPanel.BUN.get(), 2),
            r(() -> Items.WHEAT, 3, () -> Items.EGG, 1, () -> CoasterControlPanel.DOUGH.get(), 2),
            r(() -> Items.BEEF, 1, null, 0, () -> CoasterControlPanel.RAW_PATTY.get(), 2),
            r(() -> Items.PORKCHOP, 1, null, 0, () -> CoasterControlPanel.RAW_SAUSAGE.get(), 2),
            r(() -> Items.POTATO, 1, null, 0, () -> CoasterControlPanel.POTATO_STRIPS.get(), 3),
            r(() -> CoasterControlPanel.COOKED_PATTY.get(), 1, () -> CoasterControlPanel.BUN.get(), 1, () -> CoasterControlPanel.BURGER.get(), 1),
            r(() -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1, () -> CoasterControlPanel.BUN.get(), 1, () -> CoasterControlPanel.HOT_DOG.get(), 1),
            r(() -> CoasterControlPanel.BURGER.get(), 1, () -> CoasterControlPanel.CHEESE.get(), 1, () -> CoasterControlPanel.CHEESEBURGER.get(), 1),
            r(() -> Items.CARROT, 1, () -> Items.BEETROOT, 1, () -> CoasterControlPanel.SALAD.get(), 1),
            r(() -> Items.BREAD, 1, () -> Items.COOKED_CHICKEN, 1, () -> CoasterControlPanel.CHICKEN_SANDWICH.get(), 1),
            r(() -> Items.BREAD, 1, () -> Items.COOKED_PORKCHOP, 1, () -> CoasterControlPanel.HAM_SANDWICH.get(), 1),
            r(() -> CoasterControlPanel.TORTILLA.get(), 1, () -> CoasterControlPanel.COOKED_PATTY.get(), 1, () -> CoasterControlPanel.TACO.get(), 1),
            r(() -> CoasterControlPanel.TORTILLA.get(), 1, () -> Items.COOKED_CHICKEN, 1, () -> CoasterControlPanel.BURRITO.get(), 1),
            r(() -> CoasterControlPanel.TORTILLA_CHIPS.get(), 1, () -> CoasterControlPanel.CHEESE.get(), 1, () -> CoasterControlPanel.NACHOS.get(), 1),
            r(() -> Items.APPLE, 1, () -> Items.MELON_SLICE, 1, () -> CoasterControlPanel.FRUIT_CUP.get(), 2),
            r(() -> Items.COOKED_COD, 1, () -> CoasterControlPanel.CHIPS.get(), 1, () -> CoasterControlPanel.FISH_AND_CHIPS.get(), 1),
            r(() -> Items.BAKED_POTATO, 1, () -> CoasterControlPanel.CHEESE.get(), 1, () -> CoasterControlPanel.LOADED_POTATO.get(), 1),
            r(() -> CoasterControlPanel.ICE_CREAM.get(), 1, () -> Items.COCOA_BEANS, 1, () -> CoasterControlPanel.SUNDAE.get(), 1),
            r(() -> Items.MILK_BUCKET, 1, null, 0, () -> CoasterControlPanel.CHEESE.get(), 4))),
    OVEN("oven", 200, 0, List.of(
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.BEETROOT, 1, () -> CoasterControlPanel.PIZZA_SLICE.get(), 3),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.COOKED_PORKCHOP, 1, () -> CoasterControlPanel.PIZZA_SLICE.get(), 4),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> CoasterControlPanel.CHEESE.get(), 1, () -> CoasterControlPanel.CHEESE_PIZZA.get(), 4),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.APPLE, 1, () -> CoasterControlPanel.APPLE_PIE.get(), 3),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.COCOA_BEANS, 1, () -> CoasterControlPanel.CHOC_COOKIE.get(), 4),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.SUGAR, 1, () -> CoasterControlPanel.CAKE_SLICE.get(), 3),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.SWEET_BERRIES, 1, () -> CoasterControlPanel.MUFFIN.get(), 2),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> CoasterControlPanel.COOKED_SAUSAGE.get(), 1, () -> CoasterControlPanel.SAUSAGE_ROLL.get(), 2),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.BAKED_POTATO, 1, () -> CoasterControlPanel.PASTY.get(), 2),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, () -> Items.WHEAT_SEEDS, 1, () -> CoasterControlPanel.PRETZEL.get(), 2),
            r(() -> CoasterControlPanel.DOUGH.get(), 1, null, 0, () -> Items.BREAD, 1),
            r(() -> Items.POTATO, 1, null, 0, () -> Items.BAKED_POTATO, 1))),
    SOFT_SERVE("soft_serve", 100, 0, List.of(
            r(() -> Items.MILK_BUCKET, 1, () -> Items.SUGAR, 1, () -> CoasterControlPanel.ICE_CREAM.get(), 4),
            r(() -> Items.MILK_BUCKET, 1, () -> Items.SWEET_BERRIES, 2, () -> CoasterControlPanel.ICE_CREAM.get(), 4),
            r(() -> Items.MILK_BUCKET, 1, () -> Items.COCOA_BEANS, 2, () -> CoasterControlPanel.CHOC_ICE_CREAM.get(), 4),
            r(() -> Items.MILK_BUCKET, 1, () -> Items.HONEY_BOTTLE, 1, () -> CoasterControlPanel.FROZEN_YOGURT.get(), 4),
            r(() -> Items.SNOWBALL, 2, () -> Items.SWEET_BERRIES, 1, () -> CoasterControlPanel.ICE_LOLLY.get(), 2))),
    POPCORN("popcorn", 80, 0, List.of(
            r(() -> Items.WHEAT_SEEDS, 4, () -> Items.SUGAR, 1, () -> CoasterControlPanel.POPCORN_ITEM.get(), 3),
            r(() -> Items.WHEAT_SEEDS, 4, () -> Items.HONEY_BOTTLE, 1, () -> CoasterControlPanel.CARAMEL_POPCORN.get(), 3),
            r(() -> Items.WHEAT_SEEDS, 4, () -> Items.COCOA_BEANS, 1, () -> CoasterControlPanel.CHOCOLATE_POPCORN.get(), 3),
            r(() -> Items.WHEAT_SEEDS, 4, null, 0, () -> CoasterControlPanel.POPCORN_ITEM.get(), 2),
            r(() -> Items.SUGAR, 2, null, 0, () -> CoasterControlPanel.CANDY_FLOSS.get(), 1))),
    DRINKS("drinks", 60, 0, List.of(
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.APPLE, 1, () -> CoasterControlPanel.APPLE_JUICE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.SWEET_BERRIES, 2, () -> CoasterControlPanel.BERRY_FIZZ.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.MELON_SLICE, 2, () -> CoasterControlPanel.MELON_JUICE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.COCOA_BEANS, 2, () -> CoasterControlPanel.COLA.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> CoasterControlPanel.ICE_CREAM.get(), 1, () -> CoasterControlPanel.MILKSHAKE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.MILK_BUCKET, 1, () -> CoasterControlPanel.HOT_CHOCOLATE.get(), 2),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.CARROT, 2, () -> CoasterControlPanel.CARROT_JUICE.get(), 1),
            r(() -> Items.GLASS_BOTTLE, 1, () -> Items.GLOW_BERRIES, 2, () -> CoasterControlPanel.GLOW_SMOOTHIE.get(), 1)));

    /** One recipe: inputs a (and optionally b) make count of out. */
    public record Recipe(Supplier<Item> a, int ca, Supplier<Item> b, int cb, Supplier<Item> out, int outCount) {
    }

    private static Recipe r(Supplier<Item> a, int ca, Supplier<Item> b, int cb, Supplier<Item> out, int outCount) {
        return new Recipe(a, ca, b, cb, out, outCount);
    }

    public final String id;
    public final int cookTicks;
    public final List<Recipe> recipes;

    KitchenKind(String id, int cookTicks, int unused, List<Recipe> recipes) {
        this.id = id;
        this.cookTicks = cookTicks;
        this.recipes = recipes;
    }

    /** True if this machine uses the item as an ingredient. */
    public boolean accepts(net.minecraft.world.item.ItemStack stack) {
        for (Recipe rec : recipes) {
            if (stack.is(rec.a().get()) || (rec.b() != null && stack.is(rec.b().get()))) {
                return true;
            }
        }
        return false;
    }
}
