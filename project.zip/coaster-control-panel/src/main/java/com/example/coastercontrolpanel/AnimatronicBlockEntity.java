package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.animatronics.AnimatronicType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** What an animatronic is set to: which character, which of its animations, loop or redstone, and how fast. */
public class AnimatronicBlockEntity extends BlockEntity {
    public static final float[] SPEEDS = {0.5F, 1.0F, 2.0F};

    private int character;
    private int animation;
    private boolean redstoneMode;
    private int speed = 1;

    /** Set by an Animation Controller: -1 not driven, -2 driven but resting, otherwise the index of the animation to play. Not saved. */
    private int driven = -1;
    private int lastDriven = -1;

    // client only: animation clock, kept so the figure moves smoothly and eases out when it stops
    public float time;
    public float prevTime;
    public float blend;
    public float prevBlend;

    public AnimatronicBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.ANIMATRONIC_BE.get(), pos, state);
    }

    public int character() {
        return character;
    }

    public AnimatronicType type() {
        return AnimatronicType.byIndex(character);
    }

    public int animation() {
        return animation;
    }

    public boolean redstoneMode() {
        return redstoneMode;
    }

    public int speed() {
        return speed;
    }

    public int driven() {
        return driven;
    }

    public void setDriven(int value) {
        if (value != driven) {
            driven = value;
            if (level != null) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_ALL);
            }
        }
    }

    public boolean active() {
        if (driven == -2) {
            return false;
        }
        if (driven >= 0) {
            return true;
        }
        return !redstoneMode || getBlockState().getValue(AnimatronicBlock.POWERED);
    }

    public void setAll(int character, int animation, boolean redstoneMode, int speed) {
        this.character = Math.floorMod(character, AnimatronicType.values().length);
        this.animation = Math.floorMod(animation, type().animations.length);
        this.redstoneMode = redstoneMode;
        this.speed = Math.floorMod(speed, SPEEDS.length);
        changed();
    }

    private void changed() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_ALL);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Character", character);
        tag.putInt("Animation", animation);
        tag.putBoolean("Redstone", redstoneMode);
        tag.putInt("Speed", speed);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        character = Math.floorMod(tag.getInt("Character"), AnimatronicType.values().length);
        animation = Math.floorMod(tag.getInt("Animation"), AnimatronicType.byIndex(character).animations.length);
        redstoneMode = tag.getBoolean("Redstone");
        speed = Math.floorMod(tag.contains("Speed") ? tag.getInt("Speed") : 1, SPEEDS.length);
        driven = tag.contains("Driven") ? tag.getInt("Driven") : -1;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = saveWithoutMetadata(registries);
        tag.putInt("Driven", driven);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** The figure stands above the block and swings its arms, so it needs more room than the block itself. */
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition).inflate(2.5, 0, 2.5).expandTowards(0, 3.5, 0);
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, AnimatronicBlockEntity be) {
        be.prevTime = be.time;
        be.prevBlend = be.blend;
        if (be.driven != be.lastDriven) {
            be.lastDriven = be.driven;
            be.time = 0.0F;
            be.prevTime = 0.0F;
            if (be.driven >= 0) {
                be.blend = 0.0F;
                be.prevBlend = 0.0F;
            }
        }
        boolean on = be.active();
        float step = be.driven != -1 ? 0.2F : 0.1F;
        if (on || be.blend > 0.0F) {
            be.time += be.driven >= 0 ? 1.0F : SPEEDS[be.speed];
        }
        be.blend = on ? Math.min(1.0F, be.blend + step) : Math.max(0.0F, be.blend - step);
    }
}
