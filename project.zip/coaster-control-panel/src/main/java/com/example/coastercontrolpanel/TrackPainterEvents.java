package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

import java.util.List;

/**
 * The Track Painter paints Coasters Simulated track in a colour for its purpose (launch, lift, brake...).
 * Sneak + right-click in the air: next colour. Right-click an anchor, then another anchor:
 * every curve between them is painted.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID)
public class TrackPainterEvents {
    private static int presetOf(ItemStack stack) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return Math.floorMod(tag.getInt("Preset"), TrackPresets.ALL.size());
    }

    private static Component presetName(int index) {
        return Component.translatable("track_preset.coastercontrolpanel." + TrackPresets.ALL.get(index).key());
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        ItemStack stack = event.getItemStack();
        if (event.getHand() != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.TRACK_PAINTER_ITEM.get())
                || !event.getEntity().isShiftKeyDown()) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            return;
        }
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        int next = (presetOf(stack) + 1) % TrackPresets.ALL.size();
        tag.putInt("Preset", next);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        event.getEntity().displayClientMessage(
                Component.translatable("message.coastercontrolpanel.painter_mode", presetName(next)), true);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (event.getHand() != InteractionHand.MAIN_HAND || !stack.is(CoasterControlPanel.TRACK_PAINTER_ITEM.get())) {
            return;
        }
        BlockPos pos = event.getPos();
        Level level = event.getLevel();
        if (!AnchorTrack.isAnchor(level.getBlockEntity(pos))) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (level.isClientSide) {
            return;
        }
        Player player = event.getEntity();
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        if (!tag.contains("PaintFrom")) {
            tag.putLong("PaintFrom", pos.asLong());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_from",
                    presetName(presetOf(stack))), true);
            return;
        }
        BlockPos from = BlockPos.of(tag.getLong("PaintFrom"));
        if (from.equals(pos)) {
            tag.remove("PaintFrom");
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_cancel"), true);
            return;
        }
        tag.remove("PaintFrom");
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));

        TrackPresets.Preset preset = TrackPresets.ALL.get(presetOf(stack));
        List<BlockPos> route = AnchorTrack.route(level, from, pos);
        int rail = AnchorTrack.dyeRgb(preset.rail());
        int beam = AnchorTrack.dyeRgb(preset.beam());
        int painted = 0;
        for (int i = 0; i + 1 < route.size(); i++) {
            boolean a = AnchorTrack.tint(level, route.get(i), route.get(i + 1), rail, beam);
            boolean b = AnchorTrack.tint(level, route.get(i + 1), route.get(i), rail, beam);
            if (a || b) {
                painted++;
            }
        }
        if (painted == 0) {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_none"), true);
        } else {
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.painter_done",
                    painted, presetName(presetOf(stack))), true);
        }
    }
}
