package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the Announcer settings, and whether to play a test sound. */
public record AnnouncerConfigPacket(BlockPos pos, int mode, int sound, int volume, int pitch, int repeat,
                                    int delay, boolean test) implements CustomPacketPayload {
    public static final Type<AnnouncerConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "announcer_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AnnouncerConfigPacket> CODEC =
            StreamCodec.of(AnnouncerConfigPacket::write, AnnouncerConfigPacket::read);

    private static void write(RegistryFriendlyByteBuf buf, AnnouncerConfigPacket p) {
        buf.writeBlockPos(p.pos);
        buf.writeVarInt(p.mode);
        buf.writeVarInt(p.sound);
        buf.writeVarInt(p.volume);
        buf.writeVarInt(p.pitch);
        buf.writeVarInt(p.repeat);
        buf.writeVarInt(p.delay);
        buf.writeBoolean(p.test);
    }

    private static AnnouncerConfigPacket read(RegistryFriendlyByteBuf buf) {
        return new AnnouncerConfigPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(AnnouncerConfigPacket packet, IPayloadContext context) {
        AnnouncerBlockEntity announcer = AnnouncerBlockEntity.lookup(context.player(), packet.pos);
        if (announcer == null) {
            return;
        }
        announcer.applyConfig(packet.mode, packet.sound, packet.volume, packet.pitch, packet.repeat, packet.delay);
        if (packet.test) {
            announcer.startPlayback();
        }
    }
}
