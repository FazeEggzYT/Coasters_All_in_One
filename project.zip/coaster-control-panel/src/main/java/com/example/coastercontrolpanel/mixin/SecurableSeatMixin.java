package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.SeatTimerAccess;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the Seat Timer to the seat of "Create: Coaster Seats" (securable_seat).
 * In that mod a signal LOCKS the seat (restraint down), so a powered change means "close"
 * and an unpowered change means "open".
 * updateState() only runs when the signal changes, so we also re-check it every server tick
 * while a change is waiting.
 */
@Mixin(targets = "net.villagerzock.createcoasterseats.block.entity.SecurableSeatBlockEntity", remap = false)
public abstract class SecurableSeatMixin implements SeatTimerAccess {
    @Shadow
    public abstract boolean isPowered();

    @Shadow
    public abstract void updateState();

    @Unique
    private int coastersaio$open = 0;
    @Unique
    private int coastersaio$close = 0;
    @Unique
    private long coastersaio$since = -1L;
    @Unique
    private boolean coastersaio$target = false;

    @Override
    public int seatTimerOpenDelay() {
        return coastersaio$open;
    }

    @Override
    public int seatTimerCloseDelay() {
        return coastersaio$close;
    }

    @Override
    public void seatTimerSet(int openSeconds, int closeSeconds) {
        coastersaio$open = Math.max(0, Math.min(60, openSeconds));
        coastersaio$close = Math.max(0, Math.min(60, closeSeconds));
        coastersaio$since = -1L;
        ((BlockEntity) (Object) this).setChanged();
    }

    @Inject(method = "updateState", at = @At("HEAD"), cancellable = true)
    private void coastersaio$delay(CallbackInfo ci) {
        BlockEntity self = (BlockEntity) (Object) this;
        Level level = self.getLevel();
        if (level == null || level.isClientSide) {
            return;
        }
        BlockState state = self.getBlockState();
        if (!state.hasProperty(BlockStateProperties.POWERED)) {
            return;
        }
        boolean want = isPowered();
        if (want == state.getValue(BlockStateProperties.POWERED)) {
            coastersaio$since = -1L;
            return;
        }
        int delay = want ? coastersaio$close : coastersaio$open;
        if (delay <= 0) {
            coastersaio$since = -1L;
            return;
        }
        long now = level.getGameTime();
        if (coastersaio$since < 0 || coastersaio$target != want) {
            coastersaio$since = now;
            coastersaio$target = want;
        }
        if (now - coastersaio$since >= delay * 20L) {
            coastersaio$since = -1L;
            return; // time is up: let the seat change state
        }
        ci.cancel();
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void coastersaio$tick(CallbackInfo ci) {
        if (coastersaio$since >= 0) {
            Level level = ((BlockEntity) (Object) this).getLevel();
            if (level != null && !level.isClientSide) {
                updateState();
            }
        }
    }

    @Override
    public void seatTimerLoad(int openSeconds, int closeSeconds) {
        coastersaio$open = openSeconds;
        coastersaio$close = closeSeconds;
        coastersaio$since = -1L;
    }
}
