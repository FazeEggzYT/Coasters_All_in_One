package com.example.coastercontrolpanel;

import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Block Run: works out whether the block ahead of a Block Run is occupied. The block ahead is the track from the end
 * of this Block Run to the end of the next Block Run, found by walking the anchor curves. Answers are cached for a
 * few ticks per Block Run, so a long train costs almost nothing.
 */
public final class BlockSections {
    private static final int CACHE_TICKS = 4;
    private static final double RADIUS = 3.0;
    private static final int MAX_STEPS = 300;

    private record Key(Object dimension, long pos, int dir) {
    }

    private record Result(long tick, boolean blocked) {
    }

    private static final Map<Key, Result> CACHE = new ConcurrentHashMap<>();
    private static int logs;

    private BlockSections() {
    }

    /**
     * @param anchorPos the Block Run's start anchor
     * @param dir       +1 = travelling from the first anchor to the second, -1 = the other way
     */
    public static boolean blocked(Level level, BlockPos anchorPos, BrakeSettings c, int dir) {
        if (!CartScanner.isAvailable()) {
            return false;
        }
        long now = level.getGameTime();
        Key key = new Key(level.dimension(), anchorPos.asLong(), dir);
        Result r = CACHE.get(key);
        if (r != null && now - r.tick() < CACHE_TICKS && now >= r.tick()) {
            return r.blocked();
        }
        boolean b;
        try {
            b = compute(level, anchorPos, c, dir);
        } catch (Throwable t) {
            if (logs++ < 5) {
                CoasterControlPanel.LOGGER.warn("Block Run {}: could not check the block ahead: {}", anchorPos, t.toString());
            }
            b = false;
        }
        CACHE.put(key, new Result(now, b));
        if (CACHE.size() > 2000) {
            CACHE.clear();
        }
        return b;
    }

    private static boolean compute(Level level, BlockPos start, BrakeSettings c, int dir) {
        BlockEntity startBe = AnchorTrack.loadedAnchor(level, start);
        if (startBe == null) {
            return false;
        }
        BlockPos end = BrakeController.endOfAnchor(startBe);
        if (end == null) {
            return false;
        }
        // Where we leave this run, and the two anchors of this run (never walked back through)
        BlockPos origin = dir > 0 ? end : start;
        Set<BlockPos> own = new HashSet<>();
        own.add(start);
        own.add(end);

        // Breadth-first walk away from this run until a Block Run is found.
        Map<BlockPos, BlockPos> parent = new HashMap<>();
        Map<BlockPos, Double> dist = new HashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        parent.put(origin, origin);
        dist.put(origin, 0.0);
        queue.add(origin);
        BlockPos nextStart = null;
        int steps = 0;
        while (!queue.isEmpty() && steps++ < MAX_STEPS) {
            BlockPos cur = queue.poll();
            double d = dist.get(cur);
            if (!cur.equals(origin) && !own.contains(cur)) {
                BlockEntity be = level.getBlockEntity(cur);
                if (be instanceof DriveTyre.Holder h && h.ccp$brake() != null && h.ccp$brake().block) {
                    nextStart = cur;
                    break;
                }
            }
            BlockEntity be = AnchorTrack.loadedAnchor(level, cur);
            if (be == null) {
                continue;
            }
            for (Map.Entry<BlockPos, BezierConnection> e : AnchorTrack.peers(be).entrySet()) {
                BlockPos next = e.getKey();
                if (own.contains(next) || parent.containsKey(next)) {
                    continue;
                }
                double nd = d + (e.getValue() == null ? 8.0 : e.getValue().getLength());
                if (nd > c.blockRange) {
                    continue;
                }
                parent.put(next, cur);
                dist.put(next, nd);
                queue.add(next);
            }
        }
        if (nextStart == null) {
            return c.blockNoNext == 1;
        }
        BlockEntity nextBe = AnchorTrack.loadedAnchor(level, nextStart);
        BlockPos nextEnd = nextBe == null ? null : BrakeController.endOfAnchor(nextBe);

        // The next Block Run's own strip counts as occupied while a train sits on it.
        if (BrakeController.occupied(level, nextStart)) {
            return true;
        }
        List<BlockPos> route = new ArrayList<>();
        for (BlockPos p = nextStart; ; p = parent.get(p)) {
            route.add(0, p);
            if (p.equals(origin)) {
                break;
            }
        }
        List<Vec3> points = new ArrayList<>();
        if (c.blockDetect == 1) {
            if (nextEnd != null) {
                points = AnchorTrack.sample(level, nextStart, nextEnd);
            }
        } else {
            for (int i = 0; i + 1 < route.size(); i++) {
                points.addAll(AnchorTrack.sample(level, route.get(i), route.get(i + 1)));
            }
            if (nextEnd != null) {
                points.addAll(AnchorTrack.sample(level, nextStart, nextEnd));
            }
            // the first stretch is where the train that is leaving this run still is: not a blocker
            int skip = (int) Math.min(points.size(), Math.ceil(c.blockSkip));
            points = new ArrayList<>(points.subList(skip, points.size()));
        }
        return !points.isEmpty() && CartScanner.anyCartNear(level, points, RADIUS);
    }
}
