package com.example.coastercontrolpanel;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * Mouse mode for the operator panel. The world keeps running, and WASD / jump / sneak / sprint
 * still move you, so you can click the panel while walking around.
 */
public class OperatorScreen extends Screen {
    private final BlockPos pos;
    private int heldRow = -1;

    public OperatorScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.title"));
        this.pos = pos;
    }

    @Nullable
    private PanelBlockEntity panel() {
        if (minecraft == null || minecraft.level == null) {
            return null;
        }
        return minecraft.level.getBlockEntity(pos) instanceof PanelBlockEntity p ? p : null;
    }

    private int panelX() {
        return 8;
    }

    private int panelY() {
        return height - 8 - PanelRenderer.height(panel());
    }

    private int rowAt(double mx, double my) {
        return PanelRenderer.hit(panel(), panelX(), panelY(), mx, my);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur: the player must keep seeing the ride. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void tick() {
        if (panel() == null) {
            onClose();
            return;
        }
        // Keep walking: screens normally stop the movement keys from working.
        if (minecraft != null) {
            Options o = minecraft.options;
            long window = minecraft.getWindow().getWindow();
            KeyMapping[] moves = {o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keyShift, o.keySprint};
            for (KeyMapping k : moves) {
                if (k.getKey().getType() == InputConstants.Type.KEYSYM) {
                    k.setDown(InputConstants.isKeyDown(window, k.getKey().getValue()));
                }
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        PanelBlockEntity p = panel();
        if (p == null) {
            return;
        }
        PanelRenderer.draw(g, font, p, panelX(), panelY(), heldRow,
                Component.translatable("gui.coastercontrolpanel.operator_hint"));
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int row = rowAt(mouseX, mouseY);
            if (row >= 0) {
                heldRow = row;
                PacketDistributor.sendToServer(new ButtonPacket(pos, row, true));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && heldRow >= 0) {
            PacketDistributor.sendToServer(new ButtonPacket(pos, heldRow, false));
            heldRow = -1;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClientKeys.MOUSE.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        if (heldRow >= 0) {
            PacketDistributor.sendToServer(new ButtonPacket(pos, heldRow, false));
            heldRow = -1;
        }
        KeyMapping.setAll();
        super.removed();
    }
}
