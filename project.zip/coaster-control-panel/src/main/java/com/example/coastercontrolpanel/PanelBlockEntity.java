package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Holds the six rows of the panel.
 * Row r uses slots r*4+0/1 as the INPUT frequency pair (signal coming in, drives the lamp)
 * and slots r*4+2/3 as the OUTPUT frequency pair (signal the button sends out).
 */
public class PanelBlockEntity extends BlockEntity {
    public static final int ROWS = 6;
    /** Rows that stay on until pressed again: Restraints and E-STOP. The rest send a short pulse. */
    private static final boolean[] TOGGLE = {false, false, true, true, false, false};
    private static final int PULSE_TICKS = 20;

    private final SimpleContainer frequencies = new SimpleContainer(ROWS * 4);
    private final boolean[] outputOn = new boolean[ROWS];
    private final int[] pulse = new int[ROWS];
    private final int[] received = new int[ROWS];
    private final Link[] inLinks = new Link[ROWS];
    private final Link[] outLinks = new Link[ROWS];
    private boolean loading = false;
    private boolean registered = false;

    public PanelBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.PANEL_BE.get(), pos, state);
        for (int i = 0; i < ROWS; i++) {
            inLinks[i] = new Link(i, false);
            outLinks[i] = new Link(i, true);
        }
        frequencies.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLinks();
                    registerLinks();
                }
            }
        });
    }

    public SimpleContainer getFrequencies() {
        return frequencies;
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLinks();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLinks();
    }

    @Override
    public void setRemoved() {
        unregisterLinks();
        super.setRemoved();
    }

    // ---------------------------------------------------------------- redstone links

    private void registerLinks() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        for (int r = 0; r < ROWS; r++) {
            setupLink(inLinks[r], r * 4, r * 4 + 1);
            setupLink(outLinks[r], r * 4 + 2, r * 4 + 3);
        }
        for (int r = 0; r < ROWS; r++) {
            if (inLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, inLinks[r]);
            }
            if (outLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, outLinks[r]);
            }
        }
        for (int r = 0; r < ROWS; r++) {
            received[r] = 0;
            if (inLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, inLinks[r]);
            }
            if (outLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, outLinks[r]);
            }
        }
    }

    private void setupLink(Link link, int slotA, int slotB) {
        ItemStack a = frequencies.getItem(slotA);
        ItemStack b = frequencies.getItem(slotB);
        link.alive = !(a.isEmpty() && b.isEmpty());
        link.key = Couple.create(Frequency.of(a), Frequency.of(b));
    }

    private void unregisterLinks() {
        if (!registered) {
            return;
        }
        registered = false;
        for (int r = 0; r < ROWS; r++) {
            if (level != null) {
                if (inLinks[r].alive) {
                    Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, inLinks[r]);
                }
                if (outLinks[r].alive) {
                    Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, outLinks[r]);
                }
            }
            inLinks[r].alive = false;
            outLinks[r].alive = false;
            received[r] = 0;
        }
    }

    // ---------------------------------------------------------------- buttons and lamps

    public void press(int row, Player player) {
        if (level == null || level.isClientSide || row < 0 || row >= ROWS) {
            return;
        }
        Component name = Component.translatable("gui.coastercontrolpanel.row." + row);
        if (TOGGLE[row]) {
            outputOn[row] = !outputOn[row];
            player.displayClientMessage(Component.translatable(
                    outputOn[row] ? "message.coastercontrolpanel.on" : "message.coastercontrolpanel.off", name), true);
        } else {
            outputOn[row] = true;
            pulse[row] = PULSE_TICKS;
            player.displayClientMessage(Component.translatable("message.coastercontrolpanel.pressed", name), true);
        }
        pushOutput(row);
        refreshLamps();
        setChanged();
    }

    private void pushOutput(int row) {
        if (level != null && !level.isClientSide && outLinks[row].alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, outLinks[row]);
        }
    }

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int r = 0; r < ROWS; r++) {
            if (!TOGGLE[r] && pulse[r] > 0) {
                pulse[r]--;
                if (pulse[r] == 0) {
                    outputOn[r] = false;
                    pushOutput(r);
                }
            }
        }
        refreshLamps();
    }

    private boolean lampOn(int row) {
        boolean out;
        if (TOGGLE[row]) {
            out = outputOn[row];
        } else {
            // Pulse rows blink while the pulse runs.
            out = pulse[row] > 0 && (pulse[row] / 4) % 2 == 1;
        }
        return out || received[row] > 0;
    }

    private void refreshLamps() {
        if (level == null) {
            return;
        }
        BlockState state = getBlockState();
        BlockState updated = state;
        for (int r = 0; r < ROWS; r++) {
            updated = updated.setValue(PanelBlock.LIT[r], lampOn(r));
        }
        if (updated != state) {
            level.setBlock(worldPosition, updated, 3);
        }
    }

    // ---------------------------------------------------------------- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(ROWS * 4, ItemStack.EMPTY);
        for (int i = 0; i < list.size(); i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        int mask = 0;
        for (int r = 0; r < ROWS; r++) {
            if (outputOn[r] && TOGGLE[r]) {
                mask |= 1 << r;
            }
        }
        tag.putInt("ToggleMask", mask);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(ROWS * 4, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < list.size(); i++) {
            frequencies.setItem(i, list.get(i));
        }
        int mask = tag.getInt("ToggleMask");
        for (int r = 0; r < ROWS; r++) {
            outputOn[r] = TOGGLE[r] && (mask & (1 << r)) != 0;
        }
        loading = false;
    }

    // ---------------------------------------------------------------- a single Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private final int row;
        private final boolean transmitter;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int row, boolean transmitter) {
            this.row = row;
            this.transmitter = transmitter;
        }

        @Override
        public int getTransmittedStrength() {
            return transmitter && outputOn[row] ? 15 : 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            if (!transmitter) {
                received[row] = power;
            }
        }

        @Override
        public boolean isListening() {
            return !transmitter;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
