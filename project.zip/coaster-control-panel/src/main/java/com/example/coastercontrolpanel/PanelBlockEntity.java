package com.example.coastercontrolpanel;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler.Frequency;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Holds the eight rows of the panel.
 * Row r: ghost slot r*2 = INPUT link (drives the lamp), ghost slot r*2+1 = OUTPUT link (what the button sends).
 */
public class PanelBlockEntity extends BlockEntity {
    public static final int ROWS = 8;
    public static final int HOLD = 0;
    public static final int TOGGLE = 1;
    public static final int TIMED = 2;

    /** Button colours: green, red, yellow, blue, orange. */
    public static final int[] COLORS = {0xFF3CC85A, 0xFFD22A2A, 0xFFE6BE28, 0xFF3C78DC, 0xFFE67820};
    public static final String[] COLOR_NAMES = {"Grn", "Red", "Yel", "Blu", "Org"};

    private static final String[] DEFAULT_NAMES = {"Station 1", "Station 2", "Restraints", "E-STOP", "Entrance", "Exit", "", ""};
    private static final int[] DEFAULT_MODES = {TIMED, TIMED, TOGGLE, TOGGLE, HOLD, HOLD, HOLD, HOLD};
    private static final int[] DEFAULT_COLORS = {3, 3, 2, 1, 0, 4, 3, 3};

    private final SimpleContainer frequencies = new SimpleContainer(ROWS * 2);
    private final String[] names = new String[ROWS];
    private final int[] modes = new int[ROWS];
    private final int[] seconds = new int[ROWS];
    private final int[] colors = new int[ROWS];
    private String rideName = "";

    private final boolean[] outputOn = new boolean[ROWS];
    private final int[] timer = new int[ROWS];
    private final int[] received = new int[ROWS];
    private int lampMask = 0;

    private final Link[] inLinks = new Link[ROWS];
    private final Link[] outLinks = new Link[ROWS];
    private boolean loading = false;
    private boolean registered = false;

    public PanelBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.PANEL_BE.get(), pos, state);
        for (int i = 0; i < ROWS; i++) {
            names[i] = DEFAULT_NAMES[i];
            modes[i] = DEFAULT_MODES[i];
            colors[i] = DEFAULT_COLORS[i];
            seconds[i] = 5;
            inLinks[i] = new Link(i, false);
            outLinks[i] = new Link(i, true);
        }
        frequencies.addListener(c -> {
            if (!loading) {
                setChanged();
                if (level != null && !level.isClientSide) {
                    unregisterLinks();
                    registerLinks();
                }
            }
        });
    }

    public SimpleContainer getFrequencies() {
        return frequencies;
    }

    // ---------------------------------------------------------------- getters for the screens

    public String getName(int row) {
        return names[row];
    }

    public int getMode(int row) {
        return modes[row];
    }

    public int getSeconds(int row) {
        return seconds[row];
    }

    public int getColor(int row) {
        return colors[row];
    }

    public String getRideName() {
        return rideName;
    }

    public boolean isLampOn(int row) {
        return (lampMask & (1 << row)) != 0;
    }

    @Nullable
    public static PanelBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 2304.0) {
            return null;
        }
        BlockEntity be = player.level().getBlockEntity(pos);
        return be instanceof PanelBlockEntity panel ? panel : null;
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) {
            registerLinks();
        }
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        unregisterLinks();
    }

    @Override
    public void setRemoved() {
        unregisterLinks();
        super.setRemoved();
    }

    // ---------------------------------------------------------------- redstone links

    private void registerLinks() {
        if (level == null || level.isClientSide || registered) {
            return;
        }
        registered = true;
        for (int r = 0; r < ROWS; r++) {
            setupLink(inLinks[r], r * 2);
            setupLink(outLinks[r], r * 2 + 1);
        }
        for (int r = 0; r < ROWS; r++) {
            if (inLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, inLinks[r]);
            }
            if (outLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, outLinks[r]);
            }
        }
        for (int r = 0; r < ROWS; r++) {
            received[r] = 0;
            if (inLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, inLinks[r]);
            }
            if (outLinks[r].alive) {
                Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, outLinks[r]);
            }
        }
    }

    private void setupLink(Link link, int slot) {
        ItemStack stack = frequencies.getItem(slot);
        link.alive = !stack.isEmpty();
        link.key = Couple.create(Frequency.of(stack), Frequency.EMPTY);
    }

    private void unregisterLinks() {
        if (!registered) {
            return;
        }
        registered = false;
        for (int r = 0; r < ROWS; r++) {
            if (level != null) {
                if (inLinks[r].alive) {
                    Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, inLinks[r]);
                }
                if (outLinks[r].alive) {
                    Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, outLinks[r]);
                }
            }
            inLinks[r].alive = false;
            outLinks[r].alive = false;
            received[r] = 0;
        }
    }

    private void pushOutput(int row) {
        if (level != null && !level.isClientSide && outLinks[row].alive) {
            Create.REDSTONE_LINK_NETWORK_HANDLER.updateNetworkOf(level, outLinks[row]);
        }
    }

    // ---------------------------------------------------------------- buttons

    private void say(Player player, Component message) {
        player.displayClientMessage(message, true);
    }

    public void buttonDown(int row, Player player) {
        if (level == null || level.isClientSide || row < 0 || row >= ROWS || names[row].isEmpty()) {
            return;
        }
        Component name = Component.literal(names[row]);
        switch (modes[row]) {
            case TOGGLE -> {
                outputOn[row] = !outputOn[row];
                if (isEstop(row) && outputOn[row]) {
                    cancelTimed();
                }
                say(player, Component.translatable(
                        outputOn[row] ? "message.coastercontrolpanel.on" : "message.coastercontrolpanel.off", name));
            }
            case TIMED -> {
                if (timer[row] > 0) {
                    return;
                }
                // Only an active E-STOP (any row named E-STOP) blocks timed buttons. Restraints are optional.
                if (estopActive()) {
                    say(player, Component.translatable("message.coastercontrolpanel.estop_active"));
                    return;
                }
                outputOn[row] = true;
                timer[row] = Math.max(1, seconds[row]) * 20;
                say(player, Component.translatable("message.coastercontrolpanel.timed", name, seconds[row]));
            }
            default -> outputOn[row] = true;
        }
        pushOutput(row);
        refreshLamps();
        setChanged();
    }

    public void buttonUp(int row) {
        if (level == null || level.isClientSide || row < 0 || row >= ROWS) {
            return;
        }
        if (modes[row] == HOLD && outputOn[row]) {
            outputOn[row] = false;
            pushOutput(row);
            refreshLamps();
            setChanged();
        }
    }

    /** A row is the emergency stop when it is named E-STOP / ESTOP / Emergency Stop, wherever it sits. */
    private boolean isEstop(int row) {
        String n = names[row].toLowerCase().replaceAll("[^a-z0-9]", "");
        return n.equals("estop") || n.equals("emergencystop");
    }

    private boolean estopActive() {
        for (int r = 0; r < ROWS; r++) {
            if (modes[r] == TOGGLE && outputOn[r] && isEstop(r)) {
                return true;
            }
        }
        return false;
    }

    private void cancelTimed() {
        for (int r = 0; r < ROWS; r++) {
            if (modes[r] == TIMED && timer[r] > 0) {
                timer[r] = 0;
                outputOn[r] = false;
                pushOutput(r);
            }
        }
    }

    // ---------------------------------------------------------------- setup screen

    public void applyConfig(String[] newNames, int[] newModes, int[] newSeconds, int[] newColors, String newRide) {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int r = 0; r < ROWS; r++) {
            String n = newNames[r] == null ? "" : newNames[r].trim();
            names[r] = n.length() > 14 ? n.substring(0, 14) : n;
            int mode = Math.max(0, Math.min(2, newModes[r]));
            if (mode != modes[r]) {
                modes[r] = mode;
                timer[r] = 0;
                if (outputOn[r]) {
                    outputOn[r] = false;
                    pushOutput(r);
                }
            }
            seconds[r] = Math.max(1, Math.min(999, newSeconds[r]));
            colors[r] = Math.max(0, Math.min(COLORS.length - 1, newColors[r]));
        }
        String ride = newRide == null ? "" : newRide.trim();
        rideName = ride.length() > 24 ? ride.substring(0, 24) : ride;
        refreshLamps();
        setChanged();
        syncToClients();
    }

    // ---------------------------------------------------------------- ticking and lamps

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int r = 0; r < ROWS; r++) {
            if (timer[r] > 0) {
                timer[r]--;
                if (timer[r] == 0) {
                    outputOn[r] = false;
                    pushOutput(r);
                }
            }
        }
        if (estopActive() && level.getGameTime() % 10 == 0) {
            float pitch = (level.getGameTime() / 10) % 2 == 0 ? 1.6F : 1.0F;
            level.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.BLOCKS, 2.0F, pitch);
        }
        refreshLamps();
    }

    private void refreshLamps() {
        int mask = 0;
        for (int r = 0; r < ROWS; r++) {
            if (outputOn[r] || received[r] > 0) {
                mask |= 1 << r;
            }
        }
        if (mask != lampMask) {
            lampMask = mask;
            setChanged();
            syncToClients();
        }
    }

    private void syncToClients() {
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---------------------------------------------------------------- saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        NonNullList<ItemStack> list = NonNullList.withSize(ROWS * 2, ItemStack.EMPTY);
        for (int i = 0; i < list.size(); i++) {
            list.set(i, frequencies.getItem(i));
        }
        ContainerHelper.saveAllItems(tag, list, registries);
        int toggles = 0;
        for (int r = 0; r < ROWS; r++) {
            tag.putString("Name" + r, names[r]);
            tag.putInt("Mode" + r, modes[r]);
            tag.putInt("Secs" + r, seconds[r]);
            tag.putInt("Color" + r, colors[r]);
            if (modes[r] == TOGGLE && outputOn[r]) {
                toggles |= 1 << r;
            }
        }
        tag.putString("Ride", rideName);
        tag.putInt("Toggles", toggles);
        tag.putInt("Lamps", lampMask);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        loading = true;
        NonNullList<ItemStack> list = NonNullList.withSize(ROWS * 2, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        for (int i = 0; i < list.size(); i++) {
            frequencies.setItem(i, list.get(i));
        }
        int toggles = tag.getInt("Toggles");
        for (int r = 0; r < ROWS; r++) {
            if (tag.contains("Name" + r)) {
                names[r] = tag.getString("Name" + r);
                modes[r] = tag.getInt("Mode" + r);
                seconds[r] = Math.max(1, tag.getInt("Secs" + r));
                colors[r] = Math.max(0, Math.min(COLORS.length - 1, tag.getInt("Color" + r)));
            }
            outputOn[r] = modes[r] == TOGGLE && (toggles & (1 << r)) != 0;
        }
        rideName = tag.getString("Ride");
        lampMask = tag.getInt("Lamps");
        loading = false;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ---------------------------------------------------------------- a single Redstone Link endpoint

    private class Link implements IRedstoneLinkable {
        private final int row;
        private final boolean transmitter;
        private boolean alive = false;
        private Couple<Frequency> key = Couple.create(Frequency.EMPTY, Frequency.EMPTY);

        Link(int row, boolean transmitter) {
            this.row = row;
            this.transmitter = transmitter;
        }

        @Override
        public int getTransmittedStrength() {
            return transmitter && outputOn[row] ? 15 : 0;
        }

        @Override
        public void setReceivedStrength(int power) {
            if (!transmitter) {
                received[row] = power;
            }
        }

        @Override
        public boolean isListening() {
            return !transmitter;
        }

        @Override
        public boolean isAlive() {
            return alive && !isRemoved();
        }

        @Override
        public Couple<Frequency> getNetworkKey() {
            return key;
        }

        @Override
        public BlockPos getLocation() {
            return getBlockPos();
        }
    }
}
