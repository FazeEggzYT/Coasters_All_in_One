package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.animatronics.AnimatronicType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Animatronic setup: character, animation, looping or redstone, and speed. Changes are sent as you click. */
public class AnimatronicScreen extends Screen {
    private static final int W = 260;
    private static final int H = 176;

    private final BlockPos pos;
    private int character;
    private int animation;
    private boolean redstone;
    private int speed = 1;

    public AnimatronicScreen(BlockPos pos) {
        super(Component.translatable("block.coastercontrolpanel.animatronic"));
        this.pos = pos;
        if (Minecraft.getInstance().level != null
                && Minecraft.getInstance().level.getBlockEntity(pos) instanceof AnimatronicBlockEntity be) {
            character = be.character();
            animation = be.animation();
            redstone = be.redstoneMode();
            speed = be.speed();
        }
    }

    private void send() {
        PacketDistributor.sendToServer(new AnimatronicConfigPacket(pos, character, animation, redstone, speed));
    }

    @Override
    protected void init() {
        clearWidgets();
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        AnimatronicType[] types = AnimatronicType.values();
        for (int i = 0; i < types.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.translatable("animatronic.type." + types[i].id), btn -> {
                character = idx;
                animation = 0;
                send();
                init();
            }).bounds(x + 8 + (i % 4) * 61, y + 22 + (i / 4) * 20, 59, 18).build();
            b.active = i != character;
            addRenderableWidget(b);
        }
        String[] anims = AnimatronicType.byIndex(character).animations;
        for (int i = 0; i < anims.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.translatable("animatronic.anim." + anims[i]), btn -> {
                animation = idx;
                send();
                init();
            }).bounds(x + 8 + i * 81, y + 78, 79, 18).build();
            b.active = i != animation;
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.translatable("animatronic.mode.loop"), btn -> {
            redstone = false;
            send();
            init();
        }).bounds(x + 8, y + 112, 118, 18).build()).active = redstone;
        addRenderableWidget(Button.builder(Component.translatable("animatronic.mode.redstone"), btn -> {
            redstone = true;
            send();
            init();
        }).bounds(x + 134, y + 112, 118, 18).build()).active = !redstone;
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button b = Button.builder(Component.translatable("animatronic.speed." + i), btn -> {
                speed = idx;
                send();
                init();
            }).bounds(x + 8 + i * 81, y + 146, 79, 18).build();
            b.active = i != speed;
            addRenderableWidget(b);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.fill(x, y, x + W, y + H, 0xF0202830);
        g.fill(x + 1, y + 1, x + W - 1, y + H - 1, 0xF0384450);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int x = (width - W) / 2;
        int y = (height - H) / 2;
        g.drawString(font, title, x + 8, y + 7, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("animatronic.setting.animation"), x + 8, y + 67, 0xB8C0C8, false);
        g.drawString(font, Component.translatable("animatronic.setting.mode"), x + 8, y + 101, 0xB8C0C8, false);
        g.drawString(font, Component.translatable("animatronic.setting.speed"), x + 8, y + 135, 0xB8C0C8, false);
    }
}
