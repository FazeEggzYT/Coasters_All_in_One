package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.IntSupplier;

/**
 * BRAKE RUN CONFIGURATION. Same look as the Green Screen (dark panel, grey border). The settings are in a scrolling
 * list, so it fits any window size. Nothing is sent until Apply is pressed; Cancel (or Esc) discards the changes.
 */
public class BrakeRunScreen extends Screen {
    private static final int W = 300;
    private static final int ROW = 22;
    private static final int HEAD = 24;
    private static final int FOOT = 30;

    private final net.minecraft.core.BlockPos start;
    private final BrakeSettings s;
    private boolean advanced;
    private int scroll;
    private int contentHeight;

    /** A row of the scrolling list: a label, an optional widget, an optional wrapped note. */
    private static final class Row {
        Component label;
        AbstractWidget widget;
        Component note;
        boolean dim;
        int y;
        int height = ROW;
    }

    private final List<Row> rows = new ArrayList<>();
    private Dropdown open;

    /** A button that opens a list of choices below it. */
    private final class Dropdown extends Button {
        final String[] options;
        final IntSupplier get;
        final Consumer<Integer> set;

        Dropdown(String[] options, IntSupplier get, Consumer<Integer> set) {
            super(0, 0, 140, 18, Component.empty(), b -> {
            }, DEFAULT_NARRATION);
            this.options = options;
            this.get = get;
            this.set = set;
            refresh();
        }

        void refresh() {
            setMessage(Component.literal(options[Math.max(0, Math.min(options.length - 1, get.getAsInt()))] + "  v"));
        }

        @Override
        public void onPress() {
            open = open == this ? null : this;
        }
    }

    public BrakeRunScreen(net.minecraft.core.BlockPos start, BrakeSettings settings) {
        super(Component.translatable(settings != null && settings.stopper ? "gui.coastercontrolpanel.brake.title_stopper" : "gui.coastercontrolpanel.brake.title"));
        this.start = start;
        this.s = settings;
    }

    private static Component t(String key) {
        return Component.translatable("gui.coastercontrolpanel.brake." + key);
    }

    private static String[] names(String prefix, String... keys) {
        String[] out = new String[keys.length];
        for (int i = 0; i < keys.length; i++) {
            out[i] = t(prefix + "." + keys[i]).getString();
        }
        return out;
    }

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.2f", v);
    }

    private int panelX() {
        return (width - W) / 2;
    }

    private int panelH() {
        return Math.min(height - 12, 300);
    }

    private int panelY() {
        return (height - panelH()) / 2;
    }

    private int viewTop() {
        return panelY() + HEAD;
    }

    private int viewBottom() {
        return panelY() + panelH() - FOOT;
    }

    @Override
    protected void init() {
        rebuild();
        int by = panelY() + panelH() - FOOT + 6;
        addRenderableWidget(Button.builder(t("apply"), b -> apply()).bounds(panelX() + 10, by, 136, 18).build());
        addRenderableWidget(Button.builder(t("cancel"), b -> onClose()).bounds(panelX() + W - 146, by, 136, 18).build());
    }

    private Row row(String labelKey, AbstractWidget w) {
        Row r = new Row();
        r.label = t(labelKey);
        r.widget = w;
        rows.add(r);
        return r;
    }

    private EditBox edit(double value, double min, double max, String unit, Consumer<Float> set) {
        EditBox box = new EditBox(font, 0, 0, 100, 18, Component.empty());
        box.setValue(num(value));
        box.setFilter(str -> str.matches("[0-9]{0,4}([.][0-9]{0,2})?"));
        box.setResponder(str -> {
            try {
                float v = Float.parseFloat(str);
                set.accept((float) Math.max(min, Math.min(max, v)));
            } catch (NumberFormatException ignored) {
                // an empty or half-typed number is simply not applied yet
            }
        });
        return box;
    }

    private void rebuild() {
        for (Row r : rows) {
            if (r.widget != null) {
                removeWidget(r.widget);
            }
        }
        rows.clear();
        open = null;
        boolean stop = s.mode == BrakeSettings.MODE_STOP_RELEASE || s.mode == BrakeSettings.MODE_FULL_STOP;
        boolean slow = s.mode == BrakeSettings.MODE_SLOWDOWN;
        boolean drive = s.mode == BrakeSettings.MODE_DRIVE;

        row("mode", new Dropdown(names("mode", "stop_release", "slowdown", "full_stop", "controlled", "shaft"),
                () -> s.mode, v -> {
                    s.mode = v;
                    s.holdSignal = false;
                    rebuild();
                }));
        Row note = new Row();
        note.note = t("mode_note." + new String[]{"stop_release", "slowdown", "full_stop", "controlled", "shaft"}[s.mode]);
        note.height = 34;
        rows.add(note);

        row("strength", new Dropdown(names("strength", "gentle", "moderate", "strong", "very_strong", "custom"),
                () -> s.strength, v -> {
                    s.strength = v;
                    rebuild();
                }));
        if (s.strength == BrakeSettings.STRENGTH_CUSTOM) {
            row("custom_decel", edit(s.customDecel, 1, 48, "", v -> s.customDecel = v));
        }

        Row target = row("target", new Dropdown(targetNames(), this::targetIndex, v -> {
            if (v < BrakeSettings.TARGET_PRESETS.length) {
                s.targetKmh = BrakeSettings.TARGET_PRESETS[v];
            } else {
                s.targetKmh = BrakeSettings.TARGET_PRESETS.length > 0 && targetIndex() == v ? s.targetKmh : 15;
            }
            rebuild();
        }));
        target.dim = !slow;
        target.widget.active = slow;
        if (slow && targetIndex() == BrakeSettings.TARGET_PRESETS.length) {
            row("custom_target", edit(s.targetKmh, 0, 200, "", v -> s.targetKmh = v));
        }

        if (drive) {
            row("idle", new Dropdown(names("idle", "free", "hold"), () -> s.holdSignal ? 1 : 0, v -> s.holdSignal = v == 1));
            row("drive_speed", edit(s.releaseKmh, 2, 100, "", v -> s.releaseKmh = v));
            Row dn = new Row();
            dn.note = t("drive_note");
            dn.height = 46;
            rows.add(dn);
        }
        Row wait = stop ? row("hold_for", new Dropdown(names("hold_for", "timer", "signal"), () -> s.holdSignal ? 1 : 0, v -> {
            s.holdSignal = v == 1;
            rebuild();
        })) : null;
        if (wait != null && s.holdSignal) {
            Row hn = new Row();
            hn.note = t("hold_note");
            hn.height = 46;
            rows.add(hn);
        }
        Row dur = row("stop_duration", new Dropdown(durationNames(), this::durationIndex, v -> {
            if (v < BrakeSettings.STOP_PRESETS.length) {
                s.stopSeconds = BrakeSettings.STOP_PRESETS[v];
            } else if (durationIndex() != v) {
                s.stopSeconds = 4;
            }
            rebuild();
        }));
        dur.dim = !stop || s.holdSignal;
        dur.widget.active = stop && !s.holdSignal;
        if (stop && !s.holdSignal && durationIndex() == BrakeSettings.STOP_PRESETS.length) {
            row("custom_duration", edit(s.stopSeconds, 0.1, 120, "", v -> s.stopSeconds = v));
        }

        row("release", new Dropdown(names("release", "very_slow", "slow", "normal", "fast", "custom"),
                () -> s.release, v -> {
                    s.release = v;
                    rebuild();
                }));
        if (s.release == BrakeSettings.RELEASE_CUSTOM) {
            row("custom_release", edit(s.customRelease, 0.5, 30, "", v -> s.customRelease = v));
        }

        if (!drive) row("entry", new Dropdown(names("entry", "respect", "limit"), () -> s.limitEntry ? 1 : 0, v -> {
            s.limitEntry = v == 1;
            rebuild();
        }));
        if (s.limitEntry && !drive) {
            row("max_entry", edit(s.maxEntryKmh, 5, 300, "", v -> s.maxEntryKmh = v));
        }

        Row min = row("min_speed", edit(s.minKmh, 0, 100, "", v -> s.minKmh = v));
        min.dim = !slow;
        min.widget.active = slow;

        Row adv = new Row();
        adv.widget = Button.builder(t(advanced ? "advanced_hide" : "advanced_show"), b -> {
            advanced = !advanced;
            rebuild();
        }).bounds(0, 0, 140, 18).build();
        adv.label = t("advanced");
        rows.add(adv);
        if (advanced) {
            row("direction", new Dropdown(names("direction", "forward", "reverse", "both"), () -> s.direction,
                    v -> s.direction = v));
            Row rs = row("release_speed", edit(s.releaseKmh, 2, 100, "", v -> s.releaseKmh = v));
            rs.dim = false;
            row("smoothing", new Dropdown(names("smoothing", "low", "medium", "high"), () -> s.smoothing,
                    v -> s.smoothing = v));
            Row n = new Row();
            n.note = t("advanced_note");
            n.height = 34;
            rows.add(n);
        }

        int y = 0;
        for (Row r : rows) {
            r.y = y;
            y += r.height;
        }
        contentHeight = y;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - (viewBottom() - viewTop()))));
        for (Row r : rows) {
            if (r.widget != null) {
                addRenderableWidget(r.widget);
            }
        }
        layoutRows();
    }

    private String[] targetNames() {
        String[] out = new String[BrakeSettings.TARGET_PRESETS.length + 1];
        for (int i = 0; i < BrakeSettings.TARGET_PRESETS.length; i++) {
            out[i] = num(BrakeSettings.TARGET_PRESETS[i]) + " km/h";
        }
        out[out.length - 1] = t("custom").getString();
        return out;
    }

    private int targetIndex() {
        for (int i = 0; i < BrakeSettings.TARGET_PRESETS.length; i++) {
            if (Math.abs(s.targetKmh - BrakeSettings.TARGET_PRESETS[i]) < 0.005) {
                return i;
            }
        }
        return BrakeSettings.TARGET_PRESETS.length;
    }

    private String[] durationNames() {
        String[] out = new String[BrakeSettings.STOP_PRESETS.length + 1];
        for (int i = 0; i < BrakeSettings.STOP_PRESETS.length; i++) {
            out[i] = num(BrakeSettings.STOP_PRESETS[i]) + " s";
        }
        out[out.length - 1] = t("custom").getString();
        return out;
    }

    private int durationIndex() {
        for (int i = 0; i < BrakeSettings.STOP_PRESETS.length; i++) {
            if (Math.abs(s.stopSeconds - BrakeSettings.STOP_PRESETS[i]) < 0.005) {
                return i;
            }
        }
        return BrakeSettings.STOP_PRESETS.length;
    }

    /** Moves each widget to its scrolled position; widgets outside the visible area are hidden (and so not clickable). */
    private void layoutRows() {
        int x = panelX() + W - 10 - 140;
        for (Row r : rows) {
            if (r.widget == null) {
                continue;
            }
            int y = viewTop() + r.y - scroll + 2;
            r.widget.setX(x);
            r.widget.setY(y);
            r.widget.setWidth(140);
            r.widget.visible = y >= viewTop() - 1 && y + 18 <= viewBottom() + 1;
            if (r.widget instanceof Dropdown d) {
                d.refresh();
            }
        }
    }

    private void apply() {
        PacketDistributor.sendToServer(new BrakeConfigPacket(start, s.toTag()));
        onClose();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int max = Math.max(0, contentHeight - (viewBottom() - viewTop()));
        int next = Math.max(0, Math.min(max, scroll - (int) Math.signum(sy) * 14));
        if (next != scroll) {
            scroll = next;
            open = null;
            layoutRows();
        }
        return true;
    }

    private int popupY(Dropdown d) {
        return d.getY() + d.getHeight();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open != null) {
            Dropdown d = open;
            int py = popupY(d);
            if (mx >= d.getX() && mx < d.getX() + d.getWidth() && my >= py && my < py + d.options.length * 14) {
                d.set.accept((int) ((my - py) / 14));
                if (open == d) {
                    open = null;
                }
                layoutRows();
                return true;
            }
            open = null;
            if (d.isMouseOver(mx, my)) {
                return true; // the click that closes it
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderTransparentBackground(g);
        int x0 = panelX();
        int y0 = panelY();
        g.fill(x0, y0, x0 + W, y0 + panelH(), 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + W - 1, y0 + panelH() - 1, 0xFF1B1D24);
        g.drawString(font, title, x0 + 10, y0 + 8, 0xFFFFFF, false);
        g.fill(x0 + 4, y0 + HEAD - 2, x0 + W - 4, y0 + HEAD - 1, 0xFF3A3E4D);
        g.fill(x0 + 4, y0 + panelH() - FOOT, x0 + W - 4, y0 + panelH() - FOOT + 1, 0xFF3A3E4D);

        g.enableScissor(x0 + 2, viewTop(), x0 + W - 2, viewBottom());
        for (Row r : rows) {
            int y = viewTop() + r.y - scroll;
            if (y + r.height < viewTop() || y > viewBottom()) {
                continue;
            }
            int color = r.dim ? 0x6A6F80 : 0xE0E4F0;
            if (r.label != null) {
                g.drawString(font, r.label, x0 + 10, y + 7, color, false);
            }
            if (r.note != null) {
                drawWrapped(g, r.note, x0 + 10, y + 3, W - 20, 0x8A92A8);
            }
        }
        for (Row r : rows) {
            if (r.widget != null && r.widget.visible) {
                r.widget.render(g, open == null ? mouseX : -1, open == null ? mouseY : -1, partial);
            }
        }
        g.disableScissor();
        for (net.minecraft.client.gui.components.events.GuiEventListener c : children()) {
            if (c instanceof Button b && !isRowWidget(b)) {
                b.render(g, open == null ? mouseX : -1, open == null ? mouseY : -1, partial);
            }
        }
        if (contentHeight > viewBottom() - viewTop()) {
            int track = viewBottom() - viewTop();
            int bar = Math.max(12, track * track / contentHeight);
            int by = viewTop() + (track - bar) * scroll / Math.max(1, contentHeight - track);
            g.fill(x0 + W - 5, by, x0 + W - 3, by + bar, 0xFF7A8098);
        }
        if (open != null) {
            Dropdown d = open;
            int py = popupY(d);
            int h = d.options.length * 14;
            g.pose().pushPose();
            g.pose().translate(0, 0, 400);
            g.fill(d.getX() - 1, py - 1, d.getX() + d.getWidth() + 1, py + h + 1, 0xFF7A8098);
            g.fill(d.getX(), py, d.getX() + d.getWidth(), py + h, 0xFF0D0E12);
            for (int i = 0; i < d.options.length; i++) {
                boolean hover = mouseX >= d.getX() && mouseX < d.getX() + d.getWidth()
                        && mouseY >= py + i * 14 && mouseY < py + i * 14 + 14;
                if (hover) {
                    g.fill(d.getX(), py + i * 14, d.getX() + d.getWidth(), py + i * 14 + 14, 0xFF2A3350);
                }
                g.drawString(font, d.options[i], d.getX() + 4, py + i * 14 + 3, i == d.get.getAsInt() ? 0x7CE08A : 0xE0E4F0, false);
            }
            g.pose().popPose();
        }
    }

    private boolean isRowWidget(AbstractWidget w) {
        for (Row r : rows) {
            if (r.widget == w) {
                return true;
            }
        }
        return false;
    }

    private void drawWrapped(GuiGraphics g, Component text, int x, int y, int w, int color) {
        int yy = y;
        for (net.minecraft.util.FormattedCharSequence line : font.split(text, w)) {
            g.drawString(font, line, x, yy, color, false);
            yy += 10;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
