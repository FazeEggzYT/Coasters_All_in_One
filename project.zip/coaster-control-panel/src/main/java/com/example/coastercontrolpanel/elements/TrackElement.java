package com.example.coastercontrolpanel.elements;

/**
 * One predefined track element. To add a new element, add one entry to {@link TrackElements#ALL}: give it an id,
 * a category, which options it supports, and a function that turns u (0 at the entrance, 1 at the exit) into a
 * {@link Pose}. Everything else (anchor layout, preview, placement, GUI) works from that function.
 *
 * Rules for the function: u = 0 must be the origin heading straight forward (+z) with the track upright. At u = 1 the track must be
 * level and upright (its heading may have changed, for example after a turn), so the next piece can continue.
 * Roll is measured around the direction of travel: positive roll tilts the track's up towards the left.
 */
public record TrackElement(String id, String category, boolean usesSide, boolean usesRise, Profile profile) {
    @FunctionalInterface
    public interface Profile {
        Pose at(double u, Params p);
    }

    public Pose at(double u, Params p) {
        return profile.at(Math.max(0.0, Math.min(1.0, u)), p.clamped());
    }

    public String nameKey() {
        return "track_element.coastercontrolpanel." + id;
    }

    public String categoryKey() {
        return "track_element_category.coastercontrolpanel." + category;
    }
}
