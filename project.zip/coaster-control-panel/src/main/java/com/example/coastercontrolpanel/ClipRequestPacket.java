package com.example.coastercontrolpanel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: "I do not have this announcement file yet, please send it". */
public record ClipRequestPacket(String hash) implements CustomPacketPayload {
    public static final Type<ClipRequestPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ClipRequestPacket> CODEC = StreamCodec.of(
            (buf, p) -> buf.writeUtf(p.hash, 32),
            buf -> new ClipRequestPacket(buf.readUtf(32)));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ClipRequestPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        byte[] file = ClipStore.load(player.server, p.hash);
        if (file == null) {
            return;
        }
        int total = (file.length + ClipStore.CHUNK - 1) / ClipStore.CHUNK;
        for (int i = 0; i < total; i++) {
            int from = i * ClipStore.CHUNK;
            int to = Math.min(file.length, from + ClipStore.CHUNK);
            byte[] part = new byte[to - from];
            System.arraycopy(file, from, part, 0, part.length);
            PacketDistributor.sendToPlayer(player, new ClipDataPacket(p.hash, i, total, part));
        }
    }
}
