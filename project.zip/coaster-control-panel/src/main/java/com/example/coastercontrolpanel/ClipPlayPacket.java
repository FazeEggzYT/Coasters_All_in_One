package com.example.coastercontrolpanel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to nearby clients: play this uploaded announcement at this spot. */
public record ClipPlayPacket(String hash, double x, double y, double z, int volume, int pitch)
        implements CustomPacketPayload {
    public static final Type<ClipPlayPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip_play"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ClipPlayPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeUtf(p.hash, 32);
                buf.writeDouble(p.x);
                buf.writeDouble(p.y);
                buf.writeDouble(p.z);
                buf.writeVarInt(p.volume);
                buf.writeVarInt(p.pitch);
            },
            buf -> new ClipPlayPacket(buf.readUtf(32), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ClipPlayPacket p, IPayloadContext context) {
        ClipClient.playOrFetch(p.hash, p.x, p.y, p.z, p.volume / 100.0F, p.pitch / 100.0F);
    }
}
