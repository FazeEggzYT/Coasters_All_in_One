package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: an Announcement Panel button was tapped. */
public record AnnouncePlayPacket(BlockPos pos, int row) implements CustomPacketPayload {
    public static final Type<AnnouncePlayPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "announce_play"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AnnouncePlayPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.row);
            },
            buf -> new AnnouncePlayPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(AnnouncePlayPacket packet, IPayloadContext context) {
        AnnouncePanelBlockEntity panel = AnnouncePanelBlockEntity.lookup(context.player(), packet.pos);
        if (panel != null) {
            panel.play(packet.row);
        }
    }
}
