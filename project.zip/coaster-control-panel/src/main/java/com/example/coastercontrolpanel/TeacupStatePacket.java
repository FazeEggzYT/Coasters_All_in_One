package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server to client, every tick while a Teacup Ride runs: the client moves the platter and the cups from these numbers. */
public record TeacupStatePacket(BlockPos pos, float platter, float cup, int phase, long hub, int cupMode) implements CustomPacketPayload {
    public static final Type<TeacupStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "teacup_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TeacupStatePacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeFloat(p.platter);
                buf.writeFloat(p.cup);
                buf.writeVarInt(p.phase);
                buf.writeLong(p.hub);
                buf.writeVarInt(p.cupMode);
            },
            buf -> new TeacupStatePacket(buf.readBlockPos(), buf.readFloat(), buf.readFloat(), buf.readVarInt(), buf.readLong(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(TeacupStatePacket p, IPayloadContext context) {
        if (context.player().level().getBlockEntity(p.pos) instanceof TeacupBlockEntity be) {
            be.receiveState(p.platter, p.cup, p.phase, BlockPos.of(p.hub), p.cupMode);
        }
    }
}
