package com.example.coastercontrolpanel;

import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The two "Coasters" tools. Coasters Simulated is reached by name at runtime (reflection), so nothing here
 * needs the mod to compile.
 *
 * Coaster Smoother: right-click any track anchor. Every anchor on the connected track that sits in the middle
 * of a straight chain gets its two curve handles lined up with the line between its neighbours, so the bends
 * flow into each other. Ends, junctions and anchors that cannot move are left alone.
 *
 * Track Unrestrictor: held in the OFF hand while placing track, the length, span and distance limits are lifted
 * (see mixin/TrackUnrestrictMixin).
 */
public final class CoasterTools {
    private static final String EDIT = "dev.silvergold.simulatedcoasters.track.CoasterBezierHandleEdit";
    private static final String PLACEMENT = "dev.silvergold.simulatedcoasters.track.CoasterTrackPlacement";
    private static final int MAX_ANCHORS = 1024;
    private static final double[] TRIES = {1.0, 0.75, 0.5, 0.3};

    private static final ThreadLocal<ArrayDeque<Player>> SCOPE = ThreadLocal.withInitial(ArrayDeque::new);

    private CoasterTools() {
    }

    // ------------------------------------------------------------------ unrestrictor

    /** True when this player holds the Track Unrestrictor in the off hand. */
    public static boolean enabledFor(Player player) {
        return player != null && player.getOffhandItem().is(CoasterControlPanel.TRACK_UNRESTRICTOR_ITEM.get());
    }

    private static final ThreadLocal<int[]> ELEMENT = ThreadLocal.withInitial(() -> new int[1]);

    /** While a Track Element is being placed the track limits are lifted for it, like with the Unrestrictor. */
    public static void elementScope(boolean on) {
        int[] c = ELEMENT.get();
        c[0] = Math.max(0, c[0] + (on ? 1 : -1));
    }

    public static void push(Player player) {
        SCOPE.get().push(player);
    }

    public static void pop() {
        ArrayDeque<Player> d = SCOPE.get();
        if (!d.isEmpty()) {
            d.pop();
        }
    }

    /** True while a placement made by a player with the Unrestrictor is running (or, on the client, while it is held). */
    public static boolean active() {
        if (ELEMENT.get()[0] > 0) {
            return true;
        }
        ArrayDeque<Player> d = SCOPE.get();
        if (!d.isEmpty()) {
            return enabledFor(d.peek());
        }
        return net.neoforged.fml.loading.FMLEnvironment.dist.isClient() && ClientHooks.localUnrestrict();
    }

    private static Method acrossMethod;
    private static boolean triedAcross;

    /** Joining two different sub-levels is still refused. */
    public static boolean acrossSubLevels(Level level, BlockPos a, BlockPos b) {
        try {
            if (!triedAcross) {
                triedAcross = true;
                acrossMethod = Class.forName(PLACEMENT).getMethod("anchorConnectionAcrossSubLevels", Level.class, BlockPos.class, BlockPos.class);
            }
            if (acrossMethod != null) {
                return (Boolean) acrossMethod.invoke(null, level, a, b);
            }
        } catch (Throwable t) {
            acrossMethod = null;
        }
        return false;
    }

    // ------------------------------------------------------------------ smoother (port of the Additions smoother)

    private static final String BASE = "dev.silvergold.simulatedcoasters.track.";
    private static final double MAX_BANK = Math.toRadians(38.0);
    private static final double TIGHT_START = Math.toRadians(65.0);
    private static final double TIGHT_FULL = Math.toRadians(100.0);
    private static final double[] FALLBACKS = {1.0, 0.75, 0.55, 0.4, 0.25};

    private static final class R {
        Method lookupGet, nearest, edgeFrom, edgeTo, hitEdge;
        Method worldCenter, fetchPrimary, tangentInto, preview, commit, tilt, commitTilt, valid, edited;
        Method maxHandle, handleLen, bank;
        boolean ok;
    }

    private static R r;

    private static Method find(Class<?> c, String name, int argc) {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == argc) {
                return m;
            }
        }
        return null;
    }

    private static R refl() {
        if (r != null) {
            return r;
        }
        R x = new R();
        r = x;
        try {
            Class<?> lookup = Class.forName(BASE + "graph.CoasterPathGraphLookup");
            Class<?> frame = Class.forName(BASE + "graph.CoasterPathTrackFrame");
            Class<?> hit = Class.forName(BASE + "graph.CoasterPathTrackFrame$GraphHit");
            Class<?> edge = Class.forName(BASE + "graph.CoasterPathEdge");
            Class<?> anchor = Class.forName(BASE + "anchor.CoasterAnchorpointBlockEntity");
            Class<?> edit = Class.forName(BASE + "CoasterBezierHandleEdit");
            Class<?> lens = Class.forName(BASE + "CoasterPeerCurveHandleLengths");
            x.lookupGet = find(lookup, "get", 1);
            for (Method m : frame.getMethods()) {
                if (m.getName().equals("nearestGraphHit") && m.getParameterCount() == 4
                        && m.getParameterTypes()[1] == x.lookupGet.getReturnType()) {
                    x.nearest = m;
                }
            }
            x.hitEdge = find(hit, "edge", 0);
            x.edgeFrom = find(edge, "from", 0);
            x.edgeTo = find(edge, "to", 0);
            x.worldCenter = find(anchor, "worldCenter", 2);
            x.bank = find(anchor, "getJointBankRadians", 0);
            x.fetchPrimary = find(edit, "fetchPrimary", 3);
            x.tangentInto = find(edit, "tangentIntoFromAnchor", 2);
            x.preview = find(edit, "computePreview", 5);
            x.commit = find(edit, "commit", 5);
            x.tilt = find(edit, "tiltVirtualTargetWorldForJointBankRadians", 4);
            x.commitTilt = find(edit, "commitTilt", 3);
            x.valid = x.preview.getReturnType().getMethod("valid");
            x.edited = x.preview.getReturnType().getMethod("edited");
            x.maxHandle = find(lens, "maxHandleLengthForEdge", 2);
            x.handleLen = find(lens, "getLengthAtEndpoint", 2);
            x.ok = x.lookupGet != null && x.nearest != null && x.hitEdge != null && x.edgeFrom != null
                    && x.fetchPrimary != null && x.preview != null && x.commit != null && x.tangentInto != null
                    && x.tilt != null && x.commitTilt != null && x.bank != null;
        } catch (Throwable t) {
            x.ok = false;
        }
        return x;
    }

    /** The anchor of the track under the player's crosshair, or null. */
    public static BlockPos pickTrackAnchor(Level level, Player player) {
        R x = refl();
        if (!x.ok) {
            return null;
        }
        try {
            Object graph = x.lookupGet.invoke(null, level);
            if (graph == null) {
                return null;
            }
            Vec3 eye = player.getEyePosition();
            Vec3 view = player.getViewVector(1.0F);
            for (double t = 0.0; t <= 64.0; t += 0.2) {
                Vec3 p = eye.add(view.scale(t));
                Object hit = x.nearest.invoke(null, level, graph, p, 1.5);
                if (hit == null) {
                    continue;
                }
                Object edge = x.hitEdge.invoke(hit);
                if (edge != null) {
                    return (BlockPos) x.edgeFrom.invoke(edge);
                }
            }
        } catch (Throwable t) {
            return null;
        }
        return null;
    }

    public static Vec3 anchorWorld(Level level, BlockPos p) {
        R x = refl();
        try {
            if (x.worldCenter != null) {
                Object v = x.worldCenter.invoke(null, level, p);
                if (v instanceof Vec3 vv) {
                    return vv;
                }
            }
        } catch (Throwable t) {
            // fall through
        }
        return Vec3.atCenterOf(p);
    }

    /** All anchors connected to start, with the anchors next to each (links made two-way). */
    private static Map<BlockPos, Set<BlockPos>> network(Level level, BlockPos start) {
        Map<BlockPos, Set<BlockPos>> net = new java.util.LinkedHashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        queue.add(start);
        net.put(start, new java.util.LinkedHashSet<>());
        while (!queue.isEmpty() && net.size() < MAX_ANCHORS) {
            BlockPos cur = queue.poll();
            BlockEntity be = AnchorTrack.loadedAnchor(level, cur);
            if (be == null) {
                continue;
            }
            for (BlockPos next : AnchorTrack.peers(be).keySet()) {
                net.get(cur).add(next);
                if (!net.containsKey(next)) {
                    net.put(next, new java.util.LinkedHashSet<>());
                    queue.add(next);
                }
            }
        }
        for (Map.Entry<BlockPos, Set<BlockPos>> e : new ArrayList<>(net.entrySet())) {
            for (BlockPos n : e.getValue()) {
                Set<BlockPos> back = net.get(n);
                if (back != null) {
                    back.add(e.getKey());
                }
            }
        }
        return net;
    }

    private record Edit(BlockPos host, BlockPos remote, int index, Vec3 offset) {
    }

    private record Primary(BlockPos host, BlockPos remote, BezierConnection curve) {
    }

    private static Primary primaryOf(Level level, BlockPos a, BlockPos b) {
        R x = refl();
        try {
            Object c = x.fetchPrimary.invoke(null, level, a, b);
            if (c instanceof BezierConnection bc) {
                return new Primary(a, b, bc);
            }
            c = x.fetchPrimary.invoke(null, level, b, a);
            if (c instanceof BezierConnection bc) {
                return new Primary(b, a, bc);
            }
        } catch (Throwable t) {
            // none
        }
        return null;
    }

    private static boolean commitHandle(ServerPlayer player, Edit e) {
        R x = refl();
        for (double f : FALLBACKS) {
            Vec3 off = f == 1.0 ? e.offset() : e.offset().scale(f);
            try {
                Object pv = x.preview.invoke(null, player.serverLevel(), e.host(), e.remote(), e.index(), off);
                if (pv == null || !(Boolean) x.valid.invoke(pv) || x.edited.invoke(pv) == null) {
                    continue;
                }
                x.commit.invoke(null, player, e.host(), e.remote(), e.index(), off);
                return true;
            } catch (Throwable t) {
                return false;
            }
        }
        return false;
    }

    private static void addHandle(List<Edit> out, Level level, BlockPos a, BlockPos b, Vec3 dir, double length) {
        if (dir.lengthSqr() < 1.0E-12) {
            return;
        }
        Primary p = primaryOf(level, a, b);
        if (p == null) {
            return;
        }
        int index = a.equals(p.curve().bePositions.getFirst()) ? 0 : 1;
        double chord = anchorWorld(level, a).distanceTo(anchorWorld(level, b));
        double max = chord * 0.7;
        try {
            R x = refl();
            if (x.maxHandle != null) {
                Object m = x.maxHandle.invoke(null, level, p.curve());
                if (m instanceof Double d) {
                    max = Math.min(d, chord * 0.7);
                }
            }
        } catch (Throwable t) {
            // keep chord limit
        }
        double len = Mth.clamp(length, 0.05, Math.max(0.05, max));
        out.add(new Edit(p.host(), p.remote(), index, dir.normalize().scale(len)));
    }

    /** Natural cubic spline tangents (chord-length parameter) through the points. */
    private static Vec3[] tangents(Vec3[] pt, boolean loop) {
        int n = pt.length;
        Vec3[] m = new Vec3[n];
        if (n == 2) {
            Vec3 d = pt[1].subtract(pt[0]);
            double h = d.length();
            Vec3 t = h < 1.0E-9 ? Vec3.ZERO : d.scale(1.0 / h);
            m[0] = t;
            m[1] = t;
            return m;
        }
        double[] h = new double[n];
        for (int i = 0; i < n; i++) {
            h[i] = pt[i].distanceTo(pt[(i + 1) % n]);
        }
        if (loop) {
            for (int i = 0; i < n; i++) {
                int a = (i + n - 1) % n;
                int c = (i + 1) % n;
                double s = h[a] + h[i];
                m[i] = s < 1.0E-9 ? Vec3.ZERO : pt[c].subtract(pt[a]).scale(1.0 / s);
            }
            return m;
        }
        double[][] rhs = new double[3][n];
        double[] lo = new double[n];
        double[] di = new double[n];
        double[] up = new double[n];
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                di[i] = 2;
                up[i] = 1;
                Vec3 d = pt[1].subtract(pt[0]).scale(3.0 / Math.max(h[0], 1.0E-9));
                rhs[0][i] = d.x;
                rhs[1][i] = d.y;
                rhs[2][i] = d.z;
            } else if (i == n - 1) {
                lo[i] = 1;
                di[i] = 2;
                Vec3 d = pt[n - 1].subtract(pt[n - 2]).scale(3.0 / Math.max(h[n - 2], 1.0E-9));
                rhs[0][i] = d.x;
                rhs[1][i] = d.y;
                rhs[2][i] = d.z;
            } else {
                double hp = Math.max(h[i - 1], 1.0E-9);
                double hn = Math.max(h[i], 1.0E-9);
                lo[i] = hn;
                di[i] = 2 * (hp + hn);
                up[i] = hp;
                Vec3 d = pt[i].subtract(pt[i - 1]).scale(hn / hp).add(pt[i + 1].subtract(pt[i]).scale(hp / hn)).scale(3.0);
                rhs[0][i] = d.x;
                rhs[1][i] = d.y;
                rhs[2][i] = d.z;
            }
        }
        double[][] sol = new double[3][];
        for (int k = 0; k < 3; k++) {
            sol[k] = tridiag(lo, di, up, rhs[k]);
        }
        for (int i = 0; i < n; i++) {
            m[i] = new Vec3(sol[0][i], sol[1][i], sol[2][i]);
        }
        return m;
    }

    private static double[] tridiag(double[] a, double[] b, double[] c, double[] d) {
        int n = d.length;
        double[] cp = new double[n];
        double[] dp = new double[n];
        double[] x = new double[n];
        cp[0] = c[0] / b[0];
        dp[0] = d[0] / b[0];
        for (int i = 1; i < n; i++) {
            double den = b[i] - a[i] * cp[i - 1];
            if (Math.abs(den) < 1.0E-12) {
                den = 1.0E-12;
            }
            cp[i] = c[i] / den;
            dp[i] = (d[i] - a[i] * dp[i - 1]) / den;
        }
        x[n - 1] = dp[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            x[i] = dp[i] - cp[i] * x[i + 1];
        }
        return x;
    }

    private static boolean writable(Map<BlockPos, Set<BlockPos>> net, BlockPos p) {
        int d = net.getOrDefault(p, Set.of()).size();
        return d == 1 || d == 2;
    }

    private static long pairKey(BlockPos a, BlockPos b) {
        long x = a.asLong();
        long y = b.asLong();
        return x < y ? x * 31L + y : y * 31L + x;
    }

    private static List<BlockPos> walk(BlockPos start, BlockPos first, Map<BlockPos, Set<BlockPos>> net, Set<Long> used) {
        List<BlockPos> chain = new ArrayList<>();
        chain.add(start);
        BlockPos prev = start;
        BlockPos cur = first;
        used.add(pairKey(prev, cur));
        while (true) {
            chain.add(cur);
            Set<BlockPos> nb = net.getOrDefault(cur, Set.of());
            if (nb.size() != 2 || cur.equals(start) || chain.size() > MAX_ANCHORS) {
                break;
            }
            BlockPos next = null;
            for (BlockPos n : nb) {
                if (!n.equals(prev)) {
                    next = n;
                }
            }
            if (next == null || used.contains(pairKey(cur, next))) {
                break;
            }
            used.add(pairKey(cur, next));
            prev = cur;
            cur = next;
        }
        return chain;
    }

    private static void splineHandles(List<Edit> out, Level level, List<BlockPos> chain, java.util.function.Predicate<BlockPos> writable) {
        splineHandles(out, level, chain, writable, null);
    }

    private static void splineHandles(List<Edit> out, Level level, List<BlockPos> chain, java.util.function.Predicate<BlockPos> writable,
                                      Map<BlockPos, Vec3> ideal) {
        boolean loop = chain.size() > 2 && chain.get(0).equals(chain.get(chain.size() - 1));
        List<BlockPos> pts = loop ? chain.subList(0, chain.size() - 1) : chain;
        int n = pts.size();
        if (n < 2) {
            return;
        }
        Vec3[] w = new Vec3[n];
        for (int i = 0; i < n; i++) {
            w[i] = anchorWorld(level, pts.get(i));
        }
        Vec3[] t = tangents(w, loop);
        if (ideal != null) {
            for (int i = 0; i < n; i++) {
                Vec3 v = ideal.get(pts.get(i));
                if (v != null && v.lengthSqr() > 1.0E-12) {
                    t[i] = v.normalize();
                }
            }
        }
        int segs = loop ? n : n - 1;
        for (int i = 0; i < segs; i++) {
            int j = (i + 1) % n;
            double d = w[i].distanceTo(w[j]);
            if (d < 0.001) {
                continue;
            }
            BlockPos a = pts.get(i);
            BlockPos b = pts.get(j);
            if (writable.test(a) && t[i].lengthSqr() > 1.0E-12) {
                addHandle(out, level, a, b, t[i], t[i].length() * d / 3.0);
            }
            if (writable.test(b) && t[j].lengthSqr() > 1.0E-12) {
                addHandle(out, level, b, a, t[j].scale(-1.0), t[j].length() * d / 3.0);
            }
        }
    }

    private static int applyHandles(ServerLevel level, ServerPlayer player, Map<BlockPos, Set<BlockPos>> net) {
        List<Edit> edits = new ArrayList<>();
        Set<Long> used = new HashSet<>();
        for (Map.Entry<BlockPos, Set<BlockPos>> e : net.entrySet()) {
            if (e.getValue().size() == 2) {
                continue;
            }
            for (BlockPos n : e.getValue()) {
                if (!used.contains(pairKey(e.getKey(), n))) {
                    splineHandles(edits, level, walk(e.getKey(), n, net, used), q -> writable(net, q));
                }
            }
        }
        for (Map.Entry<BlockPos, Set<BlockPos>> e : net.entrySet()) {
            if (e.getValue().size() != 2) {
                continue;
            }
            for (BlockPos n : e.getValue()) {
                if (!used.contains(pairKey(e.getKey(), n))) {
                    splineHandles(edits, level, walk(e.getKey(), n, net, used), q -> writable(net, q));
                }
            }
        }
        int done = 0;
        for (int pass = 0; pass < 4; pass++) {
            done = 0;
            for (Edit e : edits) {
                if (commitHandle(player, e)) {
                    done++;
                }
            }
        }
        return done;
    }

    private static float bankOf(Level level, BlockPos p) {
        try {
            BlockEntity be = level.getBlockEntity(p);
            if (be != null && AnchorTrack.isAnchor(be)) {
                Object o = refl().bank.invoke(be);
                if (o instanceof Float f) {
                    return f;
                }
            }
        } catch (Throwable t) {
            // none
        }
        return 0.0F;
    }

    private static boolean applyTarget(ServerPlayer player, BlockPos p, Vec3 target) {
        try {
            refl().commitTilt.invoke(null, player, p, target);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean applyBank(ServerLevel level, ServerPlayer player, BlockPos p, double rad) {
        try {
            Vec3 ref = anchorWorld(level, p).add(0.0, 2.0, 0.0);
            Object v = refl().tilt.invoke(null, level, p, ref, rad);
            if (v instanceof Vec3 t && t.lengthSqr() > 1.0E-12) {
                return applyTarget(player, p, t);
            }
        } catch (Throwable t) {
            // none
        }
        return false;
    }

    private static double keep(Vec3 other, Vec3 self) {
        if (other == null || other.lengthSqr() < 1.0E-12 || self.lengthSqr() < 1.0E-12) {
            return 1.0;
        }
        double cos = other.normalize().dot(self.normalize());
        return cos >= 0.0 ? 1.0 : 0.3 + 0.7 * (1.0 + cos);
    }

    private static int applyBanks(ServerLevel level, ServerPlayer player, Map<BlockPos, Set<BlockPos>> net) {
        Map<BlockPos, Vec3> raw = new java.util.HashMap<>();
        for (Map.Entry<BlockPos, Set<BlockPos>> e : net.entrySet()) {
            if (e.getValue().size() != 2 || AnchorTrack.loadedAnchor(level, e.getKey()) == null) {
                continue;
            }
            List<BlockPos> nb = new ArrayList<>(e.getValue());
            Vec3 p = anchorWorld(level, e.getKey());
            Vec3 a = anchorWorld(level, nb.get(0));
            Vec3 c = anchorWorld(level, nb.get(1));
            Vec3 d1 = p.subtract(a);
            Vec3 d2 = c.subtract(p);
            double l1 = d1.length();
            double l2 = d2.length();
            if (l1 < 0.001 || l2 < 0.001) {
                continue;
            }
            double phi = Math.acos(Mth.clamp(d1.scale(1.0 / l1).dot(d2.scale(1.0 / l2)), -1.0, 1.0));
            double curvature = phi / (0.5 * (l1 + l2));
            if (curvature < 0.02) {
                continue;
            }
            Vec3 inside = a.add(c).scale(0.5).subtract(p);
            double il = inside.length();
            if (il < 1.0E-6) {
                continue;
            }
            double tight = 1.0 - 0.3 * Mth.clamp((phi - TIGHT_START) / (TIGHT_FULL - TIGHT_START), 0.0, 1.0);
            double amount = MAX_BANK * Math.tanh(curvature * 11.0 / MAX_BANK) * tight;
            raw.put(e.getKey(), inside.scale(1.0 / il).scale(amount));
        }
        Map<BlockPos, Vec3> fin = new java.util.HashMap<>();
        for (Map.Entry<BlockPos, Vec3> e : raw.entrySet()) {
            List<BlockPos> nb = new ArrayList<>(net.get(e.getKey()));
            double k = Math.min(keep(raw.get(nb.get(0)), e.getValue()), keep(raw.get(nb.get(1)), e.getValue()));
            fin.put(e.getKey(), e.getValue().scale(k));
        }
        for (BlockPos p : net.keySet()) {
            if (!fin.containsKey(p) && Math.abs(bankOf(level, p)) > 0.001) {
                applyBank(level, player, p, 0.0);
            }
        }
        for (int i = 0; i < 10; i++) {
            for (Map.Entry<BlockPos, Vec3> e : fin.entrySet()) {
                double mag = e.getValue().length();
                if (mag < 1.0E-4) {
                    applyBank(level, player, e.getKey(), 0.0);
                    continue;
                }
                double ang = Math.min(mag, MAX_BANK);
                Vec3 in = e.getValue().scale(1.0 / mag);
                Vec3 target = anchorWorld(level, e.getKey()).add(0.0, 2.0 * Math.cos(ang), 0.0).add(in.scale(2.0 * Math.sin(ang)));
                applyTarget(player, e.getKey(), target);
            }
        }
        int banked = 0;
        for (BlockPos p : net.keySet()) {
            if (Math.abs(bankOf(level, p)) > 0.001) {
                banked++;
            }
        }
        return banked;
    }

    /**
     * Shapes a freshly built chain of anchors: spline handles along the chain (only on the anchors in writable, so the
     * existing track the chain starts from is left alone), then the roll of each anchor.
     * Returns {handles set, tilts set}.
     */
    public static int[] shapeChain(ServerLevel level, ServerPlayer player, List<BlockPos> chain,
                                   java.util.function.Predicate<BlockPos> writable, Map<BlockPos, Vec3> normals) {
        return shapeChain(level, player, chain, writable, normals, null);
    }

    /** Same, but anchors listed in idealTangents are steered along those directions instead of being guessed from neighbours. */
    public static int[] shapeChain(ServerLevel level, ServerPlayer player, List<BlockPos> chain,
                                   java.util.function.Predicate<BlockPos> writable, Map<BlockPos, Vec3> normals,
                                   Map<BlockPos, Vec3> idealTangents) {
        R x = refl();
        if (!x.ok) {
            return new int[]{0, 0};
        }
        int handles = 0;
        int tilts = 0;
        for (int cycle = 0; cycle < 3; cycle++) {
            List<Edit> edits = new ArrayList<>();
            splineHandles(edits, level, chain, writable, idealTangents);
            for (int pass = 0; pass < 4; pass++) {
                handles = 0;
                for (Edit e : edits) {
                    if (commitHandle(player, e)) {
                        handles++;
                    }
                }
            }
            tilts = 0;
            for (Map.Entry<BlockPos, Vec3> e : normals.entrySet()) {
                if (!writable.test(e.getKey())) {
                    continue;
                }
                Vec3 target = anchorWorld(level, e.getKey()).add(e.getValue().scale(2.0));
                if (applyTarget(player, e.getKey(), target)) {
                    tilts++;
                }
            }
        }
        return new int[]{handles, tilts};
    }

    // undo memory (one step, like the Additions smoother)
    private static Level undoLevel;
    private static List<Edit> undoHandles;
    private static Map<BlockPos, Float> undoBanks;

    private static List<Edit> snapshotHandles(Level level, Map<BlockPos, Set<BlockPos>> net) {
        List<Edit> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        R x = refl();
        for (Map.Entry<BlockPos, Set<BlockPos>> e : net.entrySet()) {
            for (BlockPos n : e.getValue()) {
                if (!seen.add(pairKey(e.getKey(), n))) {
                    continue;
                }
                Primary p = primaryOf(level, e.getKey(), n);
                if (p == null) {
                    continue;
                }
                for (int i = 0; i < 2; i++) {
                    try {
                        BlockPos anchor = i == 0 ? p.curve().bePositions.getFirst() : p.curve().bePositions.getSecond();
                        Object t = x.tangentInto.invoke(null, p.curve(), anchor);
                        Object len = x.handleLen.invoke(null, p.curve(), i);
                        if (t instanceof Vec3 tv && tv.lengthSqr() > 1.0E-12 && len instanceof Double l && l > 1.0E-8) {
                            out.add(new Edit(p.host(), p.remote(), i, tv.normalize().scale(l)));
                        }
                    } catch (Throwable ex) {
                        // skip
                    }
                }
            }
        }
        return out;
    }

    /** Smooths everything connected to start. Returns {handles written, anchors banked, anchors found}, or null if unsupported. */
    public static int[] smooth(Level level, ServerPlayer player, BlockPos start) {
        R x = refl();
        Map<BlockPos, Set<BlockPos>> net = network(level, start);
        if (!x.ok || net.size() < 2 || !(level instanceof ServerLevel sl)) {
            return net.size() < 2 ? new int[]{0, 0, net.size()} : null;
        }
        undoLevel = level;
        undoHandles = snapshotHandles(level, net);
        undoBanks = new java.util.HashMap<>();
        for (BlockPos p : net.keySet()) {
            undoBanks.put(p, bankOf(level, p));
        }
        int handles = 0;
        int banked = 0;
        for (int i = 0; i < 3; i++) {
            handles = applyHandles(sl, player, net);
            banked = applyBanks(sl, player, net);
        }
        return new int[]{handles, banked, net.size()};
    }

    /** Puts back what the last smooth changed. Returns -1 if there is nothing to undo. */
    public static int undo(ServerLevel level, ServerPlayer player) {
        if (undoLevel != level || (undoHandles == null && undoBanks == null)) {
            return -1;
        }
        int n = 0;
        if (undoHandles != null) {
            for (int pass = 0; pass < 4; pass++) {
                for (Edit e : undoHandles) {
                    commitHandle(player, e);
                }
            }
            n += undoHandles.size();
        }
        if (undoBanks != null) {
            for (int i = 0; i < 10; i++) {
                for (Map.Entry<BlockPos, Float> e : undoBanks.entrySet()) {
                    applyBank(level, player, e.getKey(), e.getValue());
                }
            }
            n += undoBanks.size();
        }
        undoHandles = null;
        undoBanks = null;
        undoLevel = null;
        return n;
    }
}
