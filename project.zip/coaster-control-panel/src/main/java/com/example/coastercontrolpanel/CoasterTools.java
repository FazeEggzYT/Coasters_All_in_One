package com.example.coastercontrolpanel;

import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The two "Coasters" tools. Coasters Simulated is reached by name at runtime (reflection), so nothing here
 * needs the mod to compile.
 *
 * Coaster Smoother: right-click any track anchor. Every anchor on the connected track that sits in the middle
 * of a straight chain gets its two curve handles lined up with the line between its neighbours, so the bends
 * flow into each other. Ends, junctions and anchors that cannot move are left alone.
 *
 * Track Unrestrictor: held in the OFF hand while placing track, the length, span and distance limits are lifted
 * (see mixin/TrackUnrestrictMixin).
 */
public final class CoasterTools {
    private static final String EDIT = "dev.silvergold.simulatedcoasters.track.CoasterBezierHandleEdit";
    private static final String PLACEMENT = "dev.silvergold.simulatedcoasters.track.CoasterTrackPlacement";
    private static final int MAX_ANCHORS = 1024;
    private static final double[] TRIES = {1.0, 0.75, 0.5, 0.3};

    private static final ThreadLocal<ArrayDeque<Player>> SCOPE = ThreadLocal.withInitial(ArrayDeque::new);

    private CoasterTools() {
    }

    // ------------------------------------------------------------------ unrestrictor

    /** True when this player holds the Track Unrestrictor in the off hand. */
    public static boolean enabledFor(Player player) {
        return player != null && player.getOffhandItem().is(CoasterControlPanel.TRACK_UNRESTRICTOR_ITEM.get());
    }

    public static void push(Player player) {
        SCOPE.get().push(player);
    }

    public static void pop() {
        ArrayDeque<Player> d = SCOPE.get();
        if (!d.isEmpty()) {
            d.pop();
        }
    }

    /** True while a placement made by a player with the Unrestrictor is running (or, on the client, while it is held). */
    public static boolean active() {
        ArrayDeque<Player> d = SCOPE.get();
        if (!d.isEmpty()) {
            return enabledFor(d.peek());
        }
        return net.neoforged.fml.loading.FMLEnvironment.dist.isClient() && ClientHooks.localUnrestrict();
    }

    private static Method acrossMethod;
    private static boolean triedAcross;

    /** Joining two different sub-levels is still refused. */
    public static boolean acrossSubLevels(Level level, BlockPos a, BlockPos b) {
        try {
            if (!triedAcross) {
                triedAcross = true;
                acrossMethod = Class.forName(PLACEMENT).getMethod("anchorConnectionAcrossSubLevels", Level.class, BlockPos.class, BlockPos.class);
            }
            if (acrossMethod != null) {
                return (Boolean) acrossMethod.invoke(null, level, a, b);
            }
        } catch (Throwable t) {
            acrossMethod = null;
        }
        return false;
    }

    // ------------------------------------------------------------------ smoother

    private static Method previewMethod;
    private static Method commitMethod;
    private static Method validMethod;
    private static boolean triedEdit;

    private static boolean initEdit() {
        if (!triedEdit) {
            triedEdit = true;
            try {
                Class<?> c = Class.forName(EDIT);
                for (Method m : c.getMethods()) {
                    if (m.getName().equals("computePreview") && m.getParameterCount() == 5) {
                        previewMethod = m;
                    } else if (m.getName().equals("commit") && m.getParameterCount() == 5) {
                        commitMethod = m;
                    }
                }
                if (previewMethod != null) {
                    validMethod = previewMethod.getReturnType().getMethod("valid");
                }
            } catch (Throwable t) {
                previewMethod = null;
                commitMethod = null;
            }
        }
        return previewMethod != null && commitMethod != null && validMethod != null;
    }

    private static Vec3 centre(Level level, BlockPos p) {
        return Vec3.atCenterOf(p);
    }

    /** All anchors connected to start, with the anchors next to each. */
    private static Map<BlockPos, Set<BlockPos>> network(Level level, BlockPos start) {
        Map<BlockPos, Set<BlockPos>> net = new java.util.LinkedHashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        queue.add(start);
        net.put(start, new java.util.LinkedHashSet<>());
        while (!queue.isEmpty() && net.size() < MAX_ANCHORS) {
            BlockPos cur = queue.poll();
            BlockEntity be = AnchorTrack.loadedAnchor(level, cur);
            if (be == null) {
                continue;
            }
            for (BlockPos next : AnchorTrack.peers(be).keySet()) {
                net.get(cur).add(next);
                if (!net.containsKey(next)) {
                    net.put(next, new java.util.LinkedHashSet<>());
                    queue.add(next);
                }
            }
        }
        // links are written on one anchor only; make them two-way
        for (Map.Entry<BlockPos, Set<BlockPos>> e : new ArrayList<>(net.entrySet())) {
            for (BlockPos n : e.getValue()) {
                Set<BlockPos> back = net.get(n);
                if (back != null) {
                    back.add(e.getKey());
                }
            }
        }
        return net;
    }

    private static BezierConnection curveBetween(Level level, BlockPos a, BlockPos b, BlockPos[] owner) {
        BlockEntity ea = AnchorTrack.loadedAnchor(level, a);
        if (ea != null) {
            BezierConnection c = AnchorTrack.peers(ea).get(b);
            if (c != null) {
                owner[0] = a;
                return c;
            }
        }
        BlockEntity eb = AnchorTrack.loadedAnchor(level, b);
        if (eb != null) {
            BezierConnection c = AnchorTrack.peers(eb).get(a);
            if (c != null) {
                owner[0] = b;
                return c;
            }
        }
        return null;
    }

    private static boolean setHandle(Level level, ServerPlayer player, BlockPos host, BlockPos remote, Vec3 dir, double length) {
        BlockPos[] owner = new BlockPos[1];
        BezierConnection curve = curveBetween(level, host, remote, owner);
        if (curve == null) {
            return false;
        }
        int index = host.equals(curve.bePositions.getFirst()) ? 0 : 1;
        for (double f : TRIES) {
            Vec3 offset = dir.scale(length * f);
            try {
                Object preview = previewMethod.invoke(null, level, host, remote, index, offset);
                if (preview != null && (Boolean) validMethod.invoke(preview)) {
                    commitMethod.invoke(null, player, host, remote, index, offset);
                    return true;
                }
            } catch (Throwable t) {
                return false;
            }
        }
        return false;
    }

    /** Smooths the connected track. Returns {anchors smoothed, anchors in the network}. */
    public static int[] smooth(Level level, ServerPlayer player, BlockPos start) {
        Map<BlockPos, Set<BlockPos>> net = network(level, start);
        if (net.size() < 2 || !initEdit()) {
            return new int[]{-1, net.size()};
        }
        int done = 0;
        for (Map.Entry<BlockPos, Set<BlockPos>> e : net.entrySet()) {
            if (e.getValue().size() != 2) {
                continue;
            }
            BlockPos p = e.getKey();
            List<BlockPos> n = new ArrayList<>(e.getValue());
            Vec3 pc = centre(level, p);
            Vec3 toA = centre(level, n.get(0)).subtract(pc);
            Vec3 toC = centre(level, n.get(1)).subtract(pc);
            double la = toA.length();
            double lc = toC.length();
            if (la < 0.01 || lc < 0.01) {
                continue;
            }
            Vec3 dir = toC.normalize().subtract(toA.normalize());
            if (dir.lengthSqr() < 1.0E-6) {
                continue;
            }
            dir = dir.normalize();
            boolean a = setHandle(level, player, p, n.get(1), dir, lc / 3.0);
            boolean c = setHandle(level, player, p, n.get(0), dir.scale(-1.0), la / 3.0);
            if (a || c) {
                done++;
            }
        }
        return new int[]{done, net.size()};
    }
}
