package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen of the Station, Launch, Brake and Lift controllers. */
public class ZoneScreen extends AbstractContainerScreen<ZoneMenu> {
    private final ZoneType type;
    private int clear = 1;
    private final int[] setting = new int[2];
    private boolean redstone = false;
    private boolean linked = false;
    private String startText = "";
    private String endText = "";

    private Button redstoneButton;
    private final Button[] toggleButtons = new Button[2];

    public ZoneScreen(ZoneMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.type = menu.zoneType();
        this.imageWidth = 372;
        this.imageHeight = 196;
    }

    private static String fmt(net.minecraft.core.BlockPos p) {
        return p.getX() + ", " + p.getY() + ", " + p.getZ();
    }

    private int step() {
        return Screen.hasShiftDown() ? 5 : 1;
    }

    private Component onOff(boolean v) {
        return Component.translatable(v ? "gui.coastercontrolpanel.on" : "gui.coastercontrolpanel.off");
    }

    @Override
    protected void init() {
        super.init();
        for (int i = 0; i < 2; i++) {
            setting[i] = type.settings[i].def();
        }
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(menu.getPos()) instanceof ZoneBlockEntity z) {
            clear = z.getClearDelay();
            setting[0] = z.getSetting(0);
            setting[1] = z.getSetting(1);
            redstone = z.isRedstoneInput();
            linked = z.hasTrack();
            startText = z.getAnchorA() == null ? "" : fmt(z.getAnchorA());
            endText = z.getAnchorB() == null ? "" : fmt(z.getAnchorB());
        }

        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(leftPos + 146, topPos + 3, 38, 14).build());

        addPair(100, () -> clear = Math.max(0, clear - step()), () -> clear = Math.min(30, clear + step()));
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            ZoneType.Setting s = type.settings[i];
            int y = 118 + i * 18;
            if (s.toggle()) {
                toggleButtons[i] = Button.builder(onOff(setting[i] == 1), b -> {
                    setting[idx] = setting[idx] == 1 ? 0 : 1;
                    b.setMessage(onOff(setting[idx] == 1));
                }).bounds(leftPos + 80, topPos + y, 104, 16).build();
                addRenderableWidget(toggleButtons[i]);
            } else {
                addPair(y, () -> setting[idx] = Math.max(s.min(), setting[idx] - step()),
                        () -> setting[idx] = Math.min(s.max(), setting[idx] + step()));
            }
        }

        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.section_show"),
                b -> send(true, false)).bounds(leftPos + 199, topPos + 20, 80, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.zone_unlink"),
                b -> {
                    linked = false;
                    send(false, true);
                }).bounds(leftPos + 283, topPos + 20, 80, 16).build());
        redstoneButton = Button.builder(redstoneText(), b -> {
            redstone = !redstone;
            b.setMessage(redstoneText());
        }).bounds(leftPos + 199, topPos + 40, 164, 16).build();
        addRenderableWidget(redstoneButton);
    }

    private Component redstoneText() {
        return Component.translatable("gui.coastercontrolpanel.zone_redstone", onOff(redstone));
    }

    private void addPair(int y, Runnable minus, Runnable plus) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> minus.run())
                .bounds(leftPos + 80, topPos + y, 18, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> plus.run())
                .bounds(leftPos + 166, topPos + y, 18, 16).build());
    }

    private void send(boolean show, boolean clearTrack) {
        PacketDistributor.sendToServer(new ZoneConfigPacket(menu.getPos(), clear,
                setting[0], setting[1], redstone, show, clearTrack));
    }

    @Override
    public void removed() {
        send(false, false);
        super.removed();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x0 = leftPos;
        int y0 = topPos;
        g.fill(x0, y0, x0 + imageWidth, y0 + imageHeight, 0xFF3A3E4D);
        g.fill(x0 + 1, y0 + 1, x0 + imageWidth - 1, y0 + imageHeight - 1, 0xFF1B1D24);
        g.fill(x0 + 190, y0 + 4, x0 + 191, y0 + imageHeight - 4, 0xFF3A3E4D);
        for (Slot slot : menu.slots) {
            int sx = x0 + slot.x - 1;
            int sy = y0 + slot.y - 1;
            g.fill(sx, sy, sx + 18, sy + 18, 0xFF3A3E4D);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D0E12);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int dim = 0x7A8098;
        int text = 0xE0E4F0;
        g.drawString(font, title, 8, 6, 0xFFFFFF, false);
        for (int i = 0; i < type.slots(); i++) {
            Component label = Component.translatable("gui.coastercontrolpanel.zone." + type.key + ".slot."
                    + type.slotKeys[i]);
            Component tag = Component.translatable(type.isInput[i] ? "gui.coastercontrolpanel.zone_in"
                    : "gui.coastercontrolpanel.zone_out");
            g.drawString(font, Component.empty().append(label).append(" ").append(tag), 8, 22 + i * 19, text, false);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.section_clear"), 8, 104, text, false);
        g.drawCenteredString(font, clear + " s", 132, 104, 0xFFFFFF);
        for (int i = 0; i < 2; i++) {
            ZoneType.Setting s = type.settings[i];
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone." + type.key + ".setting."
                    + s.key()), 8, 122 + i * 18, text, false);
            if (!s.toggle()) {
                g.drawCenteredString(font, setting[i] + " s", 132, 122 + i * 18, 0xFFFFFF);
            }
        }
        if (linked) {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_start", startText), 199, 62, 0x7CE08A, false);
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_end", endText), 199, 74, 0xF0A060, false);
        } else {
            g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone_not_linked"), 199, 62, 0xE08080, false);
        }
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.zone." + type.key + ".hint"),
                199, 88, dim, false);
        g.drawString(font, Component.translatable("gui.coastercontrolpanel.inventory"), 199, 98, dim, false);
    }
}
