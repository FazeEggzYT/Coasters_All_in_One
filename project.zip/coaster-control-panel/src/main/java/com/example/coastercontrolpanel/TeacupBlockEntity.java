package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The engine of a Teacup Ride. The platter (Platter Hub and Plates) is one Create moving structure turning around the
 * hub. Every cup (a Cup Hub with its floor, walls and seats) is a moving structure of its own that is carried around
 * with the platter and also turns on its own.
 */
public class TeacupBlockEntity extends BlockEntity implements IControlContraption, RideEngine {
    public TeacupSettings cfg = new TeacupSettings();
    public final TeacupMotion motion = new TeacupMotion();

    @Nullable
    private ControlledContraptionEntity platterEntity;
    private final Map<BlockPos, ControlledContraptionEntity> cups = new HashMap<>();
    private BlockPos hub = BlockPos.ZERO;
    private int preTicks;
    private int orphanTicks;
    private int syncTicks;
    private int expectedCups;
    private boolean lastPower;
    private final RideLinks links = new RideLinks(this);
    private boolean justFinished;
    private int lastPhase;
    private int lastStep = -1;
    private boolean needRestore;

    /** Shown angles in degrees, for the screen and for the client. */
    public float shownPlatter;
    public float shownCup;
    private int shownCupMode;
    private boolean stateSeen;

    public TeacupBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.TEACUP_BE.get(), pos, state);
        if (state.is(CoasterControlPanel.CAROUSEL_BASE_BLOCK.get())) {
            cfg.preset(4);
        }
    }

    /** True when this engine belongs to a Carousel: there are no cups, everything is on the deck. */
    public boolean isCarousel() {
        return getBlockState().is(CoasterControlPanel.CAROUSEL_BASE_BLOCK.get());
    }

    // ---- IControlContraption

    private static boolean isPlatter(ControlledContraptionEntity e) {
        return e.getContraption() != null && SwingCarriage.isPlatter(e.getContraption());
    }

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return contraption == platterEntity || cups.containsValue(contraption);
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        if (isPlatter(contraption)) {
            platterEntity = contraption;
        } else if (contraption.getContraption() != null && contraption.getContraption().anchor != null) {
            cups.put(contraption.getContraption().anchor, contraption);
        }
        contraption.setRotationAxis(Direction.Axis.Y);
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && motion.phase == TeacupMotion.RUNNING) {
            motion.halt();
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    private void pollLinks() {
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.HALT) && !idle()) {
            control(ACTION_HALT);
        }
        links.tickOutputs(!idle(), motion.phase == TeacupMotion.HALTED);
        justFinished = false;
    }

    // ---- controls

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return motion.phase == TeacupMotion.IDLE;
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        if (!idle()) {
            return;
        }
        cfg = TeacupSettings.fromTag(tag);
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> startRide();
            case ACTION_PAUSE -> {
                if (motion.phase == TeacupMotion.COUNTDOWN) {
                    motion.phase = TeacupMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.togglePause();
                }
            }
            case ACTION_END -> {
                if (motion.phase == TeacupMotion.COUNTDOWN) {
                    motion.phase = TeacupMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.end();
                }
            }
            case ACTION_HALT -> motion.halt();
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        redstone(level.hasNeighborSignal(worldPosition) || DropTowerBlocks.controllerPowered(level, worldPosition) || links.on(RideLinks.START));
    }

    public void redstone(boolean power) {
        if (power == lastPower) {
            return;
        }
        lastPower = power;
        if (power && idle()) {
            control(ACTION_START);
        } else if (!power && cfg.redstoneMode == 1 && !idle()) {
            control(ACTION_END);
        }
    }

    private void startRide() {
        if (!idle() || level == null) {
            return;
        }
        BlockPos h = TeacupBlocks.findHub(level, worldPosition);
        if (h == null) {
            tell("no_hub");
            return;
        }
        if (!isCarousel() && findCups(h).isEmpty()) {
            tell("no_cup");
            return;
        }
        preTicks = Math.round(cfg.preDelay * 20.0F);
        motion.phase = TeacupMotion.COUNTDOWN;
        if (preTicks <= 0) {
            beginRide();
        } else {
            tell("starting");
        }
    }

    /** Cup Hubs on the platter: within 16 blocks sideways and up to 4 blocks above or below the hub. */
    private List<BlockPos> findCups(BlockPos h) {
        List<BlockPos> out = new ArrayList<>();
        if (level == null) {
            return out;
        }
        for (BlockPos p : BlockPos.betweenClosed(h.offset(-16, -4, -16), h.offset(16, 4, 16))) {
            if (level.getBlockState(p).getBlock() instanceof TeacupBlocks.CupHub) {
                out.add(p.immutable());
            }
        }
        out.sort(Comparator.comparingLong(BlockPos::asLong));
        return out;
    }

    // ---- assembling

    private void beginRide() {
        if (level == null) {
            return;
        }
        BlockPos h = TeacupBlocks.findHub(level, worldPosition);
        if (h == null) {
            motion.phase = TeacupMotion.IDLE;
            tell("no_hub");
            return;
        }
        List<BlockPos> hubs = findCups(h);
        if (hubs.isEmpty() && !isCarousel()) {
            motion.phase = TeacupMotion.IDLE;
            tell("no_cup");
            return;
        }
        SwingCarriage.Part platterPart = new SwingCarriage.Part();
        List<SwingCarriage.Part> cupParts = new ArrayList<>();
        try {
            if (!platterPart.assemble(level, h) || platterPart.getBlocks().isEmpty()) {
                motion.phase = TeacupMotion.IDLE;
                tell("empty");
                return;
            }
            for (BlockPos c : hubs) {
                SwingCarriage.Part part = new SwingCarriage.Part();
                SwingCarriage.Carry.begin(cfg.carryAll, c, 4, 4, 1);
                try {
                    if (!part.assemble(level, c) || part.getBlocks().isEmpty()) {
                        motion.phase = TeacupMotion.IDLE;
                        tell("empty");
                        return;
                    }
                } finally {
                    SwingCarriage.Carry.end();
                }
                cupParts.add(part);
            }
        } catch (AssemblyException e) {
            motion.phase = TeacupMotion.IDLE;
            for (ServerPlayer sp : nearby()) {
                sp.displayClientMessage(e.component, true);
            }
            return;
        }
        platterPart.removeBlocksFromWorld(level, BlockPos.ZERO);
        for (SwingCarriage.Part part : cupParts) {
            part.removeBlocksFromWorld(level, BlockPos.ZERO);
        }
        hub = h;
        cups.clear();
        platterEntity = ControlledContraptionEntity.create(level, this, platterPart);
        platterEntity.setRotationAxis(Direction.Axis.Y);
        platterEntity.setPos(h.getX(), h.getY(), h.getZ());
        level.addFreshEntity(platterEntity);
        for (int i = 0; i < hubs.size(); i++) {
            BlockPos c = hubs.get(i);
            ControlledContraptionEntity e = ControlledContraptionEntity.create(level, this, cupParts.get(i));
            e.setRotationAxis(Direction.Axis.Y);
            e.setPos(c.getX(), c.getY(), c.getZ());
            level.addFreshEntity(e);
            cups.put(c, e);
        }
        expectedCups = hubs.size();
        motion.start();
        orphanTicks = 0;
        syncNow();
    }

    /** Puts everything back as blocks where it started (the angles always end on a whole turn). */
    void landAll() {
        if (level != null && !level.isClientSide) {
            if (platterEntity != null) {
                platterEntity.setAngle(0);
                platterEntity.setPos(hub.getX(), hub.getY(), hub.getZ());
                platterEntity.setContraptionMotion(Vec3.ZERO);
            }
            for (Map.Entry<BlockPos, ControlledContraptionEntity> en : cups.entrySet()) {
                en.getValue().setAngle(0);
                en.getValue().setPos(en.getKey().getX(), en.getKey().getY(), en.getKey().getZ());
                en.getValue().setContraptionMotion(Vec3.ZERO);
            }
            if (platterEntity != null) {
                platterEntity.disassemble();
                platterEntity.discard();
            }
            for (ControlledContraptionEntity e : cups.values()) {
                e.disassemble();
                e.discard();
            }
        }
        platterEntity = null;
        cups.clear();
        motion.platter = 0;
        motion.cup = 0;
        motion.platterRate = 0;
        motion.cupRate = 0;
    }

    // ---- placing everything for the current angles (both sides)

    private void place(double platterDeg, double cupDeg, int cupMode) {
        if (platterEntity == null || !platterEntity.isAlive() || cups.isEmpty()) {
            return;
        }
        platterEntity.setRotationAxis(Direction.Axis.Y);
        platterEntity.setAngle((float) platterDeg);
        Vec3 centre = Vec3.atCenterOf(hub);
        List<BlockPos> order = new ArrayList<>(cups.keySet());
        order.sort(Comparator.comparingLong(BlockPos::asLong));
        for (int i = 0; i < order.size(); i++) {
            ControlledContraptionEntity e = cups.get(order.get(i));
            if (e == null || !e.isAlive()) {
                continue;
            }
            e.setRotationAxis(Direction.Axis.Y);
            Vec3 offset = Vec3.atCenterOf(order.get(i)).subtract(centre);
            Vec3 now = centre.add(platterEntity.applyRotation(offset, 1.0F));
            double dx = now.x - 0.5 - e.getX();
            double dy = now.y - 0.5 - e.getY();
            double dz = now.z - 0.5 - e.getZ();
            if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) > 1.0E-7) {
                e.setContraptionMotion(new Vec3(dx, dy, dz));
                e.move(dx, dy, dz);
            }
            double sign = cupMode == 1 && i % 2 == 1 ? -1.0 : 1.0;
            e.setAngle((float) (platterDeg + sign * cupDeg));
        }
    }

    // ---- client side

    public void receiveState(float platter, float cup, int phase, BlockPos h, int cupMode) {
        shownPlatter = platter;
        shownCup = cup;
        motion.phase = phase;
        hub = h;
        shownCupMode = cupMode;
        stateSeen = true;
    }

    public void clientTick() {
        if (!stateSeen || motion.phase == TeacupMotion.IDLE) {
            return;
        }
        place(shownPlatter, shownCup, shownCupMode);
    }

    // ---- ticking (server)

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        pollLinks();
        if (needRestore) {
            needRestore = false;
            motion.restoreAfterLoad();
        }
        if (motion.phase == TeacupMotion.IDLE) {
            return;
        }
        if (motion.phase == TeacupMotion.COUNTDOWN) {
            if (--preTicks <= 0) {
                beginRide();
            }
            return;
        }
        boolean complete = platterEntity != null && platterEntity.isAlive() && cups.size() >= Math.max(isCarousel() ? 0 : 1, expectedCups)
                && cups.values().stream().allMatch(AbstractContraptionEntity::isAlive);
        if (!complete) {
            if (++orphanTicks > 200) {
                motion.phase = TeacupMotion.IDLE;
                platterEntity = null;
                cups.clear();
                tell("lost");
                syncNow();
            }
            return;
        }
        orphanTicks = 0;
        motion.tick(cfg, 1.0 / 20.0);
        if (motion.landed) {
            landAll();
            motion.landed = false;
            justFinished = true;
            tell("finished");
            syncNow();
            return;
        }
        shownPlatter = (float) (motion.platter * (cfg.platterDir == 0 ? 1.0 : -1.0));
        shownCup = (float) motion.cup;
        place(shownPlatter, shownCup, cfg.cupMode);
        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                new TeacupStatePacket(worldPosition, shownPlatter, shownCup, motion.phase, hub.asLong(), cfg.cupMode));
        if (motion.phase == TeacupMotion.PAUSED && motion.finished && lastPhase != motion.phase) {
            tell("waiting_end");
        }
        if (motion.phase != lastPhase || motion.stepIndex != lastStep || ++syncTicks >= 10) {
            lastPhase = motion.phase;
            lastStep = motion.stepIndex;
            syncNow();
        }
    }

    private List<ServerPlayer> nearby() {
        if (level == null) {
            return List.of();
        }
        return ((ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 1600.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.teacup." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** The base was broken mid-ride: everything is put down where it is. */
    public void baseRemoved() {
        if (level != null && !level.isClientSide && (platterEntity != null || !cups.isEmpty())) {
            landAll();
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putInt("Phase", motion.phase);
        tag.putInt("Step", motion.stepIndex);
        tag.putInt("Loop", motion.loop);
        tag.putDouble("StepTime", motion.stepTime);
        tag.putDouble("Platter", motion.platter);
        tag.putDouble("Cup", motion.cup);
        tag.putDouble("PlatterRate", motion.platterRate);
        tag.putDouble("CupRate", motion.cupRate);
        tag.putBoolean("Finished", motion.finished);
        tag.putLong("Hub", hub.asLong());
        tag.putInt("Cups", expectedCups);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = TeacupSettings.fromTag(tag.getCompound("Cfg"));
        motion.phase = tag.getInt("Phase");
        motion.stepIndex = tag.getInt("Step");
        motion.loop = tag.getInt("Loop");
        motion.stepTime = tag.getDouble("StepTime");
        motion.platter = tag.getDouble("Platter");
        motion.cup = tag.getDouble("Cup");
        motion.platterRate = tag.getDouble("PlatterRate");
        motion.cupRate = tag.getDouble("CupRate");
        motion.finished = tag.getBoolean("Finished");
        hub = BlockPos.of(tag.getLong("Hub"));
        expectedCups = tag.getInt("Cups");
        links.load(tag, registries);
        needRestore = true;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
