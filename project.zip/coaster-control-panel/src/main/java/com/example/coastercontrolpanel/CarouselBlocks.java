package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The blocks of the Carousel. The same engine as the Teacup Ride turns the whole deck, with the horses, poles and roof
 * on it; there are no cups. A seat on top of a Carousel Horse is carried with it.
 */
public final class CarouselBlocks {
    private CarouselBlocks() {
    }

    public static class BaseBlock extends TeacupBlocks.BaseBlock {
        public BaseBlock(Properties properties) {
            super(properties);
        }
    }

    /** The centre of the deck: it turns around this block. */
    public static class Hub extends TeacupBlocks.PlatterHub {
        public Hub(Properties properties) {
            super(properties);
        }
    }

    public static class Deck extends TeacupBlocks.PlatterPlate {
        public Deck(Properties properties) {
            super(properties);
        }
    }

    /** A horse. Put a seat on its back. */
    public static class Horse extends TeacupBlocks.PlatterPart {
        private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 13, 14);

        public Horse(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** A brass pole. */
    public static class Pole extends TeacupBlocks.PlatterPart {
        private static final VoxelShape SHAPE = Block.box(6, 0, 6, 10, 16, 10);

        public Pole(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** A piece of the striped roof. */
    public static class Roof extends TeacupBlocks.PlatterPart {
        private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 8, 16);

        public Roof(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }
}
