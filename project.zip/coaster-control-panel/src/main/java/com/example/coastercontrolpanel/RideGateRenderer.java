package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the swinging gate leaf. The hinge is the left post as seen from the front. */
public class RideGateRenderer implements BlockEntityRenderer<RideGateBlockEntity> {
    public RideGateRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(RideGateBlockEntity gate, float partialTick, PoseStack pose, MultiBufferSource buffer,
                       int light, int overlay) {
        BlockState state = gate.getBlockState();
        if (!(state.getBlock() instanceof RideGateBlock)) {
            return;
        }
        float p = Mth.lerp(partialTick, gate.prevProgress, gate.progress);
        float eased = p * p * (3.0F - 2.0F * p);
        float yaw = switch (state.getValue(RideGateBlock.FACING)) {
            case EAST -> 90.0F;
            case SOUTH -> 180.0F;
            case WEST -> 270.0F;
            default -> 0.0F;
        };
        pose.pushPose();
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-yaw));
        pose.translate(-0.5, -0.5, -0.5);
        pose.translate(2.0 / 16.0, 0.0, 8.0 / 16.0);
        pose.mulPose(Axis.YP.rotationDegrees(90.0F * eased));
        if (state.getValue(RideGateBlock.LINKED)) {
            // No latch post here: stretch the leaf so it reaches the next gate's hinge post.
            pose.scale(14.0F / 12.0F, 1.0F, 1.0F);
        }
        pose.translate(-2.0 / 16.0, 0.0, -8.0 / 16.0);
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(
                CoasterControlPanel.leafFor(state.getBlock()).defaultBlockState(), pose, buffer, light, overlay);
        pose.popPose();
    }
}
