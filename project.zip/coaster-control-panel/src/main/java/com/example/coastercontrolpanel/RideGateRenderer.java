package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the swinging gate leaf. The hinge is the left post as seen from the front. */
public class RideGateRenderer implements BlockEntityRenderer<RideGateBlockEntity> {
    public RideGateRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(RideGateBlockEntity gate, float partialTick, PoseStack pose, MultiBufferSource buffer,
                       int light, int overlay) {
        BlockState state = gate.getBlockState();
        if (!(state.getBlock() instanceof RideGateBlock)) {
            return;
        }
        float p = Mth.lerp(partialTick, gate.prevProgress, gate.progress);
        float eased = p * p * (3.0F - 2.0F * p);
        float yaw = switch (state.getValue(RideGateBlock.FACING)) {
            case EAST -> 90.0F;
            case SOUTH -> 180.0F;
            case WEST -> 270.0F;
            default -> 0.0F;
        };
        boolean dbl = state.getBlock() instanceof RideDoubleGateBlock;
        boolean[] sides = dbl ? new boolean[]{false, true} : new boolean[]{state.getValue(RideGateBlock.RIGHT)};
        for (boolean right : sides) {
            pose.pushPose();
            pose.translate(0.5, 0.5, 0.5);
            pose.mulPose(Axis.YP.rotationDegrees(-yaw));
            pose.translate(-0.5, -0.5, -0.5);
            double hinge = right ? 14.0 / 16.0 : 2.0 / 16.0;
            pose.translate(hinge, 0.0, 8.0 / 16.0);
            pose.mulPose(Axis.YP.rotationDegrees((right ? -90.0F : 90.0F) * eased));
            if (dbl || state.getValue(RideGateBlock.LINKED)) {
                // Double gate: no post in the middle, so each leaf stretches to meet the other halfway.
                pose.scale(14.0F / 12.0F, 1.0F, 1.0F);
            }
            pose.translate(-hinge, 0.0, -8.0 / 16.0);
            if (right) {
                // Turn the leaf round so its hinge end is on the right post.
                pose.translate(0.5, 0.0, 0.5);
                pose.mulPose(Axis.YP.rotationDegrees(180.0F));
                pose.translate(-0.5, 0.0, -0.5);
            }
            Minecraft.getInstance().getBlockRenderer().renderSingleBlock(
                    CoasterControlPanel.leafFor(state.getBlock()).defaultBlockState(), pose, buffer, light, overlay);
            pose.popPose();
        }
    }
}
