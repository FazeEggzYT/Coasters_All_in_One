package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AddPackFindersEvent;

import java.util.Optional;

/**
 * Client only: adds the folder with the announcement files as a resource pack that is always on,
 * so the sound engine can read the .ogg files other players uploaded.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClipPackEvents {
    @SubscribeEvent
    public static void onAddPacks(AddPackFindersEvent event) {
        if (event.getPackType() != PackType.CLIENT_RESOURCES) {
            return;
        }
        ClipClient.prepare();
        event.addRepositorySource(consumer -> {
            PackLocationInfo info = new PackLocationInfo("coastercontrolpanel_clips",
                    Component.literal("Announcement clips"), PackSource.BUILT_IN, Optional.empty());
            Pack pack = Pack.readMetaAndCreate(info, new PathPackResources.PathResourcesSupplier(ClipClient.packDir()),
                    PackType.CLIENT_RESOURCES, new Pack.SelectionConfig(true,
                            Pack.Position.TOP, false));
            if (pack != null) {
                consumer.accept(pack);
            }
        });
    }
}
