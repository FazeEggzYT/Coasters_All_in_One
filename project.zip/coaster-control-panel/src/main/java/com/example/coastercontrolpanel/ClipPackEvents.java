package com.example.coastercontrolpanel;

import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AddPackFindersEvent;

import java.util.Optional;

/**
 * Client only: adds the folder with the announcement files as a resource pack that is always on,
 * so the sound engine can read the .ogg files other players uploaded.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClipPackEvents {
    @SubscribeEvent
    public static void onAddPacks(AddPackFindersEvent event) {
        if (event.getPackType() != PackType.CLIENT_RESOURCES) {
            return;
        }
        ClipClient.prepare();
        event.addRepositorySource(consumer -> {
            PackLocationInfo info = new PackLocationInfo("coastercontrolpanel_clips",
                    Component.literal("Announcement clips"), PackSource.BUILT_IN, Optional.empty());
            Pack pack = create(info, new PathPackResources.PathResourcesSupplier(ClipClient.packDir()));
            if (pack != null) {
                consumer.accept(pack);
            }
        });
    }

    /**
     * Pack.readMetaAndCreate changed its last argument between versions, so it is called by reflection:
     * whatever the last parameter type is (a config record or a position), it is filled with "required, top, fixed".
     */
    private static Pack create(PackLocationInfo info, Object supplier) {
        try {
            for (java.lang.reflect.Method m : Pack.class.getMethods()) {
                if (!m.getName().equals("readMetaAndCreate") || m.getParameterCount() != 4) {
                    continue;
                }
                Class<?> cfg = m.getParameterTypes()[3];
                Object arg;
                if (cfg.isEnum()) {
                    arg = cfg.getField("TOP").get(null);
                } else {
                    java.lang.reflect.Constructor<?> c = cfg.getConstructors()[0];
                    Class<?>[] types = c.getParameterTypes();
                    Object top = types[1].getField("TOP").get(null);
                    arg = c.newInstance(true, top, false);
                }
                return (Pack) m.invoke(null, info, supplier, PackType.CLIENT_RESOURCES, arg);
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            CoasterControlPanel.LOGGER.warn("Could not add the announcement clip pack", e);
        }
        return null;
    }
}
