package com.example.coastercontrolpanel;

import java.util.List;

/**
 * What angle a bearing track is at, at a given time. Pure maths, no world access. The angle at any time is worked out
 * from the clips alone, so pressing Play, Stop and Play again always gives the same result.
 */
public final class TimelineMath {
    public static final int MOVE_TO = 0;
    public static final int HOLD = 1;
    public static final int RETURN = 2;
    public static final int ROTATE_BY = 3;
    public static final int SPIN = 4;
    public static final int WAIT = 5;
    public static final int KINDS = 6;

    public static final int LINEAR = 0;
    public static final int EASE_IN = 1;
    public static final int EASE_OUT = 2;
    public static final int EASE_BOTH = 3;
    public static final int EASES = 4;

    private TimelineMath() {
    }

    public static float ease(int style, float p) {
        p = Math.max(0.0F, Math.min(1.0F, p));
        return switch (style) {
            case EASE_IN -> p * p;
            case EASE_OUT -> 1.0F - (1.0F - p) * (1.0F - p);
            case EASE_BOTH -> p * p * (3.0F - 2.0F * p);
            default -> p;
        };
    }

    private static float endOf(AnimationControllerBlockEntity.Clip c, float from) {
        return switch (c.anim()) {
            case MOVE_TO, RETURN -> c.value();
            case ROTATE_BY -> from + c.value();
            case SPIN -> from + c.value() * c.length() / 20.0F;
            default -> from;
        };
    }

    /** @param clips the clips of one track, sorted by start tick */
    public static float angleAt(List<AnimationControllerBlockEntity.Clip> clips, long t, float base) {
        float a = base;
        for (int i = 0; i < clips.size(); i++) {
            AnimationControllerBlockEntity.Clip c = clips.get(i);
            if (t < c.start()) {
                return a;
            }
            float end = endOf(c, a);
            boolean last = i + 1 >= clips.size() || clips.get(i + 1).start() > t;
            if (!last) {
                a = end;
                continue;
            }
            if (t >= c.start() + c.length()) {
                return end;
            }
            float p = (t - c.start()) / (float) Math.max(1, c.length());
            if (c.anim() == SPIN) {
                return a + c.value() * (t - c.start()) / 20.0F;
            }
            return a + (end - a) * ease(c.ease(), p);
        }
        return a;
    }
}
