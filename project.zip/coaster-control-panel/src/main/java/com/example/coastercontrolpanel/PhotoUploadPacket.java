package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Client to server: a piece of the finished photo. */
public record PhotoUploadPacket(BlockPos camera, int index, int total, byte[] data) implements CustomPacketPayload {
    public static final Type<PhotoUploadPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "photo_upload"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PhotoUploadPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.camera);
                buf.writeVarInt(p.index);
                buf.writeVarInt(p.total);
                buf.writeByteArray(p.data);
            },
            buf -> new PhotoUploadPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(),
                    buf.readByteArray(PhotoStore.CHUNK + 16)));

    private static final class Upload {
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        BlockPos camera;
        int next = 0;
        int total;
    }

    private static final Map<UUID, Upload> UPLOADS = new HashMap<>();

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(PhotoUploadPacket p, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        CameraBlockEntity camera = CameraBlockEntity.lookup(player, p.camera);
        if (camera == null || p.total < 1 || p.total > PhotoStore.MAX_BYTES / PhotoStore.CHUNK + 2) {
            return;
        }
        Upload up;
        if (p.index == 0) {
            up = new Upload();
            up.camera = p.camera;
            up.total = p.total;
            UPLOADS.put(player.getUUID(), up);
        } else {
            up = UPLOADS.get(player.getUUID());
            if (up == null || !up.camera.equals(p.camera) || up.next != p.index) {
                UPLOADS.remove(player.getUUID());
                return;
            }
        }
        up.bytes.writeBytes(p.data);
        up.next = p.index + 1;
        if (up.bytes.size() > PhotoStore.MAX_BYTES) {
            UPLOADS.remove(player.getUUID());
            return;
        }
        if (up.next < up.total) {
            return;
        }
        UPLOADS.remove(player.getUUID());
        byte[] png = up.bytes.toByteArray();
        if (PhotoStore.looksLikePng(png) && PhotoStore.save(player.server, p.camera, png)) {
            camera.photoReceived();
        }
    }
}
