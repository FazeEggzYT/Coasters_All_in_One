package com.example.coastercontrolpanel;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.regex.Pattern;

/** Server side: the uploaded announcement files, kept in the world folder under their hash. */
public final class ClipStore {
    public static final int MAX_BYTES = 1_500_000;
    public static final int CHUNK = 30_000;
    private static final Pattern HASH = Pattern.compile("[0-9a-f]{16}");

    private ClipStore() {
    }

    public static boolean validHash(String hash) {
        return HASH.matcher(hash).matches();
    }

    private static Path dir(MinecraftServer server) throws IOException {
        Path dir = server.getWorldPath(LevelResource.ROOT).resolve("coastercontrolpanel_audio");
        Files.createDirectories(dir);
        return dir;
    }

    /** Looks like an Ogg file? */
    public static boolean looksLikeOgg(byte[] bytes) {
        return bytes.length > 4 && bytes[0] == 'O' && bytes[1] == 'g' && bytes[2] == 'g' && bytes[3] == 'S';
    }

    /** Saves the file and returns its hash, or null if it could not be saved. */
    @Nullable
    public static String save(MinecraftServer server, byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-1").digest(bytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                sb.append(String.format("%02x", digest[i]));
            }
            String hash = sb.toString();
            Files.write(dir(server).resolve(hash + ".ogg"), bytes);
            return hash;
        } catch (Exception e) {
            CoasterControlPanel.LOGGER.warn("Could not save announcement clip", e);
            return null;
        }
    }

    @Nullable
    public static byte[] load(MinecraftServer server, String hash) {
        if (!validHash(hash)) {
            return null;
        }
        try {
            Path file = dir(server).resolve(hash + ".ogg");
            return Files.exists(file) ? Files.readAllBytes(file) : null;
        } catch (IOException e) {
            return null;
        }
    }
}
