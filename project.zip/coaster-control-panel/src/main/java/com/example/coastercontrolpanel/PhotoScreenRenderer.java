package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;

/** Draws the photo on a Photo Screen. When screens are joined, each one draws its own part of the picture. */
public class PhotoScreenRenderer implements BlockEntityRenderer<PhotoScreenBlockEntity> {
    public PhotoScreenRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(PhotoScreenBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int packedLight, int packedOverlay) {
        PhotoScreenBlockEntity.Wall wall = be.wall();
        if (wall == null || wall.camera() == null || wall.version() <= 0) {
            return;
        }
        PhotoClient.Entry entry = PhotoClient.get(wall.camera(), wall.version());
        if (entry == null) {
            return;
        }
        Direction facing = be.getBlockState().getValue(PhotoScreenBlock.FACING);
        float uLeft = wall.col() / (float) wall.cols();
        float uRight = (wall.col() + 1) / (float) wall.cols();
        float vTop = wall.row() / (float) wall.rows();
        float vBottom = (wall.row() + 1) / (float) wall.rows();

        pose.pushPose();
        pose.translate(0.5, 0.0, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
        pose.translate(-0.5, 0.0, -0.5);
        PoseStack.Pose p = pose.last();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(entry.loc));
        float z = 14.0F / 16.0F - 0.002F;
        int light = LightTexture.FULL_BRIGHT;
        int overlay = OverlayTexture.NO_OVERLAY;
        // local x = 1 is the viewer's left side, x = 0 the right side
        vertex(vc, p, 1, 1, z, uLeft, vTop, overlay, light);
        vertex(vc, p, 0, 1, z, uRight, vTop, overlay, light);
        vertex(vc, p, 0, 0, z, uRight, vBottom, overlay, light);
        vertex(vc, p, 1, 0, z, uLeft, vBottom, overlay, light);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v,
                               int overlay, int light) {
        vc.addVertex(pose, x, y, z).setColor(255, 255, 255, 255).setUv(u, v).setOverlay(overlay).setLight(light)
                .setNormal(pose, 0.0F, 0.0F, -1.0F);
    }

    @Override
    public boolean shouldRenderOffScreen(PhotoScreenBlockEntity be) {
        return false;
    }
}
