package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * The engine of a Swivel Bearing. The structure on the Swivel Plate is picked up as one Create moving structure and
 * turned to the wanted angle. It stays picked up while the angle is not zero, and is put back as blocks when it is
 * back at zero. The wanted angle comes from the settings and from a redstone or wireless signal.
 */
public class SwivelBlockEntity extends BlockEntity implements IControlContraption, RideEngine, TimelineTarget {
    public static final int ACTION_ASSEMBLE = 10;
    public static final int ACTION_DISASSEMBLE = 11;

    public SwivelSettings cfg = new SwivelSettings();

    @Nullable
    private ControlledContraptionEntity entity;
    /** Current angle in degrees (also the number the client turns the structure to). */
    public float angle;
    private boolean assembled;
    /** The latest command, 0 to 15: 0 goes to the rest angle, anything else to the active angle (or between). */
    private int cmdLevel;
    private int lastLevel;
    private boolean hold;
    private int orphanTicks;
    private int syncTicks;
    private int failCooldown;
    private float lastSent = Float.NaN;
    /** For the screen. */
    public boolean moving;
    private final RideLinks links = new RideLinks(this);

    // ---- driven by an Animation Controller (not saved)
    private boolean driven;
    private float drivenAngle;
    private long drivenTick;

    // ---- Flip / Spin sequencer (not saved: a reloaded world starts it again from the signal)
    private boolean startRequest;
    private boolean seqRun;
    private boolean finishing;
    private float[] steps = new float[0];
    private int stepIdx;
    private int rep;
    private boolean holding;
    private int phaseTick;
    private int phaseTicks = 1;
    private float from;
    private float to;

    public SwivelBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SWIVEL_BE.get(), pos, state);
    }

    // ---- geometry

    private Direction facing() {
        return getBlockState().getValue(SwivelBlocks.BearingBlock.FACING);
    }

    /** The line the structure turns around. */
    public int kind() {
        return getBlockState().getBlock() instanceof SwivelBlocks.BearingBlock b ? b.kind() : 0;
    }

    /** Flip and Spin Bearings stay assembled until a wrench takes them apart. */
    private boolean keep() {
        return kind() != 0;
    }

    private Direction.Axis axis() {
        Direction f = facing();
        if (cfg.axis == 1) {
            return Direction.Axis.X;
        } else if (cfg.axis == 2) {
            return Direction.Axis.Y;
        } else if (cfg.axis == 3) {
            return Direction.Axis.Z;
        }
        if (kind() != 0) {
            return f.getAxis(); // Flip and Spin turn round the line they face along unless told otherwise
        }
        return switch (cfg.mode) {
            case SwivelSettings.TURN -> Direction.Axis.Y;
            case SwivelSettings.ROLL -> f.getAxis();
            default -> f.getAxis() == Direction.Axis.Y ? Direction.Axis.X
                    : f.getAxis() == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X;
        };
    }

    private BlockPos anchor() {
        return worldPosition.relative(facing());
    }

    public boolean isAssembled() {
        return assembled;
    }

    // ---- IControlContraption

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return contraption == entity;
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        entity = contraption;
        contraption.setRotationAxis(axis());
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && moving) {
            hold = true;
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    // ---- RideEngine

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return !assembled || (keep() && !seqRun && !driven && !moving);
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        SwivelSettings s = SwivelSettings.fromTag(tag);
        if (assembled) {
            s.mode = cfg.mode;
            s.axis = cfg.axis;
        }
        cfg = s;
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> {
                cmdLevel = 15;
                hold = false;
                startRequest = true;
            }
            case ACTION_END -> {
                cmdLevel = 0;
                hold = false;
            }
            case ACTION_PAUSE -> hold = !hold;
            case ACTION_HALT -> hold = true;
            case ACTION_ASSEMBLE -> {
                if (!assembled) {
                    failCooldown = 0;
                    if (!assemble()) {
                        failCooldown = 60;
                    }
                }
            }
            case ACTION_DISASSEMBLE -> wrenchDisassemble();
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        int lvl = Math.max(level.getBestNeighborSignal(worldPosition), links.on(RideLinks.START) ? 15 : 0);
        if (lvl != lastLevel) {
            if (lastLevel == 0 && lvl > 0) {
                startRequest = true;
            }
            lastLevel = lvl;
            cmdLevel = lvl;
            hold = false;
            syncNow();
        }
    }

    private float target() {
        if (cfg.analog) {
            return cfg.rest + (cfg.active - cfg.rest) * cmdLevel / 15.0F;
        }
        return cmdLevel > 0 ? cfg.active : cfg.rest;
    }

    // ---- TimelineTarget

    @Override
    public Component timelineLabel() {
        if (!cfg.name.isEmpty()) {
            return Component.literal(cfg.name);
        }
        return Component.translatable("block.coastercontrolpanel." + (kind() == 1 ? "flip_bearing" : kind() == 2 ? "spin_bearing" : "swivel_bearing"));
    }

    @Override
    public void timelineSet(float degrees) {
        if (level == null || level.isClientSide) {
            return;
        }
        driven = true;
        drivenAngle = Float.isFinite(degrees) ? degrees : 0.0F;
        drivenTick = level.getGameTime();
    }

    @Override
    public void timelineRelease() {
        driven = false;
    }

    /** The wrench: back to the start and into blocks again. */
    public void wrenchDisassemble() {
        if (level == null || level.isClientSide) {
            return;
        }
        seqRun = false;
        driven = false;
        startRequest = false;
        cmdLevel = 0;
        lastLevel = 0;
        if (assembled) {
            angle = 0;
            land();
        }
    }

    // ---- Flip / Spin sequencer

    private void buildSteps() {
        java.util.List<Float> l = new java.util.ArrayList<>();
        if (kind() == 1) {
            if (cfg.flipPos > 0.0F) {
                l.add(cfg.flipPos);
                if (cfg.returnZero) {
                    l.add(0.0F);
                }
            }
            if (cfg.flipNeg > 0.0F) {
                l.add(-cfg.flipNeg);
                if (cfg.returnZero) {
                    l.add(0.0F);
                }
            }
        } else {
            float sign = cfg.spinDir == 1 ? -1.0F : 1.0F;
            l.add(sign * cfg.spinAmount);
            if (cfg.spinReturn) {
                l.add(0.0F);
            }
        }
        steps = new float[l.size()];
        for (int i = 0; i < steps.length; i++) {
            steps[i] = l.get(i);
        }
    }

    private void beginMove(float target) {
        from = angle;
        to = target;
        holding = false;
        phaseTick = 0;
        phaseTicks = Math.max(1, Math.round(Math.abs(to - from) / cfg.speed * 20.0F));
    }

    private void startSequence() {
        buildSteps();
        if (steps.length == 0) {
            return;
        }
        seqRun = true;
        finishing = false;
        stepIdx = 0;
        rep = 0;
        beginMove(steps[0]);
    }

    private void nextStep() {
        if (finishing) {
            seqRun = false;
            return;
        }
        stepIdx++;
        if (stepIdx >= steps.length) {
            rep++;
            stepIdx = 0;
            boolean doneAll = kind() == 2 || (cfg.reps > 0 && rep >= cfg.reps);
            if (doneAll) {
                if (kind() == 1 && Math.abs(angle) > 0.01F) {
                    finishing = true;
                    beginMove(0.0F);
                } else {
                    seqRun = false;
                }
                return;
            }
        }
        beginMove(steps[stepIdx]);
    }

    /** One tick of the Flip or Spin movement. Returns the angle, or NaN when it is not running. */
    private float tickSequencer() {
        if (kind() == 2 && cfg.spinAmount <= 0.0F) {
            // Spin: round and round while the signal is on
            if (cmdLevel > 0 && !hold) {
                float sign = cfg.spinDir == 1 ? -1.0F : 1.0F;
                float a = angle + sign * cfg.speed / 20.0F;
                return a % 360.0F;
            }
            if (cfg.spinReturn && Math.abs(angle) > 0.01F) {
                float a = angle % 360.0F;
                if (a > 180.0F) {
                    a -= 360.0F;
                } else if (a < -180.0F) {
                    a += 360.0F;
                }
                float step = cfg.speed / 20.0F;
                return Math.abs(a) <= step ? 0.0F : a - Math.signum(a) * step;
            }
            return Float.NaN;
        }
        if (startRequest && !seqRun) {
            startRequest = false;
            startSequence();
        }
        startRequest = false;
        if (!seqRun) {
            return Float.NaN;
        }
        if (hold) {
            return angle;
        }
        if (kind() == 1 && cmdLevel == 0 && !finishing) {
            finishing = true; // the signal went away: finish by going to 0
            beginMove(0.0F);
        }
        phaseTick++;
        if (holding) {
            if (phaseTick >= phaseTicks) {
                nextStep();
            }
            return angle;
        }
        float p = Math.min(1.0F, phaseTick / (float) phaseTicks);
        float e = cfg.smooth ? p * p * (3.0F - 2.0F * p) : p;
        float a = from + (to - from) * e;
        if (phaseTick >= phaseTicks) {
            a = to;
            if (Math.abs(to) > 0.01F && cfg.pause > 0.0F && !finishing) {
                holding = true;
                phaseTick = 0;
                phaseTicks = Math.max(1, Math.round(cfg.pause * 20.0F));
            } else {
                angle = a;
                nextStep();
            }
        }
        return a;
    }

    // ---- ticking

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.HALT)) {
            hold = true;
            syncNow();
        }
        moving = false;
        if (failCooldown > 0) {
            failCooldown--;
        }
        if (driven && level.getGameTime() - drivenTick > 3) {
            driven = false; // the Animation Controller stopped
        }
        float plain = hold ? angle : target();
        boolean needs = driven || (keep() ? (startRequest || seqRun || cmdLevel > 0) : (Math.abs(plain) > 1.0E-3F && !hold));
        if (!assembled && needs && failCooldown == 0) {
            if (!assemble()) {
                failCooldown = 60;
                startRequest = false;
                seqRun = false;
            }
        }
        if (assembled) {
            if (entity == null || !entity.isAlive()) {
                if (++orphanTicks > 200) {
                    assembled = false;
                    entity = null;
                    angle = 0;
                    seqRun = false;
                    tell("lost");
                    syncNow();
                }
            } else {
                orphanTicks = 0;
                float desired;
                boolean direct = false;
                if (driven) {
                    direct = true;
                    desired = drivenAngle;
                } else if (keep()) {
                    float seq = tickSequencer();
                    if (!Float.isNaN(seq)) {
                        direct = true;
                        desired = seq;
                    } else {
                        desired = kind() == 2 && !cfg.spinReturn ? angle : 0.0F;
                    }
                } else {
                    desired = plain;
                }
                if (direct) {
                    moving = driven || seqRun || kind() == 2;
                    angle = desired;
                } else {
                    float step = cfg.speed / 20.0F;
                    float d = desired - angle;
                    if (Math.abs(d) <= step) {
                        angle = desired;
                    } else {
                        angle += Math.signum(d) * step;
                        moving = true;
                    }
                }
                if (!keep() && !driven && Math.abs(angle) < 1.0E-3F && Math.abs(desired) < 1.0E-3F) {
                    angle = 0;
                    land();
                } else {
                    entity.setRotationAxis(axis());
                    entity.setAngle(angle);
                    if (angle != lastSent) {
                        lastSent = angle;
                        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                                new SwivelStatePacket(worldPosition, angle));
                    }
                    if (++syncTicks >= 20) {
                        syncNow();
                    }
                }
            }
        }
        links.tickOutputs(moving, !moving && assembled && (keep() ? !seqRun && !driven : Math.abs(angle - cfg.active) < 0.5F));
    }

    public void clientTick() {
        if (entity != null && entity.isAlive() && assembled) {
            entity.setRotationAxis(axis());
            entity.setAngle(angle);
        }
    }

    public void receiveAngle(float a) {
        angle = a;
    }

    // ---- assembling

    private boolean assemble() {
        if (level == null) {
            return false;
        }
        BlockPos a = anchor();
        if (!(level.getBlockState(a).getBlock() instanceof SwivelBlocks.PlateBlock)) {
            tell("no_plate");
            return false;
        }
        SwingCarriage.Part part = new SwingCarriage.Part();
        try {
            SwingCarriage.Carry.begin(cfg.carryAll, a, cfg.reach, cfg.reach, cfg.reach);
            try {
                if (!part.assemble(level, a) || part.getBlocks().isEmpty()) {
                    tell("empty");
                    return false;
                }
            } finally {
                SwingCarriage.Carry.end();
            }
        } catch (AssemblyException e) {
            for (ServerPlayer sp : nearby()) {
                sp.displayClientMessage(e.component, true);
            }
            return false;
        }
        part.removeBlocksFromWorld(level, BlockPos.ZERO);
        entity = ControlledContraptionEntity.create(level, this, part);
        entity.setRotationAxis(axis());
        entity.setPos(a.getX(), a.getY(), a.getZ());
        level.addFreshEntity(entity);
        assembled = true;
        angle = 0;
        lastSent = Float.NaN;
        orphanTicks = 0;
        syncNow();
        return true;
    }

    /** Puts the structure back as blocks, exactly where it started. */
    private void land() {
        if (level != null && !level.isClientSide && entity != null) {
            BlockPos a = anchor();
            entity.setAngle(0);
            entity.setPos(a.getX(), a.getY(), a.getZ());
            entity.setContraptionMotion(Vec3.ZERO);
            entity.disassemble();
            entity.discard();
        }
        entity = null;
        assembled = false;
        angle = 0;
        lastSent = Float.NaN;
        moving = false;
        syncNow();
    }

    /** The bearing was broken while the structure is turned: it is put back flat where it started. */
    public void bearingRemoved() {
        if (level != null && !level.isClientSide && assembled) {
            land();
        }
    }

    private java.util.List<ServerPlayer> nearby() {
        if (level == null) {
            return java.util.List.of();
        }
        return ((ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 900.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.swivel." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putFloat("Angle", angle);
        tag.putBoolean("Assembled", assembled);
        tag.putInt("Cmd", cmdLevel);
        tag.putBoolean("Hold", hold);
        tag.putBoolean("Moving", moving);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = SwivelSettings.fromTag(tag.getCompound("Cfg"));
        angle = tag.getFloat("Angle");
        assembled = tag.getBoolean("Assembled");
        cmdLevel = tag.getInt("Cmd");
        lastLevel = cmdLevel;
        hold = tag.getBoolean("Hold");
        moving = tag.getBoolean("Moving");
        links.load(tag, registries);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    public boolean holding() {
        return hold;
    }

    public float targetAngle() {
        return hold ? angle : target();
    }
}
