package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * The engine of a Swivel Bearing. The structure on the Swivel Plate is picked up as one Create moving structure and
 * turned to the wanted angle. It stays picked up while the angle is not zero, and is put back as blocks when it is
 * back at zero. The wanted angle comes from the settings and from a redstone or wireless signal.
 */
public class SwivelBlockEntity extends BlockEntity implements IControlContraption, RideEngine {
    public SwivelSettings cfg = new SwivelSettings();

    @Nullable
    private ControlledContraptionEntity entity;
    /** Current angle in degrees (also the number the client turns the structure to). */
    public float angle;
    private boolean assembled;
    /** The latest command, 0 to 15: 0 goes to the rest angle, anything else to the active angle (or between). */
    private int cmdLevel;
    private int lastLevel;
    private boolean hold;
    private int orphanTicks;
    private int syncTicks;
    private int failCooldown;
    private float lastSent = Float.NaN;
    /** For the screen. */
    public boolean moving;
    private final RideLinks links = new RideLinks(this);

    public SwivelBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.SWIVEL_BE.get(), pos, state);
    }

    // ---- geometry

    private Direction facing() {
        return getBlockState().getValue(SwivelBlocks.BearingBlock.FACING);
    }

    /** The line the structure turns around. */
    private Direction.Axis axis() {
        Direction f = facing();
        return switch (cfg.mode) {
            case SwivelSettings.TURN -> Direction.Axis.Y;
            case SwivelSettings.ROLL -> f.getAxis();
            default -> f.getAxis() == Direction.Axis.Y ? Direction.Axis.X
                    : f.getAxis() == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X;
        };
    }

    private BlockPos anchor() {
        return worldPosition.relative(facing());
    }

    public boolean isAssembled() {
        return assembled;
    }

    // ---- IControlContraption

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return contraption == entity;
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        entity = contraption;
        contraption.setRotationAxis(axis());
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && moving) {
            hold = true;
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    // ---- RideEngine

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return !assembled;
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        SwivelSettings s = SwivelSettings.fromTag(tag);
        if (assembled) {
            s.mode = cfg.mode;
        }
        cfg = s;
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> {
                cmdLevel = 15;
                hold = false;
            }
            case ACTION_END -> {
                cmdLevel = 0;
                hold = false;
            }
            case ACTION_PAUSE -> hold = !hold;
            case ACTION_HALT -> hold = true;
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        int lvl = Math.max(level.getBestNeighborSignal(worldPosition), links.on(RideLinks.START) ? 15 : 0);
        if (lvl != lastLevel) {
            lastLevel = lvl;
            cmdLevel = lvl;
            hold = false;
            syncNow();
        }
    }

    private float target() {
        if (cfg.analog) {
            return cfg.rest + (cfg.active - cfg.rest) * cmdLevel / 15.0F;
        }
        return cmdLevel > 0 ? cfg.active : cfg.rest;
    }

    // ---- ticking

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.HALT)) {
            hold = true;
            syncNow();
        }
        float target = hold ? angle : target();
        moving = false;
        if (failCooldown > 0) {
            failCooldown--;
        }
        if (!assembled) {
            if (Math.abs(target) > 1.0E-3F && failCooldown == 0 && !hold) {
                if (!assemble()) {
                    failCooldown = 60;
                }
            }
        }
        if (assembled) {
            if (entity == null || !entity.isAlive()) {
                if (++orphanTicks > 200) {
                    assembled = false;
                    entity = null;
                    angle = 0;
                    tell("lost");
                    syncNow();
                }
            } else {
                orphanTicks = 0;
                float step = cfg.speed / 20.0F;
                float d = target - angle;
                if (Math.abs(d) <= step) {
                    angle = target;
                } else {
                    angle += Math.signum(d) * step;
                    moving = true;
                }
                if (Math.abs(angle) < 1.0E-3F && Math.abs(target) < 1.0E-3F) {
                    angle = 0;
                    land();
                } else {
                    entity.setRotationAxis(axis());
                    entity.setAngle(angle);
                    if (angle != lastSent) {
                        lastSent = angle;
                        PacketDistributor.sendToPlayersTrackingChunk((ServerLevel) level, new ChunkPos(worldPosition),
                                new SwivelStatePacket(worldPosition, angle));
                    }
                    if (++syncTicks >= 20) {
                        syncNow();
                    }
                }
            }
        }
        links.tickOutputs(moving, !moving && assembled && Math.abs(angle - cfg.active) < 0.5F);
    }

    public void clientTick() {
        if (entity != null && entity.isAlive() && assembled) {
            entity.setRotationAxis(axis());
            entity.setAngle(angle);
        }
    }

    public void receiveAngle(float a) {
        angle = a;
    }

    // ---- assembling

    private boolean assemble() {
        if (level == null) {
            return false;
        }
        BlockPos a = anchor();
        if (!(level.getBlockState(a).getBlock() instanceof SwivelBlocks.PlateBlock)) {
            tell("no_plate");
            return false;
        }
        SwingCarriage.Part part = new SwingCarriage.Part();
        try {
            SwingCarriage.Carry.begin(cfg.carryAll, a, cfg.reach, cfg.reach, cfg.reach);
            try {
                if (!part.assemble(level, a) || part.getBlocks().isEmpty()) {
                    tell("empty");
                    return false;
                }
            } finally {
                SwingCarriage.Carry.end();
            }
        } catch (AssemblyException e) {
            for (ServerPlayer sp : nearby()) {
                sp.displayClientMessage(e.component, true);
            }
            return false;
        }
        part.removeBlocksFromWorld(level, BlockPos.ZERO);
        entity = ControlledContraptionEntity.create(level, this, part);
        entity.setRotationAxis(axis());
        entity.setPos(a.getX(), a.getY(), a.getZ());
        level.addFreshEntity(entity);
        assembled = true;
        angle = 0;
        lastSent = Float.NaN;
        orphanTicks = 0;
        syncNow();
        return true;
    }

    /** Puts the structure back as blocks, exactly where it started. */
    private void land() {
        if (level != null && !level.isClientSide && entity != null) {
            BlockPos a = anchor();
            entity.setAngle(0);
            entity.setPos(a.getX(), a.getY(), a.getZ());
            entity.setContraptionMotion(Vec3.ZERO);
            entity.disassemble();
            entity.discard();
        }
        entity = null;
        assembled = false;
        angle = 0;
        lastSent = Float.NaN;
        moving = false;
        syncNow();
    }

    /** The bearing was broken while the structure is turned: it is put back flat where it started. */
    public void bearingRemoved() {
        if (level != null && !level.isClientSide && assembled) {
            land();
        }
    }

    private java.util.List<ServerPlayer> nearby() {
        if (level == null) {
            return java.util.List.of();
        }
        return ((ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 900.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.swivel." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putFloat("Angle", angle);
        tag.putBoolean("Assembled", assembled);
        tag.putInt("Cmd", cmdLevel);
        tag.putBoolean("Hold", hold);
        tag.putBoolean("Moving", moving);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = SwivelSettings.fromTag(tag.getCompound("Cfg"));
        angle = tag.getFloat("Angle");
        assembled = tag.getBoolean("Assembled");
        cmdLevel = tag.getInt("Cmd");
        lastLevel = cmdLevel;
        hold = tag.getBoolean("Hold");
        moving = tag.getBoolean("Moving");
        links.load(tag, registries);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    public boolean holding() {
        return hold;
    }

    public float targetAngle() {
        return hold ? angle : target();
    }
}
