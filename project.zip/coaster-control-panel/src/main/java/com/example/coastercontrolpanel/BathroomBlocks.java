package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.context.BlockPlaceContext;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The bathroom pack: toilets, urinals, sinks, dryers, soap, toilet roll, cubicles and signs. */
public final class BathroomBlocks {
    private BathroomBlocks() {
    }

    public static final BooleanProperty FLUSH = BooleanProperty.create("flush");
    public static final BooleanProperty RUNNING = BooleanProperty.create("running");
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final IntegerProperty BOWL = IntegerProperty.create("bowl", 0, 3);
    public static final BooleanProperty CN = BooleanProperty.create("north");
    public static final BooleanProperty CE = BooleanProperty.create("east");
    public static final BooleanProperty CS = BooleanProperty.create("south");
    public static final BooleanProperty CW = BooleanProperty.create("west");
    public static final IntegerProperty SOAP = IntegerProperty.create("soap", 0, 4);
    public static final IntegerProperty ROLL = IntegerProperty.create("roll", 0, 4);

    private static void say(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    private static VoxelShape dbox(Direction d, double x1, double y1, double z1, double x2, double y2, double z2) {
        return DecorBlocks.dbox(d, x1, y1, z1, x2, y2, z2);
    }

    // ------------------------------------------------------------------ toilet and urinal

    /** Right-click to flush (the water swirls). On a toilet, sneak and right-click to sit. A redstone signal flushes it too. */
    public static class FlushBlock extends DecorBlocks.Facing {
        private final boolean urinal;

        public FlushBlock(boolean urinal, Properties p) {
            super(p);
            this.urinal = urinal;
            registerDefaultState(defaultBlockState().setValue(FLUSH, false).setValue(BOWL, 0));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(FLUSH, BOWL);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return urinal ? dbox(f, 1, 2, 6, 15, 16, 16) : dbox(f, 2, 0, 2, 14, 16, 15);
        }

        public boolean isUrinal() {
            return urinal;
        }

        private void flush(Level level, BlockPos pos, BlockState s) {
            level.setBlock(pos, s.setValue(FLUSH, true).setValue(BOWL, 0), 3);
            level.scheduleTick(pos, this, 40);
            level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 0.7F, 0.6F);
            level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.5F, 0.5F);
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + (urinal ? 0.55 : 0.65), pos.getZ() + 0.5, 12, 0.2, 0.05, 0.2, 0.05);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(FLUSH)) {
                level.setBlock(pos, s.setValue(FLUSH, false), 3);
            }
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (!level.isClientSide && level.hasNeighborSignal(pos) && !s.getValue(FLUSH)) {
                flush(level, pos, s);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (!urinal && !player.isShiftKeyDown() && !player.isPassenger()) {
                if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
                    say(player, "seat_taken");
                    return InteractionResult.CONSUME;
                }
                SeatEntity seat = new SeatEntity(CoasterControlPanel.SEAT.get(), level);
                seat.setPos(pos.getX() + 0.5, pos.getY() + 0.35, pos.getZ() + 0.5);
                level.addFreshEntity(seat);
                player.startRiding(seat);
                say(player, "toilet_hint");
                return InteractionResult.CONSUME;
            }
            if (!s.getValue(FLUSH)) {
                flush(level, pos, s);
            }
            return InteractionResult.CONSUME;
        }
    }

    static VoxelShape sinkTopShape(Direction f) {
        return Shapes.or(dbox(f, 1, 0, 3, 15, 4, 15), dbox(f, 1, 4, 14, 15, 15, 16));
    }

    static VoxelShape urinalTopShape(Direction f) {
        return Shapes.or(dbox(f, 1, 0, 13, 15, 14, 16), dbox(f, 3, 0, 6, 13, 8, 13));
    }

    private static final Map<UUID, Long> POO_COOLDOWN = new HashMap<>();

    /** The Y key while sitting on a toilet: fills the bowl one step (up to 3). */
    public static void poo(ServerPlayer player) {
        if (!(player.getVehicle() instanceof SeatEntity seat)) {
            return;
        }
        Level level = player.level();
        BlockPos pos = seat.blockPosition();
        BlockState s = level.getBlockState(pos);
        if (!(s.getBlock() instanceof FlushBlock fb) || fb.isUrinal()) {
            return;
        }
        long now = level.getGameTime();
        Long last = POO_COOLDOWN.get(player.getUUID());
        if (last != null && now - last < 30) {
            return;
        }
        int bowl = s.getValue(BOWL);
        if (bowl >= 3) {
            say(player, "toilet_full");
            return;
        }
        POO_COOLDOWN.put(player.getUUID(), now);
        if (POO_COOLDOWN.size() > 64) {
            POO_COOLDOWN.values().removeIf(t -> now - t > 200);
        }
        level.setBlock(pos, s.setValue(BOWL, bowl + 1), 3);
        level.playSound(null, pos, SoundEvents.SLIME_SQUISH, SoundSource.BLOCKS, 0.7F, 0.6F);
        level.playSound(null, pos, SoundEvents.MUD_PLACE, SoundSource.BLOCKS, 0.9F, 0.7F);
        if (level instanceof ServerLevel sl) {
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BROWN_CONCRETE.defaultBlockState()),
                    pos.getX() + 0.5, pos.getY() + 0.7, pos.getZ() + 0.5, 8, 0.12, 0.05, 0.12, 0.03);
        }
        player.causeFoodExhaustion(0.4F);
        say(player, "toilet_used");
    }

    // ------------------------------------------------------------------ sink

    private record Wash(BlockPos pos, long end) {
    }

    private static final Map<UUID, Wash> WASHERS = new HashMap<>();


    /** Right-click to run the tap; it stops by itself. Fill a glass bottle with water, or wash your hands with soap. */
    public static class SinkBlock extends DecorBlocks.Facing {
        public SinkBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(RUNNING, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(RUNNING);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(dbox(f, 1, 14, 3, 15, 16, 15), dbox(f, 6, 0, 8, 10, 14, 12));
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(RUNNING)) {
                return;
            }
            boolean washing = false;
            long now = level.getGameTime();
            Direction f = s.getValue(DecorBlocks.FACING);
            Iterator<Map.Entry<UUID, Wash>> it = WASHERS.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Wash> e = it.next();
                Wash w = e.getValue();
                if (!w.pos().equals(pos)) {
                    continue;
                }
                ServerPlayer sp = level.getServer().getPlayerList().getPlayer(e.getKey());
                if (sp == null || now >= w.end() || sp.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 9.0) {
                    it.remove();
                    if (sp != null && now >= w.end()) {
                        say(sp, "washed_done");
                    }
                    continue;
                }
                washing = true;
                sp.swing(((now / 4) % 2 == 0) ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND, true);
                level.sendParticles(ParticleTypes.BUBBLE_POP, sp.getX() + f.getStepX() * 0.3, sp.getY() + 1.0, sp.getZ() + f.getStepZ() * 0.3, 3, 0.15, 0.1, 0.15, 0.02);
                level.sendParticles(ParticleTypes.SPLASH, sp.getX() + f.getStepX() * 0.3, sp.getY() + 0.95, sp.getZ() + f.getStepZ() * 0.3, 2, 0.12, 0.0, 0.12, 0.0);
            }
            if (!washing && random.nextInt(40) == 0) {
                level.setBlock(pos, s.setValue(RUNNING, false), 3);
                return;
            }
            level.sendParticles(ParticleTypes.FALLING_WATER, pos.getX() + 0.5, pos.getY() + 1.25, pos.getZ() + 0.5, 3, 0.05, 0.05, 0.05, 0.0);
            level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 1.22, pos.getZ() + 0.5, 2, 0.1, 0.0, 0.1, 0.0);
            if (random.nextInt(8) == 0) {
                level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.25F, 1.8F);
            }
            level.scheduleTick(pos, this, 4);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.GLASS_BOTTLE)) {
                if (!level.isClientSide) {
                    ItemStack water = PotionContents.createItemStack(Items.POTION, Potions.WATER);
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    if (!player.getInventory().add(water)) {
                        player.drop(water, false);
                    }
                    level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 0.8F, 1.0F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (stack.is(CoasterControlPanel.SOAP_ITEM.get())) {
                if (!level.isClientSide) {
                    if (s.getValue(RUNNING)) {
                        if (player instanceof ServerPlayer sp) {
                            WASHERS.put(sp.getUUID(), new Wash(pos, level.getGameTime() + 100));
                        }
                        say(player, "washed");
                        level.playSound(null, pos, SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.BLOCKS, 0.6F, 1.2F);
                        if (level instanceof ServerLevel sl) {
                            sl.sendParticles(ParticleTypes.BUBBLE_POP, pos.getX() + 0.5, pos.getY() + 0.85, pos.getZ() + 0.5, 10, 0.2, 0.1, 0.2, 0.02);
                        }
                    } else {
                        say(player, "toilet_hint");
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean on = !s.getValue(RUNNING);
                level.setBlock(pos, s.setValue(RUNNING, on), 3);
                if (on) {
                    level.scheduleTick(pos, this, 2);
                    if (player instanceof ServerPlayer sp) {
                        WASHERS.put(sp.getUUID(), new Wash(pos, level.getGameTime() + 60));
                        say(player, "washing");
                    }
                } else if (player instanceof ServerPlayer sp) {
                    WASHERS.remove(sp.getUUID());
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ hand dryer

    /** Right-click or a redstone signal: blows warm air for a few seconds (the fan spins). */
    public static class DryerBlock extends DecorBlocks.Facing {
        public DryerBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(RUNNING, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(RUNNING);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(dbox(f, 3, 5, 12, 13, 13, 16), dbox(f, 5, 3, 10, 11, 5, 14));
        }

        private void start(Level level, BlockPos pos, BlockState s) {
            level.setBlock(pos, s.setValue(RUNNING, true), 3);
            level.scheduleTick(pos, this, 2);
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (!level.isClientSide && level.hasNeighborSignal(pos) && !s.getValue(RUNNING)) {
                start(level, pos, s);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(RUNNING)) {
                return;
            }
            if (random.nextInt(20) == 0) {
                level.setBlock(pos, s.setValue(RUNNING, false), 3);
                return;
            }
            level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 0.15, pos.getZ() + 0.5, 3, 0.1, 0.03, 0.1, 0.01);
            if (random.nextInt(6) == 0) {
                level.playSound(null, pos, SoundEvents.ELYTRA_FLYING, SoundSource.BLOCKS, 0.15F, 1.6F);
            }
            level.scheduleTick(pos, this, 3);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && !s.getValue(RUNNING)) {
                start(level, pos, s);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ soap dispenser

    /** Right-click to take a soap bar. Refill it with a slimeball. */
    public static class SoapDispenserBlock extends DecorBlocks.Facing {
        public SoapDispenserBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(SOAP, 4));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(SOAP);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 5, 4, 8.5, 11, 14, 16);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.SLIME_BALL)) {
                if (!level.isClientSide) {
                    if (s.getValue(SOAP) < 4) {
                        if (!player.getAbilities().instabuild) {
                            stack.shrink(1);
                        }
                        level.setBlock(pos, s.setValue(SOAP, 4), 3);
                        level.playSound(null, pos, SoundEvents.SLIME_BLOCK_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
                        say(player, "soap_refilled");
                    } else {
                        say(player, "soap_level", 4);
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                int n = s.getValue(SOAP);
                if (player.isShiftKeyDown()) {
                    say(player, "soap_level", n);
                } else if (n <= 0) {
                    say(player, "soap_empty");
                } else {
                    ItemStack soap = new ItemStack(CoasterControlPanel.SOAP_ITEM.get());
                    if (!player.getInventory().add(soap)) {
                        player.drop(soap, false);
                    }
                    level.setBlock(pos, s.setValue(SOAP, n - 1), 3);
                    level.playSound(null, pos, SoundEvents.SLIME_BLOCK_STEP, SoundSource.BLOCKS, 0.8F, 1.3F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ toilet roll holder

    /** Right-click to tear off a sheet (gives paper). Give it paper to put the roll back. */
    public static class RollHolderBlock extends DecorBlocks.Facing {
        public RollHolderBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(ROLL, 4));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(ROLL);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 4, 3, 8, 12, 13, 16);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.PAPER)) {
                if (!level.isClientSide) {
                    int n = s.getValue(ROLL);
                    if (n < 4) {
                        if (!player.getAbilities().instabuild) {
                            stack.shrink(1);
                        }
                        level.setBlock(pos, s.setValue(ROLL, n + 1), 3);
                        level.playSound(null, pos, SoundEvents.BUNDLE_INSERT, SoundSource.BLOCKS, 0.8F, 1.0F);
                        say(player, "roll_refilled");
                    } else {
                        say(player, "roll_level", 4);
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                int n = s.getValue(ROLL);
                if (player.isShiftKeyDown()) {
                    say(player, "roll_level", n);
                } else if (n <= 0) {
                    say(player, "roll_empty");
                } else {
                    ItemStack paper = new ItemStack(Items.PAPER);
                    if (!player.getInventory().add(paper)) {
                        player.drop(paper, false);
                    }
                    level.setBlock(pos, s.setValue(ROLL, n - 1), 3);
                    level.playSound(null, pos, SoundEvents.BUNDLE_DROP_CONTENTS, SoundSource.BLOCKS, 0.6F, 1.5F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ cubicle

    /** The cubicle door (two blocks tall). Right-click: it swings open (green VACANT) or shuts (red OCCUPIED). Cubicle Panels join it. */
    public static class CubicleBlock extends DecorBlocks.Facing {
        public CubicleBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(OPEN, true));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(OPEN);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(OPEN, true);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 0, 0, 7, 16, 16, 9);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return s.getValue(OPEN) ? dbox(f, 0, 0, 7, 2, 16, 15) : shapeFor(f);
        }

        @Override
        protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return getShape(s, l, p, c);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean open = !s.getValue(OPEN);
                level.setBlock(pos, s.setValue(OPEN, open), 3);
                level.playSound(null, pos, open ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.6F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    /** A cubicle wall. It joins other panels and the cubicle door like a fence. Stack two for a full height wall. */
    public static class CubiclePanelBlock extends Block {
        public CubiclePanelBlock(Properties p) {
            super(p);
            registerDefaultState(stateDefinition.any().setValue(CN, false).setValue(CE, false).setValue(CS, false).setValue(CW, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
            b.add(CN, CE, CS, CW);
        }

        private static BooleanProperty prop(Direction d) {
            return switch (d) {
                case NORTH -> CN;
                case EAST -> CE;
                case SOUTH -> CS;
                default -> CW;
            };
        }

        private static boolean joins(BlockState o, Direction toward) {
            if (o.getBlock() instanceof CubiclePanelBlock) {
                return true;
            }
            if (o.getBlock() == CoasterControlPanel.CUBICLE_BLOCK.get() || o.getBlock() == CoasterControlPanel.CUBICLE_TOP.get()) {
                return o.getValue(DecorBlocks.FACING).getAxis() != toward.getAxis();
            }
            return false;
        }

        private BlockState withJoins(BlockState s, LevelAccessor level, BlockPos pos) {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                s = s.setValue(prop(d), joins(level.getBlockState(pos.relative(d)), d));
            }
            return s;
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return withJoins(defaultBlockState(), c.getLevel(), c.getClickedPos());
        }

        @Override
        protected BlockState updateShape(BlockState state, Direction direction, BlockState neighbor, LevelAccessor level,
                                         BlockPos pos, BlockPos neighborPos) {
            if (direction.getAxis().isHorizontal()) {
                return state.setValue(prop(direction), joins(neighbor, direction));
            }
            return state;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            VoxelShape shape = Block.box(7, 0, 7, 9, 16, 9);
            if (s.getValue(CN)) {
                shape = Shapes.or(shape, Block.box(7, 0, 0, 9, 16, 7));
            }
            if (s.getValue(CS)) {
                shape = Shapes.or(shape, Block.box(7, 0, 9, 9, 16, 16));
            }
            if (s.getValue(CW)) {
                shape = Shapes.or(shape, Block.box(0, 0, 7, 7, 16, 9));
            }
            if (s.getValue(CE)) {
                shape = Shapes.or(shape, Block.box(9, 0, 7, 16, 16, 9));
            }
            return shape;
        }
    }

    /** Builds a whole stall in one click: walls, a door and a toilet. Room for a 3 by 3 floor inside. */
    public static class CubicleKitItem extends Item {
        public CubicleKitItem(Properties p) {
            super(p);
        }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            Player player = ctx.getPlayer();
            if (player == null) {
                return InteractionResult.PASS;
            }
            Direction fwd = player.getDirection();
            Direction right = fwd.getClockWise();
            BlockPos origin = ctx.getClickedPos().relative(ctx.getClickedFace());
            // the front row is v = 0 with the door at u = 0; the stall runs 5 deep. Walls are 2 blocks high.
            for (int u = -2; u <= 2; u++) {
                for (int v = 0; v <= 4; v++) {
                    if (isWall(u, v)) {
                        for (int y = 0; y < 2; y++) {
                            BlockPos p = origin.relative(right, u).relative(fwd, v).above(y);
                            if (!level.getBlockState(p).canBeReplaced() || p.getY() >= level.getMaxBuildHeight()) {
                                if (!level.isClientSide) {
                                    say(player, "kit_no_room");
                                }
                                return InteractionResult.sidedSuccess(level.isClientSide);
                            }
                        }
                    }
                }
            }
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            Direction doorFacing = fwd.getOpposite();
            for (int u = -2; u <= 2; u++) {
                for (int v = 0; v <= 4; v++) {
                    if (!isWall(u, v)) {
                        continue;
                    }
                    BlockPos p = origin.relative(right, u).relative(fwd, v);
                    if (u == 0 && v == 0) {
                        BlockState bottom = CoasterControlPanel.CUBICLE_BLOCK.get().defaultBlockState()
                                .setValue(DecorBlocks.FACING, doorFacing).setValue(OPEN, true);
                        level.setBlock(p, bottom, 3);
                        BlockState top = TallBlocks.mirrorFrom(CoasterControlPanel.CUBICLE_TOP.get().defaultBlockState()
                                .setValue(DecorBlocks.FACING, doorFacing).setValue(TallBlocks.PART, 1), bottom);
                        level.setBlock(p.above(), top, 3);
                    } else {
                        BlockState panel = CoasterControlPanel.CUBICLE_PANEL_BLOCK.get().defaultBlockState();
                        level.setBlock(p, panel, 3);
                        level.setBlock(p.above(), panel, 3);
                    }
                }
            }
            BlockPos toilet = origin.relative(fwd, 3);
            level.setBlock(toilet, CoasterControlPanel.TOILET_BLOCK.get().defaultBlockState().setValue(DecorBlocks.FACING, doorFacing), 3);
            level.playSound(null, origin, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.8F, 1.0F);
            if (!player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
            return InteractionResult.CONSUME;
        }

        private static boolean isWall(int u, int v) {
            return v == 0 || v == 4 || u == -2 || u == 2;
        }
    }

    // ------------------------------------------------------------------ signs

    /** A small wall sign with a glowing icon. */
    public static class ToiletSignBlock extends DecorBlocks.Facing {
        public ToiletSignBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return dbox(f, 2, 2, 15, 14, 14, 16);
        }
    }
}
