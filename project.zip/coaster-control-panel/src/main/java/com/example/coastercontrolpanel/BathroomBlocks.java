package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The bathroom pack: toilets, urinals, sinks, dryers, soap, toilet roll, cubicles and signs. */
public final class BathroomBlocks {
    private BathroomBlocks() {
    }

    public static final BooleanProperty FLUSH = BooleanProperty.create("flush");
    public static final BooleanProperty RUNNING = BooleanProperty.create("running");
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final IntegerProperty SOAP = IntegerProperty.create("soap", 0, 4);
    public static final IntegerProperty ROLL = IntegerProperty.create("roll", 0, 4);

    private static void say(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    private static VoxelShape box(Direction d, double x1, double y1, double z1, double x2, double y2, double z2) {
        return DecorBlocks.dbox(d, x1, y1, z1, x2, y2, z2);
    }

    // ------------------------------------------------------------------ toilet and urinal

    /** Right-click to flush (the water swirls). On a toilet, sneak and right-click to sit. A redstone signal flushes it too. */
    public static class FlushBlock extends DecorBlocks.Facing {
        private final boolean urinal;

        public FlushBlock(boolean urinal, Properties p) {
            super(p);
            this.urinal = urinal;
            registerDefaultState(defaultBlockState().setValue(FLUSH, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(FLUSH);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return urinal ? box(f, 4, 3, 6, 12, 16, 16) : box(f, 3, 0, 3, 13, 16, 15);
        }

        private void flush(Level level, BlockPos pos, BlockState s) {
            level.setBlock(pos, s.setValue(FLUSH, true), 3);
            level.scheduleTick(pos, this, 40);
            level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 0.7F, 0.6F);
            level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.5F, 0.5F);
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + (urinal ? 0.55 : 0.65), pos.getZ() + 0.5, 12, 0.2, 0.05, 0.2, 0.05);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(FLUSH)) {
                level.setBlock(pos, s.setValue(FLUSH, false), 3);
            }
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (!level.isClientSide && level.hasNeighborSignal(pos) && !s.getValue(FLUSH)) {
                flush(level, pos, s);
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (!urinal && player.isShiftKeyDown() && !player.isPassenger()) {
                if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
                    say(player, "seat_taken");
                    return InteractionResult.CONSUME;
                }
                SeatEntity seat = new SeatEntity(CoasterControlPanel.SEAT.get(), level);
                seat.setPos(pos.getX() + 0.5, pos.getY() + 0.35, pos.getZ() + 0.5);
                level.addFreshEntity(seat);
                player.startRiding(seat);
                return InteractionResult.CONSUME;
            }
            if (!s.getValue(FLUSH)) {
                flush(level, pos, s);
            }
            return InteractionResult.CONSUME;
        }
    }

    // ------------------------------------------------------------------ sink

    /** Right-click to run the tap; it stops by itself. Fill a glass bottle with water, or wash your hands with soap. */
    public static class SinkBlock extends DecorBlocks.Facing {
        public SinkBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(RUNNING, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(RUNNING);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(box(f, 2, 8, 4, 14, 16, 14), box(f, 6, 0, 8, 10, 8, 12));
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(RUNNING)) {
                return;
            }
            if (random.nextInt(40) == 0) {
                level.setBlock(pos, s.setValue(RUNNING, false), 3);
                return;
            }
            level.sendParticles(ParticleTypes.FALLING_WATER, pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 3, 0.05, 0.05, 0.05, 0.0);
            level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 0.78, pos.getZ() + 0.5, 2, 0.1, 0.0, 0.1, 0.0);
            if (random.nextInt(8) == 0) {
                level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 0.25F, 1.8F);
            }
            level.scheduleTick(pos, this, 4);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.GLASS_BOTTLE)) {
                if (!level.isClientSide) {
                    ItemStack water = PotionContents.createItemStack(Items.POTION, Potions.WATER);
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    if (!player.getInventory().add(water)) {
                        player.drop(water, false);
                    }
                    level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 0.8F, 1.0F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (stack.is(CoasterControlPanel.SOAP_ITEM.get())) {
                if (!level.isClientSide) {
                    if (s.getValue(RUNNING)) {
                        say(player, "washed");
                        level.playSound(null, pos, SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.BLOCKS, 0.6F, 1.2F);
                        if (level instanceof ServerLevel sl) {
                            sl.sendParticles(ParticleTypes.BUBBLE_POP, pos.getX() + 0.5, pos.getY() + 0.85, pos.getZ() + 0.5, 10, 0.2, 0.1, 0.2, 0.02);
                        }
                    } else {
                        say(player, "toilet_hint");
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean on = !s.getValue(RUNNING);
                level.setBlock(pos, s.setValue(RUNNING, on), 3);
                if (on) {
                    level.scheduleTick(pos, this, 2);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ hand dryer

    /** Right-click or a redstone signal: blows warm air for a few seconds (the fan spins). */
    public static class DryerBlock extends DecorBlocks.Facing {
        public DryerBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(RUNNING, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(RUNNING);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(box(f, 3, 5, 12, 13, 13, 16), box(f, 5, 3, 10, 11, 5, 14));
        }

        private void start(Level level, BlockPos pos, BlockState s) {
            level.setBlock(pos, s.setValue(RUNNING, true), 3);
            level.scheduleTick(pos, this, 2);
        }

        @Override
        protected void neighborChanged(BlockState s, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
            if (!level.isClientSide && level.hasNeighborSignal(pos) && !s.getValue(RUNNING)) {
                start(level, pos, s);
            }
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (!s.getValue(RUNNING)) {
                return;
            }
            if (random.nextInt(20) == 0) {
                level.setBlock(pos, s.setValue(RUNNING, false), 3);
                return;
            }
            level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 0.15, pos.getZ() + 0.5, 3, 0.1, 0.03, 0.1, 0.01);
            if (random.nextInt(6) == 0) {
                level.playSound(null, pos, SoundEvents.ELYTRA_FLYING, SoundSource.BLOCKS, 0.15F, 1.6F);
            }
            level.scheduleTick(pos, this, 3);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && !s.getValue(RUNNING)) {
                start(level, pos, s);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ soap dispenser

    /** Right-click to take a soap bar. Refill it with a slimeball. */
    public static class SoapDispenserBlock extends DecorBlocks.Facing {
        public SoapDispenserBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(SOAP, 4));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(SOAP);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return box(f, 5, 4, 8.5, 11, 14, 16);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.SLIME_BALL)) {
                if (!level.isClientSide) {
                    if (s.getValue(SOAP) < 4) {
                        if (!player.getAbilities().instabuild) {
                            stack.shrink(1);
                        }
                        level.setBlock(pos, s.setValue(SOAP, 4), 3);
                        level.playSound(null, pos, SoundEvents.SLIME_BLOCK_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
                        say(player, "soap_refilled");
                    } else {
                        say(player, "soap_level", 4);
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                int n = s.getValue(SOAP);
                if (player.isShiftKeyDown()) {
                    say(player, "soap_level", n);
                } else if (n <= 0) {
                    say(player, "soap_empty");
                } else {
                    ItemStack soap = new ItemStack(CoasterControlPanel.SOAP_ITEM.get());
                    if (!player.getInventory().add(soap)) {
                        player.drop(soap, false);
                    }
                    level.setBlock(pos, s.setValue(SOAP, n - 1), 3);
                    level.playSound(null, pos, SoundEvents.SLIME_BLOCK_STEP, SoundSource.BLOCKS, 0.8F, 1.3F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ toilet roll holder

    /** Right-click to tear off a sheet (gives paper). Give it paper to put the roll back. */
    public static class RollHolderBlock extends DecorBlocks.Facing {
        public RollHolderBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(ROLL, 4));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(ROLL);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return box(f, 4, 3, 8, 12, 13, 16);
        }

        @Override
        protected ItemInteractionResult useItemOn(ItemStack stack, BlockState s, Level level, BlockPos pos, Player player,
                                                  InteractionHand hand, BlockHitResult hit) {
            if (stack.is(Items.PAPER)) {
                if (!level.isClientSide) {
                    int n = s.getValue(ROLL);
                    if (n < 4) {
                        if (!player.getAbilities().instabuild) {
                            stack.shrink(1);
                        }
                        level.setBlock(pos, s.setValue(ROLL, n + 1), 3);
                        level.playSound(null, pos, SoundEvents.BUNDLE_INSERT, SoundSource.BLOCKS, 0.8F, 1.0F);
                        say(player, "roll_refilled");
                    } else {
                        say(player, "roll_level", 4);
                    }
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                int n = s.getValue(ROLL);
                if (player.isShiftKeyDown()) {
                    say(player, "roll_level", n);
                } else if (n <= 0) {
                    say(player, "roll_empty");
                } else {
                    ItemStack paper = new ItemStack(Items.PAPER);
                    if (!player.getInventory().add(paper)) {
                        player.drop(paper, false);
                    }
                    level.setBlock(pos, s.setValue(ROLL, n - 1), 3);
                    level.playSound(null, pos, SoundEvents.BUNDLE_DROP_CONTENTS, SoundSource.BLOCKS, 0.6F, 1.5F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ cubicle

    /** A toilet stall. Right-click the door: it swings open (green VACANT) or shuts (red OCCUPIED). */
    public static class CubicleBlock extends DecorBlocks.Facing {
        public CubicleBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(OPEN, true));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(OPEN);
        }

        @Override
        public net.minecraft.world.level.block.state.BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(OPEN, true);
        }

        private static VoxelShape walls(Direction f) {
            return Shapes.or(box(f, 0, 0, 0, 1, 16, 16), box(f, 15, 0, 0, 16, 16, 16), box(f, 1, 0, 15, 15, 16, 16));
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return Shapes.or(walls(f), box(f, 1, 0, 0, 15, 16, 1));
        }

        @Override
        protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return s.getValue(OPEN) ? walls(f) : shapeFor(f);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide) {
                boolean open = !s.getValue(OPEN);
                level.setBlock(pos, s.setValue(OPEN, open), 3);
                level.playSound(null, pos, open ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.6F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    // ------------------------------------------------------------------ signs

    /** A small wall sign with a glowing icon. */
    public static class ToiletSignBlock extends DecorBlocks.Facing {
        public ToiletSignBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return box(f, 2, 2, 15, 14, 14, 16);
        }
    }
}
