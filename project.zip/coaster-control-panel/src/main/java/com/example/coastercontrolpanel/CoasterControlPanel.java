package com.example.coastercontrolpanel;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one console block. Right-click it for the operator panel,
 * right-click with a Create wrench to set it up.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredBlock<AnnouncerBlock> ANNOUNCER_BLOCK = BLOCKS.register("announcer",
            () -> new AnnouncerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> ANNOUNCER_ITEM =
            ITEMS.registerSimpleBlockItem("announcer", ANNOUNCER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_BLOCK = BLOCKS.register("ride_gate",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> GATE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate", GATE_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_SILVER_BLOCK = BLOCKS.register("ride_gate_silver",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_silver", GATE_SILVER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_RED_BLOCK = BLOCKS.register("ride_gate_red",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_red", GATE_RED_BLOCK);

    public static final DeferredBlock<Block> GATE_SILVER_LEAF = BLOCKS.register("ride_gate_silver_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> GATE_RED_LEAF = BLOCKS.register("ride_gate_red_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    /** Picks the leaf block (and so the colour) that goes with a gate block. */
    public static Block leafFor(Block gate) {
        if (gate == GATE_SILVER_BLOCK.get()) {
            return GATE_SILVER_LEAF.get();
        }
        if (gate == GATE_RED_BLOCK.get()) {
            return GATE_RED_LEAF.get();
        }
        return GATE_LEAF_BLOCK.get();
    }

    public static final DeferredBlock<SectionControllerBlock> SECTION_BLOCK = BLOCKS.register("section_controller",
            () -> new SectionControllerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(SectionControllerBlock.OCCUPIED) ? 7 : 0)));

    public static final DeferredItem<BlockItem> SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("section_controller", SECTION_BLOCK);

    public static final DeferredItem<Item> SECTION_LINKER_ITEM =
            ITEMS.registerSimpleItem("section_linker", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_PAINTER_ITEM =
            ITEMS.registerSimpleItem("track_painter", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<ZoneBlock> STATION_ZONE_BLOCK = BLOCKS.register("station_controller",
            () -> new ZoneBlock(ZoneType.STATION, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> STATION_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("station_controller", STATION_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LAUNCH_ZONE_BLOCK = BLOCKS.register("launch_controller",
            () -> new ZoneBlock(ZoneType.LAUNCH, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LAUNCH_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("launch_controller", LAUNCH_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> BRAKE_ZONE_BLOCK = BLOCKS.register("brake_controller",
            () -> new ZoneBlock(ZoneType.BRAKE, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> BRAKE_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("brake_controller", BRAKE_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LIFT_ZONE_BLOCK = BLOCKS.register("lift_controller",
            () -> new ZoneBlock(ZoneType.LIFT, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LIFT_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("lift_controller", LIFT_ZONE_BLOCK);

    /** Never placed. Only used by the renderer to draw the swinging gate leaf. */
    public static final DeferredBlock<Block> GATE_LEAF_BLOCK = BLOCKS.register("ride_gate_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    public static final DeferredItem<Item> SEAT_TIMER_ITEM =
            ITEMS.registerSimpleItem("seat_timer", new Item.Properties().stacksTo(1));

    /** Placeholder logo, only used as the creative tab icon. Replace textures/item/panel_logo.png to change it. */
    public static final DeferredItem<Item> PANEL_LOGO = ITEMS.registerSimpleItem("panel_logo");

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncerBlockEntity>> ANNOUNCER_BE =
            BLOCK_ENTITIES.register("announcer",
                    () -> BlockEntityType.Builder.of(AnnouncerBlockEntity::new, ANNOUNCER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideGateBlockEntity>> GATE_BE =
            BLOCK_ENTITIES.register("ride_gate",
                    () -> BlockEntityType.Builder.of(RideGateBlockEntity::new, GATE_BLOCK.get(), GATE_SILVER_BLOCK.get(), GATE_RED_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SectionControllerBlockEntity>> SECTION_BE =
            BLOCK_ENTITIES.register("section_controller",
                    () -> BlockEntityType.Builder.of(SectionControllerBlockEntity::new, SECTION_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<SectionMenu>> SECTION_MENU =
            MENUS.register("section_controller", () -> IMenuTypeExtension.create(SectionMenu::new));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZoneBlockEntity>> ZONE_BE =
            BLOCK_ENTITIES.register("zone_controller",
                    () -> BlockEntityType.Builder.of(ZoneBlockEntity::new, STATION_ZONE_BLOCK.get(),
                            LAUNCH_ZONE_BLOCK.get(), BRAKE_ZONE_BLOCK.get(), LIFT_ZONE_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<ZoneMenu>> ZONE_MENU =
            MENUS.register("zone_controller", () -> IMenuTypeExtension.create(ZoneMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<RideGateMenu>> GATE_MENU =
            MENUS.register("ride_gate", () -> IMenuTypeExtension.create(RideGateMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<AnnouncerMenu>> ANNOUNCER_MENU =
            MENUS.register("announcer", () -> IMenuTypeExtension.create(AnnouncerMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.coastercontrolpanel"))
                    .icon(() -> PANEL_LOGO.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(PANEL_ITEM.get());
                        output.accept(ANNOUNCER_ITEM.get());
                        output.accept(GATE_ITEM.get());
                        output.accept(GATE_SILVER_ITEM.get());
                        output.accept(GATE_RED_ITEM.get());
                        output.accept(SEAT_TIMER_ITEM.get());
                        output.accept(SECTION_ITEM.get());
                        output.accept(SECTION_LINKER_ITEM.get());
                        output.accept(TRACK_PAINTER_ITEM.get());
                        output.accept(STATION_ZONE_ITEM.get());
                        output.accept(LAUNCH_ZONE_ITEM.get());
                        output.accept(BRAKE_ZONE_ITEM.get());
                        output.accept(LIFT_ZONE_ITEM.get());
                    })
                    .build());

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(this::registerPayloads);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
            event.accept(ANNOUNCER_ITEM);
            event.accept(GATE_ITEM);
            event.accept(GATE_SILVER_ITEM);
            event.accept(GATE_RED_ITEM);
            event.accept(SEAT_TIMER_ITEM);
            event.accept(SECTION_ITEM);
            event.accept(SECTION_LINKER_ITEM);
            event.accept(TRACK_PAINTER_ITEM);
            event.accept(STATION_ZONE_ITEM);
            event.accept(LAUNCH_ZONE_ITEM);
            event.accept(BRAKE_ZONE_ITEM);
            event.accept(LIFT_ZONE_ITEM);
        }
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(ButtonPacket.TYPE, ButtonPacket.CODEC, ButtonPacket::handle);
        registrar.playToServer(ConfigPacket.TYPE, ConfigPacket.CODEC, ConfigPacket::handle);
        registrar.playToServer(AnnouncerConfigPacket.TYPE, AnnouncerConfigPacket.CODEC, AnnouncerConfigPacket::handle);
        registrar.playToServer(GateConfigPacket.TYPE, GateConfigPacket.CODEC, GateConfigPacket::handle);
        registrar.playToServer(SeatTimerPacket.TYPE, SeatTimerPacket.CODEC, SeatTimerPacket::handle);
        registrar.playToServer(SectionConfigPacket.TYPE, SectionConfigPacket.CODEC, SectionConfigPacket::handle);
        registrar.playToServer(ZoneConfigPacket.TYPE, ZoneConfigPacket.CODEC, ZoneConfigPacket::handle);
    }
}
