package com.example.coastercontrolpanel;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one console block. Right-click it for the operator panel,
 * right-click with a Create wrench to set it up.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, MOD_ID);

    /** Custom 1 to 10: sounds you replace with your own .ogg files (see the resource pack). */
    public static final java.util.List<DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent>> CUSTOM_SOUNDS =
            new java.util.ArrayList<>();

    static {
        for (int i = 1; i <= 10; i++) {
            final net.minecraft.resources.ResourceLocation id =
                    net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, "custom_" + i);
            CUSTOM_SOUNDS.add(SOUND_EVENTS.register("custom_" + i,
                    () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id)));
        }
    }

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_CHAIN =
            ride("ride_chain");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_BRAKE =
            ride("ride_brake");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_HUM =
            ride("ride_hum");

    private static DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> ride(String name) {
        final net.minecraft.resources.ResourceLocation id =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id));
    }

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredBlock<PanelBlock> EFFECTS_PANEL_BLOCK = BLOCKS.register("effects_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECTS_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("effects_panel", EFFECTS_PANEL_BLOCK);

    public static final DeferredBlock<EffectBlock> EFFECT_BLOCK = BLOCKS.register("effect_machine",
            () -> new EffectBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECT_ITEM =
            ITEMS.registerSimpleBlockItem("effect_machine", EFFECT_BLOCK);

    public static final DeferredBlock<CameraBlock> CAMERA_BLOCK = BLOCKS.register("ride_camera",
            () -> new CameraBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(CameraBlock.LIT) ? 15 : 0)));

    public static final DeferredItem<BlockItem> CAMERA_ITEM =
            ITEMS.registerSimpleBlockItem("ride_camera", CAMERA_BLOCK);

    public static final DeferredItem<Item> CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("camera_connector", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<PhotoScreenBlock> PHOTO_SCREEN_BLOCK = BLOCKS.register("photo_screen",
            () -> new PhotoScreenBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PHOTO_SCREEN_ITEM =
            ITEMS.registerSimpleBlockItem("photo_screen", PHOTO_SCREEN_BLOCK);

    public static final DeferredBlock<GuestSpawnerBlock> SPAWNER_BLOCK = BLOCKS.register("guest_spawner",
            () -> new GuestSpawnerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> SPAWNER_ITEM =
            ITEMS.registerSimpleBlockItem("guest_spawner", SPAWNER_BLOCK);

    public static final DeferredBlock<MarkerBlock> QUEUE_MARKER_BLOCK = BLOCKS.register("queue_marker",
            () -> new MarkerBlock(MarkerKind.QUEUE, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> QUEUE_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("queue_marker", QUEUE_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> STATION_MARKER_BLOCK = BLOCKS.register("station_marker",
            () -> new MarkerBlock(MarkerKind.STATION, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> STATION_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("station_marker", STATION_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> EXIT_MARKER_BLOCK = BLOCKS.register("exit_marker",
            () -> new MarkerBlock(MarkerKind.EXIT, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> EXIT_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("exit_marker", EXIT_MARKER_BLOCK);

    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<GuestEntity>> GUEST = ENTITIES.register("guest",
            () -> net.minecraft.world.entity.EntityType.Builder.of(GuestEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("guest"));

    public static final DeferredBlock<AnnouncePanelBlock> ANNOUNCE_PANEL_BLOCK = BLOCKS.register("announcement_panel",
            () -> new AnnouncePanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> ANNOUNCE_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("announcement_panel", ANNOUNCE_PANEL_BLOCK);

    public static final DeferredBlock<AnnouncerBlock> ANNOUNCER_BLOCK = BLOCKS.register("announcer",
            () -> new AnnouncerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> ANNOUNCER_ITEM =
            ITEMS.registerSimpleBlockItem("announcer", ANNOUNCER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_BLOCK = BLOCKS.register("ride_gate",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> GATE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate", GATE_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_SILVER_BLOCK = BLOCKS.register("ride_gate_silver",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_silver", GATE_SILVER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_RED_BLOCK = BLOCKS.register("ride_gate_red",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_red", GATE_RED_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_BLOCK = BLOCKS.register("ride_fence",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence", RIDE_FENCE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_SILVER_BLOCK = BLOCKS.register("ride_fence_silver",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_silver", RIDE_FENCE_SILVER_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_RED_BLOCK = BLOCKS.register("ride_fence_red",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_red", RIDE_FENCE_RED_BLOCK);

    public static final DeferredBlock<Block> GATE_SILVER_LEAF = BLOCKS.register("ride_gate_silver_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> GATE_RED_LEAF = BLOCKS.register("ride_gate_red_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    /** Picks the leaf block (and so the colour) that goes with a gate block. */
    public static Block leafFor(Block gate) {
        if (gate == GATE_SILVER_BLOCK.get()) {
            return GATE_SILVER_LEAF.get();
        }
        if (gate == GATE_RED_BLOCK.get()) {
            return GATE_RED_LEAF.get();
        }
        return GATE_LEAF_BLOCK.get();
    }

    public static final DeferredBlock<SectionControllerBlock> SECTION_BLOCK = BLOCKS.register("section_controller",
            () -> new SectionControllerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(SectionControllerBlock.OCCUPIED) ? 7 : 0)));

    public static final DeferredItem<BlockItem> SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("section_controller", SECTION_BLOCK);

    public static final DeferredItem<Item> SECTION_LINKER_ITEM =
            ITEMS.registerSimpleItem("section_linker", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_PAINTER_ITEM =
            ITEMS.registerSimpleItem("track_painter", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_TOOL_ITEM =
            ITEMS.registerSimpleItem("support_tool", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_ERASER_ITEM =
            ITEMS.registerSimpleItem("support_eraser", new Item.Properties().stacksTo(1));

    // ---------------------------------------------------------------- queues and signs

    private static DeferredBlock<RideSignBlock> sign(SignKind kind) {
        return BLOCKS.register(kind.id, () -> new RideSignBlock(kind, BlockBehaviour.Properties.of()
                .strength(1.0F, 3.0F).sound(SoundType.WOOD).noOcclusion()));
    }

    public static final DeferredBlock<RideSignBlock> RIDE_SIGN_BLOCK = sign(SignKind.RIDE);
    public static final DeferredBlock<RideSignBlock> OPEN_SIGN_BLOCK = sign(SignKind.OPEN);
    public static final DeferredBlock<RideSignBlock> HEIGHT_SIGN_BLOCK = sign(SignKind.HEIGHT);
    public static final DeferredBlock<RideSignBlock> WAIT_SIGN_BLOCK = sign(SignKind.WAIT);

    public static final DeferredItem<BlockItem> RIDE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("ride_sign", RIDE_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> OPEN_SIGN_ITEM = ITEMS.registerSimpleBlockItem("open_sign", OPEN_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> HEIGHT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("height_sign", HEIGHT_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> WAIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wait_sign", WAIT_SIGN_BLOCK);

    public static final DeferredBlock<RideSignBlock> ENTRANCE_SIGN_BLOCK = sign(SignKind.ENTRANCE);
    public static final DeferredItem<BlockItem> ENTRANCE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("entrance_sign", ENTRANCE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> EXIT_SIGN_BLOCK = sign(SignKind.EXIT);
    public static final DeferredItem<BlockItem> EXIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("exit_sign", EXIT_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> NOTICE_SIGN_BLOCK = sign(SignKind.NOTICE);
    public static final DeferredItem<BlockItem> NOTICE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("notice_sign", NOTICE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> DIRECTION_SIGN_BLOCK = sign(SignKind.DIRECTION);
    public static final DeferredItem<BlockItem> DIRECTION_SIGN_ITEM = ITEMS.registerSimpleBlockItem("direction_sign", DIRECTION_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> CROWD_SIGN_BLOCK = sign(SignKind.CROWD);
    public static final DeferredItem<BlockItem> CROWD_SIGN_ITEM = ITEMS.registerSimpleBlockItem("queue_status_sign", CROWD_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> COUNTER_SIGN_BLOCK = sign(SignKind.COUNTER);
    public static final DeferredItem<BlockItem> COUNTER_SIGN_ITEM = ITEMS.registerSimpleBlockItem("rides_today_sign", COUNTER_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> FLOOR_SIGN_BLOCK = sign(SignKind.FLOOR);
    public static final DeferredItem<BlockItem> FLOOR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("floor_sign", FLOOR_SIGN_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideSignBlockEntity>> SIGN_BE =
            BLOCK_ENTITIES.register("ride_sign", () -> BlockEntityType.Builder.of(RideSignBlockEntity::new,
                    RIDE_SIGN_BLOCK.get(), OPEN_SIGN_BLOCK.get(), HEIGHT_SIGN_BLOCK.get(), WAIT_SIGN_BLOCK.get(),
                    ENTRANCE_SIGN_BLOCK.get(), EXIT_SIGN_BLOCK.get(), NOTICE_SIGN_BLOCK.get(), DIRECTION_SIGN_BLOCK.get(),
                    CROWD_SIGN_BLOCK.get(), COUNTER_SIGN_BLOCK.get(), FLOOR_SIGN_BLOCK.get()).build(null));

    public static final DeferredBlock<RopePostBlock> ROPE_POST_BLOCK = BLOCKS.register("rope_post",
            () -> new RopePostBlock(BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> ROPE_POST_ITEM = ITEMS.registerSimpleBlockItem("rope_post", ROPE_POST_BLOCK);

    public static final DeferredBlock<FloorArrowBlock> FLOOR_ARROW_BLOCK = BLOCKS.register("floor_arrow",
            () -> new FloorArrowBlock(BlockBehaviour.Properties.of().strength(0.3F).sound(SoundType.STONE).noOcclusion()));
    public static final DeferredItem<BlockItem> FLOOR_ARROW_ITEM = ITEMS.registerSimpleBlockItem("floor_arrow", FLOOR_ARROW_BLOCK);

    // ---------------------------------------------------------------- transfer table

    public static final DeferredBlock<TransferTableBlock> TRANSFER_BLOCK = BLOCKS.register("transfer_table",
            () -> new TransferTableBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_ITEM = ITEMS.registerSimpleBlockItem("transfer_table", TRANSFER_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TransferTableBlockEntity>> TRANSFER_BE =
            BLOCK_ENTITIES.register("transfer_table",
                    () -> BlockEntityType.Builder.of(TransferTableBlockEntity::new, TRANSFER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<TransferMenu>> TRANSFER_MENU =
            MENUS.register("transfer_table", () -> IMenuTypeExtension.create(TransferMenu::new));

    public static final DeferredBlock<PanelBlock> TRANSFER_PANEL_BLOCK = BLOCKS.register("transfer_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("transfer_panel", TRANSFER_PANEL_BLOCK);

    // ---------------------------------------------------------------- park decor

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<SeatEntity>> SEAT = ENTITIES.register("seat",
            () -> net.minecraft.world.entity.EntityType.Builder.<SeatEntity>of(SeatEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.1F, 0.1F).noSave().noSummon().fireImmune().clientTrackingRange(8).build("seat"));

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> PARK_JINGLE =
            ride("park_jingle");

    private static BlockBehaviour.Properties decor(SoundType sound) {
        return BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(sound).noOcclusion();
    }

    private static final net.minecraft.world.item.ItemStack[] SNACKS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.COOKIE, 2),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.APPLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BREAD),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BAKED_POTATO),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.PUMPKIN_PIE)};
    private static final net.minecraft.world.item.ItemStack[] SWEETS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.HONEY_BOTTLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SWEET_BERRIES, 3),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SUGAR, 2)};

    public static final DeferredBlock<Block> BENCH_BLOCK = BLOCKS.register("bench", () -> new DecorBlocks.SeatBlock(false, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> DECK_CHAIR_BLOCK = BLOCKS.register("deck_chair", () -> new DecorBlocks.SeatBlock(true, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BIN_BLOCK = BLOCKS.register("litter_bin", () -> new DecorBlocks.BinBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> LAMP_POST_BLOCK = BLOCKS.register("lamp_post", () -> new DecorBlocks.LampBlock(true,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 15 : 0)));
    public static final DeferredBlock<Block> GARDEN_LIGHT_BLOCK = BLOCKS.register("garden_light", () -> new DecorBlocks.LampBlock(false,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 13 : 0)));
    public static final DeferredBlock<Block> CLOCK_BLOCK = BLOCKS.register("park_clock", () -> new DecorBlocks.ClockBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> MAP_BOARD_BLOCK = BLOCKS.register("park_map", () -> new DecorBlocks.MapBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BOOTH_BLOCK = BLOCKS.register("ticket_booth", () -> new DecorBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> SNACK_BLOCK = BLOCKS.register("snack_machine", () -> new DecorBlocks.VendingBlock(SNACKS, decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CANDY_BLOCK = BLOCKS.register("candy_stand", () -> new DecorBlocks.VendingBlock(SWEETS, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FOUNTAIN_BLOCK = BLOCKS.register("drinking_fountain", () -> new DecorBlocks.FountainBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> PLANTER_BLOCK = BLOCKS.register("flower_planter", () -> new DecorBlocks.PlanterBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FLAG_BLOCK = BLOCKS.register("park_flag", () -> new DecorBlocks.FlagBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SPEAKER_BLOCK = BLOCKS.register("park_speaker", () -> new DecorBlocks.SpeakerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> BOUNCY_BLOCK = BLOCKS.register("bouncy_pad", () -> new DecorBlocks.BouncyPadBlock(decor(SoundType.SLIME_BLOCK)));
    public static final DeferredBlock<Block> MISTER_BLOCK = BLOCKS.register("cooling_mister", () -> new DecorBlocks.MisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BENCH_ITEM = ITEMS.registerSimpleBlockItem("bench", BENCH_BLOCK);
    public static final DeferredItem<BlockItem> DECK_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("deck_chair", DECK_CHAIR_BLOCK);
    public static final DeferredItem<BlockItem> BIN_ITEM = ITEMS.registerSimpleBlockItem("litter_bin", BIN_BLOCK);
    public static final DeferredItem<BlockItem> LAMP_POST_ITEM = ITEMS.registerSimpleBlockItem("lamp_post", LAMP_POST_BLOCK);
    public static final DeferredItem<BlockItem> GARDEN_LIGHT_ITEM = ITEMS.registerSimpleBlockItem("garden_light", GARDEN_LIGHT_BLOCK);
    public static final DeferredItem<BlockItem> CLOCK_ITEM = ITEMS.registerSimpleBlockItem("park_clock", CLOCK_BLOCK);
    public static final DeferredItem<BlockItem> MAP_BOARD_ITEM = ITEMS.registerSimpleBlockItem("park_map", MAP_BOARD_BLOCK);
    public static final DeferredItem<BlockItem> BOOTH_ITEM = ITEMS.registerSimpleBlockItem("ticket_booth", BOOTH_BLOCK);
    public static final DeferredItem<BlockItem> SNACK_ITEM = ITEMS.registerSimpleBlockItem("snack_machine", SNACK_BLOCK);
    public static final DeferredItem<BlockItem> CANDY_ITEM = ITEMS.registerSimpleBlockItem("candy_stand", CANDY_BLOCK);
    public static final DeferredItem<BlockItem> FOUNTAIN_ITEM = ITEMS.registerSimpleBlockItem("drinking_fountain", FOUNTAIN_BLOCK);
    public static final DeferredItem<BlockItem> PLANTER_ITEM = ITEMS.registerSimpleBlockItem("flower_planter", PLANTER_BLOCK);
    public static final DeferredItem<BlockItem> FLAG_ITEM = ITEMS.registerSimpleBlockItem("park_flag", FLAG_BLOCK);
    public static final DeferredItem<BlockItem> SPEAKER_ITEM = ITEMS.registerSimpleBlockItem("park_speaker", SPEAKER_BLOCK);
    public static final DeferredItem<BlockItem> BOUNCY_ITEM = ITEMS.registerSimpleBlockItem("bouncy_pad", BOUNCY_BLOCK);
    public static final DeferredItem<BlockItem> MISTER_ITEM = ITEMS.registerSimpleBlockItem("cooling_mister", MISTER_BLOCK);

    // ---- Bathroom pack
    public static final DeferredBlock<Block> TOILET_BLOCK = BLOCKS.register("toilet", () -> new BathroomBlocks.FlushBlock(false, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> URINAL_BLOCK = BLOCKS.register("urinal", () -> new BathroomBlocks.FlushBlock(true, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> SINK_BLOCK = BLOCKS.register("sink", () -> new BathroomBlocks.SinkBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> HAND_DRYER_BLOCK = BLOCKS.register("hand_dryer", () -> new BathroomBlocks.DryerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SOAP_DISPENSER_BLOCK = BLOCKS.register("soap_dispenser", () -> new BathroomBlocks.SoapDispenserBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> ROLL_HOLDER_BLOCK = BLOCKS.register("toilet_roll_holder", () -> new BathroomBlocks.RollHolderBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CUBICLE_BLOCK = BLOCKS.register("toilet_cubicle", () -> new BathroomBlocks.CubicleBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SIGN_MEN_BLOCK = BLOCKS.register("toilet_sign_men", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_WOMEN_BLOCK = BLOCKS.register("toilet_sign_women", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_ACCESS_BLOCK = BLOCKS.register("toilet_sign_accessible", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_BABY_BLOCK = BLOCKS.register("toilet_sign_baby", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredItem<BlockItem> TOILET_ITEM = ITEMS.registerSimpleBlockItem("toilet", TOILET_BLOCK);
    public static final DeferredItem<BlockItem> URINAL_ITEM = ITEMS.registerSimpleBlockItem("urinal", URINAL_BLOCK);
    public static final DeferredItem<BlockItem> SINK_ITEM = ITEMS.registerSimpleBlockItem("sink", SINK_BLOCK);
    public static final DeferredItem<BlockItem> HAND_DRYER_ITEM = ITEMS.registerSimpleBlockItem("hand_dryer", HAND_DRYER_BLOCK);
    public static final DeferredItem<BlockItem> SOAP_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("soap_dispenser", SOAP_DISPENSER_BLOCK);
    public static final DeferredItem<BlockItem> ROLL_HOLDER_ITEM = ITEMS.registerSimpleBlockItem("toilet_roll_holder", ROLL_HOLDER_BLOCK);
    public static final DeferredItem<BlockItem> CUBICLE_ITEM = ITEMS.registerSimpleBlockItem("toilet_cubicle", CUBICLE_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_MEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_men", SIGN_MEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_WOMEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_women", SIGN_WOMEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_ACCESS_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_accessible", SIGN_ACCESS_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_BABY_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_baby", SIGN_BABY_BLOCK);
    public static final DeferredItem<Item> SOAP_ITEM = ITEMS.registerSimpleItem("soap", new Item.Properties());
    public static final java.util.List<DeferredItem<? extends Item>> BATH_ITEMS = java.util.List.of(
            CUBICLE_ITEM, TOILET_ITEM, URINAL_ITEM, SINK_ITEM, HAND_DRYER_ITEM, SOAP_DISPENSER_ITEM, SOAP_ITEM,
            ROLL_HOLDER_ITEM, SIGN_MEN_ITEM, SIGN_WOMEN_ITEM, SIGN_ACCESS_ITEM, SIGN_BABY_ITEM);

    // ---- Kitchen pack
    public static final DeferredItem<Item> BUN = ITEMS.registerSimpleItem("bun", new Item.Properties());
    public static final DeferredItem<Item> RAW_PATTY = ITEMS.registerSimpleItem("raw_patty", new Item.Properties());
    public static final DeferredItem<Item> COOKED_PATTY = ITEMS.registerSimpleItem("cooked_patty", new Item.Properties());
    public static final DeferredItem<Item> RAW_SAUSAGE = ITEMS.registerSimpleItem("raw_sausage", new Item.Properties());
    public static final DeferredItem<Item> COOKED_SAUSAGE = ITEMS.registerSimpleItem("cooked_sausage", new Item.Properties());
    public static final DeferredItem<Item> DOUGH = ITEMS.registerSimpleItem("dough", new Item.Properties());
    public static final DeferredItem<Item> POTATO_STRIPS = ITEMS.registerSimpleItem("potato_strips", new Item.Properties());
    public static final DeferredItem<Item> BURGER = ITEMS.registerSimpleItem("burger", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> HOT_DOG = ITEMS.registerSimpleItem("hot_dog", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> CHIPS = ITEMS.registerSimpleItem("chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).fast().build()));
    public static final DeferredItem<Item> DOUGHNUT = ITEMS.registerSimpleItem("doughnut", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> PIZZA_SLICE = ITEMS.registerSimpleItem("pizza_slice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> ICE_CREAM = ITEMS.registerSimpleItem("ice_cream", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> POPCORN_ITEM = ITEMS.registerSimpleItem("popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).fast().build()));
    public static final DeferredItem<Item> APPLE_JUICE = ITEMS.register("apple_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.REGENERATION, 5));
    public static final DeferredItem<Item> BERRY_FIZZ = ITEMS.register("berry_fizz", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.JUMP, 15));
    public static final DeferredItem<Item> MELON_JUICE = ITEMS.register("melon_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.WATER_BREATHING, 20));
    public static final DeferredItem<Item> COLA = ITEMS.register("cola", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 10));
    public static final DeferredBlock<Block> PREP_BLOCK = BLOCKS.register("prep_counter", () -> new KitchenBlock(KitchenKind.PREP, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PREP_ITEM = ITEMS.registerSimpleBlockItem("prep_counter", PREP_BLOCK);
    public static final DeferredBlock<Block> GRILL_BLOCK = BLOCKS.register("park_grill", () -> new KitchenBlock(KitchenKind.GRILL, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> GRILL_ITEM = ITEMS.registerSimpleBlockItem("park_grill", GRILL_BLOCK);
    public static final DeferredBlock<Block> FRYER_BLOCK = BLOCKS.register("deep_fryer", () -> new KitchenBlock(KitchenKind.FRYER, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> FRYER_ITEM = ITEMS.registerSimpleBlockItem("deep_fryer", FRYER_BLOCK);
    public static final DeferredBlock<Block> OVEN_BLOCK = BLOCKS.register("pizza_oven", () -> new KitchenBlock(KitchenKind.OVEN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> OVEN_ITEM = ITEMS.registerSimpleBlockItem("pizza_oven", OVEN_BLOCK);
    public static final DeferredBlock<Block> SOFT_SERVE_BLOCK = BLOCKS.register("soft_serve_machine", () -> new KitchenBlock(KitchenKind.SOFT_SERVE, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredItem<BlockItem> SOFT_SERVE_ITEM = ITEMS.registerSimpleBlockItem("soft_serve_machine", SOFT_SERVE_BLOCK);
    public static final DeferredBlock<Block> POPCORN_MACHINE_BLOCK = BLOCKS.register("popcorn_machine", () -> new KitchenBlock(KitchenKind.POPCORN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredItem<BlockItem> POPCORN_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("popcorn_machine", POPCORN_MACHINE_BLOCK);
    public static final DeferredBlock<Block> DRINKS_BLOCK = BLOCKS.register("drinks_dispenser", () -> new KitchenBlock(KitchenKind.DRINKS, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredItem<BlockItem> DRINKS_ITEM = ITEMS.registerSimpleBlockItem("drinks_dispenser", DRINKS_BLOCK);
    public static final DeferredBlock<Block> FRIDGE_BLOCK = BLOCKS.register("fridge", () -> new KitchenExtras.FridgeBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FRIDGE_ITEM = ITEMS.registerSimpleBlockItem("fridge", FRIDGE_BLOCK);
    public static final DeferredBlock<Block> BELL_BLOCK = BLOCKS.register("order_bell", () -> new KitchenExtras.BellBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BELL_ITEM = ITEMS.registerSimpleBlockItem("order_bell", BELL_BLOCK);
    public static final DeferredBlock<Block> FAN_BLOCK = BLOCKS.register("extractor_fan", () -> new KitchenExtras.FanBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FAN_ITEM = ITEMS.registerSimpleBlockItem("extractor_fan", FAN_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenBlockEntity>> KITCHEN_BE =
            BLOCK_ENTITIES.register("kitchen_machine", () -> BlockEntityType.Builder.of(KitchenBlockEntity::new,
                    PREP_BLOCK.get(), GRILL_BLOCK.get(), FRYER_BLOCK.get(), OVEN_BLOCK.get(), SOFT_SERVE_BLOCK.get(),
                    POPCORN_MACHINE_BLOCK.get(), DRINKS_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.FridgeBlockEntity>> FRIDGE_BE =
            BLOCK_ENTITIES.register("fridge", () -> BlockEntityType.Builder.of(KitchenExtras.FridgeBlockEntity::new, FRIDGE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.BellBlockEntity>> BELL_BE =
            BLOCK_ENTITIES.register("order_bell", () -> BlockEntityType.Builder.of(KitchenExtras.BellBlockEntity::new, BELL_BLOCK.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<KitchenMenu>> KITCHEN_MENU =
            MENUS.register("kitchen_machine", () -> IMenuTypeExtension.create(KitchenMenu::new));
    public static final java.util.List<DeferredItem<? extends Item>> KITCHEN_ITEMS = java.util.List.of(
            PREP_ITEM, GRILL_ITEM, FRYER_ITEM, OVEN_ITEM, SOFT_SERVE_ITEM, POPCORN_MACHINE_ITEM, DRINKS_ITEM,
            FRIDGE_ITEM, BELL_ITEM, FAN_ITEM,
            BUN, RAW_PATTY, COOKED_PATTY, RAW_SAUSAGE, COOKED_SAUSAGE, DOUGH, POTATO_STRIPS,
            BURGER, HOT_DOG, CHIPS, DOUGHNUT, PIZZA_SLICE, ICE_CREAM, POPCORN_ITEM,
            APPLE_JUICE, BERRY_FIZZ, MELON_JUICE, COLA);

    // ---- Restaurant and cafe pack
    public static final DeferredBlock<Block> DINING_TABLE_BLOCK = BLOCKS.register("dining_table", () -> new DiningBlocks.TableBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_TABLE_ITEM = ITEMS.registerSimpleBlockItem("dining_table", DINING_TABLE_BLOCK);
    public static final DeferredBlock<Block> DINING_CHAIR_BLOCK = BLOCKS.register("dining_chair", () -> new DiningBlocks.ChairBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("dining_chair", DINING_CHAIR_BLOCK);
    public static final DeferredBlock<Block> DINING_BOOTH_BLOCK = BLOCKS.register("dining_booth", () -> new DiningBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("dining_booth", DINING_BOOTH_BLOCK);
    public static final DeferredBlock<Block> MENU_BOARD_BLOCK = BLOCKS.register("menu_board", () -> new RestaurantBlocks.MenuBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> MENU_BOARD_ITEM = ITEMS.registerSimpleBlockItem("menu_board", MENU_BOARD_BLOCK);
    public static final DeferredBlock<Block> ORDER_KIOSK_BLOCK = BLOCKS.register("order_kiosk", () -> new RestaurantBlocks.KioskBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ORDER_KIOSK_ITEM = ITEMS.registerSimpleBlockItem("order_kiosk", ORDER_KIOSK_BLOCK);
    public static final DeferredBlock<Block> PICKUP_DISPLAY_BLOCK = BLOCKS.register("pickup_display", () -> new RestaurantBlocks.PickupBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> PICKUP_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("pickup_display", PICKUP_DISPLAY_BLOCK);
    public static final DeferredBlock<Block> CASH_REGISTER_BLOCK = BLOCKS.register("cash_register", () -> new RestaurantBlocks.RegisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CASH_REGISTER_ITEM = ITEMS.registerSimpleBlockItem("cash_register", CASH_REGISTER_BLOCK);
    public static final DeferredBlock<Block> CONDIMENT_STAND_BLOCK = BLOCKS.register("condiment_stand", () -> new RestaurantBlocks.CondimentBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CONDIMENT_STAND_ITEM = ITEMS.registerSimpleBlockItem("condiment_stand", CONDIMENT_STAND_BLOCK);
    public static final DeferredBlock<Block> PARASOL_BLOCK = BLOCKS.register("parasol", () -> new DiningBlocks.ParasolBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> PARASOL_ITEM = ITEMS.registerSimpleBlockItem("parasol", PARASOL_BLOCK);
    public static final DeferredBlock<Block> TRAY_TROLLEY_BLOCK = BLOCKS.register("tray_trolley", () -> new RestaurantBlocks.TrolleyBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TRAY_TROLLEY_ITEM = ITEMS.registerSimpleBlockItem("tray_trolley", TRAY_TROLLEY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.KioskBlockEntity>> KIOSK_BE =
            BLOCK_ENTITIES.register("order_kiosk", () -> BlockEntityType.Builder.of(RestaurantBlocks.KioskBlockEntity::new, ORDER_KIOSK_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.PickupBlockEntity>> PICKUP_BE =
            BLOCK_ENTITIES.register("pickup_display", () -> BlockEntityType.Builder.of(RestaurantBlocks.PickupBlockEntity::new, PICKUP_DISPLAY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.MenuBoardBlockEntity>> MENU_BOARD_BE =
            BLOCK_ENTITIES.register("menu_board", () -> BlockEntityType.Builder.of(RestaurantBlocks.MenuBoardBlockEntity::new, MENU_BOARD_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.CondimentBlockEntity>> CONDIMENT_BE =
            BLOCK_ENTITIES.register("condiment_stand", () -> BlockEntityType.Builder.of(RestaurantBlocks.CondimentBlockEntity::new, CONDIMENT_STAND_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.TrolleyBlockEntity>> TROLLEY_BE =
            BLOCK_ENTITIES.register("tray_trolley", () -> BlockEntityType.Builder.of(RestaurantBlocks.TrolleyBlockEntity::new, TRAY_TROLLEY_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> RESTAURANT_ITEMS = java.util.List.of(
            DINING_TABLE_ITEM, DINING_CHAIR_ITEM, DINING_BOOTH_ITEM, MENU_BOARD_ITEM, ORDER_KIOSK_ITEM, PICKUP_DISPLAY_ITEM,
            CASH_REGISTER_ITEM, CONDIMENT_STAND_ITEM, PARASOL_ITEM, TRAY_TROLLEY_ITEM);
    // ---- Arcade pack
    public static final DeferredItem<Item> ARCADE_TOKEN = ITEMS.registerSimpleItem("arcade_token", new Item.Properties());
    public static final DeferredItem<Item> PRIZE_TICKET = ITEMS.registerSimpleItem("prize_ticket", new Item.Properties());
    public static final DeferredBlock<Block> TOKEN_MACHINE_BLOCK = BLOCKS.register("token_machine", () -> new ArcadeBlocks.TokenBlock(decor(SoundType.METAL).lightLevel(st -> 7)));
    public static final DeferredItem<BlockItem> TOKEN_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("token_machine", TOKEN_MACHINE_BLOCK);
    public static final DeferredBlock<Block> PRIZE_COUNTER_BLOCK = BLOCKS.register("prize_counter", () -> new ArcadeBlocks.PrizeBlock(decor(SoundType.WOOD).lightLevel(st -> 5)));
    public static final DeferredItem<BlockItem> PRIZE_COUNTER_ITEM = ITEMS.registerSimpleBlockItem("prize_counter", PRIZE_COUNTER_BLOCK);
    public static final DeferredBlock<Block> ARCADE_CABINET_BLOCK = BLOCKS.register("arcade_cabinet", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CABINET, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ARCADE_CABINET_ITEM = ITEMS.registerSimpleBlockItem("arcade_cabinet", ARCADE_CABINET_BLOCK);
    public static final DeferredBlock<Block> CLAW_MACHINE_BLOCK = BLOCKS.register("claw_machine", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CLAW, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> CLAW_MACHINE_ITEM = ITEMS.registerSimpleBlockItem("claw_machine", CLAW_MACHINE_BLOCK);
    public static final DeferredBlock<Block> WHACK_A_MOLE_BLOCK = BLOCKS.register("whack_a_mole", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.MOLE, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> WHACK_A_MOLE_ITEM = ITEMS.registerSimpleBlockItem("whack_a_mole", WHACK_A_MOLE_BLOCK);
    public static final DeferredBlock<Block> STRENGTH_TESTER_BLOCK = BLOCKS.register("strength_tester", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.STRENGTH, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> STRENGTH_TESTER_ITEM = ITEMS.registerSimpleBlockItem("strength_tester", STRENGTH_TESTER_BLOCK);
    public static final DeferredBlock<Block> BASKETBALL_HOOPS_BLOCK = BLOCKS.register("basketball_hoops", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.HOOPS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> BASKETBALL_HOOPS_ITEM = ITEMS.registerSimpleBlockItem("basketball_hoops", BASKETBALL_HOOPS_BLOCK);
    public static final DeferredBlock<Block> SHOOTING_GALLERY_BLOCK = BLOCKS.register("shooting_gallery", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.GALLERY, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> SHOOTING_GALLERY_ITEM = ITEMS.registerSimpleBlockItem("shooting_gallery", SHOOTING_GALLERY_BLOCK);
    public static final DeferredBlock<Block> RING_TOSS_BLOCK = BLOCKS.register("ring_toss", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.RINGS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> RING_TOSS_ITEM = ITEMS.registerSimpleBlockItem("ring_toss", RING_TOSS_BLOCK);
    public static final DeferredBlock<Block> COCONUT_SHY_BLOCK = BLOCKS.register("coconut_shy", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.COCONUT, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> COCONUT_SHY_ITEM = ITEMS.registerSimpleBlockItem("coconut_shy", COCONUT_SHY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.ArcadeBlockEntity>> ARCADE_BE =
            BLOCK_ENTITIES.register("arcade_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.ArcadeBlockEntity::new,
                    ARCADE_CABINET_BLOCK.get(), CLAW_MACHINE_BLOCK.get(), WHACK_A_MOLE_BLOCK.get(), STRENGTH_TESTER_BLOCK.get(), BASKETBALL_HOOPS_BLOCK.get(), SHOOTING_GALLERY_BLOCK.get(), RING_TOSS_BLOCK.get(), COCONUT_SHY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.TokenBlockEntity>> TOKEN_BE =
            BLOCK_ENTITIES.register("token_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.TokenBlockEntity::new, TOKEN_MACHINE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.PrizeBlockEntity>> PRIZE_BE =
            BLOCK_ENTITIES.register("prize_counter", () -> BlockEntityType.Builder.of(ArcadeBlocks.PrizeBlockEntity::new, PRIZE_COUNTER_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> ARCADE_ITEMS = java.util.List.of(
            TOKEN_MACHINE_ITEM, ARCADE_TOKEN, ARCADE_CABINET_ITEM, CLAW_MACHINE_ITEM, WHACK_A_MOLE_ITEM, STRENGTH_TESTER_ITEM,
            BASKETBALL_HOOPS_ITEM, SHOOTING_GALLERY_ITEM, RING_TOSS_ITEM, COCONUT_SHY_ITEM, PRIZE_COUNTER_ITEM, PRIZE_TICKET);
    public static final java.util.List<DeferredItem<BlockItem>> DECOR_ITEMS = java.util.List.of(
            BENCH_ITEM,
            DECK_CHAIR_ITEM,
            BIN_ITEM,
            LAMP_POST_ITEM,
            GARDEN_LIGHT_ITEM,
            CLOCK_ITEM,
            MAP_BOARD_ITEM,
            BOOTH_ITEM,
            SNACK_ITEM,
            CANDY_ITEM,
            FOUNTAIN_ITEM,
            PLANTER_ITEM,
            FLAG_ITEM,
            SPEAKER_ITEM,
            BOUNCY_ITEM,
            MISTER_ITEM);

    // ---------------------------------------------------------------- tickets and turnstile

    public static final DeferredItem<Item> TICKET_ITEM = ITEMS.registerSimpleItem("park_ticket", new Item.Properties());

    public static final DeferredBlock<TurnstileBlock> TURNSTILE_BLOCK = BLOCKS.register("turnstile",
            () -> new TurnstileBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TURNSTILE_ITEM = ITEMS.registerSimpleBlockItem("turnstile", TURNSTILE_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TurnstileBlockEntity>> TURNSTILE_BE =
            BLOCK_ENTITIES.register("turnstile",
                    () -> BlockEntityType.Builder.of(TurnstileBlockEntity::new, TURNSTILE_BLOCK.get()).build(null));

    public static final DeferredItem<Item> STATION_TRACK_ITEM =
            ITEMS.registerSimpleItem("station_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LAUNCH_TRACK_ITEM =
            ITEMS.registerSimpleItem("launch_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> BRAKE_TRACK_ITEM =
            ITEMS.registerSimpleItem("brake_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LIFT_TRACK_ITEM =
            ITEMS.registerSimpleItem("lift_track", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<ZoneBlock> STATION_ZONE_BLOCK = BLOCKS.register("station_controller",
            () -> new ZoneBlock(ZoneType.STATION, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> STATION_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("station_controller", STATION_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LAUNCH_ZONE_BLOCK = BLOCKS.register("launch_controller",
            () -> new ZoneBlock(ZoneType.LAUNCH, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LAUNCH_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("launch_controller", LAUNCH_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> BRAKE_ZONE_BLOCK = BLOCKS.register("brake_controller",
            () -> new ZoneBlock(ZoneType.BRAKE, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> BRAKE_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("brake_controller", BRAKE_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LIFT_ZONE_BLOCK = BLOCKS.register("lift_controller",
            () -> new ZoneBlock(ZoneType.LIFT, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LIFT_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("lift_controller", LIFT_ZONE_BLOCK);

    /** Never placed. Only used by the renderer to draw the swinging gate leaf. */
    public static final DeferredBlock<Block> GATE_LEAF_BLOCK = BLOCKS.register("ride_gate_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    public static final DeferredItem<Item> SEAT_TIMER_ITEM =
            ITEMS.registerSimpleItem("seat_timer", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SEAT_SPEED_ITEM =
            ITEMS.registerSimpleItem("seat_speed", new Item.Properties().stacksTo(1));

    /** Placeholder logo, only used as the creative tab icon. Replace textures/item/panel_logo.png to change it. */
    public static final DeferredItem<Item> PANEL_LOGO = ITEMS.registerSimpleItem("panel_logo");

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get(), EFFECTS_PANEL_BLOCK.get(), TRANSFER_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncePanelBlockEntity>> ANNOUNCE_PANEL_BE =
            BLOCK_ENTITIES.register("announcement_panel",
                    () -> BlockEntityType.Builder.of(AnnouncePanelBlockEntity::new, ANNOUNCE_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncerBlockEntity>> ANNOUNCER_BE =
            BLOCK_ENTITIES.register("announcer",
                    () -> BlockEntityType.Builder.of(AnnouncerBlockEntity::new, ANNOUNCER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideGateBlockEntity>> GATE_BE =
            BLOCK_ENTITIES.register("ride_gate",
                    () -> BlockEntityType.Builder.of(RideGateBlockEntity::new, GATE_BLOCK.get(), GATE_SILVER_BLOCK.get(), GATE_RED_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SectionControllerBlockEntity>> SECTION_BE =
            BLOCK_ENTITIES.register("section_controller",
                    () -> BlockEntityType.Builder.of(SectionControllerBlockEntity::new, SECTION_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<SectionMenu>> SECTION_MENU =
            MENUS.register("section_controller", () -> IMenuTypeExtension.create(SectionMenu::new));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZoneBlockEntity>> ZONE_BE =
            BLOCK_ENTITIES.register("zone_controller",
                    () -> BlockEntityType.Builder.of(ZoneBlockEntity::new, STATION_ZONE_BLOCK.get(),
                            LAUNCH_ZONE_BLOCK.get(), BRAKE_ZONE_BLOCK.get(), LIFT_ZONE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EffectBlockEntity>> EFFECT_BE =
            BLOCK_ENTITIES.register("effect_machine",
                    () -> BlockEntityType.Builder.of(EffectBlockEntity::new, EFFECT_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CameraBlockEntity>> CAMERA_BE =
            BLOCK_ENTITIES.register("ride_camera",
                    () -> BlockEntityType.Builder.of(CameraBlockEntity::new, CAMERA_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhotoScreenBlockEntity>> PHOTO_SCREEN_BE =
            BLOCK_ENTITIES.register("photo_screen",
                    () -> BlockEntityType.Builder.of(PhotoScreenBlockEntity::new, PHOTO_SCREEN_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestSpawnerBlockEntity>> SPAWNER_BE =
            BLOCK_ENTITIES.register("guest_spawner",
                    () -> BlockEntityType.Builder.of(GuestSpawnerBlockEntity::new, SPAWNER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MarkerBlockEntity>> MARKER_BE =
            BLOCK_ENTITIES.register("guest_marker",
                    () -> BlockEntityType.Builder.of(MarkerBlockEntity::new, QUEUE_MARKER_BLOCK.get(),
                            STATION_MARKER_BLOCK.get(), EXIT_MARKER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<GuestSpawnerMenu>> SPAWNER_MENU =
            MENUS.register("guest_spawner", () -> IMenuTypeExtension.create(GuestSpawnerMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<EffectMenu>> EFFECT_MENU =
            MENUS.register("effect_machine", () -> IMenuTypeExtension.create(EffectMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<ZoneMenu>> ZONE_MENU =
            MENUS.register("zone_controller", () -> IMenuTypeExtension.create(ZoneMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<RideGateMenu>> GATE_MENU =
            MENUS.register("ride_gate", () -> IMenuTypeExtension.create(RideGateMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<AnnouncerMenu>> ANNOUNCER_MENU =
            MENUS.register("announcer", () -> IMenuTypeExtension.create(AnnouncerMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.coastercontrolpanel"))
                    .icon(() -> PANEL_LOGO.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(PANEL_ITEM.get());
                        output.accept(ANNOUNCER_ITEM.get());
                        output.accept(ANNOUNCE_PANEL_ITEM.get());
                        output.accept(GATE_ITEM.get());
                        output.accept(GATE_SILVER_ITEM.get());
                        output.accept(GATE_RED_ITEM.get());
                        output.accept(RIDE_FENCE_ITEM.get());
                        output.accept(RIDE_FENCE_SILVER_ITEM.get());
                        output.accept(RIDE_FENCE_RED_ITEM.get());
                        output.accept(SEAT_TIMER_ITEM.get());
                        output.accept(SEAT_SPEED_ITEM.get());
                        output.accept(SECTION_ITEM.get());
                        output.accept(SECTION_LINKER_ITEM.get());
                        output.accept(TRACK_PAINTER_ITEM.get());
                        output.accept(SUPPORT_TOOL_ITEM.get());
                        output.accept(SUPPORT_ERASER_ITEM.get());
                        output.accept(TRANSFER_ITEM.get());
                        output.accept(TRANSFER_PANEL_ITEM.get());
                        output.accept(RIDE_SIGN_ITEM.get());
                        output.accept(OPEN_SIGN_ITEM.get());
                        output.accept(HEIGHT_SIGN_ITEM.get());
                        output.accept(WAIT_SIGN_ITEM.get());
                        output.accept(ROPE_POST_ITEM.get());
                        output.accept(FLOOR_ARROW_ITEM.get());
                        output.accept(TURNSTILE_ITEM.get());
                        output.accept(TICKET_ITEM.get());
                        output.accept(ENTRANCE_SIGN_ITEM.get());
                        output.accept(EXIT_SIGN_ITEM.get());
                        output.accept(NOTICE_SIGN_ITEM.get());
                        output.accept(DIRECTION_SIGN_ITEM.get());
                        output.accept(CROWD_SIGN_ITEM.get());
                        output.accept(COUNTER_SIGN_ITEM.get());
                        output.accept(FLOOR_SIGN_ITEM.get());
                        for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                            output.accept(decorItem.get());
                        }
                        for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                            output.accept(bathItem.get());
                        }
                        for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                            output.accept(kitchenItem.get());
                        }
                        for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                            output.accept(restaurantItem.get());
                        }
                        for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                            output.accept(arcadeItem.get());
                        }
                        output.accept(STATION_TRACK_ITEM.get());
                        output.accept(LAUNCH_TRACK_ITEM.get());
                        output.accept(BRAKE_TRACK_ITEM.get());
                        output.accept(LIFT_TRACK_ITEM.get());
                        output.accept(STATION_ZONE_ITEM.get());
                        output.accept(LAUNCH_ZONE_ITEM.get());
                        output.accept(BRAKE_ZONE_ITEM.get());
                        output.accept(LIFT_ZONE_ITEM.get());
                        output.accept(EFFECT_ITEM.get());
                        output.accept(EFFECTS_PANEL_ITEM.get());
                        output.accept(CAMERA_ITEM.get());
                        output.accept(CONNECTOR_ITEM.get());
                        output.accept(PHOTO_SCREEN_ITEM.get());
                        output.accept(SPAWNER_ITEM.get());
                        output.accept(QUEUE_MARKER_ITEM.get());
                        output.accept(STATION_MARKER_ITEM.get());
                        output.accept(EXIT_MARKER_ITEM.get());
                    })
                    .build());

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ENTITIES.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);
        SOUND_EVENTS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(this::registerPayloads);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
            event.accept(ANNOUNCER_ITEM);
            event.accept(ANNOUNCE_PANEL_ITEM);
            event.accept(GATE_ITEM);
            event.accept(GATE_SILVER_ITEM);
            event.accept(GATE_RED_ITEM);
            event.accept(RIDE_FENCE_ITEM);
            event.accept(RIDE_FENCE_SILVER_ITEM);
            event.accept(RIDE_FENCE_RED_ITEM);
            event.accept(SEAT_TIMER_ITEM);
            event.accept(SEAT_SPEED_ITEM);
            event.accept(SECTION_ITEM);
            event.accept(SECTION_LINKER_ITEM);
            event.accept(TRACK_PAINTER_ITEM);
            event.accept(SUPPORT_TOOL_ITEM);
            event.accept(SUPPORT_ERASER_ITEM);
            event.accept(TRANSFER_ITEM);
            event.accept(TRANSFER_PANEL_ITEM);
            event.accept(RIDE_SIGN_ITEM);
            event.accept(OPEN_SIGN_ITEM);
            event.accept(HEIGHT_SIGN_ITEM);
            event.accept(WAIT_SIGN_ITEM);
            event.accept(ROPE_POST_ITEM);
            event.accept(FLOOR_ARROW_ITEM);
            event.accept(TURNSTILE_ITEM);
            event.accept(TICKET_ITEM);
            event.accept(ENTRANCE_SIGN_ITEM);
            event.accept(EXIT_SIGN_ITEM);
            event.accept(NOTICE_SIGN_ITEM);
            event.accept(DIRECTION_SIGN_ITEM);
            event.accept(CROWD_SIGN_ITEM);
            event.accept(COUNTER_SIGN_ITEM);
            event.accept(FLOOR_SIGN_ITEM);
            for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                event.accept(decorItem);
            }
            for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                event.accept(bathItem.get());
            }
            for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                event.accept(kitchenItem.get());
            }
            for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                event.accept(restaurantItem.get());
            }
            for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                event.accept(arcadeItem.get());
            }
            event.accept(STATION_TRACK_ITEM);
            event.accept(LAUNCH_TRACK_ITEM);
            event.accept(BRAKE_TRACK_ITEM);
            event.accept(LIFT_TRACK_ITEM);
            event.accept(STATION_ZONE_ITEM);
            event.accept(LAUNCH_ZONE_ITEM);
            event.accept(BRAKE_ZONE_ITEM);
            event.accept(LIFT_ZONE_ITEM);
            event.accept(EFFECT_ITEM);
            event.accept(EFFECTS_PANEL_ITEM);
            event.accept(CAMERA_ITEM);
            event.accept(CONNECTOR_ITEM);
            event.accept(PHOTO_SCREEN_ITEM);
            event.accept(SPAWNER_ITEM);
            event.accept(QUEUE_MARKER_ITEM);
            event.accept(STATION_MARKER_ITEM);
            event.accept(EXIT_MARKER_ITEM);
        }
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(ButtonPacket.TYPE, ButtonPacket.CODEC, ButtonPacket::handle);
        registrar.playToServer(AnnouncePlayPacket.TYPE, AnnouncePlayPacket.CODEC, AnnouncePlayPacket::handle);
        registrar.playToServer(AnnounceConfigPacket.TYPE, AnnounceConfigPacket.CODEC, AnnounceConfigPacket::handle);
        registrar.playToServer(ClipUploadPacket.TYPE, ClipUploadPacket.CODEC, ClipUploadPacket::handle);
        registrar.playToServer(ClipRequestPacket.TYPE, ClipRequestPacket.CODEC, ClipRequestPacket::handle);
        registrar.playToClient(ClipDataPacket.TYPE, ClipDataPacket.CODEC, ClipDataPacket::handle);
        registrar.playToClient(ClipPlayPacket.TYPE, ClipPlayPacket.CODEC, ClipPlayPacket::handle);
        registrar.playToServer(ConfigPacket.TYPE, ConfigPacket.CODEC, ConfigPacket::handle);
        registrar.playToServer(AnnouncerConfigPacket.TYPE, AnnouncerConfigPacket.CODEC, AnnouncerConfigPacket::handle);
        registrar.playToServer(GateConfigPacket.TYPE, GateConfigPacket.CODEC, GateConfigPacket::handle);
        registrar.playToServer(SeatTimerPacket.TYPE, SeatTimerPacket.CODEC, SeatTimerPacket::handle);
        registrar.playToServer(SeatSpeedPacket.TYPE, SeatSpeedPacket.CODEC, SeatSpeedPacket::handle);
        registrar.playToServer(SectionConfigPacket.TYPE, SectionConfigPacket.CODEC, SectionConfigPacket::handle);
        registrar.playToServer(ZoneConfigPacket.TYPE, ZoneConfigPacket.CODEC, ZoneConfigPacket::handle);
        registrar.playToServer(EffectConfigPacket.TYPE, EffectConfigPacket.CODEC, EffectConfigPacket::handle);
        registrar.playToClient(PhotoRequestPacket.TYPE, PhotoRequestPacket.CODEC, PhotoRequestPacket::handle);
        registrar.playToServer(PhotoUploadPacket.TYPE, PhotoUploadPacket.CODEC, PhotoUploadPacket::handle);
        registrar.playToServer(PhotoFetchPacket.TYPE, PhotoFetchPacket.CODEC, PhotoFetchPacket::handle);
        registrar.playToClient(PhotoDataPacket.TYPE, PhotoDataPacket.CODEC, PhotoDataPacket::handle);
        registrar.playToServer(MarkerConfigPacket.TYPE, MarkerConfigPacket.CODEC, MarkerConfigPacket::handle);
        registrar.playToServer(GuestSpawnerConfigPacket.TYPE, GuestSpawnerConfigPacket.CODEC, GuestSpawnerConfigPacket::handle);
        registrar.playToServer(SupportConfigPacket.TYPE, SupportConfigPacket.CODEC, SupportConfigPacket::handle);
        registrar.playToServer(SignConfigPacket.TYPE, SignConfigPacket.CODEC, SignConfigPacket::handle);
        registrar.playToServer(TransferConfigPacket.TYPE, TransferConfigPacket.CODEC, TransferConfigPacket::handle);
        registrar.playToServer(KitchenConfigPacket.TYPE, KitchenConfigPacket.CODEC, KitchenConfigPacket::handle);
        registrar.playToServer(RestaurantActionPacket.TYPE, RestaurantActionPacket.CODEC, RestaurantActionPacket::handle);
        registrar.playToServer(MenuBoardPacket.TYPE, MenuBoardPacket.CODEC, MenuBoardPacket::handle);
        registrar.playToServer(ArcadeActionPacket.TYPE, ArcadeActionPacket.CODEC, ArcadeActionPacket::handle);
    }
}
