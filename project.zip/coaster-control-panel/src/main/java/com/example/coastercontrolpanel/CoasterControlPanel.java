package com.example.coastercontrolpanel;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one console block. Right-click it for the operator panel,
 * right-click with a Create wrench to set it up.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, MOD_ID);

    /** Custom 1 to 10: sounds you replace with your own .ogg files (see the resource pack). */
    public static final java.util.List<DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent>> CUSTOM_SOUNDS =
            new java.util.ArrayList<>();

    static {
        for (int i = 1; i <= 10; i++) {
            final net.minecraft.resources.ResourceLocation id =
                    net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, "custom_" + i);
            CUSTOM_SOUNDS.add(SOUND_EVENTS.register("custom_" + i,
                    () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id)));
        }
    }

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_CHAIN =
            ride("ride_chain");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_BRAKE =
            ride("ride_brake");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_HUM =
            ride("ride_hum");

    private static DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> ride(String name) {
        final net.minecraft.resources.ResourceLocation id =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id));
    }

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredBlock<PanelBlock> EFFECTS_PANEL_BLOCK = BLOCKS.register("effects_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECTS_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("effects_panel", EFFECTS_PANEL_BLOCK);

    public static final DeferredBlock<EffectBlock> EFFECT_BLOCK = BLOCKS.register("effect_machine",
            () -> new EffectBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECT_ITEM =
            ITEMS.registerSimpleBlockItem("effect_machine", EFFECT_BLOCK);

    public static final DeferredBlock<CameraBlock> CAMERA_BLOCK = BLOCKS.register("ride_camera",
            () -> new CameraBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(CameraBlock.LIT) ? 15 : 0)));

    public static final DeferredItem<BlockItem> CAMERA_ITEM =
            ITEMS.registerSimpleBlockItem("ride_camera", CAMERA_BLOCK);

    public static final DeferredItem<Item> CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("camera_connector", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<PhotoScreenBlock> PHOTO_SCREEN_BLOCK = BLOCKS.register("photo_screen",
            () -> new PhotoScreenBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PHOTO_SCREEN_ITEM =
            ITEMS.registerSimpleBlockItem("photo_screen", PHOTO_SCREEN_BLOCK);

    public static final DeferredBlock<GuestSpawnerBlock> SPAWNER_BLOCK = BLOCKS.register("guest_spawner",
            () -> new GuestSpawnerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> SPAWNER_ITEM =
            ITEMS.registerSimpleBlockItem("guest_spawner", SPAWNER_BLOCK);

    public static final DeferredBlock<MarkerBlock> QUEUE_MARKER_BLOCK = BLOCKS.register("queue_marker",
            () -> new MarkerBlock(MarkerKind.QUEUE, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> QUEUE_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("queue_marker", QUEUE_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> STATION_MARKER_BLOCK = BLOCKS.register("station_marker",
            () -> new MarkerBlock(MarkerKind.STATION, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> STATION_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("station_marker", STATION_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> EXIT_MARKER_BLOCK = BLOCKS.register("exit_marker",
            () -> new MarkerBlock(MarkerKind.EXIT, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> EXIT_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("exit_marker", EXIT_MARKER_BLOCK);

    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<GuestEntity>> GUEST = ENTITIES.register("guest",
            () -> net.minecraft.world.entity.EntityType.Builder.of(GuestEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("guest"));

    public static final DeferredBlock<AnnouncePanelBlock> ANNOUNCE_PANEL_BLOCK = BLOCKS.register("announcement_panel",
            () -> new AnnouncePanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> ANNOUNCE_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("announcement_panel", ANNOUNCE_PANEL_BLOCK);

    public static final DeferredBlock<AnnouncerBlock> ANNOUNCER_BLOCK = BLOCKS.register("announcer",
            () -> new AnnouncerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> ANNOUNCER_ITEM =
            ITEMS.registerSimpleBlockItem("announcer", ANNOUNCER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_BLOCK = BLOCKS.register("ride_gate",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> GATE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate", GATE_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_SILVER_BLOCK = BLOCKS.register("ride_gate_silver",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_silver", GATE_SILVER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_RED_BLOCK = BLOCKS.register("ride_gate_red",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_red", GATE_RED_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_BLOCK = BLOCKS.register("ride_fence",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence", RIDE_FENCE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_SILVER_BLOCK = BLOCKS.register("ride_fence_silver",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_silver", RIDE_FENCE_SILVER_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_RED_BLOCK = BLOCKS.register("ride_fence_red",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_red", RIDE_FENCE_RED_BLOCK);

    public static final DeferredBlock<Block> GATE_SILVER_LEAF = BLOCKS.register("ride_gate_silver_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> GATE_RED_LEAF = BLOCKS.register("ride_gate_red_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    /** Picks the leaf block (and so the colour) that goes with a gate block. */
    public static Block leafFor(Block gate) {
        if (gate == GATE_SILVER_BLOCK.get()) {
            return GATE_SILVER_LEAF.get();
        }
        if (gate == GATE_RED_BLOCK.get()) {
            return GATE_RED_LEAF.get();
        }
        return GATE_LEAF_BLOCK.get();
    }

    public static final DeferredBlock<SectionControllerBlock> SECTION_BLOCK = BLOCKS.register("section_controller",
            () -> new SectionControllerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(SectionControllerBlock.OCCUPIED) ? 7 : 0)));

    public static final DeferredItem<BlockItem> SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("section_controller", SECTION_BLOCK);

    public static final DeferredItem<Item> SECTION_LINKER_ITEM =
            ITEMS.registerSimpleItem("section_linker", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_PAINTER_ITEM =
            ITEMS.registerSimpleItem("track_painter", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_TOOL_ITEM =
            ITEMS.registerSimpleItem("support_tool", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_ERASER_ITEM =
            ITEMS.registerSimpleItem("support_eraser", new Item.Properties().stacksTo(1));

    // ---------------------------------------------------------------- queues and signs

    private static DeferredBlock<RideSignBlock> sign(SignKind kind) {
        return BLOCKS.register(kind.id, () -> new RideSignBlock(kind, BlockBehaviour.Properties.of()
                .strength(1.0F, 3.0F).sound(SoundType.WOOD).noOcclusion()));
    }

    public static final DeferredBlock<RideSignBlock> RIDE_SIGN_BLOCK = sign(SignKind.RIDE);
    public static final DeferredBlock<RideSignBlock> OPEN_SIGN_BLOCK = sign(SignKind.OPEN);
    public static final DeferredBlock<RideSignBlock> HEIGHT_SIGN_BLOCK = sign(SignKind.HEIGHT);
    public static final DeferredBlock<RideSignBlock> WAIT_SIGN_BLOCK = sign(SignKind.WAIT);

    public static final DeferredItem<BlockItem> RIDE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("ride_sign", RIDE_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> OPEN_SIGN_ITEM = ITEMS.registerSimpleBlockItem("open_sign", OPEN_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> HEIGHT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("height_sign", HEIGHT_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> WAIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wait_sign", WAIT_SIGN_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideSignBlockEntity>> SIGN_BE =
            BLOCK_ENTITIES.register("ride_sign", () -> BlockEntityType.Builder.of(RideSignBlockEntity::new,
                    RIDE_SIGN_BLOCK.get(), OPEN_SIGN_BLOCK.get(), HEIGHT_SIGN_BLOCK.get(), WAIT_SIGN_BLOCK.get()).build(null));

    public static final DeferredBlock<RopePostBlock> ROPE_POST_BLOCK = BLOCKS.register("rope_post",
            () -> new RopePostBlock(BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> ROPE_POST_ITEM = ITEMS.registerSimpleBlockItem("rope_post", ROPE_POST_BLOCK);

    public static final DeferredBlock<FloorArrowBlock> FLOOR_ARROW_BLOCK = BLOCKS.register("floor_arrow",
            () -> new FloorArrowBlock(BlockBehaviour.Properties.of().strength(0.3F).sound(SoundType.STONE).noOcclusion()));
    public static final DeferredItem<BlockItem> FLOOR_ARROW_ITEM = ITEMS.registerSimpleBlockItem("floor_arrow", FLOOR_ARROW_BLOCK);

    // ---------------------------------------------------------------- transfer table

    public static final DeferredBlock<TransferTableBlock> TRANSFER_BLOCK = BLOCKS.register("transfer_table",
            () -> new TransferTableBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_ITEM = ITEMS.registerSimpleBlockItem("transfer_table", TRANSFER_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TransferTableBlockEntity>> TRANSFER_BE =
            BLOCK_ENTITIES.register("transfer_table",
                    () -> BlockEntityType.Builder.of(TransferTableBlockEntity::new, TRANSFER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<TransferMenu>> TRANSFER_MENU =
            MENUS.register("transfer_table", () -> IMenuTypeExtension.create(TransferMenu::new));

    public static final DeferredBlock<PanelBlock> TRANSFER_PANEL_BLOCK = BLOCKS.register("transfer_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("transfer_panel", TRANSFER_PANEL_BLOCK);

    public static final DeferredItem<Item> STATION_TRACK_ITEM =
            ITEMS.registerSimpleItem("station_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LAUNCH_TRACK_ITEM =
            ITEMS.registerSimpleItem("launch_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> BRAKE_TRACK_ITEM =
            ITEMS.registerSimpleItem("brake_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LIFT_TRACK_ITEM =
            ITEMS.registerSimpleItem("lift_track", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<ZoneBlock> STATION_ZONE_BLOCK = BLOCKS.register("station_controller",
            () -> new ZoneBlock(ZoneType.STATION, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> STATION_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("station_controller", STATION_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LAUNCH_ZONE_BLOCK = BLOCKS.register("launch_controller",
            () -> new ZoneBlock(ZoneType.LAUNCH, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LAUNCH_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("launch_controller", LAUNCH_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> BRAKE_ZONE_BLOCK = BLOCKS.register("brake_controller",
            () -> new ZoneBlock(ZoneType.BRAKE, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> BRAKE_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("brake_controller", BRAKE_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LIFT_ZONE_BLOCK = BLOCKS.register("lift_controller",
            () -> new ZoneBlock(ZoneType.LIFT, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LIFT_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("lift_controller", LIFT_ZONE_BLOCK);

    /** Never placed. Only used by the renderer to draw the swinging gate leaf. */
    public static final DeferredBlock<Block> GATE_LEAF_BLOCK = BLOCKS.register("ride_gate_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    public static final DeferredItem<Item> SEAT_TIMER_ITEM =
            ITEMS.registerSimpleItem("seat_timer", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SEAT_SPEED_ITEM =
            ITEMS.registerSimpleItem("seat_speed", new Item.Properties().stacksTo(1));

    /** Placeholder logo, only used as the creative tab icon. Replace textures/item/panel_logo.png to change it. */
    public static final DeferredItem<Item> PANEL_LOGO = ITEMS.registerSimpleItem("panel_logo");

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get(), EFFECTS_PANEL_BLOCK.get(), TRANSFER_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncePanelBlockEntity>> ANNOUNCE_PANEL_BE =
            BLOCK_ENTITIES.register("announcement_panel",
                    () -> BlockEntityType.Builder.of(AnnouncePanelBlockEntity::new, ANNOUNCE_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncerBlockEntity>> ANNOUNCER_BE =
            BLOCK_ENTITIES.register("announcer",
                    () -> BlockEntityType.Builder.of(AnnouncerBlockEntity::new, ANNOUNCER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideGateBlockEntity>> GATE_BE =
            BLOCK_ENTITIES.register("ride_gate",
                    () -> BlockEntityType.Builder.of(RideGateBlockEntity::new, GATE_BLOCK.get(), GATE_SILVER_BLOCK.get(), GATE_RED_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SectionControllerBlockEntity>> SECTION_BE =
            BLOCK_ENTITIES.register("section_controller",
                    () -> BlockEntityType.Builder.of(SectionControllerBlockEntity::new, SECTION_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<SectionMenu>> SECTION_MENU =
            MENUS.register("section_controller", () -> IMenuTypeExtension.create(SectionMenu::new));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZoneBlockEntity>> ZONE_BE =
            BLOCK_ENTITIES.register("zone_controller",
                    () -> BlockEntityType.Builder.of(ZoneBlockEntity::new, STATION_ZONE_BLOCK.get(),
                            LAUNCH_ZONE_BLOCK.get(), BRAKE_ZONE_BLOCK.get(), LIFT_ZONE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EffectBlockEntity>> EFFECT_BE =
            BLOCK_ENTITIES.register("effect_machine",
                    () -> BlockEntityType.Builder.of(EffectBlockEntity::new, EFFECT_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CameraBlockEntity>> CAMERA_BE =
            BLOCK_ENTITIES.register("ride_camera",
                    () -> BlockEntityType.Builder.of(CameraBlockEntity::new, CAMERA_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhotoScreenBlockEntity>> PHOTO_SCREEN_BE =
            BLOCK_ENTITIES.register("photo_screen",
                    () -> BlockEntityType.Builder.of(PhotoScreenBlockEntity::new, PHOTO_SCREEN_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestSpawnerBlockEntity>> SPAWNER_BE =
            BLOCK_ENTITIES.register("guest_spawner",
                    () -> BlockEntityType.Builder.of(GuestSpawnerBlockEntity::new, SPAWNER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MarkerBlockEntity>> MARKER_BE =
            BLOCK_ENTITIES.register("guest_marker",
                    () -> BlockEntityType.Builder.of(MarkerBlockEntity::new, QUEUE_MARKER_BLOCK.get(),
                            STATION_MARKER_BLOCK.get(), EXIT_MARKER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<GuestSpawnerMenu>> SPAWNER_MENU =
            MENUS.register("guest_spawner", () -> IMenuTypeExtension.create(GuestSpawnerMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<EffectMenu>> EFFECT_MENU =
            MENUS.register("effect_machine", () -> IMenuTypeExtension.create(EffectMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<ZoneMenu>> ZONE_MENU =
            MENUS.register("zone_controller", () -> IMenuTypeExtension.create(ZoneMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<RideGateMenu>> GATE_MENU =
            MENUS.register("ride_gate", () -> IMenuTypeExtension.create(RideGateMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<AnnouncerMenu>> ANNOUNCER_MENU =
            MENUS.register("announcer", () -> IMenuTypeExtension.create(AnnouncerMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.coastercontrolpanel"))
                    .icon(() -> PANEL_LOGO.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(PANEL_ITEM.get());
                        output.accept(ANNOUNCER_ITEM.get());
                        output.accept(ANNOUNCE_PANEL_ITEM.get());
                        output.accept(GATE_ITEM.get());
                        output.accept(GATE_SILVER_ITEM.get());
                        output.accept(GATE_RED_ITEM.get());
                        output.accept(RIDE_FENCE_ITEM.get());
                        output.accept(RIDE_FENCE_SILVER_ITEM.get());
                        output.accept(RIDE_FENCE_RED_ITEM.get());
                        output.accept(SEAT_TIMER_ITEM.get());
                        output.accept(SEAT_SPEED_ITEM.get());
                        output.accept(SECTION_ITEM.get());
                        output.accept(SECTION_LINKER_ITEM.get());
                        output.accept(TRACK_PAINTER_ITEM.get());
                        output.accept(SUPPORT_TOOL_ITEM.get());
                        output.accept(SUPPORT_ERASER_ITEM.get());
                        output.accept(TRANSFER_ITEM.get());
                        output.accept(TRANSFER_PANEL_ITEM.get());
                        output.accept(RIDE_SIGN_ITEM.get());
                        output.accept(OPEN_SIGN_ITEM.get());
                        output.accept(HEIGHT_SIGN_ITEM.get());
                        output.accept(WAIT_SIGN_ITEM.get());
                        output.accept(ROPE_POST_ITEM.get());
                        output.accept(FLOOR_ARROW_ITEM.get());
                        output.accept(STATION_TRACK_ITEM.get());
                        output.accept(LAUNCH_TRACK_ITEM.get());
                        output.accept(BRAKE_TRACK_ITEM.get());
                        output.accept(LIFT_TRACK_ITEM.get());
                        output.accept(STATION_ZONE_ITEM.get());
                        output.accept(LAUNCH_ZONE_ITEM.get());
                        output.accept(BRAKE_ZONE_ITEM.get());
                        output.accept(LIFT_ZONE_ITEM.get());
                        output.accept(EFFECT_ITEM.get());
                        output.accept(EFFECTS_PANEL_ITEM.get());
                        output.accept(CAMERA_ITEM.get());
                        output.accept(CONNECTOR_ITEM.get());
                        output.accept(PHOTO_SCREEN_ITEM.get());
                        output.accept(SPAWNER_ITEM.get());
                        output.accept(QUEUE_MARKER_ITEM.get());
                        output.accept(STATION_MARKER_ITEM.get());
                        output.accept(EXIT_MARKER_ITEM.get());
                    })
                    .build());

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ENTITIES.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);
        SOUND_EVENTS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(this::registerPayloads);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
            event.accept(ANNOUNCER_ITEM);
            event.accept(ANNOUNCE_PANEL_ITEM);
            event.accept(GATE_ITEM);
            event.accept(GATE_SILVER_ITEM);
            event.accept(GATE_RED_ITEM);
            event.accept(RIDE_FENCE_ITEM);
            event.accept(RIDE_FENCE_SILVER_ITEM);
            event.accept(RIDE_FENCE_RED_ITEM);
            event.accept(SEAT_TIMER_ITEM);
            event.accept(SEAT_SPEED_ITEM);
            event.accept(SECTION_ITEM);
            event.accept(SECTION_LINKER_ITEM);
            event.accept(TRACK_PAINTER_ITEM);
            event.accept(SUPPORT_TOOL_ITEM);
            event.accept(SUPPORT_ERASER_ITEM);
            event.accept(TRANSFER_ITEM);
            event.accept(TRANSFER_PANEL_ITEM);
            event.accept(RIDE_SIGN_ITEM);
            event.accept(OPEN_SIGN_ITEM);
            event.accept(HEIGHT_SIGN_ITEM);
            event.accept(WAIT_SIGN_ITEM);
            event.accept(ROPE_POST_ITEM);
            event.accept(FLOOR_ARROW_ITEM);
            event.accept(STATION_TRACK_ITEM);
            event.accept(LAUNCH_TRACK_ITEM);
            event.accept(BRAKE_TRACK_ITEM);
            event.accept(LIFT_TRACK_ITEM);
            event.accept(STATION_ZONE_ITEM);
            event.accept(LAUNCH_ZONE_ITEM);
            event.accept(BRAKE_ZONE_ITEM);
            event.accept(LIFT_ZONE_ITEM);
            event.accept(EFFECT_ITEM);
            event.accept(EFFECTS_PANEL_ITEM);
            event.accept(CAMERA_ITEM);
            event.accept(CONNECTOR_ITEM);
            event.accept(PHOTO_SCREEN_ITEM);
            event.accept(SPAWNER_ITEM);
            event.accept(QUEUE_MARKER_ITEM);
            event.accept(STATION_MARKER_ITEM);
            event.accept(EXIT_MARKER_ITEM);
        }
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(ButtonPacket.TYPE, ButtonPacket.CODEC, ButtonPacket::handle);
        registrar.playToServer(AnnouncePlayPacket.TYPE, AnnouncePlayPacket.CODEC, AnnouncePlayPacket::handle);
        registrar.playToServer(AnnounceConfigPacket.TYPE, AnnounceConfigPacket.CODEC, AnnounceConfigPacket::handle);
        registrar.playToServer(ClipUploadPacket.TYPE, ClipUploadPacket.CODEC, ClipUploadPacket::handle);
        registrar.playToServer(ClipRequestPacket.TYPE, ClipRequestPacket.CODEC, ClipRequestPacket::handle);
        registrar.playToClient(ClipDataPacket.TYPE, ClipDataPacket.CODEC, ClipDataPacket::handle);
        registrar.playToClient(ClipPlayPacket.TYPE, ClipPlayPacket.CODEC, ClipPlayPacket::handle);
        registrar.playToServer(ConfigPacket.TYPE, ConfigPacket.CODEC, ConfigPacket::handle);
        registrar.playToServer(AnnouncerConfigPacket.TYPE, AnnouncerConfigPacket.CODEC, AnnouncerConfigPacket::handle);
        registrar.playToServer(GateConfigPacket.TYPE, GateConfigPacket.CODEC, GateConfigPacket::handle);
        registrar.playToServer(SeatTimerPacket.TYPE, SeatTimerPacket.CODEC, SeatTimerPacket::handle);
        registrar.playToServer(SeatSpeedPacket.TYPE, SeatSpeedPacket.CODEC, SeatSpeedPacket::handle);
        registrar.playToServer(SectionConfigPacket.TYPE, SectionConfigPacket.CODEC, SectionConfigPacket::handle);
        registrar.playToServer(ZoneConfigPacket.TYPE, ZoneConfigPacket.CODEC, ZoneConfigPacket::handle);
        registrar.playToServer(EffectConfigPacket.TYPE, EffectConfigPacket.CODEC, EffectConfigPacket::handle);
        registrar.playToClient(PhotoRequestPacket.TYPE, PhotoRequestPacket.CODEC, PhotoRequestPacket::handle);
        registrar.playToServer(PhotoUploadPacket.TYPE, PhotoUploadPacket.CODEC, PhotoUploadPacket::handle);
        registrar.playToServer(PhotoFetchPacket.TYPE, PhotoFetchPacket.CODEC, PhotoFetchPacket::handle);
        registrar.playToClient(PhotoDataPacket.TYPE, PhotoDataPacket.CODEC, PhotoDataPacket::handle);
        registrar.playToServer(MarkerConfigPacket.TYPE, MarkerConfigPacket.CODEC, MarkerConfigPacket::handle);
        registrar.playToServer(GuestSpawnerConfigPacket.TYPE, GuestSpawnerConfigPacket.CODEC, GuestSpawnerConfigPacket::handle);
        registrar.playToServer(SupportConfigPacket.TYPE, SupportConfigPacket.CODEC, SupportConfigPacket::handle);
        registrar.playToServer(SignConfigPacket.TYPE, SignConfigPacket.CODEC, SignConfigPacket::handle);
        registrar.playToServer(TransferConfigPacket.TYPE, TransferConfigPacket.CODEC, TransferConfigPacket::handle);
    }
}
