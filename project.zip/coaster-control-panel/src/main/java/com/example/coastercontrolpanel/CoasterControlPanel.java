package com.example.coastercontrolpanel;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one console block. Right-click it for the operator panel,
 * right-click with a Create wrench to set it up.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, MOD_ID);

    /** Custom 1 to 10: sounds you replace with your own .ogg files (see the resource pack). */
    public static final java.util.List<DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent>> CUSTOM_SOUNDS =
            new java.util.ArrayList<>();

    static {
        for (int i = 1; i <= 10; i++) {
            final net.minecraft.resources.ResourceLocation id =
                    net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, "custom_" + i);
            CUSTOM_SOUNDS.add(SOUND_EVENTS.register("custom_" + i,
                    () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id)));
        }
    }

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_CHAIN =
            ride("ride_chain");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_BRAKE =
            ride("ride_brake");
    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> RIDE_HUM =
            ride("ride_hum");

    private static DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> ride(String name) {
        final net.minecraft.resources.ResourceLocation id =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(id));
    }

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredBlock<PanelBlock> EFFECTS_PANEL_BLOCK = BLOCKS.register("effects_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECTS_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("effects_panel", EFFECTS_PANEL_BLOCK);

    public static final DeferredBlock<EffectBlock> EFFECT_BLOCK = BLOCKS.register("effect_machine",
            () -> new EffectBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> EFFECT_ITEM =
            ITEMS.registerSimpleBlockItem("effect_machine", EFFECT_BLOCK);

    public static final DeferredBlock<CameraBlock> CAMERA_BLOCK = BLOCKS.register("ride_camera",
            () -> new CameraBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(state -> state.getValue(CameraBlock.LIT) ? 15 : 0)));

    public static final DeferredItem<BlockItem> CAMERA_ITEM =
            ITEMS.registerSimpleBlockItem("ride_camera", CAMERA_BLOCK);

    public static final DeferredItem<Item> CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("camera_connector", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<PhotoScreenBlock> PHOTO_SCREEN_BLOCK = BLOCKS.register("photo_screen",
            () -> new PhotoScreenBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> PHOTO_SCREEN_ITEM =
            ITEMS.registerSimpleBlockItem("photo_screen", PHOTO_SCREEN_BLOCK);

    public static final DeferredBlock<GuestSpawnerBlock> SPAWNER_BLOCK = BLOCKS.register("guest_spawner",
            () -> new GuestSpawnerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> SPAWNER_ITEM =
            ITEMS.registerSimpleBlockItem("guest_spawner", SPAWNER_BLOCK);

    public static final DeferredBlock<MarkerBlock> QUEUE_MARKER_BLOCK = BLOCKS.register("queue_marker",
            () -> new MarkerBlock(MarkerKind.QUEUE, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> QUEUE_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("queue_marker", QUEUE_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> STATION_MARKER_BLOCK = BLOCKS.register("station_marker",
            () -> new MarkerBlock(MarkerKind.STATION, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> STATION_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("station_marker", STATION_MARKER_BLOCK);

    public static final DeferredBlock<MarkerBlock> EXIT_MARKER_BLOCK = BLOCKS.register("exit_marker",
            () -> new MarkerBlock(MarkerKind.EXIT, BlockBehaviour.Properties.of()
                    .strength(0.5F).sound(SoundType.WOOL).noOcclusion().noCollission()));
    public static final DeferredItem<BlockItem> EXIT_MARKER_ITEM =
            ITEMS.registerSimpleBlockItem("exit_marker", EXIT_MARKER_BLOCK);

    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<GuestEntity>> GUEST = ENTITIES.register("guest",
            () -> net.minecraft.world.entity.EntityType.Builder.of(GuestEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("guest"));

    public static final DeferredBlock<AnnouncePanelBlock> ANNOUNCE_PANEL_BLOCK = BLOCKS.register("announcement_panel",
            () -> new AnnouncePanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> ANNOUNCE_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("announcement_panel", ANNOUNCE_PANEL_BLOCK);

    public static final DeferredBlock<AnnouncerBlock> ANNOUNCER_BLOCK = BLOCKS.register("announcer",
            () -> new AnnouncerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));

    public static final DeferredItem<BlockItem> ANNOUNCER_ITEM =
            ITEMS.registerSimpleBlockItem("announcer", ANNOUNCER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_BLOCK = BLOCKS.register("ride_gate",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));

    public static final DeferredItem<BlockItem> GATE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate", GATE_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_SILVER_BLOCK = BLOCKS.register("ride_gate_silver",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_silver", GATE_SILVER_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_RED_BLOCK = BLOCKS.register("ride_gate_red",
            () -> new RideGateBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_gate_red", GATE_RED_BLOCK);

    public static final DeferredBlock<RideGateBlock> GATE_DOUBLE_BLOCK = BLOCKS.register("ride_gate_double",
            () -> new RideDoubleGateBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.WOOD).noOcclusion()));
    public static final DeferredItem<BlockItem> GATE_DOUBLE_ITEM = ITEMS.registerSimpleBlockItem("ride_gate_double", GATE_DOUBLE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_BLOCK = BLOCKS.register("ride_fence",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence", RIDE_FENCE_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_SILVER_BLOCK = BLOCKS.register("ride_fence_silver",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_SILVER_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_silver", RIDE_FENCE_SILVER_BLOCK);

    public static final DeferredBlock<RideFenceBlock> RIDE_FENCE_RED_BLOCK = BLOCKS.register("ride_fence_red",
            () -> new RideFenceBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()));
    public static final DeferredItem<BlockItem> RIDE_FENCE_RED_ITEM =
            ITEMS.registerSimpleBlockItem("ride_fence_red", RIDE_FENCE_RED_BLOCK);

    public static final DeferredBlock<Block> GATE_SILVER_LEAF = BLOCKS.register("ride_gate_silver_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));
    public static final DeferredBlock<Block> GATE_RED_LEAF = BLOCKS.register("ride_gate_red_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    /** Picks the leaf block (and so the colour) that goes with a gate block. */
    public static Block leafFor(Block gate) {
        if (gate == GATE_SILVER_BLOCK.get()) {
            return GATE_SILVER_LEAF.get();
        }
        if (gate == GATE_RED_BLOCK.get()) {
            return GATE_RED_LEAF.get();
        }
        return GATE_LEAF_BLOCK.get();
    }

    public static final DeferredBlock<SectionControllerBlock> SECTION_BLOCK = BLOCKS.register("section_controller",
            () -> new SectionControllerBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(SectionControllerBlock.OCCUPIED) ? 7 : 0)));

    public static final DeferredItem<BlockItem> SECTION_ITEM =
            ITEMS.registerSimpleBlockItem("section_controller", SECTION_BLOCK);

    public static final DeferredItem<Item> SECTION_LINKER_ITEM =
            ITEMS.registerSimpleItem("section_linker", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_PAINTER_ITEM =
            ITEMS.registerSimpleItem("track_painter", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> COASTER_SMOOTHER_ITEM =
            ITEMS.registerSimpleItem("coaster_smoother", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> TRACK_UNRESTRICTOR_ITEM =
            ITEMS.registerSimpleItem("track_unrestrictor", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<AnimatronicBlock> ANIMATRONIC_BLOCK = BLOCKS.register("animatronic",
            () -> new AnimatronicBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ANIMATRONIC_ITEM = ITEMS.registerSimpleBlockItem("animatronic", ANIMATRONIC_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnimatronicBlockEntity>> ANIMATRONIC_BE =
            BLOCK_ENTITIES.register("animatronic",
                    () -> BlockEntityType.Builder.of(AnimatronicBlockEntity::new, ANIMATRONIC_BLOCK.get()).build(null));
    public static final DeferredItem<Item> ANIMATRONIC_TOOL_ITEM =
            ITEMS.registerSimpleItem("animatronic_tool", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<AnimationControllerBlock> ANIMATION_CONTROLLER_BLOCK = BLOCKS.register("animation_controller",
            () -> new AnimationControllerBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL)));
    public static final DeferredItem<BlockItem> ANIMATION_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("animation_controller", ANIMATION_CONTROLLER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnimationControllerBlockEntity>> ANIMATION_CONTROLLER_BE =
            BLOCK_ENTITIES.register("animation_controller",
                    () -> BlockEntityType.Builder.of(AnimationControllerBlockEntity::new, ANIMATION_CONTROLLER_BLOCK.get()).build(null));
    public static final DeferredItem<Item> ANIMATION_CONNECTOR_ITEM =
            ITEMS.registerSimpleItem("animation_connector", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> DRIVE_TYRE_ITEM =
            ITEMS.registerSimpleItem("drive_tyre", new Item.Properties());

    public static final DeferredItem<Item> TRACK_ELEMENT_SELECTOR_ITEM =
            ITEMS.registerSimpleItem("track_element_selector", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_TOOL_ITEM =
            ITEMS.registerSimpleItem("support_tool", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SUPPORT_ERASER_ITEM =
            ITEMS.registerSimpleItem("support_eraser", new Item.Properties().stacksTo(1));

    // ---------------------------------------------------------------- queues and signs

    private static DeferredBlock<RideSignBlock> sign(SignKind kind) {
        return BLOCKS.register(kind.id, () -> new RideSignBlock(kind, BlockBehaviour.Properties.of()
                .strength(1.0F, 3.0F).sound(SoundType.WOOD).noOcclusion()));
    }

    public static final DeferredBlock<RideSignBlock> RIDE_SIGN_BLOCK = sign(SignKind.RIDE);
    public static final DeferredBlock<RideSignBlock> OPEN_SIGN_BLOCK = sign(SignKind.OPEN);
    public static final DeferredBlock<RideSignBlock> HEIGHT_SIGN_BLOCK = sign(SignKind.HEIGHT);
    public static final DeferredBlock<RideSignBlock> WAIT_SIGN_BLOCK = sign(SignKind.WAIT);

    public static final DeferredItem<BlockItem> RIDE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("ride_sign", RIDE_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> OPEN_SIGN_ITEM = ITEMS.registerSimpleBlockItem("open_sign", OPEN_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> HEIGHT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("height_sign", HEIGHT_SIGN_BLOCK);
    public static final DeferredItem<BlockItem> WAIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wait_sign", WAIT_SIGN_BLOCK);

    public static final DeferredBlock<RideSignBlock> ENTRANCE_SIGN_BLOCK = sign(SignKind.ENTRANCE);
    public static final DeferredItem<BlockItem> ENTRANCE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("entrance_sign", ENTRANCE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> EXIT_SIGN_BLOCK = sign(SignKind.EXIT);
    public static final DeferredItem<BlockItem> EXIT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("exit_sign", EXIT_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> NOTICE_SIGN_BLOCK = sign(SignKind.NOTICE);
    public static final DeferredItem<BlockItem> NOTICE_SIGN_ITEM = ITEMS.registerSimpleBlockItem("notice_sign", NOTICE_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> DIRECTION_SIGN_BLOCK = sign(SignKind.DIRECTION);
    public static final DeferredItem<BlockItem> DIRECTION_SIGN_ITEM = ITEMS.registerSimpleBlockItem("direction_sign", DIRECTION_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> CROWD_SIGN_BLOCK = sign(SignKind.CROWD);
    public static final DeferredItem<BlockItem> CROWD_SIGN_ITEM = ITEMS.registerSimpleBlockItem("queue_status_sign", CROWD_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> COUNTER_SIGN_BLOCK = sign(SignKind.COUNTER);
    public static final DeferredItem<BlockItem> COUNTER_SIGN_ITEM = ITEMS.registerSimpleBlockItem("rides_today_sign", COUNTER_SIGN_BLOCK);
    public static final DeferredBlock<RideSignBlock> FLOOR_SIGN_BLOCK = sign(SignKind.FLOOR);
    public static final DeferredItem<BlockItem> FLOOR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("floor_sign", FLOOR_SIGN_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideSignBlockEntity>> SIGN_BE =
            BLOCK_ENTITIES.register("ride_sign", () -> BlockEntityType.Builder.of(RideSignBlockEntity::new,
                    RIDE_SIGN_BLOCK.get(), OPEN_SIGN_BLOCK.get(), HEIGHT_SIGN_BLOCK.get(), WAIT_SIGN_BLOCK.get(),
                    ENTRANCE_SIGN_BLOCK.get(), EXIT_SIGN_BLOCK.get(), NOTICE_SIGN_BLOCK.get(), DIRECTION_SIGN_BLOCK.get(),
                    CROWD_SIGN_BLOCK.get(), COUNTER_SIGN_BLOCK.get(), FLOOR_SIGN_BLOCK.get()).build(null));

    public static final DeferredBlock<RopePostBlock> ROPE_POST_BLOCK = BLOCKS.register("rope_post",
            () -> new RopePostBlock(BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> ROPE_POST_ITEM = ITEMS.registerSimpleBlockItem("rope_post", ROPE_POST_BLOCK);

    public static final DeferredBlock<FloorArrowBlock> FLOOR_ARROW_BLOCK = BLOCKS.register("floor_arrow",
            () -> new FloorArrowBlock(BlockBehaviour.Properties.of().strength(0.3F).sound(SoundType.STONE).noOcclusion()));
    public static final DeferredItem<BlockItem> FLOOR_ARROW_ITEM = ITEMS.registerSimpleBlockItem("floor_arrow", FLOOR_ARROW_BLOCK);

    // ---------------------------------------------------------------- transfer table

    public static final DeferredBlock<TransferTableBlock> TRANSFER_BLOCK = BLOCKS.register("transfer_table",
            () -> new TransferTableBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_ITEM = ITEMS.registerSimpleBlockItem("transfer_table", TRANSFER_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TransferTableBlockEntity>> TRANSFER_BE =
            BLOCK_ENTITIES.register("transfer_table",
                    () -> BlockEntityType.Builder.of(TransferTableBlockEntity::new, TRANSFER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<TransferMenu>> TRANSFER_MENU =
            MENUS.register("transfer_table", () -> IMenuTypeExtension.create(TransferMenu::new));

    public static final DeferredBlock<PanelBlock> TRANSFER_PANEL_BLOCK = BLOCKS.register("transfer_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TRANSFER_PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("transfer_panel", TRANSFER_PANEL_BLOCK);

    // ---------------------------------------------------------------- park decor

    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<SeatEntity>> SEAT = ENTITIES.register("seat",
            () -> net.minecraft.world.entity.EntityType.Builder.<SeatEntity>of(SeatEntity::new,
                            net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.1F, 0.1F).noSave().noSummon().fireImmune().clientTrackingRange(8).build("seat"));

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent, net.minecraft.sounds.SoundEvent> PARK_JINGLE =
            ride("park_jingle");

    private static BlockBehaviour.Properties decor(SoundType sound) {
        return BlockBehaviour.Properties.of().strength(1.0F, 3.0F).sound(sound).noOcclusion().isViewBlocking((s, l, p) -> false).isSuffocating((s, l, p) -> false);
    }

    private static final net.minecraft.world.item.ItemStack[] SNACKS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.COOKIE, 2),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.APPLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BREAD),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BAKED_POTATO),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.PUMPKIN_PIE)};
    private static final net.minecraft.world.item.ItemStack[] SWEETS = {
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.HONEY_BOTTLE),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SWEET_BERRIES, 3),
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SUGAR, 2)};

    public static final DeferredBlock<Block> BENCH_BLOCK = BLOCKS.register("bench", () -> new DecorBlocks.BenchBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> DECK_CHAIR_BLOCK = BLOCKS.register("deck_chair", () -> new DecorBlocks.SeatBlock(true, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BIN_BLOCK = BLOCKS.register("litter_bin", () -> new DecorBlocks.BinBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> LAMP_POST_BLOCK = BLOCKS.register("lamp_post", () -> new DecorBlocks.LampBlock(true,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 15 : 0)));
    public static final DeferredBlock<Block> GARDEN_LIGHT_BLOCK = BLOCKS.register("garden_light", () -> new DecorBlocks.LampBlock(false,
            decor(SoundType.METAL).lightLevel(st -> st.getValue(DecorBlocks.LIT) ? 13 : 0)));
    public static final DeferredBlock<Block> CLOCK_BLOCK = BLOCKS.register("park_clock", () -> new DecorBlocks.ClockBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> MAP_BOARD_BLOCK = BLOCKS.register("park_map", () -> new DecorBlocks.MapBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> BOOTH_BLOCK = BLOCKS.register("ticket_booth", () -> new DecorBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> SNACK_BLOCK = BLOCKS.register("snack_machine", () -> new DecorBlocks.VendingBlock(SNACKS, decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CANDY_BLOCK = BLOCKS.register("candy_stand", () -> new DecorBlocks.VendingBlock(SWEETS, decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FOUNTAIN_BLOCK = BLOCKS.register("drinking_fountain", () -> new DecorBlocks.FountainBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> PLANTER_BLOCK = BLOCKS.register("flower_planter", () -> new DecorBlocks.PlanterBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> FLAG_BLOCK = BLOCKS.register("park_flag", () -> new DecorBlocks.FlagBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SPEAKER_BLOCK = BLOCKS.register("park_speaker", () -> new DecorBlocks.SpeakerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> BOUNCY_BLOCK = BLOCKS.register("bouncy_pad", () -> new DecorBlocks.BouncyPadBlock(decor(SoundType.SLIME_BLOCK)));
    public static final DeferredBlock<Block> MISTER_BLOCK = BLOCKS.register("cooling_mister", () -> new DecorBlocks.MisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BENCH_ITEM = ITEMS.registerSimpleBlockItem("bench", BENCH_BLOCK);
    public static final DeferredItem<BlockItem> DECK_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("deck_chair", DECK_CHAIR_BLOCK);
    public static final DeferredItem<BlockItem> BIN_ITEM = ITEMS.registerSimpleBlockItem("litter_bin", BIN_BLOCK);
    public static final DeferredItem<BlockItem> LAMP_POST_ITEM = ITEMS.registerSimpleBlockItem("lamp_post", LAMP_POST_BLOCK);
    public static final DeferredItem<BlockItem> GARDEN_LIGHT_ITEM = ITEMS.registerSimpleBlockItem("garden_light", GARDEN_LIGHT_BLOCK);
    public static final DeferredItem<BlockItem> CLOCK_ITEM = ITEMS.registerSimpleBlockItem("park_clock", CLOCK_BLOCK);
    public static final DeferredItem<BlockItem> MAP_BOARD_ITEM = ITEMS.registerSimpleBlockItem("park_map", MAP_BOARD_BLOCK);
    public static final DeferredItem<BlockItem> BOOTH_ITEM = ITEMS.registerSimpleBlockItem("ticket_booth", BOOTH_BLOCK);
    public static final DeferredItem<BlockItem> SNACK_ITEM = ITEMS.registerSimpleBlockItem("snack_machine", SNACK_BLOCK);
    public static final DeferredItem<BlockItem> CANDY_ITEM = ITEMS.registerSimpleBlockItem("candy_stand", CANDY_BLOCK);
    public static final DeferredItem<BlockItem> FOUNTAIN_ITEM = ITEMS.registerSimpleBlockItem("drinking_fountain", FOUNTAIN_BLOCK);
    public static final DeferredItem<BlockItem> PLANTER_ITEM = ITEMS.registerSimpleBlockItem("flower_planter", PLANTER_BLOCK);
    public static final DeferredItem<BlockItem> FLAG_ITEM = ITEMS.registerSimpleBlockItem("park_flag", FLAG_BLOCK);
    public static final DeferredItem<BlockItem> SPEAKER_ITEM = ITEMS.registerSimpleBlockItem("park_speaker", SPEAKER_BLOCK);
    public static final DeferredItem<BlockItem> BOUNCY_ITEM = ITEMS.registerSimpleBlockItem("bouncy_pad", BOUNCY_BLOCK);
    public static final DeferredItem<BlockItem> MISTER_ITEM = ITEMS.registerSimpleBlockItem("cooling_mister", MISTER_BLOCK);

    // ---- Bathroom pack
    public static final DeferredBlock<Block> TOILET_BLOCK = BLOCKS.register("toilet", () -> new BathroomBlocks.FlushBlock(false, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> URINAL_BLOCK = BLOCKS.register("urinal", () -> new BathroomBlocks.FlushBlock(true, decor(SoundType.STONE)));
    public static final DeferredBlock<Block> SINK_BLOCK = BLOCKS.register("sink", () -> new BathroomBlocks.SinkBlock(decor(SoundType.STONE)));
    public static final DeferredBlock<Block> HAND_DRYER_BLOCK = BLOCKS.register("hand_dryer", () -> new BathroomBlocks.DryerBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SOAP_DISPENSER_BLOCK = BLOCKS.register("soap_dispenser", () -> new BathroomBlocks.SoapDispenserBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> ROLL_HOLDER_BLOCK = BLOCKS.register("toilet_roll_holder", () -> new BathroomBlocks.RollHolderBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> CUBICLE_BLOCK = BLOCKS.register("toilet_cubicle", () -> new BathroomBlocks.CubicleBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SIGN_MEN_BLOCK = BLOCKS.register("toilet_sign_men", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_WOMEN_BLOCK = BLOCKS.register("toilet_sign_women", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_ACCESS_BLOCK = BLOCKS.register("toilet_sign_accessible", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredBlock<Block> SIGN_BABY_BLOCK = BLOCKS.register("toilet_sign_baby", () -> new BathroomBlocks.ToiletSignBlock(decor(SoundType.METAL).lightLevel(st -> 4)));
    public static final DeferredItem<BlockItem> TOILET_ITEM = ITEMS.registerSimpleBlockItem("toilet", TOILET_BLOCK);
    public static final DeferredBlock<Block> SINK_TOP = BLOCKS.register("sink_top", () -> TallBlocks.Top.create(SINK_BLOCK, (st, part) -> BathroomBlocks.sinkTopShape(st.getValue(DecorBlocks.FACING)), decor(SoundType.STONE), BathroomBlocks.RUNNING));
    public static final DeferredBlock<Block> URINAL_TOP = BLOCKS.register("urinal_top", () -> TallBlocks.Top.create(URINAL_BLOCK, (st, part) -> BathroomBlocks.urinalTopShape(st.getValue(DecorBlocks.FACING)), decor(SoundType.STONE), BathroomBlocks.FLUSH));
    public static final DeferredItem<BlockItem> URINAL_ITEM = ITEMS.<BlockItem>register("urinal", () -> new TallBlocks.Item(URINAL_BLOCK.get(), new Item.Properties(), URINAL_TOP, 2));
    public static final DeferredItem<BlockItem> SINK_ITEM = ITEMS.<BlockItem>register("sink", () -> new TallBlocks.Item(SINK_BLOCK.get(), new Item.Properties(), SINK_TOP, 2));
    public static final DeferredBlock<Block> CUBICLE_PANEL_BLOCK = BLOCKS.register("cubicle_panel", () -> new BathroomBlocks.CubiclePanelBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CUBICLE_PANEL_ITEM = ITEMS.registerSimpleBlockItem("cubicle_panel", CUBICLE_PANEL_BLOCK);
    public static final DeferredItem<Item> CUBICLE_KIT_ITEM = ITEMS.<Item>register("cubicle_kit", () -> new BathroomBlocks.CubicleKitItem(new Item.Properties()));
    public static final DeferredItem<BlockItem> HAND_DRYER_ITEM = ITEMS.registerSimpleBlockItem("hand_dryer", HAND_DRYER_BLOCK);
    public static final DeferredItem<BlockItem> SOAP_DISPENSER_ITEM = ITEMS.registerSimpleBlockItem("soap_dispenser", SOAP_DISPENSER_BLOCK);
    public static final DeferredItem<BlockItem> ROLL_HOLDER_ITEM = ITEMS.registerSimpleBlockItem("toilet_roll_holder", ROLL_HOLDER_BLOCK);
    public static final DeferredBlock<Block> CUBICLE_TOP = BLOCKS.register("toilet_cubicle_top", () -> TallBlocks.Top.create(CUBICLE_BLOCK, null, decor(SoundType.METAL), net.minecraft.world.level.block.state.properties.BlockStateProperties.OPEN));
    public static final DeferredItem<BlockItem> CUBICLE_ITEM = ITEMS.<BlockItem>register("toilet_cubicle", () -> new TallBlocks.Item(CUBICLE_BLOCK.get(), new Item.Properties(), CUBICLE_TOP, 2));
    public static final DeferredItem<BlockItem> SIGN_MEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_men", SIGN_MEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_WOMEN_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_women", SIGN_WOMEN_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_ACCESS_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_accessible", SIGN_ACCESS_BLOCK);
    public static final DeferredItem<BlockItem> SIGN_BABY_ITEM = ITEMS.registerSimpleBlockItem("toilet_sign_baby", SIGN_BABY_BLOCK);
    public static final DeferredItem<Item> SOAP_ITEM = ITEMS.registerSimpleItem("soap", new Item.Properties());
    public static final java.util.List<DeferredItem<? extends Item>> BATH_ITEMS = java.util.List.of(
            CUBICLE_KIT_ITEM, CUBICLE_ITEM, CUBICLE_PANEL_ITEM, TOILET_ITEM, URINAL_ITEM, SINK_ITEM, HAND_DRYER_ITEM, SOAP_DISPENSER_ITEM, SOAP_ITEM,
            ROLL_HOLDER_ITEM, SIGN_MEN_ITEM, SIGN_WOMEN_ITEM, SIGN_ACCESS_ITEM, SIGN_BABY_ITEM);

    // ---- Kitchen pack
    public static final DeferredItem<Item> BUN = ITEMS.registerSimpleItem("bun", new Item.Properties());
    public static final DeferredItem<Item> RAW_PATTY = ITEMS.registerSimpleItem("raw_patty", new Item.Properties());
    public static final DeferredItem<Item> COOKED_PATTY = ITEMS.registerSimpleItem("cooked_patty", new Item.Properties());
    public static final DeferredItem<Item> RAW_SAUSAGE = ITEMS.registerSimpleItem("raw_sausage", new Item.Properties());
    public static final DeferredItem<Item> COOKED_SAUSAGE = ITEMS.registerSimpleItem("cooked_sausage", new Item.Properties());
    public static final DeferredItem<Item> DOUGH = ITEMS.registerSimpleItem("dough", new Item.Properties());
    public static final DeferredItem<Item> POTATO_STRIPS = ITEMS.registerSimpleItem("potato_strips", new Item.Properties());
    public static final DeferredItem<Item> BURGER = ITEMS.registerSimpleItem("burger", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> HOT_DOG = ITEMS.registerSimpleItem("hot_dog", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> CHIPS = ITEMS.registerSimpleItem("chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).fast().build()));
    public static final DeferredItem<Item> DOUGHNUT = ITEMS.registerSimpleItem("doughnut", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> PIZZA_SLICE = ITEMS.registerSimpleItem("pizza_slice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> ICE_CREAM = ITEMS.registerSimpleItem("ice_cream", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> POPCORN_ITEM = ITEMS.registerSimpleItem("popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).fast().build()));
    public static final DeferredItem<Item> APPLE_JUICE = ITEMS.register("apple_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.REGENERATION, 5));
    public static final DeferredItem<Item> BERRY_FIZZ = ITEMS.register("berry_fizz", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.JUMP, 15));
    public static final DeferredItem<Item> MELON_JUICE = ITEMS.register("melon_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.WATER_BREATHING, 20));
    public static final DeferredItem<Item> COLA = ITEMS.register("cola", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.1F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 10));
    public static final DeferredItem<Item> CHEESE = ITEMS.registerSimpleItem("cheese", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.4F).build()));
    public static final DeferredItem<Item> SALAD = ITEMS.registerSimpleItem("salad", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> CHEESEBURGER = ITEMS.registerSimpleItem("cheeseburger", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(10).saturationModifier(0.9F).build()));
    public static final DeferredItem<Item> CHICKEN_SANDWICH = ITEMS.registerSimpleItem("chicken_sandwich", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> HAM_SANDWICH = ITEMS.registerSimpleItem("ham_sandwich", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> TORTILLA = ITEMS.registerSimpleItem("tortilla", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).build()));
    public static final DeferredItem<Item> TACO = ITEMS.registerSimpleItem("taco", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> BURRITO = ITEMS.registerSimpleItem("burrito", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(9).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> TORTILLA_CHIPS = ITEMS.registerSimpleItem("tortilla_chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> NACHOS = ITEMS.registerSimpleItem("nachos", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> FRUIT_CUP = ITEMS.registerSimpleItem("fruit_cup", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.5F).fast().build()));
    public static final DeferredItem<Item> CANDY_FLOSS = ITEMS.registerSimpleItem("candy_floss", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).fast().build()));
    public static final DeferredItem<Item> CARAMEL_POPCORN = ITEMS.registerSimpleItem("caramel_popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> CHOCOLATE_POPCORN = ITEMS.registerSimpleItem("chocolate_popcorn", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> FRIED_CHICKEN = ITEMS.registerSimpleItem("fried_chicken", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> CHURRO = ITEMS.registerSimpleItem("churro", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> FISH_AND_CHIPS = ITEMS.registerSimpleItem("fish_and_chips", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(10).saturationModifier(0.9F).build()));
    public static final DeferredItem<Item> FISH_FINGERS = ITEMS.registerSimpleItem("fish_fingers", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> NUGGETS = ITEMS.registerSimpleItem("nuggets", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.6F).fast().build()));
    public static final DeferredItem<Item> CORN_DOG = ITEMS.registerSimpleItem("corn_dog", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(7).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> CHEESE_PIZZA = ITEMS.registerSimpleItem("cheese_pizza", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> APPLE_PIE = ITEMS.registerSimpleItem("apple_pie", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> CHOC_COOKIE = ITEMS.registerSimpleItem("choc_cookie", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> CAKE_SLICE = ITEMS.registerSimpleItem("cake_slice", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.4F).build()));
    public static final DeferredItem<Item> MUFFIN = ITEMS.registerSimpleItem("muffin", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> LOADED_POTATO = ITEMS.registerSimpleItem("loaded_potato", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(9).saturationModifier(0.8F).build()));
    public static final DeferredItem<Item> SAUSAGE_ROLL = ITEMS.registerSimpleItem("sausage_roll", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(6).saturationModifier(0.6F).build()));
    public static final DeferredItem<Item> PASTY = ITEMS.registerSimpleItem("pasty", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(8).saturationModifier(0.7F).build()));
    public static final DeferredItem<Item> PRETZEL = ITEMS.registerSimpleItem("pretzel", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> CHOC_ICE_CREAM = ITEMS.registerSimpleItem("choc_ice_cream", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> ICE_LOLLY = ITEMS.registerSimpleItem("ice_lolly", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).fast().build()));
    public static final DeferredItem<Item> SUNDAE = ITEMS.registerSimpleItem("sundae", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(5).saturationModifier(0.5F).build()));
    public static final DeferredItem<Item> FROZEN_YOGURT = ITEMS.registerSimpleItem("frozen_yogurt", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).fast().build()));
    public static final DeferredItem<Item> MILKSHAKE = ITEMS.register("milkshake", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.ABSORPTION, 30));
    public static final DeferredItem<Item> HOT_CHOCOLATE = ITEMS.register("hot_chocolate", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, 30));
    public static final DeferredItem<Item> CARROT_JUICE = ITEMS.register("carrot_juice", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.NIGHT_VISION, 30));
    public static final DeferredItem<Item> GLOW_SMOOTHIE = ITEMS.register("glow_smoothie", () -> new KitchenExtras.DrinkItem(
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationModifier(0.2F).alwaysEdible().build()).stacksTo(16),
            () -> net.minecraft.world.effect.MobEffects.GLOWING, 20));
    public static final DeferredBlock<Block> PREP_BLOCK = BLOCKS.register("prep_counter", () -> new KitchenBlock(KitchenKind.PREP, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PREP_ITEM = ITEMS.registerSimpleBlockItem("prep_counter", PREP_BLOCK);
    public static final DeferredBlock<Block> GRILL_BLOCK = BLOCKS.register("park_grill", () -> new KitchenBlock(KitchenKind.GRILL, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> GRILL_ITEM = ITEMS.registerSimpleBlockItem("park_grill", GRILL_BLOCK);
    public static final DeferredBlock<Block> FRYER_BLOCK = BLOCKS.register("deep_fryer", () -> new KitchenBlock(KitchenKind.FRYER, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredItem<BlockItem> FRYER_ITEM = ITEMS.registerSimpleBlockItem("deep_fryer", FRYER_BLOCK);
    public static final DeferredBlock<Block> OVEN_BLOCK = BLOCKS.register("pizza_oven", () -> new KitchenBlock(KitchenKind.OVEN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 10 : 0)));
    public static final DeferredBlock<Block> OVEN_TOP = BLOCKS.register("pizza_oven_top", () -> TallBlocks.Top.create(OVEN_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 10), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> OVEN_ITEM = ITEMS.<BlockItem>register("pizza_oven", () -> new TallBlocks.Item(OVEN_BLOCK.get(), new Item.Properties(), OVEN_TOP, 2));
    public static final DeferredBlock<Block> SOFT_SERVE_BLOCK = BLOCKS.register("soft_serve_machine", () -> new KitchenBlock(KitchenKind.SOFT_SERVE, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredItem<BlockItem> SOFT_SERVE_ITEM = ITEMS.registerSimpleBlockItem("soft_serve_machine", SOFT_SERVE_BLOCK);
    public static final DeferredBlock<Block> POPCORN_MACHINE_BLOCK = BLOCKS.register("popcorn_machine", () -> new KitchenBlock(KitchenKind.POPCORN, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredBlock<Block> POPCORN_MACHINE_TOP = BLOCKS.register("popcorn_machine_top", () -> TallBlocks.Top.create(POPCORN_MACHINE_BLOCK, null, decor(SoundType.METAL), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> POPCORN_MACHINE_ITEM = ITEMS.<BlockItem>register("popcorn_machine", () -> new TallBlocks.Item(POPCORN_MACHINE_BLOCK.get(), new Item.Properties(), POPCORN_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> DRINKS_BLOCK = BLOCKS.register("drinks_dispenser", () -> new KitchenBlock(KitchenKind.DRINKS, decor(SoundType.METAL).lightLevel(st -> st.getValue(KitchenBlock.LIT) ? 6 : 0)));
    public static final DeferredBlock<Block> DRINKS_TOP = BLOCKS.register("drinks_dispenser_top", () -> TallBlocks.Top.create(DRINKS_BLOCK, null, decor(SoundType.METAL), KitchenBlock.LIT));
    public static final DeferredItem<BlockItem> DRINKS_ITEM = ITEMS.<BlockItem>register("drinks_dispenser", () -> new TallBlocks.Item(DRINKS_BLOCK.get(), new Item.Properties(), DRINKS_TOP, 2));
    public static final DeferredBlock<Block> FRIDGE_BLOCK = BLOCKS.register("fridge", () -> new KitchenExtras.FridgeBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> FRIDGE_TOP = BLOCKS.register("fridge_top", () -> TallBlocks.Top.create(FRIDGE_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FRIDGE_ITEM = ITEMS.<BlockItem>register("fridge", () -> new TallBlocks.Item(FRIDGE_BLOCK.get(), new Item.Properties(), FRIDGE_TOP, 2));
    public static final DeferredBlock<Block> BELL_BLOCK = BLOCKS.register("order_bell", () -> new KitchenExtras.BellBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> BELL_ITEM = ITEMS.registerSimpleBlockItem("order_bell", BELL_BLOCK);
    public static final DeferredBlock<Block> FAN_BLOCK = BLOCKS.register("extractor_fan", () -> new KitchenExtras.FanBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FAN_ITEM = ITEMS.registerSimpleBlockItem("extractor_fan", FAN_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenBlockEntity>> KITCHEN_BE =
            BLOCK_ENTITIES.register("kitchen_machine", () -> BlockEntityType.Builder.of(KitchenBlockEntity::new,
                    PREP_BLOCK.get(), GRILL_BLOCK.get(), FRYER_BLOCK.get(), OVEN_BLOCK.get(), SOFT_SERVE_BLOCK.get(),
                    POPCORN_MACHINE_BLOCK.get(), DRINKS_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.FridgeBlockEntity>> FRIDGE_BE =
            BLOCK_ENTITIES.register("fridge", () -> BlockEntityType.Builder.of(KitchenExtras.FridgeBlockEntity::new, FRIDGE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenExtras.BellBlockEntity>> BELL_BE =
            BLOCK_ENTITIES.register("order_bell", () -> BlockEntityType.Builder.of(KitchenExtras.BellBlockEntity::new, BELL_BLOCK.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<KitchenMenu>> KITCHEN_MENU =
            MENUS.register("kitchen_machine", () -> IMenuTypeExtension.create(KitchenMenu::new));
    public static final java.util.List<DeferredItem<? extends Item>> KITCHEN_ITEMS = java.util.List.of(
            PREP_ITEM, GRILL_ITEM, FRYER_ITEM, OVEN_ITEM, SOFT_SERVE_ITEM, POPCORN_MACHINE_ITEM, DRINKS_ITEM,
            FRIDGE_ITEM, BELL_ITEM, FAN_ITEM,
            BUN, RAW_PATTY, COOKED_PATTY, RAW_SAUSAGE, COOKED_SAUSAGE, DOUGH, POTATO_STRIPS,
            BURGER, HOT_DOG, CHIPS, DOUGHNUT, PIZZA_SLICE, ICE_CREAM, POPCORN_ITEM,
            APPLE_JUICE, BERRY_FIZZ, MELON_JUICE, COLA,
            CHEESE, SALAD, CHEESEBURGER, CHICKEN_SANDWICH, HAM_SANDWICH, TORTILLA, TACO, BURRITO, TORTILLA_CHIPS, NACHOS, FRUIT_CUP, CANDY_FLOSS, CARAMEL_POPCORN, CHOCOLATE_POPCORN, FRIED_CHICKEN, CHURRO, FISH_AND_CHIPS, FISH_FINGERS, NUGGETS, CORN_DOG, CHEESE_PIZZA, APPLE_PIE, CHOC_COOKIE, CAKE_SLICE, MUFFIN, LOADED_POTATO, SAUSAGE_ROLL, PASTY, PRETZEL, CHOC_ICE_CREAM, ICE_LOLLY, SUNDAE, FROZEN_YOGURT, MILKSHAKE, HOT_CHOCOLATE, CARROT_JUICE, GLOW_SMOOTHIE);

    private static final TallBlocks.ShapeFn TALL_PARASOL_SHAPE = (st, part) -> st.getValue(DiningBlocks.PARASOL_OPEN)
            ? net.minecraft.world.phys.shapes.Shapes.or(Block.box(7, 0, 7, 9, 16, 9), Block.box(1, 14, 1, 15, 16, 15))
            : Block.box(6, 0, 6, 10, 16, 10);
    // ---- Restaurant and cafe pack
    public static final DeferredBlock<Block> DINING_TABLE_BLOCK = BLOCKS.register("dining_table", () -> new DiningBlocks.TableBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_TABLE_ITEM = ITEMS.registerSimpleBlockItem("dining_table", DINING_TABLE_BLOCK);
    public static final DeferredBlock<Block> DINING_CHAIR_BLOCK = BLOCKS.register("dining_chair", () -> new DiningBlocks.ChairBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_CHAIR_ITEM = ITEMS.registerSimpleBlockItem("dining_chair", DINING_CHAIR_BLOCK);
    public static final DeferredBlock<Block> DINING_BOOTH_BLOCK = BLOCKS.register("dining_booth", () -> new DiningBlocks.BoothBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> DINING_BOOTH_ITEM = ITEMS.registerSimpleBlockItem("dining_booth", DINING_BOOTH_BLOCK);
    public static final DeferredBlock<Block> MENU_BOARD_BLOCK = BLOCKS.register("menu_board", () -> new RestaurantBlocks.MenuBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> MENU_BOARD_ITEM = ITEMS.registerSimpleBlockItem("menu_board", MENU_BOARD_BLOCK);
    public static final DeferredBlock<Block> ORDER_KIOSK_BLOCK = BLOCKS.register("order_kiosk", () -> new RestaurantBlocks.KioskBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ORDER_KIOSK_TOP = BLOCKS.register("order_kiosk_top", () -> TallBlocks.Top.create(ORDER_KIOSK_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ORDER_KIOSK_ITEM = ITEMS.<BlockItem>register("order_kiosk", () -> new TallBlocks.Item(ORDER_KIOSK_BLOCK.get(), new Item.Properties(), ORDER_KIOSK_TOP, 2));
    public static final DeferredBlock<Block> PICKUP_DISPLAY_BLOCK = BLOCKS.register("pickup_display", () -> new RestaurantBlocks.PickupBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> PICKUP_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("pickup_display", PICKUP_DISPLAY_BLOCK);
    public static final DeferredBlock<Block> CASH_REGISTER_BLOCK = BLOCKS.register("cash_register", () -> new RestaurantBlocks.RegisterBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CASH_REGISTER_ITEM = ITEMS.registerSimpleBlockItem("cash_register", CASH_REGISTER_BLOCK);
    public static final DeferredBlock<Block> CONDIMENT_STAND_BLOCK = BLOCKS.register("condiment_stand", () -> new RestaurantBlocks.CondimentBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> CONDIMENT_STAND_ITEM = ITEMS.registerSimpleBlockItem("condiment_stand", CONDIMENT_STAND_BLOCK);
    public static final DeferredBlock<Block> PARASOL_BLOCK = BLOCKS.register("parasol", () -> new DiningBlocks.ParasolBlock(decor(SoundType.WOOL)));
    public static final DeferredBlock<Block> PARASOL_TOP = BLOCKS.register("parasol_top", () -> TallBlocks.Top.create(PARASOL_BLOCK, TALL_PARASOL_SHAPE, decor(SoundType.WOOL), DiningBlocks.PARASOL_OPEN, DecorBlocks.COLOR));
    public static final DeferredItem<BlockItem> PARASOL_ITEM = ITEMS.<BlockItem>register("parasol", () -> new TallBlocks.Item(PARASOL_BLOCK.get(), new Item.Properties(), PARASOL_TOP, 2));
    public static final DeferredBlock<Block> TRAY_TROLLEY_BLOCK = BLOCKS.register("tray_trolley", () -> new RestaurantBlocks.TrolleyBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TRAY_TROLLEY_ITEM = ITEMS.registerSimpleBlockItem("tray_trolley", TRAY_TROLLEY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.KioskBlockEntity>> KIOSK_BE =
            BLOCK_ENTITIES.register("order_kiosk", () -> BlockEntityType.Builder.of(RestaurantBlocks.KioskBlockEntity::new, ORDER_KIOSK_BLOCK.get()).build(null));
    public static final DeferredBlock<Block> ORDER_DISPLAY_BLOCK = BLOCKS.register("order_display", () -> new RestaurantBlocks.OrderDisplayBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> ORDER_DISPLAY_ITEM = ITEMS.registerSimpleBlockItem("order_display", ORDER_DISPLAY_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.PickupBlockEntity>> PICKUP_BE =
            BLOCK_ENTITIES.register("pickup_display", () -> BlockEntityType.Builder.of(RestaurantBlocks.PickupBlockEntity::new, PICKUP_DISPLAY_BLOCK.get(), ORDER_DISPLAY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.MenuBoardBlockEntity>> MENU_BOARD_BE =
            BLOCK_ENTITIES.register("menu_board", () -> BlockEntityType.Builder.of(RestaurantBlocks.MenuBoardBlockEntity::new, MENU_BOARD_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.CondimentBlockEntity>> CONDIMENT_BE =
            BLOCK_ENTITIES.register("condiment_stand", () -> BlockEntityType.Builder.of(RestaurantBlocks.CondimentBlockEntity::new, CONDIMENT_STAND_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RestaurantBlocks.TrolleyBlockEntity>> TROLLEY_BE =
            BLOCK_ENTITIES.register("tray_trolley", () -> BlockEntityType.Builder.of(RestaurantBlocks.TrolleyBlockEntity::new, TRAY_TROLLEY_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> RESTAURANT_ITEMS = java.util.List.of(
            DINING_TABLE_ITEM, DINING_CHAIR_ITEM, DINING_BOOTH_ITEM, MENU_BOARD_ITEM, ORDER_KIOSK_ITEM, ORDER_DISPLAY_ITEM, PICKUP_DISPLAY_ITEM,
            CASH_REGISTER_ITEM, CONDIMENT_STAND_ITEM, PARASOL_ITEM, TRAY_TROLLEY_ITEM);
    // ---- Arcade pack
    public static final DeferredItem<Item> ARCADE_TOKEN = ITEMS.registerSimpleItem("arcade_token", new Item.Properties());
    public static final DeferredItem<Item> PRIZE_TICKET = ITEMS.registerSimpleItem("prize_ticket", new Item.Properties());
    public static final DeferredBlock<Block> TOKEN_MACHINE_BLOCK = BLOCKS.register("token_machine", () -> new ArcadeBlocks.TokenBlock(decor(SoundType.METAL).lightLevel(st -> 7)));
    public static final DeferredBlock<Block> TOKEN_MACHINE_TOP = BLOCKS.register("token_machine_top", () -> TallBlocks.Top.create(TOKEN_MACHINE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 7)));
    public static final DeferredItem<BlockItem> TOKEN_MACHINE_ITEM = ITEMS.<BlockItem>register("token_machine", () -> new TallBlocks.Item(TOKEN_MACHINE_BLOCK.get(), new Item.Properties(), TOKEN_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> PRIZE_COUNTER_BLOCK = BLOCKS.register("prize_counter", () -> new ArcadeBlocks.PrizeBlock(decor(SoundType.WOOD).lightLevel(st -> 5)));
    public static final DeferredBlock<Block> PRIZE_COUNTER_TOP = BLOCKS.register("prize_counter_top", () -> TallBlocks.Top.create(PRIZE_COUNTER_BLOCK, null, decor(SoundType.WOOD).lightLevel(st -> 5)));
    public static final DeferredItem<BlockItem> PRIZE_COUNTER_ITEM = ITEMS.<BlockItem>register("prize_counter", () -> new TallBlocks.Item(PRIZE_COUNTER_BLOCK.get(), new Item.Properties(), PRIZE_COUNTER_TOP, 2));
    public static final DeferredBlock<Block> ARCADE_CABINET_BLOCK = BLOCKS.register("arcade_cabinet", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CABINET, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ARCADE_CABINET_TOP = BLOCKS.register("arcade_cabinet_top", () -> TallBlocks.Top.create(ARCADE_CABINET_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ARCADE_CABINET_ITEM = ITEMS.<BlockItem>register("arcade_cabinet", () -> new TallBlocks.Item(ARCADE_CABINET_BLOCK.get(), new Item.Properties(), ARCADE_CABINET_TOP, 2));
    public static final DeferredBlock<Block> CLAW_MACHINE_BLOCK = BLOCKS.register("claw_machine", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.CLAW, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> CLAW_MACHINE_TOP = BLOCKS.register("claw_machine_top", () -> TallBlocks.Top.create(CLAW_MACHINE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> CLAW_MACHINE_ITEM = ITEMS.<BlockItem>register("claw_machine", () -> new TallBlocks.Item(CLAW_MACHINE_BLOCK.get(), new Item.Properties(), CLAW_MACHINE_TOP, 2));
    public static final DeferredBlock<Block> WHACK_A_MOLE_BLOCK = BLOCKS.register("whack_a_mole", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.MOLE, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> WHACK_A_MOLE_ITEM = ITEMS.registerSimpleBlockItem("whack_a_mole", WHACK_A_MOLE_BLOCK);
    public static final DeferredBlock<Block> STRENGTH_TESTER_BLOCK = BLOCKS.register("strength_tester", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.STRENGTH, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> STRENGTH_TESTER_TOP = BLOCKS.register("strength_tester_top", () -> TallBlocks.Top.create(STRENGTH_TESTER_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6), ArcadeBlocks.LEVEL));
    public static final DeferredItem<BlockItem> STRENGTH_TESTER_ITEM = ITEMS.<BlockItem>register("strength_tester", () -> new TallBlocks.Item(STRENGTH_TESTER_BLOCK.get(), new Item.Properties(), STRENGTH_TESTER_TOP, 2));
    public static final DeferredBlock<Block> BASKETBALL_HOOPS_BLOCK = BLOCKS.register("basketball_hoops", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.HOOPS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> BASKETBALL_HOOPS_TOP = BLOCKS.register("basketball_hoops_top", () -> TallBlocks.Top.create(BASKETBALL_HOOPS_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> BASKETBALL_HOOPS_ITEM = ITEMS.<BlockItem>register("basketball_hoops", () -> new TallBlocks.Item(BASKETBALL_HOOPS_BLOCK.get(), new Item.Properties(), BASKETBALL_HOOPS_TOP, 2));
    public static final DeferredBlock<Block> SHOOTING_GALLERY_BLOCK = BLOCKS.register("shooting_gallery", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.GALLERY, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> SHOOTING_GALLERY_TOP = BLOCKS.register("shooting_gallery_top", () -> TallBlocks.Top.create(SHOOTING_GALLERY_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> SHOOTING_GALLERY_ITEM = ITEMS.<BlockItem>register("shooting_gallery", () -> new TallBlocks.Item(SHOOTING_GALLERY_BLOCK.get(), new Item.Properties(), SHOOTING_GALLERY_TOP, 2));
    public static final DeferredBlock<Block> RING_TOSS_BLOCK = BLOCKS.register("ring_toss", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.RINGS, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> RING_TOSS_ITEM = ITEMS.registerSimpleBlockItem("ring_toss", RING_TOSS_BLOCK);
    public static final DeferredBlock<Block> COCONUT_SHY_BLOCK = BLOCKS.register("coconut_shy", () -> new ArcadeBlocks.ArcadeBlock(ArcadeGame.COCONUT, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> COCONUT_SHY_TOP = BLOCKS.register("coconut_shy_top", () -> TallBlocks.Top.create(COCONUT_SHY_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> COCONUT_SHY_ITEM = ITEMS.<BlockItem>register("coconut_shy", () -> new TallBlocks.Item(COCONUT_SHY_BLOCK.get(), new Item.Properties(), COCONUT_SHY_TOP, 2));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.ArcadeBlockEntity>> ARCADE_BE =
            BLOCK_ENTITIES.register("arcade_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.ArcadeBlockEntity::new,
                    ARCADE_CABINET_BLOCK.get(), CLAW_MACHINE_BLOCK.get(), WHACK_A_MOLE_BLOCK.get(), STRENGTH_TESTER_BLOCK.get(), BASKETBALL_HOOPS_BLOCK.get(), SHOOTING_GALLERY_BLOCK.get(), RING_TOSS_BLOCK.get(), COCONUT_SHY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.TokenBlockEntity>> TOKEN_BE =
            BLOCK_ENTITIES.register("token_machine", () -> BlockEntityType.Builder.of(ArcadeBlocks.TokenBlockEntity::new, TOKEN_MACHINE_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcadeBlocks.PrizeBlockEntity>> PRIZE_BE =
            BLOCK_ENTITIES.register("prize_counter", () -> BlockEntityType.Builder.of(ArcadeBlocks.PrizeBlockEntity::new, PRIZE_COUNTER_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> ARCADE_ITEMS = java.util.List.of(
            TOKEN_MACHINE_ITEM, ARCADE_TOKEN, ARCADE_CABINET_ITEM, CLAW_MACHINE_ITEM, WHACK_A_MOLE_ITEM, STRENGTH_TESTER_ITEM,
            BASKETBALL_HOOPS_ITEM, SHOOTING_GALLERY_ITEM, RING_TOSS_ITEM, COCONUT_SHY_ITEM, PRIZE_COUNTER_ITEM, PRIZE_TICKET);
    // ---- Gift Shop pack
    public static final DeferredBlock<Block> SHOP_SHELF_BLOCK = BLOCKS.register("shop_shelf", () -> new GiftBlocks.ShopBlock(decor(SoundType.WOOD), false));
    public static final DeferredBlock<Block> SHOP_SHELF_TOP = BLOCKS.register("shop_shelf_top", () -> TallBlocks.Top.create(SHOP_SHELF_BLOCK, null, decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SHOP_SHELF_ITEM = ITEMS.<BlockItem>register("shop_shelf", () -> new TallBlocks.Item(SHOP_SHELF_BLOCK.get(), new Item.Properties(), SHOP_SHELF_TOP, 2));
    public static final DeferredBlock<Block> SOUVENIR_RACK_BLOCK = BLOCKS.register("souvenir_rack", () -> new GiftBlocks.RackBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> SOUVENIR_RACK_TOP = BLOCKS.register("souvenir_rack_top", () -> TallBlocks.Top.create(SOUVENIR_RACK_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> SOUVENIR_RACK_ITEM = ITEMS.<BlockItem>register("souvenir_rack", () -> new TallBlocks.Item(SOUVENIR_RACK_BLOCK.get(), new Item.Properties(), SOUVENIR_RACK_TOP, 2));
    public static final DeferredBlock<Block> PLUSH_TOY_BLOCK = BLOCKS.register("plush_toy", () -> new GiftBlocks.PlushBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> PLUSH_TOY_ITEM = ITEMS.registerSimpleBlockItem("plush_toy", PLUSH_TOY_BLOCK);
    public static final DeferredBlock<Block> SHOP_TILL_BLOCK = BLOCKS.register("shop_till", () -> new GiftBlocks.ShopBlock(decor(SoundType.WOOD), true));
    public static final DeferredItem<BlockItem> SHOP_TILL_ITEM = ITEMS.registerSimpleBlockItem("shop_till", SHOP_TILL_BLOCK);
    public static final DeferredBlock<Block> PRICE_TAG_BLOCK = BLOCKS.register("price_tag", () -> new GiftBlocks.PriceTagBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PRICE_TAG_ITEM = ITEMS.registerSimpleBlockItem("price_tag", PRICE_TAG_BLOCK);
    public static final DeferredBlock<Block> WINDOW_DISPLAY_BLOCK = BLOCKS.register("window_display", () -> new GiftBlocks.WindowBlock(decor(SoundType.GLASS).lightLevel(st -> 8)));
    public static final DeferredBlock<Block> WINDOW_DISPLAY_TOP = BLOCKS.register("window_display_top", () -> TallBlocks.Top.create(WINDOW_DISPLAY_BLOCK, null, decor(SoundType.GLASS).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> WINDOW_DISPLAY_ITEM = ITEMS.<BlockItem>register("window_display", () -> new TallBlocks.Item(WINDOW_DISPLAY_BLOCK.get(), new Item.Properties(), WINDOW_DISPLAY_TOP, 2));
    public static final DeferredBlock<Block> SHOPPING_BASKET_BLOCK = BLOCKS.register("shopping_basket", () -> new GiftBlocks.BasketBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> SHOPPING_BASKET_ITEM = ITEMS.registerSimpleBlockItem("shopping_basket", SHOPPING_BASKET_BLOCK);
    public static final DeferredItem<Item> GIFT_BAG = ITEMS.register("gift_bag", () -> new GiftBlocks.GiftBagItem(new Item.Properties()));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.ShopBlockEntity>> SHOP_BE =
            BLOCK_ENTITIES.register("shop", () -> BlockEntityType.Builder.of(GiftBlocks.ShopBlockEntity::new, SHOP_SHELF_BLOCK.get(), SHOP_TILL_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.PriceTagBlockEntity>> PRICE_TAG_BE =
            BLOCK_ENTITIES.register("price_tag", () -> BlockEntityType.Builder.of(GiftBlocks.PriceTagBlockEntity::new, PRICE_TAG_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.WindowBlockEntity>> WINDOW_BE =
            BLOCK_ENTITIES.register("window_display", () -> BlockEntityType.Builder.of(GiftBlocks.WindowBlockEntity::new, WINDOW_DISPLAY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiftBlocks.BasketBlockEntity>> BASKET_BE =
            BLOCK_ENTITIES.register("shopping_basket", () -> BlockEntityType.Builder.of(GiftBlocks.BasketBlockEntity::new, SHOPPING_BASKET_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> GIFT_ITEMS = java.util.List.of(
            SHOP_SHELF_ITEM, SOUVENIR_RACK_ITEM, PLUSH_TOY_ITEM, SHOP_TILL_ITEM, PRICE_TAG_ITEM, WINDOW_DISPLAY_ITEM, SHOPPING_BASKET_ITEM, GIFT_BAG);
    // ---- First Aid and Safety pack
    public static final DeferredBlock<Block> FIRST_AID_STATION_BLOCK = BLOCKS.register("first_aid_station", () -> new SafetyBlocks.FirstAidBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> FIRST_AID_STATION_TOP = BLOCKS.register("first_aid_station_top", () -> TallBlocks.Top.create(FIRST_AID_STATION_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> FIRST_AID_STATION_ITEM = ITEMS.<BlockItem>register("first_aid_station", () -> new TallBlocks.Item(FIRST_AID_STATION_BLOCK.get(), new Item.Properties(), FIRST_AID_STATION_TOP, 2));
    public static final DeferredBlock<Block> DEFIBRILLATOR_CABINET_BLOCK = BLOCKS.register("defibrillator_cabinet", () -> new SafetyBlocks.DefibBlock(decor(SoundType.METAL).lightLevel(st -> 8)));
    public static final DeferredItem<BlockItem> DEFIBRILLATOR_CABINET_ITEM = ITEMS.registerSimpleBlockItem("defibrillator_cabinet", DEFIBRILLATOR_CABINET_BLOCK);
    public static final DeferredBlock<Block> LOST_CHILD_POINT_BLOCK = BLOCKS.register("lost_child_point", () -> new SafetyBlocks.ChildPointBlock(decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 15 : 4)));
    public static final DeferredBlock<Block> LOST_CHILD_POINT_TOP = BLOCKS.register("lost_child_point_top", () -> TallBlocks.Top.create(LOST_CHILD_POINT_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 15 : 4), SafetyBlocks.LIT));
    public static final DeferredItem<BlockItem> LOST_CHILD_POINT_ITEM = ITEMS.<BlockItem>register("lost_child_point", () -> new TallBlocks.Item(LOST_CHILD_POINT_BLOCK.get(), new Item.Properties(), LOST_CHILD_POINT_TOP, 2));
    public static final DeferredBlock<Block> FIRE_EXTINGUISHER_BLOCK = BLOCKS.register("fire_extinguisher", () -> new SafetyBlocks.ExtinguisherBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FIRE_EXTINGUISHER_ITEM = ITEMS.registerSimpleBlockItem("fire_extinguisher", FIRE_EXTINGUISHER_BLOCK);
    public static final DeferredBlock<Block> EXIT_LIGHT_BLOCK = BLOCKS.register("exit_light", () -> new SafetyBlocks.ExitLightBlock(decor(SoundType.METAL).lightLevel(st -> 9)));
    public static final DeferredItem<BlockItem> EXIT_LIGHT_ITEM = ITEMS.registerSimpleBlockItem("exit_light", EXIT_LIGHT_BLOCK);
    public static final DeferredBlock<Block> EMERGENCY_PHONE_BLOCK = BLOCKS.register("emergency_phone", () -> new SafetyBlocks.PhoneBlock(decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 13 : 5)));
    public static final DeferredBlock<Block> EMERGENCY_PHONE_TOP = BLOCKS.register("emergency_phone_top", () -> TallBlocks.Top.create(EMERGENCY_PHONE_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> st.getValue(SafetyBlocks.LIT) ? 13 : 5), SafetyBlocks.LIT));
    public static final DeferredItem<BlockItem> EMERGENCY_PHONE_ITEM = ITEMS.<BlockItem>register("emergency_phone", () -> new TallBlocks.Item(EMERGENCY_PHONE_BLOCK.get(), new Item.Properties(), EMERGENCY_PHONE_TOP, 2));
    public static final DeferredBlock<Block> PRAM_PARKING_BLOCK = BLOCKS.register("pram_parking", () -> new SafetyBlocks.BayBlock(decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> PRAM_PARKING_ITEM = ITEMS.registerSimpleBlockItem("pram_parking", PRAM_PARKING_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.FirstAidBlockEntity>> FIRST_AID_BE =
            BLOCK_ENTITIES.register("first_aid_station", () -> BlockEntityType.Builder.of(SafetyBlocks.FirstAidBlockEntity::new, FIRST_AID_STATION_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.DefibBlockEntity>> DEFIB_BE =
            BLOCK_ENTITIES.register("defibrillator_cabinet", () -> BlockEntityType.Builder.of(SafetyBlocks.DefibBlockEntity::new, DEFIBRILLATOR_CABINET_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.ChildPointBlockEntity>> CHILD_POINT_BE =
            BLOCK_ENTITIES.register("lost_child_point", () -> BlockEntityType.Builder.of(SafetyBlocks.ChildPointBlockEntity::new, LOST_CHILD_POINT_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.ExtinguisherBlockEntity>> EXTINGUISHER_BE =
            BLOCK_ENTITIES.register("fire_extinguisher", () -> BlockEntityType.Builder.of(SafetyBlocks.ExtinguisherBlockEntity::new, FIRE_EXTINGUISHER_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SafetyBlocks.PhoneBlockEntity>> PHONE_BE =
            BLOCK_ENTITIES.register("emergency_phone", () -> BlockEntityType.Builder.of(SafetyBlocks.PhoneBlockEntity::new, EMERGENCY_PHONE_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> SAFETY_ITEMS = java.util.List.of(
            FIRST_AID_STATION_ITEM, DEFIBRILLATOR_CABINET_ITEM, LOST_CHILD_POINT_ITEM, FIRE_EXTINGUISHER_ITEM, EXIT_LIGHT_ITEM, EMERGENCY_PHONE_ITEM, PRAM_PARKING_ITEM);
    // ---- Guest Services pack
    public static final DeferredBlock<Block> INFORMATION_DESK_BLOCK = BLOCKS.register("information_desk", () -> new GuestBlocks.InfoDeskBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> INFORMATION_DESK_ITEM = ITEMS.registerSimpleBlockItem("information_desk", INFORMATION_DESK_BLOCK);
    public static final DeferredBlock<Block> LOCKER_BLOCK = BLOCKS.register("locker", () -> new GuestBlocks.LockerBlock(decor(SoundType.METAL), false));
    public static final DeferredBlock<Block> LOCKER_TOP = BLOCKS.register("locker_top", () -> TallBlocks.Top.create(LOCKER_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> LOCKER_ITEM = ITEMS.<BlockItem>register("locker", () -> new TallBlocks.Item(LOCKER_BLOCK.get(), new Item.Properties(), LOCKER_TOP, 2));
    public static final DeferredItem<Item> LOCKER_KEY = ITEMS.register("locker_key", () -> new GuestBlocks.LockerKeyItem(new Item.Properties()));
    public static final DeferredBlock<Block> ATM_BLOCK = BLOCKS.register("atm", () -> new GuestBlocks.AtmBlock(decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredBlock<Block> ATM_TOP = BLOCKS.register("atm_top", () -> TallBlocks.Top.create(ATM_BLOCK, null, decor(SoundType.METAL).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> ATM_ITEM = ITEMS.<BlockItem>register("atm", () -> new TallBlocks.Item(ATM_BLOCK.get(), new Item.Properties(), ATM_TOP, 2));
    public static final DeferredBlock<Block> PHOTO_FRAME_WALL_BLOCK = BLOCKS.register("photo_frame_wall", () -> new GuestBlocks.PhotoWallBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> PHOTO_FRAME_WALL_ITEM = ITEMS.registerSimpleBlockItem("photo_frame_wall", PHOTO_FRAME_WALL_BLOCK);
    public static final DeferredBlock<Block> BROCHURE_STAND_BLOCK = BLOCKS.register("brochure_stand", () -> new GuestBlocks.BrochureBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BROCHURE_STAND_ITEM = ITEMS.registerSimpleBlockItem("brochure_stand", BROCHURE_STAND_BLOCK);
    public static final DeferredBlock<Block> STROLLER_HIRE_RACK_BLOCK = BLOCKS.register("stroller_hire_rack", () -> new GuestBlocks.StrollerBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> STROLLER_HIRE_RACK_ITEM = ITEMS.registerSimpleBlockItem("stroller_hire_rack", STROLLER_HIRE_RACK_BLOCK);
    public static final DeferredItem<Item> STROLLER = ITEMS.register("stroller", () -> new GuestBlocks.StrollerItem(new Item.Properties()));
    public static final DeferredBlock<Block> FEEDBACK_BOX_BLOCK = BLOCKS.register("feedback_box", () -> new GuestBlocks.FeedbackBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> FEEDBACK_BOX_ITEM = ITEMS.registerSimpleBlockItem("feedback_box", FEEDBACK_BOX_BLOCK);
    // ---- Staff and Cleaning pack
    public static final DeferredItem<Item> STAFF_BADGE = ITEMS.register("staff_badge", () -> new StaffBlocks.BadgeItem(new Item.Properties()));
    public static final DeferredBlock<Block> STAFF_DOOR_BLOCK = BLOCKS.register("staff_door", () -> new StaffBlocks.StaffDoorBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> STAFF_DOOR_TOP = BLOCKS.register("staff_door_top", () -> TallBlocks.Top.create(STAFF_DOOR_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> STAFF_DOOR_ITEM = ITEMS.<BlockItem>register("staff_door", () -> new TallBlocks.Item(STAFF_DOOR_BLOCK.get(), new Item.Properties(), STAFF_DOOR_TOP, 2));
    public static final DeferredBlock<Block> JANITOR_CART_BLOCK = BLOCKS.register("janitor_cart", () -> new StaffBlocks.CartBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> JANITOR_CART_ITEM = ITEMS.registerSimpleBlockItem("janitor_cart", JANITOR_CART_BLOCK);
    public static final DeferredItem<Item> SWEEPER_BRUSH = ITEMS.register("sweeper_brush", () -> new StaffBlocks.SweeperItem(new Item.Properties()));
    public static final DeferredBlock<Block> WET_FLOOR_SIGN_BLOCK = BLOCKS.register("wet_floor_sign", () -> new StaffBlocks.WetFloorBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> WET_FLOOR_SIGN_ITEM = ITEMS.registerSimpleBlockItem("wet_floor_sign", WET_FLOOR_SIGN_BLOCK);
    public static final DeferredItem<Item> LITTER_PICKER = ITEMS.register("litter_picker", () -> new StaffBlocks.PickerItem(new Item.Properties()));
    public static final DeferredBlock<Block> STAFF_LOCKER_BLOCK = BLOCKS.register("staff_locker", () -> new GuestBlocks.LockerBlock(decor(SoundType.METAL), true));
    public static final DeferredBlock<Block> STAFF_LOCKER_TOP = BLOCKS.register("staff_locker_top", () -> TallBlocks.Top.create(STAFF_LOCKER_BLOCK, null, decor(SoundType.METAL), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> STAFF_LOCKER_ITEM = ITEMS.<BlockItem>register("staff_locker", () -> new TallBlocks.Item(STAFF_LOCKER_BLOCK.get(), new Item.Properties(), STAFF_LOCKER_TOP, 2));
    public static final DeferredBlock<Block> STAFF_ROTA_BOARD_BLOCK = BLOCKS.register("staff_rota_board", () -> new StaffBlocks.RotaBoardBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> STAFF_ROTA_BOARD_ITEM = ITEMS.registerSimpleBlockItem("staff_rota_board", STAFF_ROTA_BOARD_BLOCK);
    public static final DeferredBlock<Block> LITTER_BLOCK = BLOCKS.register("litter", () -> new StaffBlocks.LitterBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties.of().instabreak().noCollission().noOcclusion().sound(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> LITTER_ITEM = ITEMS.registerSimpleBlockItem("litter", LITTER_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<StaffBlocks.CartBlockEntity>> CART_BE =
            BLOCK_ENTITIES.register("janitor_cart", () -> BlockEntityType.Builder.of(StaffBlocks.CartBlockEntity::new, JANITOR_CART_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.LockerBlockEntity>> LOCKER_BE =
            BLOCK_ENTITIES.register("locker", () -> BlockEntityType.Builder.of(GuestBlocks.LockerBlockEntity::new, LOCKER_BLOCK.get(), STAFF_LOCKER_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.PhotoWallBlockEntity>> PHOTO_WALL_BE =
            BLOCK_ENTITIES.register("photo_frame_wall", () -> BlockEntityType.Builder.of(GuestBlocks.PhotoWallBlockEntity::new, PHOTO_FRAME_WALL_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.StrollerBlockEntity>> STROLLER_BE =
            BLOCK_ENTITIES.register("stroller_hire_rack", () -> BlockEntityType.Builder.of(GuestBlocks.StrollerBlockEntity::new, STROLLER_HIRE_RACK_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.FeedbackBlockEntity>> FEEDBACK_BE =
            BLOCK_ENTITIES.register("feedback_box", () -> BlockEntityType.Builder.of(GuestBlocks.FeedbackBlockEntity::new, FEEDBACK_BOX_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> GUEST_ITEMS = java.util.List.of(
            INFORMATION_DESK_ITEM, LOCKER_ITEM, LOCKER_KEY, ATM_ITEM, PHOTO_FRAME_WALL_ITEM, BROCHURE_STAND_ITEM, STROLLER_HIRE_RACK_ITEM, FEEDBACK_BOX_ITEM, STROLLER);
    public static final java.util.List<DeferredItem<? extends Item>> STAFF_ITEMS = java.util.List.of(
            STAFF_DOOR_ITEM, STAFF_BADGE, JANITOR_CART_ITEM, SWEEPER_BRUSH, WET_FLOOR_SIGN_ITEM, LITTER_PICKER, STAFF_LOCKER_ITEM, STAFF_ROTA_BOARD_ITEM, LITTER_ITEM);
    // ---- Ride Maintenance pack
    public static final DeferredBlock<Block> WORKSHOP_BENCH_BLOCK = BLOCKS.register("workshop_bench", () -> new MaintBlocks.WorkshopBenchBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> WORKSHOP_BENCH_ITEM = ITEMS.registerSimpleBlockItem("workshop_bench", WORKSHOP_BENCH_BLOCK);
    public static final DeferredBlock<Block> PARTS_SHELF_BLOCK = BLOCKS.register("parts_shelf", () -> new ResortBlocks.PartsShelfBlock(decor(SoundType.METAL)));
    public static final DeferredBlock<Block> PARTS_SHELF_TOP = BLOCKS.register("parts_shelf_top", () -> TallBlocks.Top.create(PARTS_SHELF_BLOCK, null, decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> PARTS_SHELF_ITEM = ITEMS.<BlockItem>register("parts_shelf", () -> new TallBlocks.Item(PARTS_SHELF_BLOCK.get(), new Item.Properties(), PARTS_SHELF_TOP, 2));
    public static final DeferredBlock<Block> INSPECTION_PIT_BLOCK = BLOCKS.register("inspection_pit", () -> new MaintBlocks.PitBlock(decor(SoundType.STONE)));
    public static final DeferredItem<BlockItem> INSPECTION_PIT_ITEM = ITEMS.registerSimpleBlockItem("inspection_pit", INSPECTION_PIT_BLOCK);
    public static final DeferredBlock<Block> TOOL_WALL_BLOCK = BLOCKS.register("tool_wall", () -> new MaintBlocks.ToolWallBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> TOOL_WALL_ITEM = ITEMS.registerSimpleBlockItem("tool_wall", TOOL_WALL_BLOCK);
    public static final DeferredBlock<Block> TEST_DUMMY_BLOCK = BLOCKS.register("test_dummy", () -> new MaintBlocks.DummyBlock(decor(SoundType.WOOL)));
    public static final DeferredBlock<Block> TEST_DUMMY_TOP = BLOCKS.register("test_dummy_top", () -> TallBlocks.Top.create(TEST_DUMMY_BLOCK, null, decor(SoundType.WOOL), MaintBlocks.LOCKED));
    public static final DeferredItem<BlockItem> TEST_DUMMY_ITEM = ITEMS.<BlockItem>register("test_dummy", () -> new TallBlocks.Item(TEST_DUMMY_BLOCK.get(), new Item.Properties(), TEST_DUMMY_TOP, 2));
    public static final DeferredBlock<Block> SAFETY_CHECKLIST_BOARD_BLOCK = BLOCKS.register("safety_checklist_board", () -> new MaintBlocks.ChecklistBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> SAFETY_CHECKLIST_BOARD_ITEM = ITEMS.registerSimpleBlockItem("safety_checklist_board", SAFETY_CHECKLIST_BOARD_BLOCK);
    public static final DeferredBlock<Block> GREASE_STATION_BLOCK = BLOCKS.register("grease_station", () -> new MaintBlocks.GreaseBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> GREASE_STATION_ITEM = ITEMS.registerSimpleBlockItem("grease_station", GREASE_STATION_BLOCK);
    public static final DeferredBlock<Block> LIFT_JACK_BLOCK = BLOCKS.register("lift_jack", () -> new MaintBlocks.JackBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> LIFT_JACK_ITEM = ITEMS.registerSimpleBlockItem("lift_jack", LIFT_JACK_BLOCK);
    // ---- Park Hotel and Resort pack
    public static final DeferredBlock<Block> RECEPTION_DESK_BLOCK = BLOCKS.register("reception_desk", () -> new ResortBlocks.ReceptionBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> RECEPTION_DESK_ITEM = ITEMS.registerSimpleBlockItem("reception_desk", RECEPTION_DESK_BLOCK);
    public static final DeferredBlock<Block> HOTEL_ROOM_DOOR_BLOCK = BLOCKS.register("hotel_room_door", () -> new ResortBlocks.RoomDoorBlock(decor(SoundType.WOOD)));
    public static final DeferredBlock<Block> HOTEL_ROOM_DOOR_TOP = BLOCKS.register("hotel_room_door_top", () -> TallBlocks.Top.create(HOTEL_ROOM_DOOR_BLOCK, null, decor(SoundType.WOOD), GuestBlocks.OPEN));
    public static final DeferredItem<BlockItem> HOTEL_ROOM_DOOR_ITEM = ITEMS.<BlockItem>register("hotel_room_door", () -> new TallBlocks.Item(HOTEL_ROOM_DOOR_BLOCK.get(), new Item.Properties(), HOTEL_ROOM_DOOR_TOP, 2));
    public static final DeferredItem<Item> ROOM_KEY = ITEMS.register("room_key_card", () -> new ResortBlocks.RoomKeyItem(new Item.Properties()));
    public static final DeferredBlock<Block> LUGGAGE_TROLLEY_BLOCK = BLOCKS.register("luggage_trolley", () -> new ResortBlocks.LuggageBlock(decor(SoundType.METAL)));
    public static final DeferredItem<BlockItem> LUGGAGE_TROLLEY_ITEM = ITEMS.registerSimpleBlockItem("luggage_trolley", LUGGAGE_TROLLEY_BLOCK);
    public static final DeferredBlock<Block> BELLHOP_STAND_BLOCK = BLOCKS.register("bellhop_stand", () -> new ResortBlocks.BellStandBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> BELLHOP_STAND_ITEM = ITEMS.registerSimpleBlockItem("bellhop_stand", BELLHOP_STAND_BLOCK);
    public static final DeferredBlock<Block> POOL_BAR_BLOCK = BLOCKS.register("pool_bar", () -> new ResortBlocks.PoolBarBlock(decor(SoundType.WOOD)));
    public static final DeferredItem<BlockItem> POOL_BAR_ITEM = ITEMS.registerSimpleBlockItem("pool_bar", POOL_BAR_BLOCK);
    public static final DeferredBlock<Block> RESORT_SIGN_BLOCK = BLOCKS.register("resort_sign", () -> new ResortBlocks.ResortSignBlock(decor(SoundType.WOOD).lightLevel(st -> 6)));
    public static final DeferredItem<BlockItem> RESORT_SIGN_ITEM = ITEMS.registerSimpleBlockItem("resort_sign", RESORT_SIGN_BLOCK);
    public static final DeferredBlock<Block> HOTEL_BED_BLOCK = BLOCKS.register("hotel_bed", () -> new ResortBlocks.HotelBedBlock(decor(SoundType.WOOL)));
    public static final DeferredItem<BlockItem> HOTEL_BED_ITEM = ITEMS.registerSimpleBlockItem("hotel_bed", HOTEL_BED_BLOCK);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestBlocks.TextBlockEntity>> TEXT_BE =
            BLOCK_ENTITIES.register("service_text", () -> BlockEntityType.Builder.of(GuestBlocks.TextBlockEntity::new, INFORMATION_DESK_BLOCK.get(), BROCHURE_STAND_BLOCK.get(), STAFF_ROTA_BOARD_BLOCK.get(), RESORT_SIGN_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.RoomDoorBlockEntity>> ROOM_DOOR_BE =
            BLOCK_ENTITIES.register("room_door", () -> BlockEntityType.Builder.of(ResortBlocks.RoomDoorBlockEntity::new, HOTEL_ROOM_DOOR_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.ReceptionBlockEntity>> RECEPTION_BE =
            BLOCK_ENTITIES.register("reception_desk", () -> BlockEntityType.Builder.of(ResortBlocks.ReceptionBlockEntity::new, RECEPTION_DESK_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResortBlocks.StorageBlockEntity>> STORAGE_BE =
            BLOCK_ENTITIES.register("resort_storage", () -> BlockEntityType.Builder.of(ResortBlocks.StorageBlockEntity::new, PARTS_SHELF_BLOCK.get(), LUGGAGE_TROLLEY_BLOCK.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MaintBlocks.ChecklistBlockEntity>> CHECKLIST_BE =
            BLOCK_ENTITIES.register("safety_checklist", () -> BlockEntityType.Builder.of(MaintBlocks.ChecklistBlockEntity::new, SAFETY_CHECKLIST_BOARD_BLOCK.get()).build(null));
    public static final java.util.List<DeferredItem<? extends Item>> MAINT_ITEMS = java.util.List.of(
            WORKSHOP_BENCH_ITEM, PARTS_SHELF_ITEM, INSPECTION_PIT_ITEM, TOOL_WALL_ITEM, TEST_DUMMY_ITEM, SAFETY_CHECKLIST_BOARD_ITEM, GREASE_STATION_ITEM, LIFT_JACK_ITEM);
    public static final java.util.List<DeferredItem<? extends Item>> RESORT_ITEMS = java.util.List.of(
            RECEPTION_DESK_ITEM, HOTEL_ROOM_DOOR_ITEM, ROOM_KEY, LUGGAGE_TROLLEY_ITEM, BELLHOP_STAND_ITEM, POOL_BAR_ITEM, RESORT_SIGN_ITEM, HOTEL_BED_ITEM);
    public static final java.util.List<DeferredItem<BlockItem>> DECOR_ITEMS = java.util.List.of(
            BENCH_ITEM,
            DECK_CHAIR_ITEM,
            BIN_ITEM,
            LAMP_POST_ITEM,
            GARDEN_LIGHT_ITEM,
            CLOCK_ITEM,
            MAP_BOARD_ITEM,
            BOOTH_ITEM,
            SNACK_ITEM,
            CANDY_ITEM,
            FOUNTAIN_ITEM,
            PLANTER_ITEM,
            FLAG_ITEM,
            SPEAKER_ITEM,
            BOUNCY_ITEM,
            MISTER_ITEM);

    // ---------------------------------------------------------------- tickets and turnstile

    public static final DeferredItem<Item> TICKET_ITEM = ITEMS.registerSimpleItem("park_ticket", new Item.Properties());

    public static final DeferredBlock<TurnstileBlock> TURNSTILE_BLOCK = BLOCKS.register("turnstile",
            () -> new TurnstileBlock(BlockBehaviour.Properties.of().strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
    public static final DeferredItem<BlockItem> TURNSTILE_ITEM = ITEMS.registerSimpleBlockItem("turnstile", TURNSTILE_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TurnstileBlockEntity>> TURNSTILE_BE =
            BLOCK_ENTITIES.register("turnstile",
                    () -> BlockEntityType.Builder.of(TurnstileBlockEntity::new, TURNSTILE_BLOCK.get()).build(null));

    public static final DeferredItem<Item> STATION_TRACK_ITEM =
            ITEMS.registerSimpleItem("station_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LAUNCH_TRACK_ITEM =
            ITEMS.registerSimpleItem("launch_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> BRAKE_TRACK_ITEM =
            ITEMS.registerSimpleItem("brake_track", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> LIFT_TRACK_ITEM =
            ITEMS.registerSimpleItem("lift_track", new Item.Properties().stacksTo(1));

    public static final DeferredBlock<ZoneBlock> STATION_ZONE_BLOCK = BLOCKS.register("station_controller",
            () -> new ZoneBlock(ZoneType.STATION, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> STATION_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("station_controller", STATION_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LAUNCH_ZONE_BLOCK = BLOCKS.register("launch_controller",
            () -> new ZoneBlock(ZoneType.LAUNCH, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LAUNCH_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("launch_controller", LAUNCH_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> BRAKE_ZONE_BLOCK = BLOCKS.register("brake_controller",
            () -> new ZoneBlock(ZoneType.BRAKE, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> BRAKE_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("brake_controller", BRAKE_ZONE_BLOCK);

    public static final DeferredBlock<ZoneBlock> LIFT_ZONE_BLOCK = BLOCKS.register("lift_controller",
            () -> new ZoneBlock(ZoneType.LIFT, BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ZoneBlock.OCCUPIED) ? 7 : 0)));
    public static final DeferredItem<BlockItem> LIFT_ZONE_ITEM =
            ITEMS.registerSimpleBlockItem("lift_controller", LIFT_ZONE_BLOCK);

    /** Never placed. Only used by the renderer to draw the swinging gate leaf. */
    public static final DeferredBlock<Block> GATE_LEAF_BLOCK = BLOCKS.register("ride_gate_leaf",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion()));

    public static final DeferredItem<Item> SEAT_TIMER_ITEM =
            ITEMS.registerSimpleItem("seat_timer", new Item.Properties().stacksTo(1));

    public static final DeferredItem<Item> SEAT_SPEED_ITEM =
            ITEMS.registerSimpleItem("seat_speed", new Item.Properties().stacksTo(1));

    /** Placeholder logo, only used as the creative tab icon. Replace textures/item/panel_logo.png to change it. */
    public static final DeferredItem<Item> PANEL_LOGO = ITEMS.registerSimpleItem("panel_logo");

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get(), EFFECTS_PANEL_BLOCK.get(), TRANSFER_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncePanelBlockEntity>> ANNOUNCE_PANEL_BE =
            BLOCK_ENTITIES.register("announcement_panel",
                    () -> BlockEntityType.Builder.of(AnnouncePanelBlockEntity::new, ANNOUNCE_PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnnouncerBlockEntity>> ANNOUNCER_BE =
            BLOCK_ENTITIES.register("announcer",
                    () -> BlockEntityType.Builder.of(AnnouncerBlockEntity::new, ANNOUNCER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RideGateBlockEntity>> GATE_BE =
            BLOCK_ENTITIES.register("ride_gate",
                    () -> BlockEntityType.Builder.of(RideGateBlockEntity::new, GATE_BLOCK.get(), GATE_SILVER_BLOCK.get(), GATE_RED_BLOCK.get(), GATE_DOUBLE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SectionControllerBlockEntity>> SECTION_BE =
            BLOCK_ENTITIES.register("section_controller",
                    () -> BlockEntityType.Builder.of(SectionControllerBlockEntity::new, SECTION_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<SectionMenu>> SECTION_MENU =
            MENUS.register("section_controller", () -> IMenuTypeExtension.create(SectionMenu::new));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZoneBlockEntity>> ZONE_BE =
            BLOCK_ENTITIES.register("zone_controller",
                    () -> BlockEntityType.Builder.of(ZoneBlockEntity::new, STATION_ZONE_BLOCK.get(),
                            LAUNCH_ZONE_BLOCK.get(), BRAKE_ZONE_BLOCK.get(), LIFT_ZONE_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EffectBlockEntity>> EFFECT_BE =
            BLOCK_ENTITIES.register("effect_machine",
                    () -> BlockEntityType.Builder.of(EffectBlockEntity::new, EFFECT_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CameraBlockEntity>> CAMERA_BE =
            BLOCK_ENTITIES.register("ride_camera",
                    () -> BlockEntityType.Builder.of(CameraBlockEntity::new, CAMERA_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhotoScreenBlockEntity>> PHOTO_SCREEN_BE =
            BLOCK_ENTITIES.register("photo_screen",
                    () -> BlockEntityType.Builder.of(PhotoScreenBlockEntity::new, PHOTO_SCREEN_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuestSpawnerBlockEntity>> SPAWNER_BE =
            BLOCK_ENTITIES.register("guest_spawner",
                    () -> BlockEntityType.Builder.of(GuestSpawnerBlockEntity::new, SPAWNER_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MarkerBlockEntity>> MARKER_BE =
            BLOCK_ENTITIES.register("guest_marker",
                    () -> BlockEntityType.Builder.of(MarkerBlockEntity::new, QUEUE_MARKER_BLOCK.get(),
                            STATION_MARKER_BLOCK.get(), EXIT_MARKER_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<GuestSpawnerMenu>> SPAWNER_MENU =
            MENUS.register("guest_spawner", () -> IMenuTypeExtension.create(GuestSpawnerMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<EffectMenu>> EFFECT_MENU =
            MENUS.register("effect_machine", () -> IMenuTypeExtension.create(EffectMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<ZoneMenu>> ZONE_MENU =
            MENUS.register("zone_controller", () -> IMenuTypeExtension.create(ZoneMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<RideGateMenu>> GATE_MENU =
            MENUS.register("ride_gate", () -> IMenuTypeExtension.create(RideGateMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<AnnouncerMenu>> ANNOUNCER_MENU =
            MENUS.register("announcer", () -> IMenuTypeExtension.create(AnnouncerMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.coastercontrolpanel"))
                    .icon(() -> PANEL_LOGO.get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(PANEL_ITEM.get());
                        output.accept(COASTER_SMOOTHER_ITEM.get());
                        output.accept(TRACK_UNRESTRICTOR_ITEM.get());
                        output.accept(TRACK_ELEMENT_SELECTOR_ITEM.get());
                        output.accept(DRIVE_TYRE_ITEM.get());
                        output.accept(ANIMATRONIC_ITEM.get());
                        output.accept(ANIMATRONIC_TOOL_ITEM.get());
                        output.accept(ANIMATION_CONTROLLER_ITEM.get());
                        output.accept(ANIMATION_CONNECTOR_ITEM.get());
                        output.accept(ANNOUNCER_ITEM.get());
                        output.accept(ANNOUNCE_PANEL_ITEM.get());
                        output.accept(GATE_ITEM.get());
                        output.accept(GATE_SILVER_ITEM.get());
                        output.accept(GATE_RED_ITEM.get());
                        output.accept(GATE_DOUBLE_ITEM.get());
                        output.accept(RIDE_FENCE_ITEM.get());
                        output.accept(RIDE_FENCE_SILVER_ITEM.get());
                        output.accept(RIDE_FENCE_RED_ITEM.get());
                        output.accept(SEAT_TIMER_ITEM.get());
                        output.accept(SEAT_SPEED_ITEM.get());
                        output.accept(SECTION_ITEM.get());
                        output.accept(SECTION_LINKER_ITEM.get());
                        output.accept(TRACK_PAINTER_ITEM.get());
                        output.accept(SUPPORT_TOOL_ITEM.get());
                        output.accept(SUPPORT_ERASER_ITEM.get());
                        output.accept(TRANSFER_ITEM.get());
                        output.accept(TRANSFER_PANEL_ITEM.get());
                        output.accept(RIDE_SIGN_ITEM.get());
                        output.accept(OPEN_SIGN_ITEM.get());
                        output.accept(HEIGHT_SIGN_ITEM.get());
                        output.accept(WAIT_SIGN_ITEM.get());
                        output.accept(ROPE_POST_ITEM.get());
                        output.accept(FLOOR_ARROW_ITEM.get());
                        output.accept(TURNSTILE_ITEM.get());
                        output.accept(TICKET_ITEM.get());
                        output.accept(ENTRANCE_SIGN_ITEM.get());
                        output.accept(EXIT_SIGN_ITEM.get());
                        output.accept(NOTICE_SIGN_ITEM.get());
                        output.accept(DIRECTION_SIGN_ITEM.get());
                        output.accept(CROWD_SIGN_ITEM.get());
                        output.accept(COUNTER_SIGN_ITEM.get());
                        output.accept(FLOOR_SIGN_ITEM.get());
                        for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                            output.accept(decorItem.get());
                        }
                        for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                            output.accept(bathItem.get());
                        }
                        for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                            output.accept(kitchenItem.get());
                        }
                        for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                            output.accept(restaurantItem.get());
                        }
                        for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                            output.accept(arcadeItem.get());
                        }
                        for (DeferredItem<? extends Item> giftItem : GIFT_ITEMS) {
                            output.accept(giftItem.get());
                        }
                        for (DeferredItem<? extends Item> safetyItem : SAFETY_ITEMS) {
                            output.accept(safetyItem.get());
                        }
                        for (DeferredItem<? extends Item> guestItem : GUEST_ITEMS) {
                            output.accept(guestItem.get());
                        }
                        for (DeferredItem<? extends Item> staffItem : STAFF_ITEMS) {
                            output.accept(staffItem.get());
                        }
                        for (DeferredItem<? extends Item> maintItem : MAINT_ITEMS) {
                            output.accept(maintItem.get());
                        }
                        for (DeferredItem<? extends Item> resortItem : RESORT_ITEMS) {
                            output.accept(resortItem.get());
                        }
                        output.accept(STATION_TRACK_ITEM.get());
                        output.accept(LAUNCH_TRACK_ITEM.get());
                        output.accept(BRAKE_TRACK_ITEM.get());
                        output.accept(LIFT_TRACK_ITEM.get());
                        output.accept(STATION_ZONE_ITEM.get());
                        output.accept(LAUNCH_ZONE_ITEM.get());
                        output.accept(BRAKE_ZONE_ITEM.get());
                        output.accept(LIFT_ZONE_ITEM.get());
                        output.accept(EFFECT_ITEM.get());
                        output.accept(EFFECTS_PANEL_ITEM.get());
                        output.accept(CAMERA_ITEM.get());
                        output.accept(CONNECTOR_ITEM.get());
                        output.accept(PHOTO_SCREEN_ITEM.get());
                        output.accept(SPAWNER_ITEM.get());
                        output.accept(QUEUE_MARKER_ITEM.get());
                        output.accept(STATION_MARKER_ITEM.get());
                        output.accept(EXIT_MARKER_ITEM.get());
                    })
                    .build());

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ENTITIES.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);
        SOUND_EVENTS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(this::registerPayloads);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
            event.accept(COASTER_SMOOTHER_ITEM);
            event.accept(TRACK_UNRESTRICTOR_ITEM);
            event.accept(TRACK_ELEMENT_SELECTOR_ITEM);
            event.accept(DRIVE_TYRE_ITEM);
            event.accept(ANIMATRONIC_ITEM);
            event.accept(ANIMATRONIC_TOOL_ITEM);
            event.accept(ANIMATION_CONTROLLER_ITEM);
            event.accept(ANIMATION_CONNECTOR_ITEM);
            event.accept(ANNOUNCER_ITEM);
            event.accept(ANNOUNCE_PANEL_ITEM);
            event.accept(GATE_ITEM);
            event.accept(GATE_SILVER_ITEM);
            event.accept(GATE_RED_ITEM);
            event.accept(GATE_DOUBLE_ITEM);
            event.accept(RIDE_FENCE_ITEM);
            event.accept(RIDE_FENCE_SILVER_ITEM);
            event.accept(RIDE_FENCE_RED_ITEM);
            event.accept(SEAT_TIMER_ITEM);
            event.accept(SEAT_SPEED_ITEM);
            event.accept(SECTION_ITEM);
            event.accept(SECTION_LINKER_ITEM);
            event.accept(TRACK_PAINTER_ITEM);
            event.accept(SUPPORT_TOOL_ITEM);
            event.accept(SUPPORT_ERASER_ITEM);
            event.accept(TRANSFER_ITEM);
            event.accept(TRANSFER_PANEL_ITEM);
            event.accept(RIDE_SIGN_ITEM);
            event.accept(OPEN_SIGN_ITEM);
            event.accept(HEIGHT_SIGN_ITEM);
            event.accept(WAIT_SIGN_ITEM);
            event.accept(ROPE_POST_ITEM);
            event.accept(FLOOR_ARROW_ITEM);
            event.accept(TURNSTILE_ITEM);
            event.accept(TICKET_ITEM);
            event.accept(ENTRANCE_SIGN_ITEM);
            event.accept(EXIT_SIGN_ITEM);
            event.accept(NOTICE_SIGN_ITEM);
            event.accept(DIRECTION_SIGN_ITEM);
            event.accept(CROWD_SIGN_ITEM);
            event.accept(COUNTER_SIGN_ITEM);
            event.accept(FLOOR_SIGN_ITEM);
            for (DeferredItem<BlockItem> decorItem : DECOR_ITEMS) {
                event.accept(decorItem);
            }
            for (DeferredItem<? extends Item> bathItem : BATH_ITEMS) {
                event.accept(bathItem.get());
            }
            for (DeferredItem<? extends Item> kitchenItem : KITCHEN_ITEMS) {
                event.accept(kitchenItem.get());
            }
            for (DeferredItem<? extends Item> restaurantItem : RESTAURANT_ITEMS) {
                event.accept(restaurantItem.get());
            }
            for (DeferredItem<? extends Item> arcadeItem : ARCADE_ITEMS) {
                event.accept(arcadeItem.get());
            }
            for (DeferredItem<? extends Item> giftItem : GIFT_ITEMS) {
                event.accept(giftItem.get());
            }
            for (DeferredItem<? extends Item> safetyItem : SAFETY_ITEMS) {
                event.accept(safetyItem.get());
            }
            for (DeferredItem<? extends Item> guestItem : GUEST_ITEMS) {
                event.accept(guestItem.get());
            }
            for (DeferredItem<? extends Item> staffItem : STAFF_ITEMS) {
                event.accept(staffItem.get());
            }
            for (DeferredItem<? extends Item> maintItem : MAINT_ITEMS) {
                event.accept(maintItem.get());
            }
            for (DeferredItem<? extends Item> resortItem : RESORT_ITEMS) {
                event.accept(resortItem.get());
            }
            event.accept(STATION_TRACK_ITEM);
            event.accept(LAUNCH_TRACK_ITEM);
            event.accept(BRAKE_TRACK_ITEM);
            event.accept(LIFT_TRACK_ITEM);
            event.accept(STATION_ZONE_ITEM);
            event.accept(LAUNCH_ZONE_ITEM);
            event.accept(BRAKE_ZONE_ITEM);
            event.accept(LIFT_ZONE_ITEM);
            event.accept(EFFECT_ITEM);
            event.accept(EFFECTS_PANEL_ITEM);
            event.accept(CAMERA_ITEM);
            event.accept(CONNECTOR_ITEM);
            event.accept(PHOTO_SCREEN_ITEM);
            event.accept(SPAWNER_ITEM);
            event.accept(QUEUE_MARKER_ITEM);
            event.accept(STATION_MARKER_ITEM);
            event.accept(EXIT_MARKER_ITEM);
        }
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(TrackElementSelectPacket.TYPE, TrackElementSelectPacket.CODEC, TrackElementSelectPacket::handle);
        registrar.playToServer(AnimationConfigPacket.TYPE, AnimationConfigPacket.CODEC, AnimationConfigPacket::handle);
        registrar.playToServer(AnimatronicConfigPacket.TYPE, AnimatronicConfigPacket.CODEC, AnimatronicConfigPacket::handle);
        registrar.playToServer(ButtonPacket.TYPE, ButtonPacket.CODEC, ButtonPacket::handle);
        registrar.playToServer(AnnouncePlayPacket.TYPE, AnnouncePlayPacket.CODEC, AnnouncePlayPacket::handle);
        registrar.playToServer(AnnounceConfigPacket.TYPE, AnnounceConfigPacket.CODEC, AnnounceConfigPacket::handle);
        registrar.playToServer(ClipUploadPacket.TYPE, ClipUploadPacket.CODEC, ClipUploadPacket::handle);
        registrar.playToServer(ClipRequestPacket.TYPE, ClipRequestPacket.CODEC, ClipRequestPacket::handle);
        registrar.playToClient(ClipDataPacket.TYPE, ClipDataPacket.CODEC, ClipDataPacket::handle);
        registrar.playToClient(ClipPlayPacket.TYPE, ClipPlayPacket.CODEC, ClipPlayPacket::handle);
        registrar.playToServer(ConfigPacket.TYPE, ConfigPacket.CODEC, ConfigPacket::handle);
        registrar.playToServer(AnnouncerConfigPacket.TYPE, AnnouncerConfigPacket.CODEC, AnnouncerConfigPacket::handle);
        registrar.playToServer(GateConfigPacket.TYPE, GateConfigPacket.CODEC, GateConfigPacket::handle);
        registrar.playToServer(SeatTimerPacket.TYPE, SeatTimerPacket.CODEC, SeatTimerPacket::handle);
        registrar.playToServer(SeatSpeedPacket.TYPE, SeatSpeedPacket.CODEC, SeatSpeedPacket::handle);
        registrar.playToServer(SectionConfigPacket.TYPE, SectionConfigPacket.CODEC, SectionConfigPacket::handle);
        registrar.playToServer(ZoneConfigPacket.TYPE, ZoneConfigPacket.CODEC, ZoneConfigPacket::handle);
        registrar.playToServer(EffectConfigPacket.TYPE, EffectConfigPacket.CODEC, EffectConfigPacket::handle);
        registrar.playToClient(PhotoRequestPacket.TYPE, PhotoRequestPacket.CODEC, PhotoRequestPacket::handle);
        registrar.playToServer(PhotoUploadPacket.TYPE, PhotoUploadPacket.CODEC, PhotoUploadPacket::handle);
        registrar.playToServer(PhotoFetchPacket.TYPE, PhotoFetchPacket.CODEC, PhotoFetchPacket::handle);
        registrar.playToClient(PhotoDataPacket.TYPE, PhotoDataPacket.CODEC, PhotoDataPacket::handle);
        registrar.playToServer(MarkerConfigPacket.TYPE, MarkerConfigPacket.CODEC, MarkerConfigPacket::handle);
        registrar.playToServer(GuestSpawnerConfigPacket.TYPE, GuestSpawnerConfigPacket.CODEC, GuestSpawnerConfigPacket::handle);
        registrar.playToServer(SupportConfigPacket.TYPE, SupportConfigPacket.CODEC, SupportConfigPacket::handle);
        registrar.playToServer(SignConfigPacket.TYPE, SignConfigPacket.CODEC, SignConfigPacket::handle);
        registrar.playToServer(TransferConfigPacket.TYPE, TransferConfigPacket.CODEC, TransferConfigPacket::handle);
        registrar.playToServer(KitchenConfigPacket.TYPE, KitchenConfigPacket.CODEC, KitchenConfigPacket::handle);
        registrar.playToServer(RestaurantActionPacket.TYPE, RestaurantActionPacket.CODEC, RestaurantActionPacket::handle);
        registrar.playToServer(MenuBoardPacket.TYPE, MenuBoardPacket.CODEC, MenuBoardPacket::handle);
        registrar.playToServer(ArcadeActionPacket.TYPE, ArcadeActionPacket.CODEC, ArcadeActionPacket::handle);
        registrar.playToServer(ParkActionPacket.TYPE, ParkActionPacket.CODEC, ParkActionPacket::handle);
        registrar.playToServer(ServiceActionPacket.TYPE, ServiceActionPacket.CODEC, ServiceActionPacket::handle);
        registrar.playToServer(ServiceTextPacket.TYPE, ServiceTextPacket.CODEC, ServiceTextPacket::handle);
    }
}
