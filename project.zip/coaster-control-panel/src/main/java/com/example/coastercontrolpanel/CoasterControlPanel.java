package com.example.coastercontrolpanel;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Coaster Control Panel: one block with six buttons and six lamps.
 * Each row has an input and an output Create Redstone Link frequency,
 * set by right-clicking the block with a Create wrench.
 */
@Mod(CoasterControlPanel.MOD_ID)
public class CoasterControlPanel {
    public static final String MOD_ID = "coastercontrolpanel";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);

    public static final DeferredBlock<PanelBlock> PANEL_BLOCK = BLOCKS.register("control_panel",
            () -> new PanelBlock(BlockBehaviour.Properties.of()
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .lightLevel(PanelBlock::lightFor)));

    public static final DeferredItem<BlockItem> PANEL_ITEM =
            ITEMS.registerSimpleBlockItem("control_panel", PANEL_BLOCK);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PanelBlockEntity>> PANEL_BE =
            BLOCK_ENTITIES.register("control_panel",
                    () -> BlockEntityType.Builder.of(PanelBlockEntity::new, PANEL_BLOCK.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<PanelMenu>> PANEL_MENU =
            MENUS.register("control_panel", () -> IMenuTypeExtension.create(PanelMenu::new));

    public CoasterControlPanel(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        MENUS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(PANEL_ITEM);
        }
    }
}
