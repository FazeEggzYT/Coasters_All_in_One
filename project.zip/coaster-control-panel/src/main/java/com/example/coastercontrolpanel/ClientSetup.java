package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Mod-bus client setup: setup screen, key bindings, and the always-on panel HUD. */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    private static final double MAX_DISTANCE_SQR = 48.0 * 48.0;

    @SubscribeEvent
    public static void onRegisterScreens(RegisterMenuScreensEvent event) {
        event.register(CoasterControlPanel.PANEL_MENU.get(), PanelScreen::new);
        event.register(CoasterControlPanel.ANNOUNCER_MENU.get(), AnnouncerScreen::new);
        event.register(CoasterControlPanel.GATE_MENU.get(), RideGateScreen::new);
        event.register(CoasterControlPanel.SECTION_MENU.get(), SectionScreen::new);
        event.register(CoasterControlPanel.ZONE_MENU.get(), ZoneScreen::new);
        event.register(CoasterControlPanel.EFFECT_MENU.get(), EffectScreen::new);
        event.register(CoasterControlPanel.TRANSFER_MENU.get(), TransferScreen::new);
        event.register(CoasterControlPanel.SPAWNER_MENU.get(), GuestSpawnerScreen::new);
        event.register(CoasterControlPanel.KITCHEN_MENU.get(), KitchenScreen::new);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(CoasterControlPanel.GATE_BE.get(), RideGateRenderer::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.PHOTO_SCREEN_BE.get(), PhotoScreenRenderer::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.SIGN_BE.get(), RideSignRenderer::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.TURNSTILE_BE.get(), TurnstileRenderer::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.MENU_BOARD_BE.get(), RestaurantRenderers.MenuBoard::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.PICKUP_BE.get(), RestaurantRenderers.PickupDisplay::new);
        event.registerBlockEntityRenderer(CoasterControlPanel.TRANSFER_BE.get(), TransferTableRenderer::new);
        event.registerEntityRenderer(CoasterControlPanel.GUEST.get(), GuestRenderer::new);
        event.registerEntityRenderer(CoasterControlPanel.SEAT.get(), net.minecraft.client.renderer.entity.NoopRenderer::new);
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(ClientKeys.MOUSE);
        event.register(ClientKeys.UNPIN);
    }

    @SubscribeEvent
    public static void onRegisterLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(
                ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "panel_hud"),
                (graphics, deltaTracker) -> renderHud(graphics));
        event.registerAboveAll(
                ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "photo_flash"),
                (graphics, deltaTracker) -> PhotoClient.renderFlash(graphics));
    }

    private static void renderHud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (ClientKeys.pinned == null || mc.level == null || mc.player == null
                || mc.options.hideGui || mc.screen instanceof OperatorScreen) {
            return;
        }
        if (mc.player.distanceToSqr(ClientKeys.pinned.getX() + 0.5, ClientKeys.pinned.getY() + 0.5,
                ClientKeys.pinned.getZ() + 0.5) > MAX_DISTANCE_SQR) {
            return;
        }
        BlockEntity be = mc.level.getBlockEntity(ClientKeys.pinned);
        if (be instanceof PanelBlockEntity panel) {
            PanelRenderer.draw(g, mc.font, panel, 8, g.guiHeight() - 8 - PanelRenderer.height(panel), -1,
                    Component.translatable("gui.coastercontrolpanel.hud_hint"));
        }
    }
}
