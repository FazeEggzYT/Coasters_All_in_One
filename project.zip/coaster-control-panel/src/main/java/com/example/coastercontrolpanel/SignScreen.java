package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen for the four sign kinds. */
public class SignScreen extends Screen {
    private static final int W = 252;
    private static final int H = 172;
    private static final String[] FRAMES = {"Plain", "Neon", "Wooden", "Metal"};

    private final BlockPos pos;
    private SignKind kind = SignKind.RIDE;
    private EditBox box1;
    private EditBox box2;
    private int color;
    private int frame;
    private int number;
    private int mode;
    private int left;
    private int top;

    public SignScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.sign_title"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        String l1 = "";
        String l2 = "";
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof RideSignBlockEntity s) {
            kind = s.kind();
            l1 = s.line1();
            l2 = s.line2();
            color = s.color();
            number = s.number();
            mode = s.mode();
            frame = s.getBlockState().getValue(RideSignBlock.FRAME);
        }
        int y = top + 22;
        box1 = new EditBox(font, left + 8, y, W - 16, 16, Component.empty());
        box1.setMaxLength(RideSignBlockEntity.MAX_TEXT);
        box1.setValue(l1);
        addRenderableWidget(box1);
        y += 22;
        if (hasLine2()) {
            box2 = new EditBox(font, left + 8, y, W - 16, 16, Component.empty());
            box2.setMaxLength(RideSignBlockEntity.MAX_TEXT);
            box2.setValue(l2);
            addRenderableWidget(box2);
            y += 22;
        }
        if (kind != SignKind.OPEN && kind != SignKind.CROWD) {
            cycle(y, () -> Component.literal(DyeColor.byId(color).getName()),
                    () -> color = (color + 1) % 16, () -> color = (color + 15) % 16);
            y += 22;
        }
        cycle(y, () -> Component.literal(FRAMES[frame]), () -> frame = (frame + 1) % 4, () -> frame = (frame + 3) % 4);
        y += 22;
        int modes = modeCount();
        if (modes > 0) {
            cycle(y, () -> Component.translatable("gui.coastercontrolpanel.sign_mode_" + kind.id + "_" + mode),
                    () -> mode = (mode + 1) % modes, () -> mode = (mode + 1) % modes);
            y += 22;
        }
        if (kind == SignKind.HEIGHT || kind == SignKind.WAIT || kind == SignKind.CROWD) {
            cycle(y, () -> Component.literal(numberText()),
                    () -> number = number + numberStep() > maxNumber() ? minNumber() : number + numberStep(),
                    () -> number = Math.max(minNumber(), number - numberStep()));
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(left + W - 52, top + H - 22, 44, 16).build());
    }

    private boolean hasLine2() {
        return kind == SignKind.RIDE || kind == SignKind.OPEN || kind == SignKind.ENTRANCE
                || kind == SignKind.EXIT || kind == SignKind.FLOOR || kind == SignKind.WAIT;
    }

    /** How many choices the mode button has (0 = no mode button). */
    private int modeCount() {
        return switch (kind) {
            case OPEN -> 3;
            case WAIT, COUNTER -> 2;
            case NOTICE -> 8;
            case DIRECTION -> 4;
            default -> 0;
        };
    }

    private int maxNumber() {
        return switch (kind) {
            case HEIGHT -> 220;
            case CROWD -> 99;
            default -> mode == 1 ? 99 : 120;
        };
    }

    private int minNumber() {
        return switch (kind) {
            case HEIGHT -> 60;
            case CROWD -> 3;
            default -> 1;
        };
    }

    private int numberStep() {
        return kind == SignKind.HEIGHT ? 5 : 1;
    }

    private String numberText() {
        if (kind == SignKind.HEIGHT) {
            return String.format("%d.%02d m", number / 100, number % 100);
        }
        if (kind == SignKind.CROWD) {
            return "Full at " + number + " guests";
        }
        return "Power x " + number;
    }

    private void cycle(int y, java.util.function.Supplier<Component> label, Runnable next, Runnable prev) {
        Button[] holder = new Button[1];
        holder[0] = Button.builder(label.get(), b -> {
            next.run();
            clampNumber();
            b.setMessage(label.get());
        }).bounds(left + 8, y, W - 16, 16).build();
        addRenderableWidget(holder[0]);
    }

    private void clampNumber() {
        number = Math.max(minNumber(), Math.min(maxNumber(), number));
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new SignConfigPacket(pos, box1.getValue(),
                box2 != null ? box2.getValue() : "", color, frame, number, mode));
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, Component.translatable("block.coastercontrolpanel." + kind.id), left + 8, top + 7, 0xFFFFFF, false);
    }
}
