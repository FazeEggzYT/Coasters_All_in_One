package com.example.coastercontrolpanel;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.neoforged.neoforge.network.PacketDistributor;

/** Setup screen for the four sign kinds. */
public class SignScreen extends Screen {
    private static final int W = 252;
    private static final int H = 150;
    private static final String[] FRAMES = {"Plain", "Neon", "Wooden", "Metal"};

    private final BlockPos pos;
    private SignKind kind = SignKind.RIDE;
    private EditBox box1;
    private EditBox box2;
    private int color;
    private int frame;
    private int number;
    private int mode;
    private int left;
    private int top;

    public SignScreen(BlockPos pos) {
        super(Component.translatable("gui.coastercontrolpanel.sign_title"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        String l1 = "";
        String l2 = "";
        if (minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof RideSignBlockEntity s) {
            kind = s.kind();
            l1 = s.line1();
            l2 = s.line2();
            color = s.color();
            number = s.number();
            mode = s.mode();
            frame = s.getBlockState().getValue(RideSignBlock.FRAME);
        }
        int y = top + 22;
        box1 = new EditBox(font, left + 8, y, W - 16, 16, Component.empty());
        box1.setMaxLength(RideSignBlockEntity.MAX_TEXT);
        box1.setValue(l1);
        addRenderableWidget(box1);
        y += 22;
        if (kind == SignKind.RIDE || kind == SignKind.OPEN) {
            box2 = new EditBox(font, left + 8, y, W - 16, 16, Component.empty());
            box2.setMaxLength(RideSignBlockEntity.MAX_TEXT);
            box2.setValue(l2);
            addRenderableWidget(box2);
            y += 22;
        }
        if (kind != SignKind.OPEN) {
            cycle(y, () -> Component.literal(DyeColor.byId(color).getName()),
                    () -> color = (color + 1) % 16, () -> color = (color + 15) % 16);
            y += 22;
        }
        cycle(y, () -> Component.literal(FRAMES[frame]), () -> frame = (frame + 1) % 4, () -> frame = (frame + 3) % 4);
        y += 22;
        if (kind == SignKind.OPEN) {
            cycle(y, () -> Component.translatable("gui.coastercontrolpanel.sign_open_mode_" + mode),
                    () -> mode = (mode + 1) % 3, () -> mode = (mode + 2) % 3);
        } else if (kind == SignKind.WAIT) {
            cycle(y, () -> Component.translatable("gui.coastercontrolpanel.sign_wait_mode_" + mode),
                    () -> mode = (mode + 1) % 2, () -> mode = (mode + 1) % 2);
            y += 22;
        }
        if (kind == SignKind.HEIGHT || kind == SignKind.WAIT) {
            cycle(y, () -> Component.literal(numberText()),
                    () -> number = Math.min(maxNumber(), number + numberStep()),
                    () -> number = Math.max(minNumber(), number - numberStep()));
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.coastercontrolpanel.ok"), b -> onClose())
                .bounds(left + W - 52, top + H - 22, 44, 16).build());
    }

    private int maxNumber() {
        return kind == SignKind.HEIGHT ? 220 : (mode == 1 ? 90 : 120);
    }

    private int minNumber() {
        return kind == SignKind.HEIGHT ? 60 : (mode == 1 ? 1 : 0);
    }

    private int numberStep() {
        return kind == SignKind.HEIGHT ? 5 : 1;
    }

    private String numberText() {
        if (kind == SignKind.HEIGHT) {
            return String.format("%d.%02d m", number / 100, number % 100);
        }
        return mode == 1 ? number + " s per guest" : number + " min";
    }

    private void cycle(int y, java.util.function.Supplier<Component> label, Runnable next, Runnable prev) {
        Button[] holder = new Button[1];
        holder[0] = Button.builder(label.get(), b -> {
            next.run();
            clampNumber();
            b.setMessage(label.get());
        }).bounds(left + 8, y, W - 16, 16).build();
        addRenderableWidget(holder[0]);
    }

    private void clampNumber() {
        number = Math.max(minNumber(), Math.min(maxNumber(), number));
    }

    @Override
    public void removed() {
        PacketDistributor.sendToServer(new SignConfigPacket(pos, box1.getValue(),
                box2 != null ? box2.getValue() : "", color, frame, number, mode));
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        g.fill(left, top, left + W, top + H, 0xFF3A3E4D);
        g.fill(left + 1, top + 1, left + W - 1, top + H - 1, 0xFF1B1D24);
        g.drawString(font, Component.translatable("block.coastercontrolpanel." + kind.id), left + 8, top + 7, 0xFFFFFF, false);
    }
}
