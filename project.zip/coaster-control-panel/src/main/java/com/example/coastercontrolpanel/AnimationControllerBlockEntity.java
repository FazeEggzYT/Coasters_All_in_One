package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * An Animation Controller: a timeline. Up to eight animatronics are linked to it (each one is a track) and clips on the
 * tracks say which animation each plays and when. While it plays it drives the linked animatronics.
 */
public class AnimationControllerBlockEntity extends BlockEntity {
    public static final int MAX_TRACKS = 8;
    public static final int MAX_CLIPS = 64;
    public static final int MIN_LENGTH = 20;
    public static final int MAX_LENGTH = 6000;

    /** track = index into the linked list, anim = index into Anims.ids(). */
    public record Clip(int track, int anim, int start, int length) {
    }

    private final List<BlockPos> linked = new ArrayList<>();
    private final List<Clip> clips = new ArrayList<>();
    private int totalLength = 400;
    private boolean loop = true;
    private boolean playing;
    private long startTime;
    private boolean wasPowered;

    public AnimationControllerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.ANIMATION_CONTROLLER_BE.get(), pos, state);
    }

    public List<BlockPos> linked() {
        return linked;
    }

    public List<Clip> clips() {
        return clips;
    }

    public int totalLength() {
        return totalLength;
    }

    public boolean loop() {
        return loop;
    }

    public boolean playing() {
        return playing;
    }

    public long startTime() {
        return startTime;
    }

    /** Linking toggles: linking an already linked animatronic unlinks it (and removes its clips). Returns true when now linked. */
    public boolean toggleLink(BlockPos animatronic) {
        int idx = linked.indexOf(animatronic);
        if (idx >= 0) {
            clearDriven(animatronic);
            linked.remove(idx);
            clips.removeIf(c -> c.track() == idx);
            for (int i = 0; i < clips.size(); i++) {
                Clip c = clips.get(i);
                if (c.track() > idx) {
                    clips.set(i, new Clip(c.track() - 1, c.anim(), c.start(), c.length()));
                }
            }
            changed();
            return false;
        }
        if (linked.size() >= MAX_TRACKS) {
            return false;
        }
        linked.add(animatronic.immutable());
        changed();
        return true;
    }

    public void setTimeline(int total, boolean loop, List<Clip> newClips) {
        this.totalLength = Math.max(MIN_LENGTH, Math.min(MAX_LENGTH, total));
        this.loop = loop;
        clips.clear();
        for (Clip c : newClips) {
            if (clips.size() >= MAX_CLIPS || c.track() < 0 || c.track() >= MAX_TRACKS || c.anim() < 0 || c.length() < 1) {
                continue;
            }
            int start = Math.max(0, Math.min(totalLength - 1, c.start()));
            int len = Math.max(1, Math.min(totalLength - start, c.length()));
            clips.add(new Clip(c.track(), c.anim(), start, len));
        }
        changed();
    }

    public void play() {
        if (level == null || level.isClientSide) {
            return;
        }
        playing = true;
        startTime = level.getGameTime();
        changed();
    }

    public void stop() {
        playing = false;
        for (BlockPos p : linked) {
            clearDriven(p);
        }
        changed();
    }

    public void redstone(boolean powered) {
        if (powered && !wasPowered) {
            play();
        }
        wasPowered = powered;
    }

    private void clearDriven(BlockPos p) {
        if (level != null && !level.isClientSide && level.isLoaded(p) && level.getBlockEntity(p) instanceof AnimatronicBlockEntity a) {
            a.setDriven(-1);
        }
    }

    private void changed() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Level.UPDATE_ALL);
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AnimationControllerBlockEntity be) {
        if (!be.playing) {
            return;
        }
        long t = level.getGameTime() - be.startTime;
        if (t >= be.totalLength) {
            if (be.loop) {
                be.startTime = level.getGameTime();
                t = 0;
            } else {
                be.stop();
                return;
            }
        }
        for (int track = 0; track < be.linked.size(); track++) {
            BlockPos p = be.linked.get(track);
            if (!level.isLoaded(p) || !(level.getBlockEntity(p) instanceof AnimatronicBlockEntity a)) {
                continue;
            }
            int target = -2;
            for (Clip c : be.clips) {
                if (c.track() == track && t >= c.start() && t < c.start() + c.length()) {
                    target = c.anim();
                }
            }
            a.setDriven(target);
        }
    }

    @Override
    public void setRemoved() {
        if (level != null && !level.isClientSide) {
            for (BlockPos p : linked) {
                clearDriven(p);
            }
        }
        super.setRemoved();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ListTag l = new ListTag();
        for (BlockPos p : linked) {
            l.add(NbtUtils.writeBlockPos(p));
        }
        tag.put("Linked", l);
        ListTag cl = new ListTag();
        for (Clip c : clips) {
            CompoundTag ct = new CompoundTag();
            ct.putInt("Track", c.track());
            ct.putInt("Anim", c.anim());
            ct.putInt("Start", c.start());
            ct.putInt("Length", c.length());
            cl.add(ct);
        }
        tag.put("Clips", cl);
        tag.putInt("Total", totalLength);
        tag.putBoolean("Loop", loop);
        tag.putBoolean("Playing", playing);
        tag.putLong("StartTime", startTime);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ListTag l = tag.getList("Linked", Tag.TAG_INT_ARRAY);
        linked.clear();
        for (int i = 0; i < l.size() && i < MAX_TRACKS; i++) {
            int[] a = l.getIntArray(i);
            if (a.length == 3) {
                linked.add(new BlockPos(a[0], a[1], a[2]));
            }
        }
        clips.clear();
        ListTag cl = tag.getList("Clips", Tag.TAG_COMPOUND);
        for (int i = 0; i < cl.size() && i < MAX_CLIPS; i++) {
            CompoundTag ct = cl.getCompound(i);
            clips.add(new Clip(ct.getInt("Track"), ct.getInt("Anim"), ct.getInt("Start"), Math.max(1, ct.getInt("Length"))));
        }
        totalLength = Math.max(MIN_LENGTH, Math.min(MAX_LENGTH, tag.contains("Total") ? tag.getInt("Total") : 400));
        loop = !tag.contains("Loop") || tag.getBoolean("Loop");
        playing = tag.getBoolean("Playing");
        startTime = tag.getLong("StartTime");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
