package com.example.coastercontrolpanel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the Support Tool settings, saved onto the tool in your hand. */
public record SupportConfigPacket(int style, int spacing, int thickness, int material, int gap)
        implements CustomPacketPayload {
    public static final Type<SupportConfigPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "support_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SupportConfigPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeVarInt(p.style);
                buf.writeVarInt(p.spacing);
                buf.writeVarInt(p.thickness);
                buf.writeVarInt(p.material);
                buf.writeVarInt(p.gap);
            },
            buf -> new SupportConfigPacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SupportConfigPacket p, IPayloadContext context) {
        ItemStack stack = context.player().getItemInHand(InteractionHand.MAIN_HAND);
        if (stack.is(CoasterControlPanel.SUPPORT_TOOL_ITEM.get())) {
            SupportSettings.write(stack, p.style, p.spacing, p.thickness, p.material, p.gap);
        }
    }
}
