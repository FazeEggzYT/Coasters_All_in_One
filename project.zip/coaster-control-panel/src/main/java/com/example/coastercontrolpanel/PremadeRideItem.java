package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;

import java.util.List;

/** Places a complete, working ride where you click, facing the way you look. */
public class PremadeRideItem extends Item {
    private final int kind;

    public PremadeRideItem(Properties properties, int kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        BlockPos origin = context.getClickedPos().relative(context.getClickedFace());
        PremadeRides.place(context.getLevel(), origin, context.getHorizontalDirection(), kind);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.coastercontrolpanel.premade.tooltip." + kind));
        tooltip.add(Component.translatable("item.coastercontrolpanel.premade.tooltip"));
    }
}
