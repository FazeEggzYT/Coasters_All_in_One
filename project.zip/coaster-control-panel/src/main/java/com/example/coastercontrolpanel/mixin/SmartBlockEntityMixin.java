package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.SeatTimerAccess;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Saves and loads the Seat Timer delays for any block entity that has them.
 * The seat mods inherit write/read from SmartBlockEntity, so this is where the data has to be added.
 */
@Mixin(value = SmartBlockEntity.class, remap = false)
public abstract class SmartBlockEntityMixin {
    @Inject(method = "write", at = @At("TAIL"))
    private void coastersaio$write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket,
                                   CallbackInfo ci) {
        if ((Object) this instanceof SeatTimerAccess timer) {
            tag.putInt("AioSeatOpen", timer.seatTimerOpenDelay());
            tag.putInt("AioSeatClose", timer.seatTimerCloseDelay());
        }
    }

    @Inject(method = "read", at = @At("TAIL"))
    private void coastersaio$read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket,
                                  CallbackInfo ci) {
        if ((Object) this instanceof SeatTimerAccess timer) {
            timer.seatTimerLoad(tag.getInt("AioSeatOpen"), tag.getInt("AioSeatClose"));
        }
    }
}
