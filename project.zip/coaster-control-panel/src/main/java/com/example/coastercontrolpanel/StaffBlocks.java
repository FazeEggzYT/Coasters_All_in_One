package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.List;

/**
 * The Staff and Cleaning pack: Staff Badge and Staff Door, Staff Locker (see GuestBlocks.LockerBlock), Janitor Cart,
 * Sweeper Brush, Litter Picker, Litter, Wet Floor Sign and the Staff Rota Board.
 */
public final class StaffBlocks {
    private StaffBlocks() {
    }

    private static void say(Player p, String key, Object... args) {
        p.displayClientMessage(Component.translatable("message.coastercontrolpanel." + key, args), true);
    }

    /** True if the player carries a Staff Badge anywhere (or is in creative). */
    public static boolean hasBadge(Player p) {
        if (p.getAbilities().instabuild) {
            return true;
        }
        Item badge = CoasterControlPanel.STAFF_BADGE.get();
        for (ItemStack s : p.getInventory().items) {
            if (s.is(badge)) {
                return true;
            }
        }
        return p.getOffhandItem().is(badge);
    }

    public static class BadgeItem extends Item {
        public BadgeItem(Properties p) {
            super(p.stacksTo(1));
        }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            tip.add(Component.translatable("item.coastercontrolpanel.staff_badge.tip"));
        }
    }

    // ------------------------------------------------------------------ staff door

    public static class StaffDoorBlock extends DecorBlocks.Facing {
        public StaffDoorBlock(Properties p) {
            super(p);
            registerDefaultState(defaultBlockState().setValue(GuestBlocks.OPEN, false));
        }

        @Override
        protected void extra(StateDefinition.Builder<Block, BlockState> b) {
            b.add(GuestBlocks.OPEN);
        }

        @Override
        public BlockState getStateForPlacement(BlockPlaceContext c) {
            return super.getStateForPlacement(c).setValue(GuestBlocks.OPEN, false);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            Direction f = s.getValue(DecorBlocks.FACING);
            return s.getValue(GuestBlocks.OPEN) ? DecorBlocks.dbox(f, 0, 0, 6, 3, 16, 16) : DecorBlocks.dbox(f, 0, 0, 6, 16, 16, 10);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 0, 0, 6, 16, 16, 10);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (!hasBadge(player)) {
                level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.4F, 1.9F);
                say(player, "staff_only");
                return InteractionResult.CONSUME;
            }
            boolean open = !s.getValue(GuestBlocks.OPEN);
            level.setBlock(pos, s.setValue(GuestBlocks.OPEN, open), 3);
            level.playSound(null, pos, open ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.7F, 1.2F);
            if (open) {
                level.scheduleTick(pos, this, 80);
            }
            return InteractionResult.CONSUME;
        }

        @Override
        protected void tick(BlockState s, ServerLevel level, BlockPos pos, RandomSource random) {
            if (s.getValue(GuestBlocks.OPEN)) {
                level.setBlock(pos, s.setValue(GuestBlocks.OPEN, false), 3);
                level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.7F, 1.2F);
            }
        }
    }

    // ------------------------------------------------------------------ janitor cart

    public static class CartBlockEntity extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);

        public CartBlockEntity(BlockPos pos, BlockState state) {
            super(CoasterControlPanel.CART_BE.get(), pos, state);
        }

        @Override
        public int getContainerSize() {
            return 27;
        }

        @Override
        protected Component getDefaultName() {
            return Component.translatable("block.coastercontrolpanel.janitor_cart");
        }

        @Override
        protected NonNullList<ItemStack> getItems() {
            return items;
        }

        @Override
        protected void setItems(NonNullList<ItemStack> list) {
            items = list;
        }

        @Override
        protected AbstractContainerMenu createMenu(int id, Inventory inv) {
            return ChestMenu.threeRows(id, inv, this);
        }

        @Override
        protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.saveAdditional(tag, registries);
            if (!trySaveLootTable(tag)) {
                ContainerHelper.saveAllItems(tag, items, registries);
            }
        }

        @Override
        protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
            super.loadAdditional(tag, registries);
            items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!tryLoadLootTable(tag)) {
                ContainerHelper.loadAllItems(tag, items, registries);
            }
        }
    }

    public static class CartBlock extends RestaurantBlocks.FacingEntityBlock {
        public static final MapCodec<CartBlock> CODEC = simpleCodec(CartBlock::new);

        public CartBlock(Properties p) {
            super(p);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 1, 0, 1, 15, 16, 15);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new CartBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof CartBlockEntity be) {
                player.openMenu(be);
                level.playSound(null, pos, SoundEvents.BARREL_OPEN, SoundSource.BLOCKS, 0.5F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof CartBlockEntity c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }

    // ------------------------------------------------------------------ wet floor sign

    public static class WetFloorBlock extends DecorBlocks.Facing {
        public WetFloorBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape shapeFor(Direction f) {
            return DecorBlocks.dbox(f, 3, 0, 4, 13, 11, 12);
        }
    }

    // ------------------------------------------------------------------ litter

    public static class LitterBlock extends Block {
        public LitterBlock(Properties p) {
            super(p);
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Block.box(1, 0, 1, 15, 1.5, 15);
        }

        @Override
        protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return Shapes.empty();
        }

        @Override
        protected boolean canSurvive(BlockState s, LevelReader level, BlockPos pos) {
            return Block.canSupportCenter(level, pos.below(), Direction.UP);
        }

        @Override
        protected BlockState updateShape(BlockState s, Direction dir, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos npos) {
            return dir == Direction.DOWN && !canSurvive(s, level, pos) ? Blocks.AIR.defaultBlockState() : s;
        }
    }

    /** Removes litter blocks in a box around the centre. Returns how many were removed. */
    public static int sweep(Level level, BlockPos centre, int radius) {
        int n = 0;
        for (BlockPos q : BlockPos.betweenClosed(centre.offset(-radius, -1, -radius), centre.offset(radius, 2, radius))) {
            if (level.getBlockState(q).getBlock() instanceof LitterBlock) {
                level.destroyBlock(q.immutable(), false);
                n++;
            }
        }
        return n;
    }

    public static class SweeperItem extends Item {
        public SweeperItem(Properties p) {
            super(p.durability(250));
        }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            Player player = ctx.getPlayer();
            if (player == null) {
                return InteractionResult.PASS;
            }
            return run(level, player, ctx.getClickedPos().above(), ctx.getItemInHand(), ctx.getHand());
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            InteractionResult r = run(level, player, player.blockPosition(), player.getItemInHand(hand), hand);
            return new InteractionResultHolder<>(r, player.getItemInHand(hand));
        }

        private InteractionResult run(Level level, Player player, BlockPos centre, ItemStack stack, InteractionHand hand) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            int n = sweep(level, centre, 3);
            level.playSound(null, player.blockPosition(), SoundEvents.BRUSH_GENERIC, SoundSource.PLAYERS, 0.8F, 1.0F);
            if (n > 0) {
                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
                say(player, "swept", n);
            } else {
                say(player, "sweep_none");
            }
            player.getCooldowns().addCooldown(this, 8);
            return InteractionResult.CONSUME;
        }
    }

    public static class PickerItem extends Item {
        public PickerItem(Properties p) {
            super(p.durability(250));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide) {
                return InteractionResultHolder.success(stack);
            }
            int n = sweep(level, player.blockPosition(), 3);
            for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, new AABB(player.blockPosition()).inflate(4.0))) {
                int before = e.getItem().getCount();
                e.setPickUpDelay(0);
                e.playerTouch(player);
                if (e.isRemoved() || e.getItem().getCount() < before) {
                    n++;
                }
            }
            level.playSound(null, player.blockPosition(), SoundEvents.CHAIN_HIT, SoundSource.PLAYERS, 0.8F, 1.6F);
            if (n > 0) {
                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
                say(player, "picked", n);
            } else {
                say(player, "pick_none");
            }
            player.getCooldowns().addCooldown(this, 10);
            return InteractionResultHolder.consume(stack);
        }
    }

    // ------------------------------------------------------------------ rota board

    public static class RotaBoardBlock extends RestaurantBlocks.FacingEntityBlock implements GuestBlocks.TextHolder {
        public static final MapCodec<RotaBoardBlock> CODEC = simpleCodec(RotaBoardBlock::new);

        public RotaBoardBlock(Properties p) {
            super(p);
        }

        @Override
        public int textLines() {
            return 12;
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
            return DecorBlocks.dbox(s.getValue(DecorBlocks.FACING), 0, 2, 13, 16, 16, 16);
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new GuestBlocks.TextBlockEntity(pos, state);
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState s, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openService(2, pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }
}
