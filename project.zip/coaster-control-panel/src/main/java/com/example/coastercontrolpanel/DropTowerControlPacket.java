package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: Start, Pause/Resume or End of a Drop Tower ride. */
public record DropTowerControlPacket(BlockPos pos, int action) implements CustomPacketPayload {
    public static final Type<DropTowerControlPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "drop_tower_control"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DropTowerControlPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.action);
            },
            buf -> new DropTowerControlPacket(buf.readBlockPos(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(DropTowerControlPacket p, IPayloadContext context) {
        RideEngine be = RideLookup.find(context.player(), p.pos);
        if (be != null) {
            be.control(p.action);
        }
    }
}
