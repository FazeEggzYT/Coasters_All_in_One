package com.example.coastercontrolpanel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Drive Tyre lifts are drawn as pairs of rubber wheels that spin, like the drive tyres on a launch or lift of a real
 * coaster, instead of a chain. The track path, spacing and drive speed all come from Coasters Simulated's own chain
 * lift (the same path and the same signed speed the chain uses), so the wheels turn exactly when the chain would run.
 * Everything is read by reflection; if anything does not match, the wheels switch themselves off and the lift falls
 * back to the plain tyre-belt texture instead of vanishing.
 */
@EventBusSubscriber(modid = CoasterControlPanel.MOD_ID, value = Dist.CLIENT)
public class TyreWheels {
    private static final String BASE = "dev.silvergold.simulatedcoasters.";
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "textures/block/animatronic_white.png");

    private static final double SPACING = 0.8;
    private static final float RADIUS = 0.2F;
    private static final float HALF_WIDTH = 0.09F;
    private static final float SIDE = 0.25F;
    private static final float LIFT = 0.14F;
    private static final int SEGMENTS = 14;

    private static boolean broken;
    private static Method snapshot;
    private static Method resolve;
    private static Method totalLength;
    private static Method sampleHit;
    private static Method hitPoint;
    private static Method basisAt;
    private static Method forwardOf;
    private static Method rightOf;
    private static Method upOf;
    private static Method signedSpeed;
    private static boolean ready;

    private static final class Frame {
        final Vec3 pos;
        final Vec3 forward;
        final Vec3 right;
        final Vec3 up;

        Frame(Vec3 pos, Vec3 forward, Vec3 right, Vec3 up) {
            this.pos = pos;
            this.forward = forward;
            this.right = right;
            this.up = up;
        }
    }

    private static final class State {
        List<Frame> frames = new ArrayList<>();
        double total = -1;
        long builtAt;
        float angle;
        long lastMillis;
    }

    private static final Map<BlockEntity, State> STATES = new WeakHashMap<>();

    private static void init() throws Exception {
        Class<?> index = Class.forName(BASE + "track.anchor.ChainLiftClientIndex");
        snapshot = index.getMethod("snapshotAnchors");
        Class<?> cache = Class.forName(BASE + "track.chainlift.ChainLiftSpanPathCache");
        for (Method m : cache.getMethods()) {
            if (m.getName().equals("resolve") && m.getParameterCount() == 2) {
                resolve = m;
            }
        }
        Class<?> spanPath = Class.forName(BASE + "track.graph.CoasterPathGraphSpans$SpanPath");
        totalLength = spanPath.getMethod("totalLength");
        Class<?> spans = Class.forName(BASE + "track.graph.CoasterPathGraphSpans");
        for (Method m : spans.getMethods()) {
            if (m.getName().equals("sampleGraphHitAtArcLength") && m.getParameterCount() == 4) {
                sampleHit = m;
            }
        }
        Class<?> hit = Class.forName(BASE + "track.graph.CoasterPathTrackFrame$GraphHit");
        hitPoint = hit.getMethod("point");
        Class<?> frame = Class.forName(BASE + "track.graph.CoasterPathTrackFrame");
        for (Method m : frame.getMethods()) {
            if (m.getName().equals("trackBasisAtHit") && m.getParameterCount() == 2) {
                basisAt = m;
            }
        }
        Class<?> basis = Class.forName(BASE + "track.graph.CoasterPathTrackFrame$TrackBasis");
        forwardOf = basis.getMethod("forward");
        rightOf = basis.getMethod("right");
        upOf = basis.getMethod("up");
        Class<?> drive = Class.forName(BASE + "track.chainlift.ChainLiftDriveDirection");
        for (Method m : drive.getMethods()) {
            if (m.getName().equals("signedChainBlocksPerSecond") && m.getParameterCount() == 5) {
                signedSpeed = m;
            }
        }
        if (snapshot == null || resolve == null || sampleHit == null || basisAt == null || signedSpeed == null) {
            throw new IllegalStateException("chain lift classes differ from what the Drive Tyre expects");
        }
        ready = true;
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (broken || event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        try {
            if (!ready) {
                init();
            }
            draw(event, mc);
        } catch (Throwable t) {
            broken = true;
            DriveTyre.wheelsOk = false;
            CoasterControlPanel.LOGGER.error("Drive Tyre wheels turned themselves off; the tyre belt texture is used instead", t);
        }
    }

    @SuppressWarnings("unchecked")
    private static void draw(RenderLevelStageEvent event, Minecraft mc) throws Exception {
        Level level = mc.level;
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        List<?> anchors = (List<?>) snapshot.invoke(null);
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = null;
        PoseStack ps = event.getPoseStack();
        long now = System.currentTimeMillis();
        boolean any = false;
        for (Object o : anchors) {
            if (!(o instanceof BlockEntity be) || be.isRemoved() || be.getLevel() != level
                    || !(be instanceof DriveTyre.Holder h) || !(h.ccp$isDriveTyre() || DriveTyre.isControlled(h))) {
                continue;
            }
            BlockPos bp = be.getBlockPos();
            if (cam.distanceToSqr(bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5) > 128.0 * 128.0) {
                continue;
            }
            Object path = resolve.invoke(null, be, (double) pt);
            if (path == null) {
                continue;
            }
            double total = (Double) totalLength.invoke(path);
            State st = STATES.computeIfAbsent(be, k -> new State());
            if (st.total != total || level.getGameTime() - st.builtAt > 200) {
                st.frames = frames(level, path, total, pt);
                st.total = total;
                st.builtAt = level.getGameTime();
            }
            double speed;
            if (DriveTyre.isControlled(h)) {
                // controlled tyres turn at the drive speed, in the direction they are driving (0 = still)
                double along = BrakeSettings.toBlocksPerSecond(h.ccp$brake().releaseKmh) * h.ccp$brake().driving;
                speed = along;
            } else {
                speed = (Double) signedSpeed.invoke(null, be, path, (double) pt, 256.0F, 16.0);
            }
            if (st.lastMillis != 0) {
                float dt = Math.min(0.1F, (now - st.lastMillis) / 1000.0F);
                st.angle += (float) (speed * dt / RADIUS);
            }
            st.lastMillis = now;
            if (vc == null) {
                vc = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
            }
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);
            for (Frame f : st.frames) {
                int light = LevelRenderer.getLightColor(level, BlockPos.containing(f.pos));
                wheel(vc, ps.last(), f, 1, st.angle, light);
                wheel(vc, ps.last(), f, -1, st.angle, light);
                any = true;
            }
            ps.popPose();
        }
        if (any) {
            buffers.endBatch(RenderType.entityCutoutNoCull(WHITE));
            DriveTyre.wheelsOk = true;
        }
    }

    private static List<Frame> frames(Level level, Object path, double total, float pt) throws Exception {
        List<Frame> out = new ArrayList<>();
        int count = (int) Math.min(300, Math.floor(total / SPACING));
        for (int i = 0; i < count; i++) {
            double arc = (i + 0.5) * SPACING;
            Object hit = sampleHit.invoke(null, level, path, arc, (double) pt);
            if (hit == null) {
                continue;
            }
            Vec3 point = (Vec3) hitPoint.invoke(hit);
            Object basis = basisAt.invoke(null, level, hit);
            if (point == null || basis == null) {
                continue;
            }
            out.add(new Frame(point, (Vec3) forwardOf.invoke(basis), (Vec3) rightOf.invoke(basis), (Vec3) upOf.invoke(basis)));
        }
        return out;
    }

    /** One wheel: a 14-sided rubber tyre with a lighter hub and a spoke, lying flat on the track, turning about the track's up direction. */
    private static void wheel(VertexConsumer vc, PoseStack.Pose p, Frame f, int side, float angle, int light) {
        Vec3 axis = f.up;
        Vec3 centre = f.pos.add(f.right.scale(side * SIDE)).add(axis.scale(LIFT));
        float spin = side * angle;
        Vec3 lo = axis.scale(-HALF_WIDTH);
        Vec3 hi = axis.scale(HALF_WIDTH);
        Vec3[] ring = new Vec3[SEGMENTS];
        for (int i = 0; i < SEGMENTS; i++) {
            double a = spin + i * 2.0 * Math.PI / SEGMENTS;
            ring[i] = f.right.scale(Math.cos(a)).add(f.forward.scale(Math.sin(a)));
        }
        for (int i = 0; i < SEGMENTS; i++) {
            int j = (i + 1) % SEGMENTS;
            Vec3 a0 = centre.add(ring[i].scale(RADIUS));
            Vec3 a1 = centre.add(ring[j].scale(RADIUS));
            int shade = (i % 2 == 0) ? 0x2A2A2E : 0x46464C;
            Vec3 mid = ring[i].add(ring[j]).normalize();
            // tread
            quad(vc, p, a0.add(lo), a1.add(lo), a1.add(hi), a0.add(hi), mid, shade, light);
            // top and bottom faces, outer ring and hub
            Vec3 h0 = centre.add(ring[i].scale(RADIUS * 0.45F));
            Vec3 h1 = centre.add(ring[j].scale(RADIUS * 0.45F));
            quad(vc, p, a0.add(hi), a1.add(hi), h1.add(hi), h0.add(hi), axis, 0x1E1E22, light);
            quad(vc, p, a0.add(lo), a1.add(lo), h1.add(lo), h0.add(lo), axis.scale(-1), 0x1E1E22, light);
            quad(vc, p, h0.add(hi), h1.add(hi), centre.add(hi), centre.add(hi), axis, 0x8C919B, light);
            quad(vc, p, h0.add(lo), h1.add(lo), centre.add(lo), centre.add(lo), axis.scale(-1), 0x8C919B, light);
        }
        // a spoke across the top so the turning is easy to see
        Vec3 s = ring[0].scale(RADIUS * 0.8F);
        Vec3 w = ring[SEGMENTS / 4].scale(0.025F);
        Vec3 top = axis.scale(HALF_WIDTH + 0.004F);
        quad(vc, p, centre.add(s).add(w).add(top), centre.add(s).subtract(w).add(top),
                centre.subtract(s).subtract(w).add(top), centre.subtract(s).add(w).add(top), axis, 0xD8DCE4, light);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose p, Vec3 a, Vec3 b, Vec3 c, Vec3 d, Vec3 n, int rgb, int light) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int bl = rgb & 255;
        v(vc, p, a, 0, 1, n, r, g, bl, light);
        v(vc, p, b, 1, 1, n, r, g, bl, light);
        v(vc, p, c, 1, 0, n, r, g, bl, light);
        v(vc, p, d, 0, 0, n, r, g, bl, light);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, Vec3 pos, float u, float v, Vec3 n, int r, int g, int b, int light) {
        vc.addVertex(p, (float) pos.x, (float) pos.y, (float) pos.z).setColor(r, g, b, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p, (float) n.x, (float) n.y, (float) n.z);
    }
}
