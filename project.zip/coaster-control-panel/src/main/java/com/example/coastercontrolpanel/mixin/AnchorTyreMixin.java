package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.DriveTyre;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drive Tyre: remembers, on the start anchor of a chain lift, that it was placed with a Drive Tyre. Saved with the
 * anchor and sent to clients with it. Optional: if the anchor class differs, the Drive Tyre simply looks like a chain.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity", remap = false)
public abstract class AnchorTyreMixin implements DriveTyre.Holder {
    @Unique
    private boolean ccp$tyre;

    @Override
    public boolean ccp$isDriveTyre() {
        return ccp$tyre;
    }

    @Inject(method = "write", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        if (ccp$tyre) {
            tag.putBoolean("CcpDriveTyre", true);
        }
    }

    @Inject(method = "read", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        ccp$tyre = tag.getBoolean("CcpDriveTyre");
    }

    @Inject(method = "commitChainLift", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$commit(CallbackInfo ci) {
        boolean tyre = DriveTyre.consumeHit();
        if (tyre != ccp$tyre) {
            ccp$tyre = tyre;
            SmartBlockEntity self = (SmartBlockEntity) (Object) this;
            if (self.getLevel() != null && !self.getLevel().isClientSide) {
                self.setChanged();
                self.sendData();
            }
        }
    }

    @Inject(method = "clearChainLiftSpanData", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$clear(CallbackInfo ci) {
        ccp$tyre = false;
    }
}
