package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.BrakeController;
import com.example.coastercontrolpanel.BrakeSettings;
import com.example.coastercontrolpanel.DriveTyre;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drive Tyre: remembers, on the start anchor of a chain lift, that it was placed with a Drive Tyre. Saved with the
 * anchor and sent to clients with it. Optional: if the anchor class differs, the Drive Tyre simply looks like a chain.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity", remap = false)
public abstract class AnchorTyreMixin implements DriveTyre.Holder {
    @Unique
    private boolean ccp$tyre;

    @Unique
    private BrakeSettings ccp$brake;

    @Unique
    private float ccp$rampUp;

    @Unique
    private float ccp$rampDown;

    @Override
    public float ccp$rampUp() {
        return ccp$rampUp;
    }

    @Override
    public float ccp$rampDown() {
        return ccp$rampDown;
    }

    @Override
    public void ccp$setRamp(float up, float down) {
        ccp$rampUp = Math.max(0.0F, Math.min(120.0F, Float.isNaN(up) ? 0.0F : up));
        ccp$rampDown = Math.max(0.0F, Math.min(120.0F, Float.isNaN(down) ? 0.0F : down));
        if (ccp$rampUp > 0.0F || ccp$rampDown > 0.0F) {
            BrakeController.armed = true;
        }
    }

    @Override
    public boolean ccp$isDriveTyre() {
        return ccp$tyre;
    }

    @Override
    public BrakeSettings ccp$brake() {
        return ccp$brake;
    }

    @Override
    public void ccp$setBrake(BrakeSettings settings) {
        ccp$brake = settings;
        if (settings != null) {
            if (!BrakeController.armed) {
                com.example.coastercontrolpanel.CoasterControlPanel.LOGGER.info("Brake Run: an anchor now holds a Brake Run.");
            }
            BrakeController.armed = true;
        }
    }

    @Override
    public void ccp$sync() {
        SmartBlockEntity self = (SmartBlockEntity) (Object) this;
        if (self.getLevel() != null && !self.getLevel().isClientSide) {
            self.setChanged();
            self.sendData();
        }
    }

    @Inject(method = "write", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        if (ccp$tyre) {
            tag.putBoolean("CcpDriveTyre", true);
        }
        if (ccp$brake != null) {
            tag.put("CcpBrake", ccp$brake.toTag());
        }
        if (ccp$rampUp > 0.0F || ccp$rampDown > 0.0F) {
            tag.putFloat("CcpRampUp", ccp$rampUp);
            tag.putFloat("CcpRampDown", ccp$rampDown);
        }
    }

    @Inject(method = "read", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        ccp$tyre = tag.getBoolean("CcpDriveTyre");
        ccp$brake = tag.contains("CcpBrake") ? BrakeSettings.fromTag(tag.getCompound("CcpBrake")) : null;
        ccp$setRamp(tag.getFloat("CcpRampUp"), tag.getFloat("CcpRampDown"));
        if (ccp$brake != null) {
            BrakeController.armed = true;
        }
    }

    @Inject(method = "commitChainLift", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$commit(CallbackInfo ci) {
        int kind = DriveTyre.consumeHit();
        boolean tyre = kind == 1;
        boolean brake = kind == 2 || kind == 3 || kind == 4 || kind == 5 || kind == 6;
        boolean stopperKind = kind == 3;
        boolean launchKind = kind == 4;
        boolean blockKind = kind == 5;
        boolean triggerKind = kind == 6;
        boolean hadBrake = ccp$brake != null;
        boolean wantBrake = brake || tyre; // a Drive Tyre carries its own settings: controlled tyres or Create shaft
        if (tyre != ccp$tyre || wantBrake != hadBrake) {
            ccp$tyre = tyre;
            ccp$setBrake(wantBrake ? (hadBrake ? ccp$brake : (tyre ? BrakeSettings.tyreDefaults() : stopperKind ? BrakeSettings.stopperDefaults() : launchKind ? BrakeSettings.launchDefaults() : blockKind ? BrakeSettings.blockDefaults() : triggerKind ? BrakeSettings.triggerDefaults() : BrakeSettings.defaults())) : null);
            ccp$sync();
        }
    }

    @Inject(method = "clearChainLiftSpanData", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$clear(CallbackInfo ci) {
        ccp$tyre = false;
        ccp$brake = null;
        ccp$rampUp = 0.0F;
        ccp$rampDown = 0.0F;
    }
}
