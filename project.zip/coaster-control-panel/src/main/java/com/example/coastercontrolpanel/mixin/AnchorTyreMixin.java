package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.BrakeController;
import com.example.coastercontrolpanel.BrakeSettings;
import com.example.coastercontrolpanel.DriveTyre;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drive Tyre: remembers, on the start anchor of a chain lift, that it was placed with a Drive Tyre. Saved with the
 * anchor and sent to clients with it. Optional: if the anchor class differs, the Drive Tyre simply looks like a chain.
 */
@Mixin(targets = "dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity", remap = false)
public abstract class AnchorTyreMixin implements DriveTyre.Holder {
    @Unique
    private boolean ccp$tyre;

    @Unique
    private BrakeSettings ccp$brake;

    @Override
    public boolean ccp$isDriveTyre() {
        return ccp$tyre;
    }

    @Override
    public BrakeSettings ccp$brake() {
        return ccp$brake;
    }

    @Override
    public void ccp$setBrake(BrakeSettings settings) {
        ccp$brake = settings;
        if (settings != null) {
            if (!BrakeController.armed) {
                com.example.coastercontrolpanel.CoasterControlPanel.LOGGER.info("Brake Run: an anchor now holds a Brake Run.");
            }
            BrakeController.armed = true;
        }
    }

    @Override
    public void ccp$sync() {
        SmartBlockEntity self = (SmartBlockEntity) (Object) this;
        if (self.getLevel() != null && !self.getLevel().isClientSide) {
            self.setChanged();
            self.sendData();
        }
    }

    @Inject(method = "write", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        if (ccp$tyre) {
            tag.putBoolean("CcpDriveTyre", true);
        }
        if (ccp$brake != null) {
            tag.put("CcpBrake", ccp$brake.toTag());
        }
    }

    @Inject(method = "read", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket, CallbackInfo ci) {
        ccp$tyre = tag.getBoolean("CcpDriveTyre");
        ccp$brake = tag.contains("CcpBrake") ? BrakeSettings.fromTag(tag.getCompound("CcpBrake")) : null;
        if (ccp$brake != null) {
            BrakeController.armed = true;
        }
    }

    @Inject(method = "commitChainLift", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$commit(CallbackInfo ci) {
        int kind = DriveTyre.consumeHit();
        boolean tyre = kind == 1;
        boolean brake = kind == 2 || kind == 3 || kind == 4 || kind == 5 || kind == 6;
        boolean stopperKind = kind == 3;
        boolean launchKind = kind == 4;
        boolean blockKind = kind == 5;
        boolean triggerKind = kind == 6;
        boolean hadBrake = ccp$brake != null;
        boolean wantBrake = brake || tyre; // a Drive Tyre carries its own settings: controlled tyres or Create shaft
        if (tyre != ccp$tyre || wantBrake != hadBrake) {
            ccp$tyre = tyre;
            ccp$setBrake(wantBrake ? (hadBrake ? ccp$brake : (tyre ? BrakeSettings.tyreDefaults() : stopperKind ? BrakeSettings.stopperDefaults() : launchKind ? BrakeSettings.launchDefaults() : blockKind ? BrakeSettings.blockDefaults() : triggerKind ? BrakeSettings.triggerDefaults() : BrakeSettings.defaults())) : null);
            ccp$sync();
        }
    }

    @Inject(method = "clearChainLiftSpanData", at = @At("TAIL"), remap = false, require = 0)
    private void ccp$clear(CallbackInfo ci) {
        ccp$tyre = false;
        ccp$brake = null;
    }
}
