package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The console of a Bumper Cars arena. While a ride is running the cars within 48 blocks can be driven; before it starts,
 * after it ends and during an emergency stop they are held still. Cars far from any console are free.
 */
public class BumperBlockEntity extends BlockEntity implements RideEngine {
    public static final int RANGE = 48;
    private static final Set<BumperBlockEntity> ALL = ConcurrentHashMap.newKeySet();

    /** Seconds one ride lasts. */
    public int rideSeconds = 120;
    /** 0 = a redstone pulse starts the ride, 1 = the ride runs while powered. */
    public int redstoneMode = 0;
    public boolean running;
    public boolean paused;
    public boolean halted;
    public int ticksLeft;
    private boolean lastPower;
    private int syncTicks;
    private final RideLinks links = new RideLinks(this);

    public BumperBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.BUMPER_BE.get(), pos, state);
    }

    // ---- registry of consoles, so cars can ask whether they may be driven

    @Override
    public void onLoad() {
        super.onLoad();
        ALL.add(this);
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        ALL.remove(this);
        links.unregister();
    }

    @Override
    public void setRemoved() {
        ALL.remove(this);
        links.unregister();
        super.setRemoved();
    }

    public boolean driveAllowed() {
        return running && !paused && !halted;
    }

    /** True when the nearest console in range says this car must stand still. */
    public static boolean lockedAt(Level level, Entity car) {
        BumperBlockEntity best = null;
        double bestD = (double) RANGE * RANGE;
        for (BumperBlockEntity be : ALL) {
            if (be.level != level) {
                continue;
            }
            double d = be.worldPosition.distSqr(car.blockPosition());
            if (d < bestD) {
                bestD = d;
                best = be;
            }
        }
        return best != null && !best.driveAllowed();
    }

    // ---- RideEngine

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return !running;
    }

    @Override
    public void applyConfig(CompoundTag tag) {
        if (running) {
            return;
        }
        rideSeconds = Math.max(10, Math.min(1800, tag.getInt("RideSeconds")));
        redstoneMode = Math.max(0, Math.min(1, tag.getInt("Redstone")));
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> {
                if (!running) {
                    running = true;
                    paused = false;
                    halted = false;
                    ticksLeft = rideSeconds * 20;
                } else if (halted) {
                    halted = false;
                }
            }
            case ACTION_PAUSE -> {
                if (running) {
                    paused = !paused;
                }
            }
            case ACTION_END -> {
                running = false;
                paused = false;
                halted = false;
            }
            case ACTION_HALT -> {
                if (running) {
                    halted = true;
                }
            }
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean power = level.hasNeighborSignal(worldPosition) || DropTowerBlocks.controllerPowered(level, worldPosition) || links.on(RideLinks.START);
        if (power == lastPower) {
            return;
        }
        lastPower = power;
        if (power && !running) {
            control(ACTION_START);
        } else if (!power && redstoneMode == 1 && running) {
            control(ACTION_END);
        }
    }

    // ---- ticking

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.HALT) && running) {
            control(ACTION_HALT);
        }
        links.tickOutputs(running, halted);
        if (running && !paused && !halted) {
            if (--ticksLeft <= 0) {
                running = false;
                syncNow();
                return;
            }
        }
        if (running && ++syncTicks >= 20) {
            syncNow();
        }
    }

    private void syncNow() {
        syncTicks = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("RideSeconds", rideSeconds);
        tag.putInt("Redstone", redstoneMode);
        tag.putBoolean("Running", running);
        tag.putBoolean("Paused", paused);
        tag.putBoolean("Halted", halted);
        tag.putInt("TicksLeft", ticksLeft);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        rideSeconds = tag.contains("RideSeconds") ? tag.getInt("RideSeconds") : 120;
        redstoneMode = tag.getInt("Redstone");
        running = tag.getBoolean("Running");
        paused = tag.getBoolean("Paused");
        halted = tag.getBoolean("Halted");
        ticksLeft = tag.getInt("TicksLeft");
        links.load(tag, registries);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
