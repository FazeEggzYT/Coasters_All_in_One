package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.elements.ElementPlan;
import com.example.coastercontrolpanel.elements.Params;
import com.example.coastercontrolpanel.elements.TrackElement;
import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Places a track element with Coasters Simulated's own representation: real Anchorpoint blocks joined by real
 * curves (stored with the anchors' own putAnchorPeerCurve inside the mod's batch update), then shaped with the
 * mod's own handle and tilt edits, exactly like the Coaster Smoother does. Nothing here invents a track system.
 *
 * Placement is all or nothing: every block is checked first, and if anything fails afterwards everything this
 * placement created is removed again.
 */
public final class ElementPlacer {
    private static final String BASE = "dev.silvergold.simulatedcoasters.";

    private ElementPlacer() {
    }

    /** Where an element would go. problems is empty when it can be placed. */
    public static final class Context {
        public ElementPlan.Plan plan;
        public BlockPos entrance;
        public boolean entranceExists;
        public BlockPos before;
        public int heading;
        public final List<String> problems = new ArrayList<>();
        public final List<BlockPos> blocked = new ArrayList<>();
    }

    // ------------------------------------------------------------------ reflection

    private static Method buildBezier;
    private static Method putCurve;
    private static Method batch;
    private static Method cost;
    private static Object material;
    private static Object anchorBlock;
    private static boolean tried;
    private static boolean ok;

    private static boolean init() {
        if (!tried) {
            tried = true;
            try {
                Class<?> opt = Class.forName(BASE + "track.CoasterAnchorBezierOptimizer");
                for (Method m : opt.getMethods()) {
                    if (m.getName().equals("buildAnchorAnchorBezier") && m.getParameterCount() == 5) {
                        buildBezier = m;
                    }
                }
                Class<?> be = Class.forName(BASE + "track.anchor.CoasterAnchorpointBlockEntity");
                for (Method m : be.getMethods()) {
                    if (m.getName().equals("putAnchorPeerCurve") && m.getParameterCount() == 3) {
                        putCurve = m;
                    }
                }
                Class<?> prop = Class.forName(BASE + "track.graph.CoasterTrackPropagator");
                for (Method m : prop.getMethods()) {
                    if (m.getName().equals("runBatchUpdate") && m.getParameterCount() == 2) {
                        batch = m;
                    }
                }
                Class<?> drops = Class.forName(BASE + "track.CoasterTrackCurveDrops");
                for (Method m : drops.getMethods()) {
                    if (m.getName().equals("trackItemCostForAnchorPair") && m.getParameterCount() == 3) {
                        cost = m;
                    }
                }
                material = Class.forName(BASE + "CoasterTrackMaterials").getField("COASTER").get(null);
                Object holder = Class.forName(BASE + "SimulatedCoastersBlocks").getField("COASTER_ANCHORPOINT").get(null);
                anchorBlock = holder.getClass().getMethod("get").invoke(holder);
                ok = buildBezier != null && putCurve != null && cost != null && material != null && anchorBlock instanceof Block;
            } catch (Throwable t) {
                ok = false;
            }
        }
        return ok;
    }

    public static boolean supported() {
        return init();
    }

    private static Item trackItem() {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse("simulatedcoasters:coaster_track"));
    }

    // ------------------------------------------------------------------ resolve (client preview and server placement)

    /**
     * Works out where the element goes when the player clicks block clicked on the given face.
     * Clicking an open end of existing track continues it; anything else starts new track in the air block beside the face.
     */
    public static Context resolve(Level level, Player player, BlockPos clicked, Direction face, ElementState st) {
        Context c = new Context();
        BlockEntity be = level.getBlockEntity(clicked);
        int rot = st.rotation();
        if (AnchorTrack.isAnchor(be)) {
            Set<BlockPos> peers = AnchorTrack.peers(be).keySet();
            BlockPos peerBefore = null;
            if (peers.isEmpty()) {
                c.heading = Math.floorMod(Direction.fromYRot(player.getYRot()).get2DDataValue() + 2 + rot, 4);
            } else if (peers.size() == 1) {
                peerBefore = peers.iterator().next();
                int dx = clicked.getX() - peerBefore.getX();
                int dz = clicked.getZ() - peerBefore.getZ();
                if (dx == 0 && dz == 0) {
                    c.problems.add("entrance_vertical");
                }
                Direction d = Math.abs(dx) >= Math.abs(dz) ? (dx >= 0 ? Direction.EAST : Direction.WEST)
                        : (dz >= 0 ? Direction.SOUTH : Direction.NORTH);
                c.heading = headingOf(d);
            } else {
                c.problems.add("entrance_busy");
            }
            if (level.getBlockState(clicked).hasProperty(blockFacing()) && level.getBlockState(clicked).getValue(blockFacing()) != Direction.UP) {
                c.problems.add("entrance_not_upright");
            }
            c.entrance = clicked;
            c.entranceExists = true;
            c.before = peerBefore;
        } else {
            c.entrance = clicked.relative(face);
            c.heading = Math.floorMod(headingOf(Direction.fromYRot(player.getYRot())) + rot, 4);
        }
        if (!c.problems.isEmpty()) {
            return c;
        }
        c.plan = ElementPlan.plan(st.element(), st.params(), c.heading, c.entrance.getX(), c.entrance.getY(), c.entrance.getZ());
        c.problems.addAll(c.plan.problems);
        validate(level, player, c);
        return c;
    }

    private static net.minecraft.world.level.block.state.properties.DirectionProperty blockFacing() {
        return net.minecraft.world.level.block.state.properties.BlockStateProperties.FACING;
    }

    /** ElementPlan heading: 0 north, 1 east, 2 south, 3 west. */
    private static int headingOf(Direction d) {
        return switch (d) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
    }

    private static void validate(Level level, Player player, Context c) {
        List<ElementPlan.Node> nodes = c.plan.nodes;
        for (int i = 0; i < nodes.size(); i++) {
            ElementPlan.Node n = nodes.get(i);
            BlockPos p = new BlockPos(n.x(), n.y(), n.z());
            if (i == 0 && c.entranceExists) {
                continue;
            }
            if (!level.isInWorldBounds(p) || !level.isLoaded(p)) {
                c.problems.add("out_of_world");
                c.blocked.add(p);
                continue;
            }
            BlockState s = level.getBlockState(p);
            if (!(s.isAir() || (s.canBeReplaced() && s.getFluidState().isEmpty()))) {
                c.problems.add("blocked");
                c.blocked.add(p);
            } else if (!level.mayInteract(player, p) || !player.mayBuild()) {
                c.problems.add("protected");
                c.blocked.add(p);
            }
        }
        if (!supported()) {
            c.problems.add("unsupported");
        }
    }

    // ------------------------------------------------------------------ placement (server only)

    /** Returns null on success, otherwise {translation key, args...}. */
    public static Object[] place(ServerLevel level, ServerPlayer player, Context c) {
        if (!c.problems.isEmpty() || c.plan == null) {
            return new Object[]{"message.coastercontrolpanel.element_problem." + (c.problems.isEmpty() ? "too_small" : c.problems.get(0))};
        }
        if (!init()) {
            return new Object[]{"message.coastercontrolpanel.element_problem.unsupported"};
        }
        List<BlockPos> placed = new ArrayList<>();
        List<BlockPos> chain = new ArrayList<>();
        Map<BlockPos, Vec3> normals = new HashMap<>();
        try {
            // 1. the anchor blocks
            Block block = (Block) anchorBlock;
            List<ElementPlan.Node> nodes = c.plan.nodes;
            for (int i = 0; i < nodes.size(); i++) {
                ElementPlan.Node n = nodes.get(i);
                BlockPos p = new BlockPos(n.x(), n.y(), n.z());
                chain.add(p);
                normals.put(p, new Vec3(n.normal()[0], n.normal()[1], n.normal()[2]));
                if (i == 0 && c.entranceExists) {
                    continue;
                }
                BlockState state = block.defaultBlockState().setValue(blockFacing(), Direction.values()[n.facing()]);
                if (!level.setBlock(p, state, 3)) {
                    throw new IllegalStateException("set_block");
                }
                placed.add(p);
            }
            // 2. the curves, from the mod's own builder
            List<BezierConnection> curves = new ArrayList<>();
            int total = 0;
            for (int i = 0; i + 1 < chain.size(); i++) {
                Object b = buildBezier.invoke(null, level, chain.get(i), chain.get(i + 1), material, false);
                if (!(b instanceof BezierConnection bc)) {
                    throw new IllegalStateException("curve");
                }
                curves.add(bc);
                total += (Integer) cost.invoke(null, level, chain.get(i), chain.get(i + 1));
            }
            // 3. the cost
            Item track = trackItem();
            if (!player.isCreative()) {
                int have = count(player, track);
                if (have < total) {
                    rollback(level, placed);
                    return new Object[]{"message.coastercontrolpanel.element_problem.not_enough_track", total, have};
                }
            }
            // 4. store the curves the way the mod does
            final List<BlockPos> ch = chain;
            Runnable store = () -> {
                try {
                    for (int i = 0; i + 1 < ch.size(); i++) {
                        BlockEntity a = level.getBlockEntity(ch.get(i));
                        if (a == null) {
                            throw new IllegalStateException("anchor");
                        }
                        putCurve.invoke(a, level, ch.get(i + 1), curves.get(i));
                    }
                } catch (Exception ex) {
                    throw new IllegalStateException(ex);
                }
            };
            if (batch != null) {
                batch.invoke(null, level, store);
            } else {
                store.run();
            }
            // 5. shape it with the mod's own edits
            List<BlockPos> shapeChain = new ArrayList<>();
            if (c.before != null) {
                shapeChain.add(c.before);
            }
            shapeChain.addAll(chain);
            Set<BlockPos> mine = new LinkedHashSet<>(chain);
            int[] shaped = CoasterTools.shapeChain(level, player, shapeChain, mine::contains, normals);
            if (!player.isCreative() && total > 0) {
                take(player, track, total);
            }
            return new Object[]{null, placed.size(), shaped[0], shaped[1], total};
        } catch (Throwable t) {
            rollback(level, placed);
            return new Object[]{"message.coastercontrolpanel.element_problem.failed"};
        }
    }

    private static void rollback(ServerLevel level, List<BlockPos> placed) {
        for (BlockPos p : placed) {
            try {
                BlockEntity be = level.getBlockEntity(p);
                if (be != null) {
                    for (Method m : be.getClass().getMethods()) {
                        if (m.getName().equals("detachAllConnections") && m.getParameterCount() == 1) {
                            m.invoke(be, level);
                        }
                    }
                }
            } catch (Throwable ignored) {
                // removing the block below is what matters
            }
            level.removeBlock(p, false);
        }
    }

    private static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        return n;
    }

    private static void take(Player player, Item item, int amount) {
        int left = amount;
        for (ItemStack s : player.getInventory().items) {
            if (left <= 0) {
                break;
            }
            if (s.is(item)) {
                int k = Math.min(left, s.getCount());
                s.shrink(k);
                left -= k;
            }
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (left <= 0) {
                break;
            }
            if (s.is(item)) {
                int k = Math.min(left, s.getCount());
                s.shrink(k);
                left -= k;
            }
        }
    }

    /** Which element is it, for the action bar. */
    public static String describe(TrackElement e, Params p) {
        return e.id() + " " + p.size() + (p.side() < 0 ? "L" : "R");
    }
}
