package com.example.coastercontrolpanel;

import com.example.coastercontrolpanel.elements.ElementPlan;
import com.example.coastercontrolpanel.elements.Params;
import com.example.coastercontrolpanel.elements.TrackElement;
import com.simibubi.create.content.trains.track.BezierConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Places a track element with Coasters Simulated's own representation: real Anchorpoint blocks joined by real
 * curves (stored with the anchors' own putAnchorPeerCurve inside the mod's batch update), then shaped with the
 * mod's own handle and tilt edits, exactly like the Coaster Smoother does. Nothing here invents a track system.
 *
 * Placement is all or nothing: every block is checked first, and if anything fails afterwards everything this
 * placement created is removed again.
 */
public final class ElementPlacer {
    private static final String BASE = "dev.silvergold.simulatedcoasters.";

    private ElementPlacer() {
    }

    /** Where an element would go. problems is empty when it can be placed. */
    public static final class Context {
        public ElementPlan.Plan plan;
        public BlockPos entrance;
        public boolean entranceExists;
        public BlockPos before;
        public int heading;
        public final List<String> problems = new ArrayList<>();
        public final List<BlockPos> blocked = new ArrayList<>();
    }

    // ------------------------------------------------------------------ reflection

    private static Method buildBezier;
    private static Method putCurve;
    private static Method batch;
    private static Method cost;
    private static Object material;
    private static Object anchorBlock;
    private static boolean tried;
    private static boolean ok;

    private static boolean init() {
        if (!tried) {
            tried = true;
            try {
                Class<?> opt = Class.forName(BASE + "track.CoasterAnchorBezierOptimizer");
                for (Method m : opt.getMethods()) {
                    if (m.getName().equals("buildAnchorAnchorBezier") && m.getParameterCount() == 5) {
                        buildBezier = m;
                    }
                }
                Class<?> be = Class.forName(BASE + "track.anchor.CoasterAnchorpointBlockEntity");
                for (Method m : be.getMethods()) {
                    if (m.getName().equals("putAnchorPeerCurve") && m.getParameterCount() == 3) {
                        putCurve = m;
                    }
                }
                Class<?> prop = Class.forName(BASE + "track.graph.CoasterTrackPropagator");
                for (Method m : prop.getMethods()) {
                    if (m.getName().equals("runBatchUpdate") && m.getParameterCount() == 2) {
                        batch = m;
                    }
                }
                Class<?> drops = Class.forName(BASE + "track.CoasterTrackCurveDrops");
                for (Method m : drops.getMethods()) {
                    if (m.getName().equals("trackItemCostForAnchorPair") && m.getParameterCount() == 3) {
                        cost = m;
                    }
                }
                material = Class.forName(BASE + "CoasterTrackMaterials").getField("COASTER").get(null);
                Object holder = Class.forName(BASE + "SimulatedCoastersBlocks").getField("COASTER_ANCHORPOINT").get(null);
                anchorBlock = holder.getClass().getMethod("get").invoke(holder);
                ok = buildBezier != null && putCurve != null && cost != null && material != null && anchorBlock instanceof Block;
            } catch (Throwable t) {
                ok = false;
            }
        }
        return ok;
    }

    public static boolean supported() {
        return init();
    }

    private static Item trackItem() {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse("simulatedcoasters:coaster_track"));
    }

    // ------------------------------------------------------------------ resolve (client preview and server placement)

    /**
     * Works out where the element goes when the player clicks block clicked on the given face.
     * Clicking an open end of existing track continues it; anything else starts new track in the air block beside the face.
     */
    public static Context resolve(Level level, Player player, BlockPos clicked, Direction face, ElementState st) {
        Context c = new Context();
        BlockEntity be = level.getBlockEntity(clicked);
        int rot = st.rotation();
        if (AnchorTrack.isAnchor(be)) {
            Set<BlockPos> peers = AnchorTrack.peers(be).keySet();
            BlockPos peerBefore = null;
            if (peers.isEmpty()) {
                c.heading = Math.floorMod(Direction.fromYRot(player.getYRot()).get2DDataValue() + 2 + rot, 4);
            } else if (peers.size() == 1) {
                peerBefore = peers.iterator().next();
                int dx = clicked.getX() - peerBefore.getX();
                int dz = clicked.getZ() - peerBefore.getZ();
                if (dx == 0 && dz == 0) {
                    c.problems.add("entrance_vertical");
                }
                Direction d = Math.abs(dx) >= Math.abs(dz) ? (dx >= 0 ? Direction.EAST : Direction.WEST)
                        : (dz >= 0 ? Direction.SOUTH : Direction.NORTH);
                c.heading = headingOf(d);
            } else {
                c.problems.add("entrance_busy");
            }
            if (level.getBlockState(clicked).hasProperty(blockFacing()) && level.getBlockState(clicked).getValue(blockFacing()) != Direction.UP) {
                c.problems.add("entrance_not_upright");
            }
            c.entrance = clicked;
            c.entranceExists = true;
            c.before = peerBefore;
        } else {
            c.entrance = clicked.relative(face);
            c.heading = Math.floorMod(headingOf(Direction.fromYRot(player.getYRot())) + rot, 4);
        }
        if (!c.problems.isEmpty()) {
            return c;
        }
        c.plan = ElementPlan.plan(st.element(), st.params(), c.heading, c.entrance.getX(), c.entrance.getY(), c.entrance.getZ());
        c.problems.addAll(c.plan.problems);
        validate(level, player, c);
        return c;
    }

    /** Sets the anchor's direction using whatever direction property the block really has (logged if none). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static BlockState withFacing(BlockState state, Direction dir) {
        for (net.minecraft.world.level.block.state.properties.Property p : state.getProperties()) {
            if (p.getValueClass() == Direction.class && p.getPossibleValues().contains(dir)) {
                return (BlockState) state.setValue(p, dir);
            }
        }
        org.slf4j.LoggerFactory.getLogger("coastercontrolpanel").warn("Anchor block has no direction property: {}", state.getProperties());
        return state;
    }

    private static net.minecraft.world.level.block.state.properties.DirectionProperty blockFacing() {
        return net.minecraft.world.level.block.state.properties.BlockStateProperties.FACING;
    }

    /** ElementPlan heading: 0 north, 1 east, 2 south, 3 west. */
    private static int headingOf(Direction d) {
        return switch (d) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
    }

    private static void validate(Level level, Player player, Context c) {
        List<ElementPlan.Node> nodes = c.plan.nodes;
        for (int i = 0; i < nodes.size(); i++) {
            ElementPlan.Node n = nodes.get(i);
            BlockPos p = new BlockPos(n.x(), n.y(), n.z());
            if (i == 0 && c.entranceExists) {
                continue;
            }
            if (!level.isInWorldBounds(p) || !level.isLoaded(p)) {
                c.problems.add("out_of_world");
                c.blocked.add(p);
                continue;
            }
            BlockState s = level.getBlockState(p);
            if (!(s.isAir() || (s.canBeReplaced() && s.getFluidState().isEmpty()))) {
                c.problems.add("blocked");
                c.blocked.add(p);
            } else if (!level.mayInteract(player, p) || !player.mayBuild()) {
                c.problems.add("protected");
                c.blocked.add(p);
            }
        }
        if (!supported()) {
            c.problems.add("unsupported");
        }
    }

    // ------------------------------------------------------------------ placement (server only)

    private static Method connect;
    private static Method flush;
    private static Class<?> trackItemClass;
    private static boolean triedConnect;

    private static boolean initConnect() {
        if (!triedConnect) {
            triedConnect = true;
            try {
                Class<?> place = Class.forName(BASE + "track.CoasterTrackPlacement");
                for (Method m : place.getMethods()) {
                    if (m.getName().equals("commitSecondAnchorOnServer") && m.getParameterCount() == 4) {
                        connect = m;
                    }
                }
                Class<?> def = Class.forName(BASE + "track.CoasterTrackPlacementCommitDeferral");
                for (Method m : def.getMethods()) {
                    if (m.getName().equals("flushPending") && m.getParameterCount() == 1) {
                        flush = m;
                    }
                }
                trackItemClass = Class.forName(BASE + "track.CoasterTrackItem");
            } catch (Throwable t) {
                connect = null;
            }
        }
        return connect != null && trackItemClass != null;
    }

    /** Returns null on success, otherwise {translation key, args...}; the last element after success is {null, anchors, shapedHandles, tilts, trackUsed}. */
    public static Object[] place(ServerLevel level, ServerPlayer player, Context c) {
        if (!c.problems.isEmpty() || c.plan == null) {
            return new Object[]{"message.coastercontrolpanel.element_problem." + (c.problems.isEmpty() ? "too_small" : c.problems.get(0))};
        }
        if (!init() || !initConnect()) {
            return new Object[]{"message.coastercontrolpanel.element_problem.unsupported"};
        }
        List<BlockPos> placed = new ArrayList<>();
        List<BlockPos> chain = new ArrayList<>();
        Map<BlockPos, Vec3> normals = new HashMap<>();
        Map<BlockPos, Vec3> tangents = new HashMap<>();
        ItemStack original = player.getItemInHand(InteractionHand.MAIN_HAND);
        ItemStack temp = ItemStack.EMPTY;
        int taken = 0;
        boolean scoped = false;
        try {
            Item track = trackItem();
            // 1. the anchor blocks (nothing is connected yet)
            Block block = (Block) anchorBlock;
            List<ElementPlan.Node> nodes = c.plan.nodes;
            for (int i = 0; i < nodes.size(); i++) {
                ElementPlan.Node n = nodes.get(i);
                BlockPos p = new BlockPos(n.x(), n.y(), n.z());
                chain.add(p);
                normals.put(p, new Vec3(n.normal()[0], n.normal()[1], n.normal()[2]));
                tangents.put(p, new Vec3(n.tangent()[0], n.tangent()[1], n.tangent()[2]));
                if (i == 0 && c.entranceExists) {
                    continue;
                }
                BlockState state = withFacing(block.defaultBlockState(), Direction.values()[n.facing()]);
                if (!level.setBlock(p, state, 3)) {
                    throw new IllegalStateException("set_block " + p);
                }
                placed.add(p);
            }
            // 2. the track items: taken from the inventory (creative gets a free temporary stack)
            int estimate = 0;
            for (int i = 0; i + 1 < chain.size(); i++) {
                estimate += (Integer) cost.invoke(null, level, chain.get(i), chain.get(i + 1));
            }
            int want = estimate + 4;
            if (player.isCreative()) {
                temp = new ItemStack(track, 4096);
            } else {
                int have = count(player, track);
                if (have < estimate) {
                    rollback(level, placed);
                    return new Object[]{"message.coastercontrolpanel.element_problem.not_enough_track", estimate, have};
                }
                taken = Math.min(have, want);
                take(player, track, taken);
                temp = new ItemStack(track, taken);
            }
            int before = temp.getCount();
            // 3. connect every pair with the mod's own server routine, exactly as if the player had clicked the two anchors
            CoasterTools.elementScope(true);
            scoped = true;
            player.setItemInHand(InteractionHand.MAIN_HAND, temp);
            for (int i = 0; i + 1 < chain.size(); i++) {
                BlockPos a = chain.get(i);
                BlockPos b = chain.get(i + 1);
                Object ok = connect.invoke(null, player, InteractionHand.MAIN_HAND, a, b);
                if (flush != null) {
                    flush.invoke(null, level.getServer());
                }
                temp = player.getItemInHand(InteractionHand.MAIN_HAND);
                BlockEntity be = level.getBlockEntity(a);
                if (!AnchorTrack.isAnchor(be) || !AnchorTrack.peers(be).containsKey(b)) {
                    throw new IllegalStateException("not connected " + a + " -> " + b + " (routine returned " + ok + ")");
                }
            }
            int used = before - temp.getCount();
            // 4. shape it with the mod's own handle and tilt edits
            List<BlockPos> shapeChain = new ArrayList<>();
            if (c.before != null) {
                shapeChain.add(c.before);
            }
            shapeChain.addAll(chain);
            Set<BlockPos> mine = new LinkedHashSet<>(chain);
            int[] shaped = CoasterTools.shapeChain(level, player, shapeChain, mine::contains, normals, tangents);
            finish(player, original, temp, player.isCreative());
            temp = ItemStack.EMPTY;
            return new Object[]{null, placed.size(), shaped[0], shaped[1], used};
        } catch (Throwable t) {
            Throwable root = t;
            while (root.getCause() != null && root.getCause() != root) {
                root = root.getCause();
            }
            CoasterControlPanel.LOGGER.error("Track element placement failed and was undone", t);
            rollback(level, placed);
            finish(player, original, temp.isEmpty() ? ItemStack.EMPTY : temp, player.isCreative());
            return new Object[]{"message.coastercontrolpanel.element_problem.failed", String.valueOf(root.getMessage())};
        } finally {
            if (scoped) {
                CoasterTools.elementScope(false);
            }
        }
    }

    /** Puts the selector back in the hand and returns unused track items. */
    private static void finish(ServerPlayer player, ItemStack original, ItemStack leftover, boolean creative) {
        player.setItemInHand(InteractionHand.MAIN_HAND, original);
        if (!creative && !leftover.isEmpty() && leftover.getItem() == trackItem()) {
            if (!player.getInventory().add(leftover.copy())) {
                player.drop(leftover.copy(), false);
            }
        }
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
    }

    private static void rollback(ServerLevel level, List<BlockPos> placed) {
        for (BlockPos p : placed) {
            try {
                BlockEntity be = level.getBlockEntity(p);
                if (be != null) {
                    for (Method m : be.getClass().getMethods()) {
                        if (m.getName().equals("detachAllConnections") && m.getParameterCount() == 1) {
                            m.invoke(be, level);
                        }
                    }
                }
            } catch (Throwable ignored) {
                // removing the block below is what matters
            }
            level.removeBlock(p, false);
        }
    }

    private static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        return n;
    }

    private static void take(Player player, Item item, int amount) {
        int left = amount;
        for (ItemStack s : player.getInventory().items) {
            if (left <= 0) {
                break;
            }
            if (s.is(item)) {
                int k = Math.min(left, s.getCount());
                s.shrink(k);
                left -= k;
            }
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (left <= 0) {
                break;
            }
            if (s.is(item)) {
                int k = Math.min(left, s.getCount());
                s.shrink(k);
                left -= k;
            }
        }
    }

    /** Which element is it, for the action bar. */
    public static String describe(TrackElement e, Params p) {
        return e.id() + " " + p.size() + (p.side() < 0 ? "L" : "R");
    }
}
