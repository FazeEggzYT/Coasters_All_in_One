package com.example.coastercontrolpanel;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/** The sounds the Announcer can play for now. Your own audio files come in a later version. */
public final class AnnouncerSounds {
    public static final String[] NAMES = {
            "Bell", "Chime", "Note bell", "Pling", "8-bit beep", "Crystal chime",
            "Villager yes", "Air horn", "Power-up", "Ding", "Fanfare"
    };

    private static final String[] IDS = {
            "block.bell.use", "block.note_block.chime", "block.note_block.bell", "block.note_block.pling",
            "block.note_block.bit", "block.amethyst_block.chime", "entity.villager.yes", "event.raid.horn",
            "block.beacon.activate", "entity.experience_orb.pickup", "ui.toast.challenge_complete"
    };

    private AnnouncerSounds() {
    }

    public static int count() {
        return NAMES.length;
    }

    public static SoundEvent get(int index) {
        int i = Math.max(0, Math.min(IDS.length - 1, index));
        SoundEvent event = BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("minecraft:" + IDS[i]));
        return event != null ? event : SoundEvents.BELL_BLOCK;
    }
}
