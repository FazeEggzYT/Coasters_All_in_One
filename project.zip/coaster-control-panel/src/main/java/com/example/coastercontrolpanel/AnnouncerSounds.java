package com.example.coastercontrolpanel;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/**
 * The sounds the Announcer and the Announcement Panel can play: a few built in, then
 * Custom 1 to 10, which you replace with your own .ogg files using a resource pack.
 */
public final class AnnouncerSounds {
    private static final String[] IDS = {
            "block.bell.use", "block.note_block.chime", "block.note_block.bell", "block.note_block.pling",
            "block.note_block.bit", "block.amethyst_block.chime", "entity.villager.yes", "event.raid.horn",
            "block.beacon.activate", "entity.experience_orb.pickup", "ui.toast.challenge_complete"
    };

    public static final String[] NAMES = {
            "Bell", "Chime", "Note bell", "Pling", "8-bit beep", "Crystal chime",
            "Villager yes", "Air horn", "Power-up", "Ding", "Fanfare",
            "Custom 1", "Custom 2", "Custom 3", "Custom 4", "Custom 5",
            "Custom 6", "Custom 7", "Custom 8", "Custom 9", "Custom 10"
    };

    private AnnouncerSounds() {
    }

    public static int count() {
        return NAMES.length;
    }

    public static SoundEvent get(int index) {
        int i = Math.max(0, Math.min(NAMES.length - 1, index));
        if (i >= IDS.length) {
            return CoasterControlPanel.CUSTOM_SOUNDS.get(i - IDS.length).get();
        }
        SoundEvent event = BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("minecraft:" + IDS[i]));
        return event != null ? event : SoundEvents.BELL_BLOCK;
    }
}
