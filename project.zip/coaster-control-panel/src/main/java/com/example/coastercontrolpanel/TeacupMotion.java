package com.example.coastercontrolpanel;

/**
 * The movement of a Teacup Ride, free of any Minecraft types: the platter turns, and every cup also turns on its
 * own. Both speeds ease toward the targets of the current step. Ending winds both down and then settles each angle
 * onto a whole turn so every block can be put back where it was.
 */
public final class TeacupMotion {
    public static final int IDLE = 0;
    public static final int COUNTDOWN = 1;
    public static final int RUNNING = 2;
    public static final int PAUSED = 3;
    public static final int ENDING = 4;
    public static final int HALTED = 5;

    private static final double SETTLE_SPEED = 45.0;

    public int phase = IDLE;
    public int stepIndex;
    public int loop;
    public double stepTime;
    /** Degrees (not wrapped). */
    public double platter;
    public double cup;
    /** Degrees per second. */
    public double platterRate;
    public double cupRate;
    public boolean finished;
    public boolean landed;

    private double haltPlatter;
    private double haltCup;

    public void start() {
        phase = RUNNING;
        stepIndex = 0;
        loop = 0;
        stepTime = 0;
        platter = 0;
        cup = 0;
        platterRate = 0;
        cupRate = 0;
        finished = false;
        landed = false;
    }

    public void togglePause() {
        if (phase == RUNNING) {
            phase = PAUSED;
        } else if (phase == PAUSED && !finished) {
            phase = RUNNING;
        } else if (phase == HALTED) {
            phase = RUNNING;
        }
    }

    public void halt() {
        if (phase == RUNNING || phase == PAUSED || phase == ENDING) {
            phase = HALTED;
            haltPlatter = Math.max(Math.abs(platterRate), 1.0);
            haltCup = Math.max(Math.abs(cupRate), 1.0);
            finished = false;
        }
    }

    public void end() {
        if (phase == RUNNING || phase == PAUSED || phase == HALTED) {
            phase = ENDING;
            finished = false;
        }
    }

    public void restoreAfterLoad() {
        if (phase == RUNNING) {
            phase = PAUSED;
        } else if (phase == COUNTDOWN) {
            phase = IDLE;
        }
    }

    private static double chase(double value, double target, double accel, double dt) {
        double d = target - value;
        double s = accel * dt;
        return Math.abs(d) <= s ? target : value + Math.signum(d) * s;
    }

    private void nextStep(TeacupSettings c) {
        stepIndex++;
        stepTime = 0;
        if (stepIndex >= c.steps.size()) {
            loop++;
            stepIndex = 0;
            if (loop >= c.loops) {
                if (c.endMode == 0) {
                    phase = ENDING;
                } else {
                    phase = PAUSED;
                    finished = true;
                }
            }
        }
    }

    public void tick(TeacupSettings c, double dt) {
        double acc = c.accel;
        switch (phase) {
            case RUNNING -> {
                if (c.steps.isEmpty()) {
                    nextStep(c);
                    break;
                }
                TeacupSettings.Step s = c.steps.get(Math.min(stepIndex, c.steps.size() - 1));
                double tp = s.type == TeacupSettings.RUN ? s.a * 6.0 : 0.0;
                double tc = s.type == TeacupSettings.RUN ? s.b * 6.0 : 0.0;
                platterRate = chase(platterRate, tp, acc, dt);
                cupRate = chase(cupRate, tc, acc * 2.0, dt);
                stepTime += dt;
                if (stepTime >= s.c) {
                    nextStep(c);
                }
            }
            case PAUSED -> {
                platterRate = chase(platterRate, 0, acc, dt);
                cupRate = chase(cupRate, 0, acc * 2.0, dt);
            }
            case HALTED -> {
                platterRate = chase(platterRate, 0, haltPlatter / Math.max(0.3, c.haltTime), dt);
                cupRate = chase(cupRate, 0, haltCup / Math.max(0.3, c.haltTime), dt);
            }
            case ENDING -> {
                platterRate = chase(platterRate, 0, acc, dt);
                cupRate = chase(cupRate, 0, acc * 2.0, dt);
                if (platterRate == 0 && cupRate == 0) {
                    boolean p = settle(true, dt);
                    boolean q = settle(false, dt);
                    if (p && q) {
                        platter = 0;
                        cup = 0;
                        landed = true;
                        phase = IDLE;
                    }
                }
            }
            default -> {
            }
        }
        platter += platterRate * dt;
        cup += cupRate * dt;
    }

    /** Eases one angle onto the nearest whole turn; true when it is there. */
    private boolean settle(boolean isPlatter, double dt) {
        double a = isPlatter ? platter : cup;
        double goal = Math.rint(a / 360.0) * 360.0;
        double d = goal - a;
        double step = SETTLE_SPEED * dt;
        if (Math.abs(d) <= step) {
            if (isPlatter) {
                platter = goal;
            } else {
                cup = goal;
            }
            return true;
        }
        if (isPlatter) {
            platter += Math.signum(d) * step;
        } else {
            cup += Math.signum(d) * step;
        }
        return false;
    }
}
