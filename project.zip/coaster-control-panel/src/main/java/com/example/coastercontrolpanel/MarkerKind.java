package com.example.coastercontrolpanel;

/** The three kinds of guest marker. */
public enum MarkerKind {
    QUEUE("queue_marker"),
    STATION("station_marker"),
    EXIT("exit_marker");

    public final String id;

    MarkerKind(String id) {
        this.id = id;
    }

    public static MarkerKind byIndex(int i) {
        MarkerKind[] all = values();
        return all[Math.floorMod(i, all.length)];
    }
}
