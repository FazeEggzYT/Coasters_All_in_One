package com.example.coastercontrolpanel;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.ContraptionCollider;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.IControlContraption;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * The engine of a Drop Tower. It holds the sequence, runs it, and drives the carriage: a Create moving structure
 * (a {@link ControlledContraptionEntity}) that is created when the ride starts and put back as blocks when it ends.
 * Create's own pulley is the model for how the structure is assembled, moved and disassembled.
 */
public class DropTowerBlockEntity extends BlockEntity implements IControlContraption, RideEngine {
    public static final int MAX_TOWER = 256;

    public DropTowerSettings cfg = new DropTowerSettings();
    public final DropTowerMotion motion = new DropTowerMotion();

    @Nullable
    private AbstractContraptionEntity moved;
    private BlockPos anchor = BlockPos.ZERO;
    private int preTicks;
    private int orphanTicks;
    private int syncTicks;
    private boolean lastPower;
    private final RideLinks links = new RideLinks(this);
    private boolean justFinished;
    private int lastPhase;
    private int lastStep = -1;

    /** Client: sections counted by the server, for the screen. */
    public int towerHeight;

    public DropTowerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterControlPanel.DROP_TOWER_BE.get(), pos, state);
    }

    // ---- IControlContraption

    @Override
    public boolean isAttachedTo(AbstractContraptionEntity contraption) {
        return moved == contraption;
    }

    @Override
    public void attach(ControlledContraptionEntity contraption) {
        moved = contraption;
    }

    @Override
    public void onStall() {
        if (level != null && !level.isClientSide && motion.phase == DropTowerMotion.RUNNING) {
            motion.vel = 0;
            motion.phase = DropTowerMotion.PAUSED;
            tell("stalled");
            syncNow();
        }
    }

    @Override
    public boolean isValid() {
        return !isRemoved();
    }

    @Override
    public BlockPos getBlockPosition() {
        return worldPosition;
    }

    // ---- Redstone Link lifecycle

    @Override
    public void onLoad() {
        super.onLoad();
        links.register();
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        links.unregister();
    }

    @Override
    public void setRemoved() {
        links.unregister();
        super.setRemoved();
    }

    /** Runs every server tick, also while the ride stands still: reads the three inputs, drives the two outputs. */
    private void pollLinks() {
        links.register();
        if (links.changed(RideLinks.START)) {
            refreshRedstone();
        }
        if (links.rising(RideLinks.END) && !idle()) {
            control(ACTION_END);
        }
        if (links.rising(RideLinks.HALT) && !idle()) {
            control(ACTION_HALT);
        }
        links.tickOutputs(!idle(), justFinished);
        justFinished = false;
    }

    // ---- controls

    @Nullable
    public static DropTowerBlockEntity lookup(Player player, BlockPos pos) {
        if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 400.0) {
            return null;
        }
        return player.level().getBlockEntity(pos) instanceof DropTowerBlockEntity be ? be : null;
    }

    @Override
    public RideLinks links() {
        return links;
    }

    @Override
    public boolean idle() {
        return motion.phase == DropTowerMotion.IDLE;
    }

    /** Only while the ride is standing still is the sequence editable. */
    @Override
    public void applyConfig(CompoundTag tag) {
        if (!idle()) {
            return;
        }
        cfg = DropTowerSettings.fromTag(tag);
        syncNow();
    }

    @Override
    public void control(int action) {
        if (level == null || level.isClientSide) {
            return;
        }
        switch (action) {
            case ACTION_START -> startRide();
            case ACTION_PAUSE -> {
                if (motion.phase == DropTowerMotion.COUNTDOWN) {
                    motion.phase = DropTowerMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.togglePause();
                }
            }
            case ACTION_END -> {
                if (motion.phase == DropTowerMotion.COUNTDOWN) {
                    motion.phase = DropTowerMotion.IDLE;
                    tell("cancelled");
                } else {
                    motion.end();
                }
            }
            case ACTION_HALT -> {
                if (motion.phase == DropTowerMotion.RUNNING) {
                    motion.phase = DropTowerMotion.PAUSED;
                }
            }
            default -> {
            }
        }
        syncNow();
    }

    @Override
    public void refreshRedstone() {
        if (level == null || level.isClientSide) {
            return;
        }
        redstone(level.hasNeighborSignal(worldPosition) || DropTowerBlocks.controllerPowered(level, worldPosition) || links.on(RideLinks.START));
    }

    public void redstone(boolean power) {
        if (power == lastPower) {
            return;
        }
        lastPower = power;
        if (power && idle()) {
            control(ACTION_START);
        } else if (!power && cfg.redstoneMode == 1 && !idle()) {
            control(ACTION_END);
        }
    }

    private void startRide() {
        if (!idle()) {
            return;
        }
        if (findCarriage() == null) {
            tell("no_carriage");
            return;
        }
        preTicks = Math.round(cfg.preDelay * 20.0F);
        motion.phase = DropTowerMotion.COUNTDOWN;
        if (preTicks <= 0) {
            beginRide();
        } else {
            tell("starting");
        }
    }

    // ---- tower and carriage

    private int sections() {
        int n = 0;
        BlockPos p = worldPosition.above();
        while (n < MAX_TOWER && level != null && level.getBlockState(p).getBlock() instanceof DropTowerBlocks.SectionBlock) {
            n++;
            p = p.above();
        }
        return n;
    }

    /** The lowest Carriage Frame or seat beside the tower: the riding part is gathered from here. */
    @Nullable
    private BlockPos findCarriage() {
        if (level == null) {
            return null;
        }
        int top = worldPosition.getY() + sections();
        BlockPos best = null;
        for (BlockPos p : BlockPos.betweenClosed(worldPosition.offset(-4, 0, -4), new BlockPos(worldPosition.getX() + 4, top, worldPosition.getZ() + 4))) {
            if ((level.getBlockState(p).getBlock() instanceof DropTowerBlocks.FrameBlock
                    || com.simibubi.create.AllTags.AllBlockTags.SEATS.matches(level.getBlockState(p)))
                    && (best == null || p.getY() < best.getY()
                    || (p.getY() == best.getY() && p.distSqr(worldPosition) < best.distSqr(worldPosition)))) {
                best = p.immutable();
            }
        }
        return best;
    }

    private void beginRide() {
        BlockPos frame = findCarriage();
        if (frame == null || level == null) {
            motion.phase = DropTowerMotion.IDLE;
            tell("no_carriage");
            return;
        }
        DropTowerCarriage.Contraption contraption = new DropTowerCarriage.Contraption();
        SwingCarriage.Carry.begin(cfg.carryAll, frame, 6, 14, 0);
        try {
            if (!contraption.assemble(level, frame) || contraption.getBlocks().isEmpty()) {
                motion.phase = DropTowerMotion.IDLE;
                tell("empty");
                return;
            }
        } catch (AssemblyException e) {
            motion.phase = DropTowerMotion.IDLE;
            for (ServerPlayer p : nearby()) {
                p.displayClientMessage(e.component, true);
            }
            return;
        } finally {
            SwingCarriage.Carry.end();
        }
        int maxRise = Math.max(0, worldPosition.getY() + sections() - frame.getY());
        if (maxRise <= 0) {
            motion.phase = DropTowerMotion.IDLE;
            tell("no_height");
            return;
        }
        contraption.removeBlocksFromWorld(level, BlockPos.ZERO);
        ControlledContraptionEntity entity = ControlledContraptionEntity.create(level, this, contraption);
        entity.setPos(frame.getX(), frame.getY(), frame.getZ());
        level.addFreshEntity(entity);
        moved = entity;
        anchor = frame;
        motion.start(maxRise);
        orphanTicks = 0;
        syncNow();
    }

    /** Puts the carriage back as blocks at the nearest whole height. */
    void landCarriage() {
        if (moved != null && level != null && !level.isClientSide) {
            long whole = Math.round(motion.rise);
            moved.setPos(anchor.getX(), anchor.getY() + (double) whole, anchor.getZ());
            moved.setContraptionMotion(Vec3.ZERO);
            moved.disassemble();
            moved.discard();
        }
        moved = null;
        motion.rise = 0;
        motion.vel = 0;
    }

    // ---- client side: Create ignores server position packets for a controlled structure, so we move it ourselves

    private boolean stateSeen;

    public void receiveState(double rise, double vel, int phase, BlockPos newAnchor) {
        motion.rise = rise;
        motion.vel = vel;
        motion.phase = phase;
        anchor = newAnchor;
        stateSeen = true;
    }

    public void clientTick() {
        if (!stateSeen || moved == null || !moved.isAlive() || motion.phase == DropTowerMotion.IDLE) {
            return;
        }
        double dy = anchor.getY() + motion.rise - moved.getY();
        if (Math.abs(dy) > 1.0E-6) {
            moved.setContraptionMotion(new Vec3(0, dy, 0));
            moved.move(0, dy, 0);
        }
    }

    // ---- ticking (server)

    public void serverTick() {
        if (level == null || level.isClientSide) {
            return;
        }
        pollLinks();
        if (motion.phase == DropTowerMotion.IDLE) {
            return;
        }
        if (motion.phase == DropTowerMotion.COUNTDOWN) {
            if (--preTicks <= 0) {
                beginRide();
            }
            return;
        }
        if (moved == null || !moved.isAlive()) {
            if (++orphanTicks > 200) { // the carriage is gone (killed, or its chunk never came back)
                motion.phase = DropTowerMotion.IDLE;
                moved = null;
                tell("lost");
                syncNow();
            }
            return;
        }
        orphanTicks = 0;
        double before = motion.rise;
        motion.tick(cfg, 1.0 / 20.0);
        double targetY = anchor.getY() + motion.rise;
        double dy = targetY - moved.getY();
        moved.setContraptionMotion(new Vec3(0, dy, 0));
        moved.move(0, dy, 0);
        if (Math.abs(dy) > 1.0E-6 && ContraptionCollider.collideBlocks(moved)) {
            // something solid is in the way: back to where it was and hold
            motion.rise = before;
            moved.setPos(anchor.getX(), anchor.getY() + before, anchor.getZ());
            moved.setContraptionMotion(Vec3.ZERO);
            motion.vel = 0;
            motion.phase = DropTowerMotion.PAUSED;
            tell("blocked");
            syncNow();
            return;
        }
        if (motion.phase == DropTowerMotion.IDLE) { // landed
            landCarriage();
            justFinished = true;
            tell("finished");
            syncNow();
            return;
        }
        if (motion.phase == DropTowerMotion.PAUSED && motion.finished && lastPhase != motion.phase) {
            tell("waiting_end");
        }
        net.neoforged.neoforge.network.PacketDistributor.sendToPlayersTrackingChunk((net.minecraft.server.level.ServerLevel) level,
                new net.minecraft.world.level.ChunkPos(worldPosition),
                new DropTowerStatePacket(worldPosition, motion.rise, motion.vel, motion.phase, anchor.asLong()));
        if (motion.phase != lastPhase || motion.stepIndex != lastStep || ++syncTicks >= 10) {
            lastPhase = motion.phase;
            lastStep = motion.stepIndex;
            syncNow();
        }
    }

    private java.util.List<ServerPlayer> nearby() {
        if (level == null) {
            return java.util.List.of();
        }
        return ((net.minecraft.server.level.ServerLevel) level).getPlayers(
                p -> p.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) < 900.0);
    }

    private void tell(String key) {
        for (ServerPlayer p : nearby()) {
            p.displayClientMessage(Component.translatable("message.coastercontrolpanel.droptower." + key), true);
        }
    }

    private void syncNow() {
        syncTicks = 0;
        towerHeight = level != null && !level.isClientSide ? sections() : towerHeight;
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    /** The base block was broken or replaced mid-ride: put the carriage down where it is. */
    public void baseRemoved() {
        if (level != null && !level.isClientSide && moved != null) {
            landCarriage();
        }
    }

    // ---- saving

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Cfg", cfg.toTag());
        tag.putInt("Phase", motion.phase);
        tag.putInt("Step", motion.stepIndex);
        tag.putInt("Loop", motion.loop);
        tag.putDouble("StepTime", motion.stepTime);
        tag.putDouble("Rise", motion.rise);
        tag.putDouble("Vel", motion.vel);
        tag.putDouble("MaxRise", motion.maxRise);
        tag.putBoolean("Finished", motion.finished);
        tag.putLong("Anchor", anchor.asLong());
        tag.putInt("Tower", towerHeight);
        links.save(tag, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        cfg = DropTowerSettings.fromTag(tag.getCompound("Cfg"));
        motion.phase = tag.getInt("Phase");
        if (motion.phase == DropTowerMotion.COUNTDOWN) {
            motion.phase = DropTowerMotion.IDLE;
        }
        motion.stepIndex = tag.getInt("Step");
        motion.loop = tag.getInt("Loop");
        motion.stepTime = tag.getDouble("StepTime");
        motion.rise = tag.getDouble("Rise");
        motion.vel = tag.getDouble("Vel");
        motion.maxRise = tag.getDouble("MaxRise");
        motion.finished = tag.getBoolean("Finished");
        anchor = BlockPos.of(tag.getLong("Anchor"));
        towerHeight = tag.getInt("Tower");
        links.load(tag, registries);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
