package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/** Everything a Swivel Bearing can be told. All values are clamped here. */
public final class SwivelSettings {
    /** The structure tilts like a hinge: the turning line is sideways to the way the bearing faces. */
    public static final int TILT = 0;
    /** The structure turns flat, around an upright line. */
    public static final int TURN = 1;
    /** The structure rolls around the line the bearing faces along. */
    public static final int ROLL = 2;
    public static final int MODES = 3;

    /** Angle the structure rests at when there is no signal, in degrees. */
    public float rest = 0.0F;
    /** Angle the structure goes to when there is a signal, in degrees. */
    public float active = 45.0F;
    /** Degrees per second. */
    public float speed = 30.0F;
    public int mode = TILT;
    /** True: the signal strength (1 to 15) picks an angle between rest and active. False: any signal goes to active. */
    public boolean analog = false;
    /** True: every block touching the structure comes with it, whatever it is. False: only blocks that are stuck on. */
    public boolean carryAll = true;
    /** How many blocks away from the plate a touching block is still picked up. */
    public int reach = 12;

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void sanitize() {
        rest = clamp(rest, -180.0F, 180.0F);
        active = clamp(active, -180.0F, 180.0F);
        speed = clamp(speed, 1.0F, 180.0F);
        mode = Math.max(0, Math.min(MODES - 1, mode));
        reach = Math.max(2, Math.min(24, reach));
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putFloat("Rest", rest);
        t.putFloat("Active", active);
        t.putFloat("Speed", speed);
        t.putInt("Mode", mode);
        t.putBoolean("Analog", analog);
        t.putBoolean("CarryAll", carryAll);
        t.putInt("Reach", reach);
        return t;
    }

    public static SwivelSettings fromTag(CompoundTag t) {
        SwivelSettings s = new SwivelSettings();
        if (t.contains("Rest")) {
            s.rest = t.getFloat("Rest");
        }
        if (t.contains("Active")) {
            s.active = t.getFloat("Active");
        }
        if (t.contains("Speed")) {
            s.speed = t.getFloat("Speed");
        }
        s.mode = t.getInt("Mode");
        s.analog = t.getBoolean("Analog");
        s.carryAll = !t.contains("CarryAll") || t.getBoolean("CarryAll");
        s.reach = t.contains("Reach") ? t.getInt("Reach") : 12;
        s.sanitize();
        return s;
    }

    public SwivelSettings copy() {
        return fromTag(toTag());
    }
}
