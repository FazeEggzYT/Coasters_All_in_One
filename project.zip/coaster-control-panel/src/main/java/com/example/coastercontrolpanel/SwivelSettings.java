package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/** Everything a Swivel, Flip or Spin Bearing can be told. All values are clamped here. */
public final class SwivelSettings {
    /** The structure tilts like a hinge: the turning line is sideways to the way the bearing faces. */
    public static final int TILT = 0;
    /** The structure turns flat, around an upright line. */
    public static final int TURN = 1;
    /** The structure rolls around the line the bearing faces along. */
    public static final int ROLL = 2;
    public static final int MODES = 3;

    /** Angle the structure rests at when there is no signal, in degrees. */
    public float rest = 0.0F;
    /** Angle the structure goes to when there is a signal, in degrees. */
    public float active = 45.0F;
    /** Degrees per second. */
    public float speed = 30.0F;
    public int mode = TILT;
    /** The turning line picked by hand: 0 = from "Turns" (Swivel only), 1 = X, 2 = Y, 3 = Z. */
    public int axis = 0;
    /** True: the signal strength (1 to 15) picks an angle between rest and active. False: any signal goes to active. */
    public boolean analog = false;
    /** True: every block touching the structure comes with it, whatever it is. False: only blocks that are stuck on. */
    public boolean carryAll = true;
    /** How many blocks away from the plate a touching block is still picked up. */
    public int reach = 12;
    /** The name shown on this bearing's track in an Animation Controller. Empty = the default name. */
    public String name = "";

    // ---- Flip Bearing
    public float flipPos = 90.0F;
    public float flipNeg = 90.0F;
    /** Seconds held at each end. */
    public float pause = 1.0F;
    /** How many times the whole flip is done. 0 = for as long as the signal is on. */
    public int reps = 1;
    /** True: back to 0 between the two ends. */
    public boolean returnZero = true;
    /** True: each move starts and ends gently. */
    public boolean smooth = true;

    // ---- Spin Bearing
    /** 0 = clockwise, 1 = counter-clockwise. */
    public int spinDir = 0;
    /** 0 = turn for as long as the signal is on, otherwise turn this many degrees once per start. */
    public float spinAmount = 0.0F;
    /** True: go back to the start when the turning is over. */
    public boolean spinReturn = false;

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void sanitize() {
        rest = clamp(rest, -180.0F, 180.0F);
        active = clamp(active, -180.0F, 180.0F);
        speed = clamp(speed, 1.0F, 720.0F);
        mode = Math.max(0, Math.min(MODES - 1, mode));
        axis = Math.max(0, Math.min(3, axis));
        reach = Math.max(2, Math.min(24, reach));
        flipPos = clamp(flipPos, 0.0F, 360.0F);
        flipNeg = clamp(flipNeg, 0.0F, 360.0F);
        pause = clamp(pause, 0.0F, 60.0F);
        reps = Math.max(0, Math.min(99, reps));
        spinDir = spinDir == 1 ? 1 : 0;
        spinAmount = clamp(spinAmount, 0.0F, 3600.0F);
        if (name == null) {
            name = "";
        }
        if (name.length() > 24) {
            name = name.substring(0, 24);
        }
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putFloat("Rest", rest);
        t.putFloat("Active", active);
        t.putFloat("Speed", speed);
        t.putInt("Mode", mode);
        t.putInt("Axis", axis);
        t.putBoolean("Analog", analog);
        t.putBoolean("CarryAll", carryAll);
        t.putInt("Reach", reach);
        t.putString("Name", name);
        t.putFloat("FlipPos", flipPos);
        t.putFloat("FlipNeg", flipNeg);
        t.putFloat("Pause", pause);
        t.putInt("Reps", reps);
        t.putBoolean("ReturnZero", returnZero);
        t.putBoolean("Smooth", smooth);
        t.putInt("SpinDir", spinDir);
        t.putFloat("SpinAmount", spinAmount);
        t.putBoolean("SpinReturn", spinReturn);
        return t;
    }

    public static SwivelSettings fromTag(CompoundTag t) {
        SwivelSettings s = new SwivelSettings();
        if (t.contains("Rest")) {
            s.rest = t.getFloat("Rest");
        }
        if (t.contains("Active")) {
            s.active = t.getFloat("Active");
        }
        if (t.contains("Speed")) {
            s.speed = t.getFloat("Speed");
        }
        s.mode = t.getInt("Mode");
        s.axis = t.getInt("Axis");
        s.analog = t.getBoolean("Analog");
        s.carryAll = !t.contains("CarryAll") || t.getBoolean("CarryAll");
        s.reach = t.contains("Reach") ? t.getInt("Reach") : 12;
        s.name = t.getString("Name");
        if (t.contains("FlipPos")) {
            s.flipPos = t.getFloat("FlipPos");
        }
        if (t.contains("FlipNeg")) {
            s.flipNeg = t.getFloat("FlipNeg");
        }
        if (t.contains("Pause")) {
            s.pause = t.getFloat("Pause");
        }
        if (t.contains("Reps")) {
            s.reps = t.getInt("Reps");
        }
        s.returnZero = !t.contains("ReturnZero") || t.getBoolean("ReturnZero");
        s.smooth = !t.contains("Smooth") || t.getBoolean("Smooth");
        s.spinDir = t.getInt("SpinDir");
        s.spinAmount = t.getFloat("SpinAmount");
        s.spinReturn = t.getBoolean("SpinReturn");
        s.sanitize();
        return s;
    }

    public SwivelSettings copy() {
        return fromTag(toTag());
    }
}
