package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helper so the server never loads screen classes. */
public final class ClientHooks {
    private ClientHooks() {
    }

    /** True while the local player holds the Track Unrestrictor in the off hand (so the placement preview matches). */
    public static boolean localUnrestrict() {
        Minecraft mc = Minecraft.getInstance();
        return mc != null && mc.player != null && CoasterTools.enabledFor(mc.player);
    }

    /** Wrench on an Animation Controller opens the timeline. */
    public static void openAnimationController(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnimationControllerScreen(pos));
    }

    /** Wrench on an Animatronic opens its setup screen. */
    public static void openAnimatronic(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnimatronicScreen(pos));
    }

    /** Track Element Selector: opens the element picker. */
    public static void openElementSelector() {
        Minecraft.getInstance().setScreen(new TrackElementScreen());
    }

    /** Right-clicking the block pins its panel to the screen and opens mouse mode. */
    public static void openOperator(BlockPos pos) {
        ClientKeys.pinned = pos;
        Minecraft.getInstance().setScreen(new OperatorScreen(pos));
    }

    /** Right-clicking an Announcement Panel opens its tap-to-play screen. */
    public static void openAnnounce(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceScreen(pos));
    }

    /** Wrench on an Announcement Panel opens its setup screen. */
    public static void openAnnounceSetup(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceSetupScreen(pos));
    }

    /** Right-clicking a camera shows what it sees. */
    public static void openCameraView(BlockPos pos, net.minecraft.core.Direction facing) {
        Minecraft.getInstance().setScreen(new CameraViewScreen(pos, facing));
    }

    /** Wrench on a guest marker opens its setup screen. */
    public static void openMarker(BlockPos pos) {
        Minecraft.getInstance().setScreen(new MarkerScreen(pos));
    }

    /** Sneak + right-click in the air with the Support Tool opens its settings. */
    public static void openSupportSettings() {
        Minecraft.getInstance().setScreen(new SupportScreen());
    }

    /** Wrench on a sign opens its setup screen. */
    public static void openSign(BlockPos pos) {
        Minecraft.getInstance().setScreen(new SignScreen(pos));
    }

    public static void openOrderBell(BlockPos pos) {
        Minecraft.getInstance().setScreen(new KitchenScreens.BellScreen(pos));
    }

    public static void openFan(BlockPos pos) {
        Minecraft.getInstance().setScreen(new KitchenScreens.FanScreen(pos));
    }

    /** kind: 0 options, 1 kiosk, 2 register, 3 pickup display, 4 condiment stand, 5 menu board. */
    public static void openRestaurant(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case 1 -> mc.setScreen(new RestaurantScreens.KioskScreen(pos));
            case 2 -> mc.setScreen(new RestaurantScreens.RegisterScreen(pos));
            case 3 -> mc.setScreen(new RestaurantScreens.PickupScreen(pos));
            case 4 -> mc.setScreen(new RestaurantScreens.CondimentScreen(pos));
            case 5 -> mc.setScreen(new RestaurantScreens.MenuBoardScreen(pos));
            default -> mc.setScreen(new RestaurantScreens.OptionsScreen(pos));
        }
    }

    /** kind: 0..7 an arcade game (ArcadeGame ordinal), 100 token machine, 101 prize counter. */
    public static void openArcade(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (kind == 100) {
            mc.setScreen(new ArcadeScreens.TokenScreen(pos));
        } else if (kind == 101) {
            mc.setScreen(new ArcadeScreens.PrizeScreen(pos));
        } else if (kind >= 0 && kind < ArcadeGame.values().length) {
            mc.setScreen(ArcadeScreens.forGame(ArcadeGame.values()[kind], pos));
        }
    }

    /** kind: 0 shop shelf, 1 shop till, 2 price tag, 3 window display, 10 first aid, 11 defibrillator, 12 lost child, 13 phone. */
    public static void openPark(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case 0, 1 -> mc.setScreen(new GiftScreens.ShopScreen(pos));
            case 2 -> mc.setScreen(new GiftScreens.TagScreen(pos));
            case 3 -> mc.setScreen(new GiftScreens.WindowScreen(pos));
            case 10 -> mc.setScreen(new SafetyScreens.FirstAidScreen(pos));
            case 11 -> mc.setScreen(new SafetyScreens.DefibScreen(pos));
            case 12 -> mc.setScreen(new SafetyScreens.ChildScreen(pos));
            case 13 -> mc.setScreen(new SafetyScreens.PhoneScreen(pos));
            default -> {
            }
        }
    }

    /** kind: 0 info desk, 1 brochure stand, 2 rota board, 3 ATM, 4 photo frame wall, 5 stroller rack, 6 feedback box. */
    public static void openService(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case 0 -> mc.setScreen(new ServiceScreens.TextScreen(pos, "block.coastercontrolpanel.information_desk", 0xFF2E64B0, 6, 1,
                    "gui.coastercontrolpanel.desk_guide", "gui.coastercontrolpanel.desk_help"));
            case 1 -> mc.setScreen(new ServiceScreens.TextScreen(pos, "block.coastercontrolpanel.brochure_stand", 0xFFB0602E, 7, 2,
                    "gui.coastercontrolpanel.brochure_take", "gui.coastercontrolpanel.brochure_help"));
            case 2 -> mc.setScreen(new ServiceScreens.RotaScreen(pos));
            case 3 -> mc.setScreen(new ServiceScreens.AtmScreen(pos));
            case 4 -> mc.setScreen(new ServiceScreens.PhotoScreen(pos));
            case 5 -> mc.setScreen(new ServiceScreens.StrollerScreen(pos));
            case 6 -> mc.setScreen(new ServiceScreens.FeedbackScreen(pos));
            default -> {
            }
        }
    }

    /** kind: 0 reception desk, 1 room door, 2 resort sign, 3 workshop bench, 4 safety checklist. */
    public static void openResort(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case 0 -> mc.setScreen(new ResortScreens.ReceptionScreen(pos));
            case 1 -> mc.setScreen(new ResortScreens.RoomScreen(pos));
            case 2 -> mc.setScreen(new ServiceScreens.TextScreen(pos, "block.coastercontrolpanel.resort_sign", 0xFF2A7FA8, 3, -1,
                    "gui.coastercontrolpanel.desk_guide", "gui.coastercontrolpanel.sign_help"));
            case 3 -> mc.setScreen(new ResortScreens.BenchScreen(pos));
            case 4 -> mc.setScreen(new ResortScreens.ChecklistScreen(pos));
            default -> {
            }
        }
    }
}
