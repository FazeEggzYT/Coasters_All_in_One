package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helper so the server never loads screen classes. */
public final class ClientHooks {
    private ClientHooks() {
    }

    /** Right-clicking the block pins its panel to the screen and opens mouse mode. */
    public static void openOperator(BlockPos pos) {
        ClientKeys.pinned = pos;
        Minecraft.getInstance().setScreen(new OperatorScreen(pos));
    }

    /** Right-clicking an Announcement Panel opens its tap-to-play screen. */
    public static void openAnnounce(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceScreen(pos));
    }

    /** Wrench on an Announcement Panel opens its setup screen. */
    public static void openAnnounceSetup(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceSetupScreen(pos));
    }

    /** Right-clicking a camera shows what it sees. */
    public static void openCameraView(BlockPos pos, net.minecraft.core.Direction facing) {
        Minecraft.getInstance().setScreen(new CameraViewScreen(pos, facing));
    }

    /** Wrench on a guest marker opens its setup screen. */
    public static void openMarker(BlockPos pos) {
        Minecraft.getInstance().setScreen(new MarkerScreen(pos));
    }

    /** Sneak + right-click in the air with the Support Tool opens its settings. */
    public static void openSupportSettings() {
        Minecraft.getInstance().setScreen(new SupportScreen());
    }

    /** Wrench on a sign opens its setup screen. */
    public static void openSign(BlockPos pos) {
        Minecraft.getInstance().setScreen(new SignScreen(pos));
    }

    public static void openOrderBell(BlockPos pos) {
        Minecraft.getInstance().setScreen(new KitchenScreens.BellScreen(pos));
    }

    public static void openFan(BlockPos pos) {
        Minecraft.getInstance().setScreen(new KitchenScreens.FanScreen(pos));
    }

    /** kind: 0 options, 1 kiosk, 2 register, 3 pickup display, 4 condiment stand, 5 menu board. */
    public static void openRestaurant(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case 1 -> mc.setScreen(new RestaurantScreens.KioskScreen(pos));
            case 2 -> mc.setScreen(new RestaurantScreens.RegisterScreen(pos));
            case 3 -> mc.setScreen(new RestaurantScreens.PickupScreen(pos));
            case 4 -> mc.setScreen(new RestaurantScreens.CondimentScreen(pos));
            case 5 -> mc.setScreen(new RestaurantScreens.MenuBoardScreen(pos));
            default -> mc.setScreen(new RestaurantScreens.OptionsScreen(pos));
        }
    }

    /** kind: 0..7 an arcade game (ArcadeGame ordinal), 100 token machine, 101 prize counter. */
    public static void openArcade(int kind, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (kind == 100) {
            mc.setScreen(new ArcadeScreens.TokenScreen(pos));
        } else if (kind == 101) {
            mc.setScreen(new ArcadeScreens.PrizeScreen(pos));
        } else if (kind >= 0 && kind < ArcadeGame.values().length) {
            mc.setScreen(ArcadeScreens.forGame(ArcadeGame.values()[kind], pos));
        }
    }
}
