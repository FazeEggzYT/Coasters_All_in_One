package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helper so the server never loads screen classes. */
public final class ClientHooks {
    private ClientHooks() {
    }

    /** Right-clicking the block pins its panel to the screen and opens mouse mode. */
    public static void openOperator(BlockPos pos) {
        ClientKeys.pinned = pos;
        Minecraft.getInstance().setScreen(new OperatorScreen(pos));
    }

    /** Right-clicking an Announcement Panel opens its tap-to-play screen. */
    public static void openAnnounce(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceScreen(pos));
    }

    /** Wrench on an Announcement Panel opens its setup screen. */
    public static void openAnnounceSetup(BlockPos pos) {
        Minecraft.getInstance().setScreen(new AnnounceSetupScreen(pos));
    }

    /** Right-clicking a camera shows what it sees. */
    public static void openCameraView(BlockPos pos, net.minecraft.core.Direction facing) {
        Minecraft.getInstance().setScreen(new CameraViewScreen(pos, facing));
    }

    /** Wrench on a guest marker opens its setup screen. */
    public static void openMarker(BlockPos pos) {
        Minecraft.getInstance().setScreen(new MarkerScreen(pos));
    }

    /** Sneak + right-click in the air with the Support Tool opens its settings. */
    public static void openSupportSettings() {
        Minecraft.getInstance().setScreen(new SupportScreen());
    }

    /** Wrench on a sign opens its setup screen. */
    public static void openSign(BlockPos pos) {
        Minecraft.getInstance().setScreen(new SignScreen(pos));
    }
}
