package com.example.coastercontrolpanel;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helper so the server never loads screen classes. */
public final class ClientHooks {
    private ClientHooks() {
    }

    /** Right-clicking the block pins its panel to the screen and opens mouse mode. */
    public static void openOperator(BlockPos pos) {
        ClientKeys.pinned = pos;
        Minecraft.getInstance().setScreen(new OperatorScreen(pos));
    }
}
