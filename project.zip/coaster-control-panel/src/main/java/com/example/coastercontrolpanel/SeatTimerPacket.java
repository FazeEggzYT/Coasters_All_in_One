package com.example.coastercontrolpanel;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: the open and close delays chosen in the Seat Timer screen. */
public record SeatTimerPacket(BlockPos pos, int open, int close) implements CustomPacketPayload {
    public static final Type<SeatTimerPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "seat_timer"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SeatTimerPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.open);
                buf.writeVarInt(p.close);
            },
            buf -> new SeatTimerPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SeatTimerPacket packet, IPayloadContext context) {
        Player player = context.player();
        if (player.distanceToSqr(packet.pos.getX() + 0.5, packet.pos.getY() + 0.5, packet.pos.getZ() + 0.5) > 2304.0) {
            return;
        }
        boolean holding = player.getMainHandItem().is(CoasterControlPanel.SEAT_TIMER_ITEM.get())
                || player.getOffhandItem().is(CoasterControlPanel.SEAT_TIMER_ITEM.get());
        if (!holding) {
            return;
        }
        BlockEntity be = player.level().getBlockEntity(packet.pos);
        if (be instanceof SeatTimerAccess access) {
            access.seatTimerSet(packet.open, packet.close, access.seatTimerSpeed());
            if (be instanceof SmartBlockEntity smart) {
                smart.sendData();
            }
        }
    }
}
