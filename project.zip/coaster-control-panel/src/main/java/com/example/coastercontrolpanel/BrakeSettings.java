package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/**
 * Everything one Brake Run can be told. Each placed Brake Run has its own copy, stored with its start anchor.
 * Speeds are in km/h in the settings (1 block = 1 metre, so blocks per second x 3.6) and converted when braking.
 * Every value is clamped here, so nothing that arrives from a screen, a packet or a save can break a coaster.
 */
public final class BrakeSettings {
    public static final int MODE_STOP_RELEASE = 0;
    public static final int MODE_SLOWDOWN = 1;
    public static final int MODE_FULL_STOP = 2;

    public static final int STRENGTH_CUSTOM = 4;
    public static final int RELEASE_CUSTOM = 4;

    public static final int DIR_FORWARD = 0;
    public static final int DIR_REVERSE = 1;
    public static final int DIR_BOTH = 2;

    /** Braking deceleration in blocks per second squared: gentle, moderate, strong, very strong. */
    public static final float[] STRENGTH = {3.0F, 6.0F, 12.0F, 24.0F};
    /** Acceleration after a stop: very slow, slow, normal, fast. */
    public static final float[] RELEASE = {1.0F, 2.5F, 5.0F, 10.0F};
    /** Ramp-in time for smoothing: low, medium, high (seconds). */
    public static final float[] SMOOTH = {0.1F, 0.35F, 0.8F};

    public static final float[] TARGET_PRESETS = {0, 5, 10, 20, 30};
    public static final float[] STOP_PRESETS = {0.5F, 1, 2, 3, 5};
    /** Speed given to a train that is pushed away after a stop, km/h. */
    public static final float RELEASE_KMH_DEFAULT = 12.0F;

    public int mode = MODE_STOP_RELEASE;
    public int strength = 1;
    public float customDecel = 6.0F;
    public float targetKmh = 0.0F;
    public float stopSeconds = 1.0F;
    public int release = 2;
    public float customRelease = 5.0F;
    public boolean limitEntry = false;
    public float maxEntryKmh = 60.0F;
    public float minKmh = 0.0F;
    // advanced
    public int direction = DIR_FORWARD;
    public float releaseKmh = 12.0F;
    public int smoothing = 1;

    public static BrakeSettings defaults() {
        return new BrakeSettings();
    }

    public BrakeSettings copy() {
        return fromTag(toTag());
    }

    private static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void sanitize() {
        mode = clamp(mode, 0, 2);
        strength = clamp(strength, 0, 4);
        customDecel = clamp(customDecel, 1.0F, 48.0F);
        targetKmh = clamp(targetKmh, 0.0F, 200.0F);
        stopSeconds = clamp(stopSeconds, 0.1F, 120.0F);
        release = clamp(release, 0, 4);
        customRelease = clamp(customRelease, 0.5F, 30.0F);
        maxEntryKmh = clamp(maxEntryKmh, 5.0F, 300.0F);
        minKmh = clamp(minKmh, 0.0F, 100.0F);
        direction = clamp(direction, 0, 2);
        releaseKmh = clamp(releaseKmh, 2.0F, 100.0F);
        smoothing = clamp(smoothing, 0, 2);
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Mode", mode);
        t.putInt("Strength", strength);
        t.putFloat("CustomDecel", customDecel);
        t.putFloat("Target", targetKmh);
        t.putFloat("Stop", stopSeconds);
        t.putInt("Release", release);
        t.putFloat("CustomRelease", customRelease);
        t.putBoolean("LimitEntry", limitEntry);
        t.putFloat("MaxEntry", maxEntryKmh);
        t.putFloat("Min", minKmh);
        t.putInt("Direction", direction);
        t.putFloat("ReleaseSpeed", releaseKmh);
        t.putInt("Smoothing", smoothing);
        return t;
    }

    public static BrakeSettings fromTag(CompoundTag t) {
        BrakeSettings s = new BrakeSettings();
        if (t != null) {
            if (t.contains("Mode")) {
                s.mode = t.getInt("Mode");
            }
            if (t.contains("Strength")) {
                s.strength = t.getInt("Strength");
            }
            if (t.contains("CustomDecel")) {
                s.customDecel = t.getFloat("CustomDecel");
            }
            if (t.contains("Target")) {
                s.targetKmh = t.getFloat("Target");
            }
            if (t.contains("Stop")) {
                s.stopSeconds = t.getFloat("Stop");
            }
            if (t.contains("Release")) {
                s.release = t.getInt("Release");
            }
            if (t.contains("CustomRelease")) {
                s.customRelease = t.getFloat("CustomRelease");
            }
            s.limitEntry = t.getBoolean("LimitEntry");
            if (t.contains("MaxEntry")) {
                s.maxEntryKmh = t.getFloat("MaxEntry");
            }
            if (t.contains("Min")) {
                s.minKmh = t.getFloat("Min");
            }
            if (t.contains("Direction")) {
                s.direction = t.getInt("Direction");
            }
            if (t.contains("ReleaseSpeed")) {
                s.releaseKmh = t.getFloat("ReleaseSpeed");
            }
            if (t.contains("Smoothing")) {
                s.smoothing = t.getInt("Smoothing");
            }
        }
        s.sanitize();
        return s;
    }

    // ---- what the numbers mean for the physics

    /** Braking deceleration, blocks per second squared. */
    public double decel() {
        sanitize();
        return strength == STRENGTH_CUSTOM ? customDecel : STRENGTH[strength];
    }

    /** Acceleration used to get a train moving again, blocks per second squared. */
    public double releaseAccel() {
        sanitize();
        return release == RELEASE_CUSTOM ? customRelease : RELEASE[release];
    }

    public double rampSeconds() {
        sanitize();
        return SMOOTH[smoothing];
    }

    public static double toBlocksPerSecond(double kmh) {
        return kmh / 3.6;
    }

    public boolean stops() {
        return mode != MODE_SLOWDOWN;
    }
}
