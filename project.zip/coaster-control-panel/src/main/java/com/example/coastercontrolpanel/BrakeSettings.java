package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;

/**
 * Everything one Brake Run can be told. Each placed Brake Run has its own copy, stored with its start anchor.
 * Speeds are in km/h in the settings (1 block = 1 metre, so blocks per second x 3.6) and converted when braking.
 * Every value is clamped here, so nothing that arrives from a screen, a packet or a save can break a coaster.
 */
public final class BrakeSettings {
    public static final int MODE_STOP_RELEASE = 0;
    public static final int MODE_SLOWDOWN = 1;
    public static final int MODE_FULL_STOP = 2;
    /** Tyres you control: pushes the train along at the release speed while a signal is on. */
    public static final int MODE_DRIVE = 3;
    /** Drive Tyre only: leave the tyre to the Create shaft, as a chain lift is driven. */
    public static final int MODE_SHAFT = 4;
    /** Launch Run: accelerates every cart that rolls in up to the launch speed, then hands it back. */
    public static final int MODE_LAUNCH = 5;
    /** Launch Run: stops the train, holds it (timer or signal), then accelerates it to the launch speed. */
    public static final int MODE_HOLD_LAUNCH = 6;
    /** Block Run: lets trains through while the next block is clear, stops them while it is occupied. */
    public static final int MODE_BLOCK = 7;
    /** Redstone Trigger: lets trains through and gives a redstone signal while/when a train passes. */
    public static final int MODE_TRIGGER = 8;

    public static final int STRENGTH_CUSTOM = 4;
    public static final int RELEASE_CUSTOM = 4;

    public static final int DIR_FORWARD = 0;
    public static final int DIR_REVERSE = 1;
    public static final int DIR_BOTH = 2;

    /** Braking deceleration in blocks per second squared: gentle, moderate, strong, very strong. */
    public static final float[] STRENGTH = {3.0F, 6.0F, 12.0F, 24.0F};
    /** Acceleration after a stop: very slow, slow, normal, fast. */
    public static final float[] RELEASE = {1.0F, 2.5F, 5.0F, 10.0F};
    /** Ramp-in time for smoothing: low, medium, high (seconds). */
    /** Acceleration of a launch in blocks per second squared: gentle, moderate, strong, very strong. */
    public static final float[] LAUNCH_ACCEL = {5.0F, 10.0F, 20.0F, 40.0F};
    public static final float[] LAUNCH_SPEEDS = {20, 40, 60, 80, 100, 150};
    public static final float[] SMOOTH = {0.1F, 0.35F, 0.8F};

    public static final float[] TARGET_PRESETS = {0, 5, 10, 20, 30};
    public static final float[] STOP_PRESETS = {0.5F, 1, 2, 3, 5};
    /** Speed given to a train that is pushed away after a stop, km/h. */
    public static final float RELEASE_KMH_DEFAULT = 12.0F;

    public int mode = MODE_STOP_RELEASE;
    public int strength = 1;
    public float customDecel = 6.0F;
    public float targetKmh = 0.0F;
    public float stopSeconds = 1.0F;
    public int release = 2;
    public float customRelease = 5.0F;
    public boolean limitEntry = false;
    public float maxEntryKmh = 60.0F;
    public float minKmh = 0.0F;
    // advanced
    public int direction = DIR_FORWARD;
    public float releaseKmh = 12.0F;
    public int smoothing = 1;
    /** Stop modes: hold the train until a signal arrives instead of for a set time. */
    public boolean holdSignal = false;
    /** Placed with the Train Stopper item: only changes how it is drawn and named. */
    public boolean stopper = false;
    /** Placed with the Launch Run item: drawn as a launch strip and named Launch Run. */
    public boolean launch = false;
    /** Controlled Drive only: which way the tyres are turning right now (-1, 0, 1). Saved so clients can draw the wheels turning. */
    public volatile int driving = 0;
    /** Placed with the Block Run item. */
    public boolean block = false;
    /** Block Run: how far ahead (blocks of track) to look for the next Block Run. */
    public float blockRange = 128.0F;
    /** Block Run: carts closer than this to the end of the run are the train that is leaving, not a blocker. */
    public float blockSkip = 16.0F;
    /** Block Run: 0 = whole track up to the next Block Run, 1 = only the next Block Run's own strip. */
    public int blockDetect = 0;
    /** Block Run redstone: 0 = ignored, 1 = power forces a stop, 2 = power forces the way clear. */
    public int blockRedstone = 0;
    /** Block Run: with no Block Run ahead, 0 = trains pass, 1 = trains are held. */
    public int blockNoNext = 0;
    /** Placed with the Redstone Trigger item. */
    public boolean trigger = false;
    /** Trigger: 0 = signal while a train is on it, 1 = short pulse when a train arrives, 2 = toggles with every train. */
    public int trigMode = 0;
    /** Trigger: signal strength 1-15. */
    public int trigStrength = 15;
    /** Trigger: seconds the signal stays after the train has left (mode 0) or the pulse length (mode 1). */
    public float trigSeconds = 1.0F;
    // runtime only, never saved
    public volatile long trigLast = Long.MIN_VALUE / 2;
    public volatile long trigUntil = Long.MIN_VALUE / 2;
    public volatile boolean trigLatched;
    public volatile int power;

    public static BrakeSettings defaults() {
        return new BrakeSettings();
    }

    /** What a freshly placed Launch Run starts with: accelerates carts to 60 km/h. */
    public static BrakeSettings launchDefaults() {
        BrakeSettings b = new BrakeSettings();
        b.launch = true;
        b.mode = MODE_LAUNCH;
        b.targetKmh = 60.0F;
        b.release = 2; // 20 m/s²
        b.strength = 2;
        b.stopSeconds = 3.0F;
        return b;
    }

    /** What a freshly placed Redstone Trigger starts with. */
    public static BrakeSettings triggerDefaults() {
        BrakeSettings b = new BrakeSettings();
        b.trigger = true;
        b.mode = MODE_TRIGGER;
        return b;
    }

    /** What a freshly placed Block Run starts with: firm stop, 2 s after the block clears, then pushed on. */
    public static BrakeSettings blockDefaults() {
        BrakeSettings b = new BrakeSettings();
        b.block = true;
        b.mode = MODE_BLOCK;
        b.strength = 2;
        b.stopSeconds = 2.0F;
        b.release = 2;
        b.releaseKmh = 15.0F;
        return b;
    }

    /** What a freshly placed Train Stopper starts with: stops the train firmly and holds it until a signal. */
    public static BrakeSettings stopperDefaults() {
        BrakeSettings b = new BrakeSettings();
        b.stopper = true;
        b.mode = MODE_STOP_RELEASE;
        b.strength = 2;
        b.holdSignal = true;
        b.release = 3;        // pushes off briskly
        b.releaseKmh = 20.0F;
        return b;
    }

    /** What a freshly placed Drive Tyre starts with: tyres you control. */
    public static BrakeSettings tyreDefaults() {
        BrakeSettings b = new BrakeSettings();
        b.mode = MODE_DRIVE;
        return b;
    }

    public BrakeSettings copy() {
        return fromTag(toTag());
    }

    private static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void sanitize() {
        mode = clamp(mode, 0, 8);
        trigMode = clamp(trigMode, 0, 2);
        trigStrength = clamp(trigStrength, 1, 15);
        trigSeconds = clamp(trigSeconds, 0.1F, 60.0F);
        blockRange = clamp(blockRange, 8.0F, 300.0F);
        blockSkip = clamp(blockSkip, 2.0F, 60.0F);
        blockDetect = clamp(blockDetect, 0, 1);
        blockRedstone = clamp(blockRedstone, 0, 2);
        blockNoNext = clamp(blockNoNext, 0, 1);
        strength = clamp(strength, 0, 4);
        customDecel = clamp(customDecel, 1.0F, 48.0F);
        targetKmh = clamp(targetKmh, 0.0F, 300.0F);
        stopSeconds = clamp(stopSeconds, 0.1F, 120.0F);
        release = clamp(release, 0, 4);
        customRelease = clamp(customRelease, 0.5F, 80.0F);
        maxEntryKmh = clamp(maxEntryKmh, 5.0F, 300.0F);
        minKmh = clamp(minKmh, 0.0F, 100.0F);
        direction = clamp(direction, 0, 2);
        releaseKmh = clamp(releaseKmh, 2.0F, 100.0F);
        smoothing = clamp(smoothing, 0, 2);
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Mode", mode);
        t.putInt("Strength", strength);
        t.putFloat("CustomDecel", customDecel);
        t.putFloat("Target", targetKmh);
        t.putFloat("Stop", stopSeconds);
        t.putInt("Release", release);
        t.putFloat("CustomRelease", customRelease);
        t.putBoolean("LimitEntry", limitEntry);
        t.putFloat("MaxEntry", maxEntryKmh);
        t.putFloat("Min", minKmh);
        t.putInt("Direction", direction);
        t.putFloat("ReleaseSpeed", releaseKmh);
        t.putInt("Smoothing", smoothing);
        t.putBoolean("HoldSignal", holdSignal);
        t.putBoolean("Stopper", stopper);
        t.putBoolean("Launch", launch);
        t.putInt("Driving", driving);
        t.putBoolean("Block", block);
        t.putBoolean("Trigger", trigger);
        t.putInt("TrigMode", trigMode);
        t.putInt("TrigStrength", trigStrength);
        t.putFloat("TrigSeconds", trigSeconds);
        t.putFloat("BlockRange", blockRange);
        t.putFloat("BlockSkip", blockSkip);
        t.putInt("BlockDetect", blockDetect);
        t.putInt("BlockRedstone", blockRedstone);
        t.putInt("BlockNoNext", blockNoNext);
        return t;
    }

    public static BrakeSettings fromTag(CompoundTag t) {
        BrakeSettings s = new BrakeSettings();
        if (t != null) {
            if (t.contains("Mode")) {
                s.mode = t.getInt("Mode");
            }
            if (t.contains("Strength")) {
                s.strength = t.getInt("Strength");
            }
            if (t.contains("CustomDecel")) {
                s.customDecel = t.getFloat("CustomDecel");
            }
            if (t.contains("Target")) {
                s.targetKmh = t.getFloat("Target");
            }
            if (t.contains("Stop")) {
                s.stopSeconds = t.getFloat("Stop");
            }
            if (t.contains("Release")) {
                s.release = t.getInt("Release");
            }
            if (t.contains("CustomRelease")) {
                s.customRelease = t.getFloat("CustomRelease");
            }
            s.limitEntry = t.getBoolean("LimitEntry");
            if (t.contains("MaxEntry")) {
                s.maxEntryKmh = t.getFloat("MaxEntry");
            }
            if (t.contains("Min")) {
                s.minKmh = t.getFloat("Min");
            }
            if (t.contains("Direction")) {
                s.direction = t.getInt("Direction");
            }
            if (t.contains("ReleaseSpeed")) {
                s.releaseKmh = t.getFloat("ReleaseSpeed");
            }
            if (t.contains("Smoothing")) {
                s.smoothing = t.getInt("Smoothing");
            }
        }
        s.driving = t == null ? 0 : Math.max(-1, Math.min(1, t.getInt("Driving")));
        s.stopper = t != null && t.getBoolean("Stopper");
        s.launch = t != null && t.getBoolean("Launch");
        s.holdSignal = t != null && t.getBoolean("HoldSignal");
        s.block = t != null && t.getBoolean("Block");
        s.trigger = t != null && t.getBoolean("Trigger");
        if (t != null) {
            s.trigMode = t.getInt("TrigMode");
            s.trigStrength = t.contains("TrigStrength") ? t.getInt("TrigStrength") : 15;
            s.trigSeconds = t.contains("TrigSeconds") ? t.getFloat("TrigSeconds") : 1.0F;
        }
        if (t != null) {
            if (t.contains("BlockRange")) {
                s.blockRange = t.getFloat("BlockRange");
            }
            if (t.contains("BlockSkip")) {
                s.blockSkip = t.getFloat("BlockSkip");
            }
            s.blockDetect = t.getInt("BlockDetect");
            s.blockRedstone = t.getInt("BlockRedstone");
            s.blockNoNext = t.getInt("BlockNoNext");
        }
        s.sanitize();
        return s;
    }

    // ---- what the numbers mean for the physics

    /** Braking deceleration, blocks per second squared. */
    public double decel() {
        sanitize();
        return strength == STRENGTH_CUSTOM ? customDecel : STRENGTH[strength];
    }

    /** Acceleration used to get a train moving again, blocks per second squared. */
    public double releaseAccel() {
        sanitize();
        if (mode == MODE_LAUNCH || mode == MODE_HOLD_LAUNCH) {
            return release == RELEASE_CUSTOM ? customRelease : LAUNCH_ACCEL[Math.min(release, LAUNCH_ACCEL.length - 1)];
        }
        return release == RELEASE_CUSTOM ? customRelease : RELEASE[release];
    }

    /** The speed a held train is pushed to when it is let go, km/h: the launch speed for Hold & Launch. */
    public double releaseTargetKmh() {
        sanitize();
        return mode == MODE_HOLD_LAUNCH ? targetKmh : releaseKmh;
    }

    public double rampSeconds() {
        sanitize();
        return SMOOTH[smoothing];
    }

    public static double toBlocksPerSecond(double kmh) {
        return kmh / 3.6;
    }

    public boolean stops() {
        return mode == MODE_STOP_RELEASE || mode == MODE_FULL_STOP || mode == MODE_HOLD_LAUNCH || mode == MODE_BLOCK;
    }
}
