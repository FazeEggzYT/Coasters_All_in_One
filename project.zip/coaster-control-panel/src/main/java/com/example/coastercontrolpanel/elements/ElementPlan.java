package com.example.coastercontrolpanel.elements;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns a track element into anchors on the block grid. Pure maths (no Minecraft), so it can be tested on its own.
 *
 * Steps: sample the element's centre line, build a smooth frame along it (so "up" never flips), apply the element's
 * roll, then choose anchors: one at each end and one wherever the track has turned or rolled enough or gone far enough.
 */
public final class ElementPlan {
    /** Facing axes, same order as Minecraft's Direction: 0 down, 1 up, 2 north, 3 south, 4 west, 5 east. */
    public static final int[][] AXES = {{0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};

    /** heading 0 north, 1 east, 2 south, 3 west. */
    public static final int[][] HEADINGS = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

    public record Node(int x, int y, int z, int facing, double[] normal, double[] tangent) {
    }

    public static final class Plan {
        public final List<Node> nodes = new ArrayList<>();
        public final List<double[]> line = new ArrayList<>();
        public final List<String> problems = new ArrayList<>();
        public int exitHeading;
        public double maxSnapError;
    }

    private static final int SAMPLES = 320;
    private static final double MIN_GAP = 3.0;
    private static final double MAX_GAP = 9.0;
    private static final double TURN_LIMIT = Math.toRadians(32.0);
    private static final double NORMAL_LIMIT = Math.toRadians(45.0);

    private ElementPlan() {
    }

    // ------------------------------------------------------------------ small vector helpers

    private static double[] sub(double[] a, double[] b) {
        return new double[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]};
    }

    private static double dot(double[] a, double[] b) {
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static double len(double[] a) {
        return Math.sqrt(dot(a, a));
    }

    private static double[] norm(double[] a) {
        double l = len(a);
        return l < 1.0E-12 ? new double[]{0, 0, 0} : new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    private static double[] scale(double[] a, double k) {
        return new double[]{a[0] * k, a[1] * k, a[2] * k};
    }

    private static double[] add(double[] a, double[] b) {
        return new double[]{a[0] + b[0], a[1] + b[1], a[2] + b[2]};
    }

    private static double[] reflect(double[] v, double[] n) {
        return sub(v, scale(n, 2.0 * dot(v, n)));
    }

    /** Rotates v around the unit axis by angle (Rodrigues). */
    private static double[] rotate(double[] v, double[] axis, double angle) {
        double c = Math.cos(angle);
        double s = Math.sin(angle);
        return add(add(scale(v, c), scale(cross(axis, v), s)), scale(axis, dot(axis, v) * (1.0 - c)));
    }

    private static double angle(double[] a, double[] b) {
        return Math.acos(Math.max(-1.0, Math.min(1.0, dot(norm(a), norm(b)))));
    }

    // ------------------------------------------------------------------ the plan

    /** Local frame result for one sample. */
    private record Sample(double[] pos, double[] tan, double[] normal) {
    }

    /** Samples in local space (x right, y up, z forward) with the element's roll applied. */
    static List<Sample> sample(TrackElement e, Params p) {
        double[][] pos = new double[SAMPLES + 1][];
        double[] roll = new double[SAMPLES + 1];
        for (int i = 0; i <= SAMPLES; i++) {
            Pose q = e.at(i / (double) SAMPLES, p);
            pos[i] = new double[]{q.x(), q.y(), q.z()};
            roll[i] = q.roll();
        }
        double[][] tan = new double[SAMPLES + 1][];
        for (int i = 0; i <= SAMPLES; i++) {
            double[] a = pos[Math.max(0, i - 1)];
            double[] b = pos[Math.min(SAMPLES, i + 1)];
            tan[i] = norm(sub(b, a));
        }
        // rotation-minimising frame (double reflection), starting upright
        double[][] up = new double[SAMPLES + 1][];
        up[0] = new double[]{0, 1, 0};
        for (int i = 0; i < SAMPLES; i++) {
            double[] v1 = sub(pos[i + 1], pos[i]);
            double c1 = dot(v1, v1);
            if (c1 < 1.0E-12) {
                up[i + 1] = up[i];
                continue;
            }
            double[] rL = sub(up[i], scale(v1, 2.0 / c1 * dot(v1, up[i])));
            double[] tL = sub(tan[i], scale(v1, 2.0 / c1 * dot(v1, tan[i])));
            double[] v2 = sub(tan[i + 1], tL);
            double c2 = dot(v2, v2);
            up[i + 1] = c2 < 1.0E-12 ? rL : sub(rL, scale(v2, 2.0 / c2 * dot(v2, rL)));
            up[i + 1] = norm(up[i + 1]);
        }
        // roll about the direction of travel (positive: up tilts to the left)
        double[][] normal = new double[SAMPLES + 1][];
        for (int i = 0; i <= SAMPLES; i++) {
            normal[i] = norm(rotate(up[i], tan[i], roll[i]));
        }
        // make sure the track ends upright: spread any leftover twist over the element
        double[] end = normal[SAMPLES];
        double[] tEnd = tan[SAMPLES];
        double[] want = norm(sub(new double[]{0, 1, 0}, scale(tEnd, tEnd[1])));
        double twist = 0.0;
        if (len(want) > 0.5) {
            double s = dot(cross(end, want), tEnd);
            twist = Math.atan2(s, dot(end, want));
        }
        List<Sample> out = new ArrayList<>(SAMPLES + 1);
        for (int i = 0; i <= SAMPLES; i++) {
            double w = i / (double) SAMPLES;
            double k = w * w * (3.0 - 2.0 * w);
            out.add(new Sample(pos[i], tan[i], norm(rotate(normal[i], tan[i], twist * k))));
        }
        return out;
    }

    private static int nearestAxis(double[] n) {
        int best = 1;
        double bd = -2.0;
        for (int i = 0; i < 6; i++) {
            double d = n[0] * AXES[i][0] + n[1] * AXES[i][1] + n[2] * AXES[i][2];
            if (d > bd + 1.0E-9) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    /**
     * Plans element e. The entrance anchor sits at block (ox, oy, oz); the element heads in the given heading (0 north,
     * 1 east, 2 south, 3 west). The first node is the entrance itself.
     */
    public static Plan plan(TrackElement e, Params params, int heading, int ox, int oy, int oz) {
        Params p = params.clamped();
        Plan plan = new Plan();
        int[] f = HEADINGS[Math.floorMod(heading, 4)];
        List<Sample> s = sample(e, p);

        // world positions along the line
        double[][] wp = new double[s.size()][];
        double[][] wt = new double[s.size()][];
        double[][] wn = new double[s.size()][];
        for (int i = 0; i < s.size(); i++) {
            wp[i] = toWorld(s.get(i).pos(), f, ox + 0.5, oy + 0.5, oz + 0.5, true);
            wt[i] = toWorld(s.get(i).tan(), f, 0, 0, 0, false);
            wn[i] = toWorld(s.get(i).normal(), f, 0, 0, 0, false);
            plan.line.add(wp[i]);
        }

        // choose anchors
        List<Integer> pick = new ArrayList<>();
        pick.add(0);
        double travelled = 0.0;
        int last = 0;
        for (int i = 1; i < s.size(); i++) {
            travelled += len(sub(wp[i], wp[i - 1]));
            boolean end = i == s.size() - 1;
            if (end) {
                break;
            }
            double turned = angle(wt[last], wt[i]);
            double twisted = angle(wn[last], wn[i]);
            boolean need = travelled >= MAX_GAP || (travelled >= MIN_GAP && (turned >= TURN_LIMIT || twisted >= NORMAL_LIMIT));
            if (need) {
                pick.add(i);
                last = i;
                travelled = 0.0;
            }
        }
        pick.add(s.size() - 1);

        // snap to blocks, keep the entrance exactly where it is
        List<Node> raw = new ArrayList<>();
        for (int k = 0; k < pick.size(); k++) {
            int i = pick.get(k);
            int x = k == 0 ? ox : (int) Math.floor(wp[i][0]);
            int y = k == 0 ? oy : (int) Math.floor(wp[i][1]);
            int z = k == 0 ? oz : (int) Math.floor(wp[i][2]);
            raw.add(new Node(x, y, z, nearestAxis(wn[i]), wn[i], wt[i]));
            double err = len(sub(new double[]{x + 0.5, y + 0.5, z + 0.5}, wp[i]));
            if (k > 0) {
                plan.maxSnapError = Math.max(plan.maxSnapError, err);
            }
        }

        // drop interior nodes that landed on the same block or too close to the previous one
        for (int k = 0; k < raw.size(); k++) {
            Node n = raw.get(k);
            if (plan.nodes.isEmpty()) {
                plan.nodes.add(n);
                continue;
            }
            Node prev = plan.nodes.get(plan.nodes.size() - 1);
            double d = Math.sqrt(sq(n.x() - prev.x()) + sq(n.y() - prev.y()) + sq(n.z() - prev.z()));
            boolean lastNode = k == raw.size() - 1;
            if (d < 2.0) {
                if (lastNode) {
                    if (plan.nodes.size() > 1) {
                        plan.nodes.remove(plan.nodes.size() - 1);
                        prev = plan.nodes.get(plan.nodes.size() - 1);
                        d = Math.sqrt(sq(n.x() - prev.x()) + sq(n.y() - prev.y()) + sq(n.z() - prev.z()));
                    }
                    if (d < 2.0) {
                        plan.problems.add("too_small");
                    }
                    plan.nodes.add(n);
                }
                continue;
            }
            plan.nodes.add(n);
        }
        if (plan.nodes.size() < 2) {
            plan.problems.add("too_small");
        }
        // no two nodes on the same block anywhere in the list
        for (int a = 0; a < plan.nodes.size(); a++) {
            for (int b = a + 1; b < plan.nodes.size(); b++) {
                Node na = plan.nodes.get(a);
                Node nb = plan.nodes.get(b);
                if (na.x() == nb.x() && na.y() == nb.y() && na.z() == nb.z()) {
                    plan.problems.add("overlap");
                }
            }
        }
        double[] t = wt[wt.length - 1];
        int best = 0;
        double bd = -2.0;
        for (int h = 0; h < 4; h++) {
            double d = t[0] * HEADINGS[h][0] + t[2] * HEADINGS[h][1];
            if (d > bd) {
                bd = d;
                best = h;
            }
        }
        plan.exitHeading = best;
        return plan;
    }

    private static double sq(double v) {
        return v * v;
    }

    private static double[] toWorld(double[] l, int[] f, double ox, double oy, double oz, boolean position) {
        double wx = -f[1] * l[0] + f[0] * l[2];
        double wz = f[0] * l[0] + f[1] * l[2];
        return new double[]{wx + ox, l[1] + oy, wz + oz};
    }
}
