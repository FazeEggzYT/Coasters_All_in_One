package com.example.coastercontrolpanel;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Draws a guest with one of the generated skins. */
public class GuestRenderer extends HumanoidMobRenderer<GuestEntity, HumanoidModel<GuestEntity>> {
    private static final ResourceLocation[] SKINS = new ResourceLocation[GuestEntity.SKINS];

    static {
        for (int i = 0; i < SKINS.length; i++) {
            SKINS[i] = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID,
                    "textures/entity/guest/guest_" + i + ".png");
        }
    }

    public GuestRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(GuestEntity entity) {
        return SKINS[entity.getSkin()];
    }
}
