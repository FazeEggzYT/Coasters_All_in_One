package com.example.coastercontrolpanel;

import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.ConstantFloat;

/**
 * A sound that is not in any sounds.json: it points straight at an uploaded .ogg file
 * (assets/coastercontrolpanel/sounds/clip/HASH.ogg in the clip resource pack folder).
 */
public class ClipSoundInstance extends SimpleSoundInstance {
    private final ResourceLocation clip;

    public ClipSoundInstance(String hash, double x, double y, double z, float volume, float pitch) {
        super(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip/" + hash),
                SoundSource.RECORDS, volume, pitch, RandomSource.create(), false, 0,
                SoundInstance.Attenuation.LINEAR, x, y, z, false);
        this.clip = ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "clip/" + hash);
    }

    @Override
    public WeighedSoundEvents resolve(SoundManager manager) {
        WeighedSoundEvents events = new WeighedSoundEvents(this.clip, null);
        this.sound = new Sound(this.clip, ConstantFloat.of(1.0F), ConstantFloat.of(1.0F), 1, Sound.Type.FILE,
                true, false, 16);
        events.addSound(this.sound);
        return events;
    }
}
