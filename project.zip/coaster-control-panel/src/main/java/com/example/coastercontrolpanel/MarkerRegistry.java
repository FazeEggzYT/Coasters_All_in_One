package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Server side list of every guest marker, so guests and spawners can find them without scanning the world. */
public final class MarkerRegistry {
    private static final Map<ResourceKey<Level>, Set<BlockPos>> MARKERS = new HashMap<>();

    private MarkerRegistry() {
    }

    public static void add(Level level, BlockPos pos) {
        MARKERS.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(pos.immutable());
    }

    public static void remove(Level level, BlockPos pos) {
        Set<BlockPos> set = MARKERS.get(level.dimension());
        if (set != null) {
            set.remove(pos);
        }
    }

    public static void clear() {
        MARKERS.clear();
    }

    /** Markers of one kind and channel within a distance of a position. Queue markers come sorted by number. */
    public static List<MarkerBlockEntity> find(Level level, BlockPos origin, int channel, MarkerKind kind, double radius) {
        List<MarkerBlockEntity> out = new ArrayList<>();
        Set<BlockPos> set = MARKERS.get(level.dimension());
        if (set == null) {
            return out;
        }
        double r2 = radius * radius;
        for (BlockPos p : new ArrayList<>(set)) {
            if (p.distSqr(origin) > r2) {
                continue;
            }
            if (level.getBlockEntity(p) instanceof MarkerBlockEntity m && m.kind() == kind && m.getChannel() == channel) {
                out.add(m);
            }
        }
        if (kind == MarkerKind.QUEUE) {
            out.sort((a, b) -> Integer.compare(a.getNumber(), b.getNumber()));
        } else {
            out.sort((a, b) -> Double.compare(a.getBlockPos().distSqr(origin), b.getBlockPos().distSqr(origin)));
        }
        return out;
    }
}
