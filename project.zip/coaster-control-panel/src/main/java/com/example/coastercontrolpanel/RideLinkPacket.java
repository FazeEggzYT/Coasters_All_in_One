package com.example.coastercontrolpanel;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client to server: set one Redstone Link slot of a ride from the item in the player's hand, or clear it. */
public record RideLinkPacket(BlockPos pos, int slot, boolean clear) implements CustomPacketPayload {
    public static final Type<RideLinkPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CoasterControlPanel.MOD_ID, "ride_link"));

    public static final StreamCodec<RegistryFriendlyByteBuf, RideLinkPacket> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBlockPos(p.pos);
                buf.writeVarInt(p.slot);
                buf.writeBoolean(p.clear);
            },
            buf -> new RideLinkPacket(buf.readBlockPos(), buf.readVarInt(), buf.readBoolean()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(RideLinkPacket p, IPayloadContext context) {
        RideEngine be = RideLookup.find(context.player(), p.pos);
        if (be != null && be.links() != null && p.slot >= 0 && p.slot < RideLinks.COUNT) {
            ItemStack held = context.player().getMainHandItem();
            be.links().set(p.slot, p.clear ? ItemStack.EMPTY : held);
        }
    }
}
