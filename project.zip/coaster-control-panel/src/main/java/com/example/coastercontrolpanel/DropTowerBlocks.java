package com.example.coastercontrolpanel;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** The blocks of the Drop Tower: Base, Tower Section, Carriage Frame and Controller. */
public final class DropTowerBlocks {
    private DropTowerBlocks() {
    }

    /** The nearest Drop Tower Base within reach of a block (used by the Controller). */
    @Nullable
    public static BlockPos findBase(Level level, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(from.offset(-10, -6, -10), from.offset(10, 6, 10))) {
            if (level.getBlockState(p).getBlock() instanceof BaseBlock) {
                double d = p.distSqr(from);
                if (d < bestD) {
                    bestD = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    /** True when any Controller next to this base is receiving a redstone signal. */
    public static boolean controllerPowered(Level level, BlockPos base) {
        for (BlockPos p : BlockPos.betweenClosed(base.offset(-10, -6, -10), base.offset(10, 6, 10))) {
            if (level.getBlockState(p).getBlock() instanceof ControllerBlock && level.hasNeighborSignal(p)
                    && base.equals(findBase(level, p))) {
                return true;
            }
        }
        return false;
    }

    /** The foot of the tower. Right-click opens the ride settings. */
    public static class BaseBlock extends BaseEntityBlock {
        public static final MapCodec<BaseBlock> CODEC = simpleCodec(BaseBlock::new);
        private static final VoxelShape SHAPE = Shapes.or(Block.box(0, 0, 0, 16, 4, 16), Block.box(4, 4, 4, 12, 16, 12));

        public BaseBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected MapCodec<? extends BaseEntityBlock> codec() {
            return CODEC;
        }

        @Override
        protected RenderShape getRenderShape(BlockState state) {
            return RenderShape.MODEL;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Nullable
        @Override
        public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
            return new DropTowerBlockEntity(pos, state);
        }

        @Nullable
        @Override
        public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
            return level.isClientSide ? null
                    : createTickerHelper(type, CoasterControlPanel.DROP_TOWER_BE.get(), (l, p, s, be) -> be.serverTick());
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) {
                ClientHooks.openDropTower(pos);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
            if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof DropTowerBlockEntity be) {
                be.baseRemoved();
            }
            super.onRemove(state, level, pos, newState, movedByPiston);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof DropTowerBlockEntity be) {
                be.refreshRedstone();
            }
        }
    }

    /** One block of tower. Stack them above the base; the number of sections is the height of the ride. */
    public static class SectionBlock extends Block {
        private static final VoxelShape SHAPE = Block.box(4, 0, 4, 12, 16, 12);

        public SectionBlock(Properties properties) {
            super(properties);
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }
    }

    /** The riding frame. Frames stick together and to touching seats; Super Glue carries anything else. */
    public static class FrameBlock extends Block {
        private static final VoxelShape SHAPE = frameShape();

        public FrameBlock(Properties properties) {
            super(properties);
        }

        private static VoxelShape frameShape() {
            VoxelShape s = Shapes.empty();
            for (int a = 0; a <= 14; a += 14) {
                for (int b = 0; b <= 14; b += 14) {
                    s = Shapes.or(s, Block.box(a, b, 0, a + 2, b + 2, 16)); // beams along z
                    s = Shapes.or(s, Block.box(a, 0, b, a + 2, 16, b + 2)); // beams along y
                    s = Shapes.or(s, Block.box(0, a, b, 16, a + 2, b + 2)); // beams along x
                }
            }
            return s;
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return Shapes.empty();
        }

        @Override
        protected float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
            return 1.0F;
        }

        @Override
        protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
            return true;
        }
    }

    /** A small control desk: right-click opens the ride settings and controls of the nearest Drop Tower Base. */
    public static class ControllerBlock extends Block {
        public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
        private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 12, 15);

        public ControllerBlock(Properties properties) {
            super(properties);
            registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(FACING);
        }

        @Nullable
        @Override
        public BlockState getStateForPlacement(BlockPlaceContext context) {
            return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
        }

        @Override
        protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
            return SHAPE;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            BlockPos base = findBase(level, pos);
            if (level.isClientSide) {
                if (base == null) {
                    player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.coastercontrolpanel.droptower.no_base"), true);
                } else {
                    ClientHooks.openDropTower(base);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
            super.neighborChanged(state, level, pos, block, fromPos, moved);
            if (!level.isClientSide) {
                BlockPos base = findBase(level, pos);
                if (base != null && level.getBlockEntity(base) instanceof DropTowerBlockEntity be) {
                    be.refreshRedstone();
                }
            }
        }
    }
}
