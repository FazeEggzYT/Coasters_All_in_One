package com.example.coastercontrolpanel;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/** Everything a Swing Ride can be told: the sequence of steps and the general settings. All values are clamped here. */
public final class SwingSettings {
    public static final int SWING = 0;
    public static final int SPIN = 1;
    public static final int REST = 2;
    public static final int TYPES = 3;
    public static final int MAX_STEPS = 10;
    public static final int PRESETS = 4;

    /** SWING: a = amplitude in degrees, b = number of swings. SPIN: a = turns per minute (signed), b = seconds. REST: a = seconds. */
    public static final class Step {
        public int type;
        public float a;
        public float b;

        public Step(int type, float a, float b) {
            this.type = type;
            this.a = a;
            this.b = b;
            clamp();
        }

        public void clamp() {
            type = Math.max(0, Math.min(TYPES - 1, type));
            switch (type) {
                case SWING -> {
                    a = SwingSettings.clamp(a, 0.0F, 170.0F);
                    b = SwingSettings.clamp(b, 0.5F, 20.0F);
                }
                case SPIN -> {
                    a = SwingSettings.clamp(a, 0.0F, 30.0F);
                    b = SwingSettings.clamp(b, 1.0F, 300.0F);
                }
                default -> {
                    a = SwingSettings.clamp(a, 0.0F, 120.0F);
                    b = 0.0F;
                }
            }
        }

        public void retype(int newType) {
            type = newType;
            switch (type) {
                case SWING -> {
                    a = 60;
                    b = 2;
                }
                case SPIN -> {
                    a = 6;
                    b = 10;
                }
                default -> {
                    a = 3;
                    b = 0;
                }
            }
        }
    }

    public final List<Step> steps = new ArrayList<>();
    public int loops = 1;
    public float preDelay = 3.0F;
    /** Seconds for one full swing there and back; 0 = worked out from the length of the arm. */
    public float period = 0.0F;
    /** No swing target goes beyond this many degrees. */
    public float limit = 150.0F;
    /** Swings it takes to wind down when paused or ended. */
    public float windDown = 2.0F;
    /** Seconds an emergency stop takes. */
    public float haltTime = 1.5F;
    /** 0 = the gondola stays fixed to the arm, 1 = the gondola stays level. */
    public int gondolaMode = 0;
    public int redstoneMode = 0;
    public int endMode = 0;
    /** True: every block touching the riding part comes with it, whatever it is. False: only frames and seats. */
    public boolean carryAll = true;

    public SwingSettings() {
        preset(0);
    }

    static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) {
            return lo;
        }
        return Math.max(lo, Math.min(hi, v));
    }

    public void preset(int index) {
        steps.clear();
        limit = index >= 12 ? 65.0F : index >= 8 ? 120.0F : index >= 4 ? 90.0F : 150.0F;
        if (index >= 4 && index < 8) {
            gondolaMode = 0;
        }
        switch (index) {
            case 1 -> { // gentle
                steps.add(new Step(SWING, 30, 3));
                steps.add(new Step(SWING, 45, 3));
                steps.add(new Step(SWING, 30, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            case 2 -> { // spinner
                steps.add(new Step(SWING, 45, 2));
                steps.add(new Step(SPIN, 6, 12));
                steps.add(new Step(SWING, 90, 3));
                steps.add(new Step(SPIN, 0, 4));
                steps.add(new Step(SWING, 0, 3));
            }
            case 3 -> { // giant
                steps.add(new Step(SWING, 45, 2));
                steps.add(new Step(SWING, 90, 2));
                steps.add(new Step(SWING, 135, 3));
                steps.add(new Step(SWING, 135, 3));
                steps.add(new Step(SWING, 70, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            case 4 -> { // pirate: calm sea
                steps.add(new Step(SWING, 20, 2));
                steps.add(new Step(SWING, 35, 2));
                steps.add(new Step(SWING, 45, 3));
                steps.add(new Step(SWING, 0, 2));
            }
            case 5 -> { // pirate: rough sea
                steps.add(new Step(SWING, 30, 2));
                steps.add(new Step(SWING, 50, 2));
                steps.add(new Step(SWING, 70, 3));
                steps.add(new Step(SWING, 40, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            case 6 -> { // pirate: storm
                steps.add(new Step(SWING, 40, 2));
                steps.add(new Step(SWING, 70, 3));
                steps.add(new Step(SWING, 85, 4));
                steps.add(new Step(SWING, 85, 3));
                steps.add(new Step(SWING, 50, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            case 7 -> { // pirate: cradle
                steps.add(new Step(SWING, 15, 4));
                steps.add(new Step(SWING, 25, 4));
                steps.add(new Step(SWING, 0, 3));
            }
            case 8 -> { // gyro: warm up
                steps.add(new Step(SWING, 30, 2));
                steps.add(new Step(SPIN, 3, 10));
                steps.add(new Step(SWING, 0, 2));
            }
            case 9 -> { // gyro: frisbee
                steps.add(new Step(SWING, 40, 2));
                steps.add(new Step(SPIN, 6, 12));
                steps.add(new Step(SWING, 70, 3));
                steps.add(new Step(SPIN, 8, 12));
                steps.add(new Step(SWING, 0, 3));
            }
            case 10 -> { // gyro: full spin
                steps.add(new Step(SWING, 60, 2));
                steps.add(new Step(SPIN, 10, 15));
                steps.add(new Step(SWING, 120, 3));
                steps.add(new Step(SPIN, 12, 15));
                steps.add(new Step(SWING, 50, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            case 11 -> { // gyro: spin only
                steps.add(new Step(SWING, 20, 2));
                steps.add(new Step(SPIN, 6, 15));
                steps.add(new Step(SPIN, 12, 15));
                steps.add(new Step(SWING, 0, 2));
            }
            case 12 -> { // time machine: the original cycle
                steps.add(new Step(SWING, 20, 2));
                steps.add(new Step(SPIN, 3, 8));
                steps.add(new Step(SWING, 40, 2));
                steps.add(new Step(SPIN, 6, 12));
                steps.add(new Step(SWING, 60, 2));
                steps.add(new Step(SPIN, 9, 10));
                steps.add(new Step(SWING, 0, 2));
            }
            case 13 -> { // time machine: the reopening cycle, a little shorter
                steps.add(new Step(SWING, 25, 2));
                steps.add(new Step(SPIN, 4, 10));
                steps.add(new Step(SWING, 45, 2));
                steps.add(new Step(SPIN, 6, 10));
                steps.add(new Step(SWING, 0, 2));
            }
            case 14 -> { // time machine: gentle
                steps.add(new Step(SWING, 20, 3));
                steps.add(new Step(SPIN, 2, 15));
                steps.add(new Step(SWING, 0, 2));
            }
            case 15 -> { // time machine: wild
                steps.add(new Step(SWING, 40, 2));
                steps.add(new Step(SPIN, 8, 10));
                steps.add(new Step(SWING, 65, 3));
                steps.add(new Step(SPIN, 12, 12));
                steps.add(new Step(SWING, 65, 2));
                steps.add(new Step(SWING, 0, 2));
            }
            default -> { // Rush: builds up one swing at a time to about 104 degrees, hangs there, then winds down
                steps.add(new Step(SWING, 35, 1));
                steps.add(new Step(SWING, 60, 1));
                steps.add(new Step(SWING, 85, 1));
                steps.add(new Step(SWING, 104, 2));
                steps.add(new Step(SWING, 104, 2));
                steps.add(new Step(SWING, 70, 1));
                steps.add(new Step(SWING, 35, 1));
                steps.add(new Step(SWING, 0, 1));
            }
        }
    }

    public void sanitize() {
        loops = Math.max(1, Math.min(20, loops));
        preDelay = clamp(preDelay, 0.0F, 30.0F);
        period = period == 0.0F ? 0.0F : clamp(period, 2.0F, 15.0F);
        limit = clamp(limit, 20.0F, 170.0F);
        windDown = clamp(windDown, 1.0F, 8.0F);
        haltTime = clamp(haltTime, 0.5F, 6.0F);
        gondolaMode = Math.max(0, Math.min(1, gondolaMode));
        redstoneMode = Math.max(0, Math.min(1, redstoneMode));
        endMode = Math.max(0, Math.min(1, endMode));
        while (steps.size() > MAX_STEPS) {
            steps.remove(steps.size() - 1);
        }
        for (Step s : steps) {
            s.clamp();
        }
    }

    public CompoundTag toTag() {
        sanitize();
        CompoundTag t = new CompoundTag();
        t.putInt("Loops", loops);
        t.putFloat("PreDelay", preDelay);
        t.putFloat("Period", period);
        t.putFloat("Limit", limit);
        t.putFloat("WindDown", windDown);
        t.putFloat("HaltTime", haltTime);
        t.putInt("Gondola", gondolaMode);
        t.putInt("Redstone", redstoneMode);
        t.putInt("EndMode", endMode);
        t.putBoolean("CarryAll", carryAll);
        ListTag list = new ListTag();
        for (Step s : steps) {
            CompoundTag c = new CompoundTag();
            c.putInt("T", s.type);
            c.putFloat("A", s.a);
            c.putFloat("B", s.b);
            list.add(c);
        }
        t.put("Steps", list);
        return t;
    }

    public static SwingSettings fromTag(CompoundTag t) {
        SwingSettings s = new SwingSettings();
        if (t == null || t.isEmpty()) {
            return s;
        }
        s.loops = t.contains("Loops") ? t.getInt("Loops") : 1;
        s.preDelay = t.contains("PreDelay") ? t.getFloat("PreDelay") : 3.0F;
        s.period = t.getFloat("Period");
        s.limit = t.contains("Limit") ? t.getFloat("Limit") : 150.0F;
        s.windDown = t.contains("WindDown") ? t.getFloat("WindDown") : 2.0F;
        s.haltTime = t.contains("HaltTime") ? t.getFloat("HaltTime") : 1.5F;
        s.gondolaMode = t.getInt("Gondola");
        s.redstoneMode = t.getInt("Redstone");
        s.endMode = t.getInt("EndMode");
        s.carryAll = !t.contains("CarryAll") || t.getBoolean("CarryAll");
        if (t.contains("Steps", Tag.TAG_LIST)) {
            s.steps.clear();
            ListTag list = t.getList("Steps", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size() && i < MAX_STEPS; i++) {
                CompoundTag c = list.getCompound(i);
                s.steps.add(new Step(c.getInt("T"), c.getFloat("A"), c.getFloat("B")));
            }
        }
        s.sanitize();
        return s;
    }

    public SwingSettings copy() {
        return fromTag(toTag());
    }
}
