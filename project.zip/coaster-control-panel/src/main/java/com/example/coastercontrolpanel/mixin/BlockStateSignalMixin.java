package com.example.coastercontrolpanel.mixin;

import com.example.coastercontrolpanel.BrakeController;
import com.example.coastercontrolpanel.TriggerSignal;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Redstone Trigger: lets the anchor block of a Redstone Trigger give a redstone signal. Only anchor blocks of
 * Coasters Simulated are touched, and only once a Brake-type run exists (BrakeController.armed). Optional.
 */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateSignalMixin {
    @Inject(method = "isSignalSource", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccp$source(CallbackInfoReturnable<Boolean> cir) {
        if (BrakeController.armed && TriggerSignal.isAnchorBlock(((BlockState) (Object) this).getBlock())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getSignal", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccp$signal(BlockGetter level, BlockPos pos, Direction dir, CallbackInfoReturnable<Integer> cir) {
        if (BrakeController.armed && TriggerSignal.isAnchorBlock(((BlockState) (Object) this).getBlock())) {
            int p = TriggerSignal.power(level, pos);
            if (p > 0) {
                cir.setReturnValue(p);
            }
        }
    }

    @Inject(method = "getDirectSignal", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccp$direct(BlockGetter level, BlockPos pos, Direction dir, CallbackInfoReturnable<Integer> cir) {
        if (BrakeController.armed && TriggerSignal.isAnchorBlock(((BlockState) (Object) this).getBlock())) {
            int p = TriggerSignal.power(level, pos);
            if (p > 0) {
                cir.setReturnValue(p);
            }
        }
    }
}
