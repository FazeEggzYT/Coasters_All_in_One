package com.example.coastercontrolpanel.animatronics;

/** Joint angles for one moment of an animation. All zero is the rest pose. */
public final class Pose {
    public static final int ROOT_Y = 0;      // pixels
    public static final int ROOT_YAW = 1;
    public static final int TORSO_PITCH = 2;
    public static final int TORSO_ROLL = 3;
    public static final int TORSO_YAW = 4;
    public static final int HEAD_PITCH = 5;
    public static final int HEAD_YAW = 6;
    public static final int HEAD_ROLL = 7;
    public static final int AL_PITCH = 8;
    public static final int AL_ROLL = 9;
    public static final int AL_ELBOW = 10;
    public static final int AR_PITCH = 11;
    public static final int AR_ROLL = 12;
    public static final int AR_ELBOW = 13;
    public static final int LL_HIP = 14;
    public static final int LL_KNEE = 15;
    public static final int LR_HIP = 16;
    public static final int LR_KNEE = 17;
    public static final int COUNT = 18;

    private Pose() {
    }

    public static float[] rest() {
        return new float[COUNT];
    }

    /** a blended towards b by f (0 = a, 1 = b). */
    public static float[] mix(float[] a, float[] b, float f) {
        float[] r = new float[COUNT];
        for (int i = 0; i < COUNT; i++) {
            r[i] = a[i] + (b[i] - a[i]) * f;
        }
        return r;
    }
}
